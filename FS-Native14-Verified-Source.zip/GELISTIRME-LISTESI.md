# FS Mesajlaşma 34.32 — Native12 sonrası geliştirme listesi
Taban: FS-source-34.32-native12-tests5.zip ve FS-Mesajlasma-34.32-Native12-Dogrulanmis-Tam-Kaynak-Yedegi.zip. Mevcut imzalı Native12 ve CI.13 canlı sistemi değiştirilmedi. Her “Devam et” komutunda bir sonraki madde ele alınır. Bir madde ancak kaynak kodu ve ilgili testleri başarılı olduğunda kaynakta tamamlandı olarak işaretlenir; fiziksel cihaz ve üretim yayını ayrıdır.

- [x] 1. Gerçek zamanlı Yazıyor… göstergesi — kaynak ve yerel doğrulamalar tamamlandı, canlı dağıtım bekliyor.
- [x] 2. Çağrı zil sesi seçimi ve alternatif zil sesleri — kaynak ve yerel regresyon tamamlandı, Android derleme/cihaz ve canlı dağıtım bekliyor.
- [x] 3. Çağrı sesini sessize alma — kaynak ve yerel regresyon tamamlandı; Android derleme/cihaz ve canlı dağıtım bekliyor.
- [x] 4. Fotoğraf albümünü toplu indirme — kaynak ve yerel regresyon tamamlandı; Android derleme/cihaz ve canlı dağıtım bekliyor.
- [x] 5. Dörtten fazla fotoğraf içeren albümlerin tamamını görüntüleme — kaynak ve yerel regresyon tamamlandı; Android cihaz ve canlı dağıtım bekliyor.
- [x] 6. Profil resmi altına resim değiştirme ikonu — kaynak ve yerel regresyon tamamlandı; Android cihaz ve canlı dağıtım bekliyor.
- [x] 7. Hazır 16 adet kadın ve erkek profil avatarı — kaynak ve yerel regresyon tamamlandı; Android cihaz ve canlı dağıtım bekliyor.
- [x] 8. Profil resmine dokununca orta boy, tekrar dokununca tam ekran görüntüleme — kaynak ve yerel regresyon tamamlandı; Android cihaz ve canlı dağıtım bekliyor.
- [x] 9. Profil resminde yakınlaştırma, uzaklaştırma ve sürükleme — kaynak ve yerel regresyon tamamlandı; Android cihaz ve canlı dağıtım bekliyor.
- [x] 10. Unicode emoji animasyon kapsamının genişletilmesi — 3.757 yerel eşleşme, kaynak ve yerel regresyon tamamlandı; Android cihaz ve canlı dağıtım bekliyor.
- [x] 11. Telegram seviyesine yakın, emojilere özel efektler — 44 efekt ailesi / 21 hareket profili; kaynak ve yerel regresyon tamamlandı, Android cihaz ve canlı dağıtım bekliyor.
- [x] 12. Arka plan çağrılarının Android sınırları içerisinde iyileştirilmesi — kaynak ve yerel doğrulamalar tamamlandı; Android SDK/cihaz ve canlı dağıtım bekliyor (zorla durdurma aşılamaz).
- [x] 13. Güvenli, kullanıcı kontrollü şifreleme anahtarı kurtarma — kaynak ve yerel API/DOM/JS doğrulamaları tamamlandı; gerçek tarayıcı anahtar deposu ek testi, Android cihaz ve canlı dağıtım bekliyor. Yedeksiz eski özel anahtar geri getirilemez.
- [x] 14. Mesaj düzenleme geçmişi ve teslim bilgileri — kaynak ve yerel testleri tamamlandı; Android cihaz ve canlı dağıtım bekliyor.
- [x] 15. İnternet hızına göre otomatik görüşme kalitesi.
- [x] 16. Gelişmiş dosya gönderim ve indirme kuyruğu.
- [x] 17. Bellek, pil, hız ve genel performans optimizasyonu.
- [ ] 18. Genel regresyon testleri, canlı entegrasyon ve kalıcı imzalı APK.

## Madde 1
- Client web/typing-status.js, web/app.js, web/style.css ve server/app.py güncellendi. typing-v1 için capability negotiation; yalnızca oda, gönderen ve aktivite bayrağı. Yazılan metin sunucuya gönderilmez, veritabanında yazıyor kaydı yoktur. Grup üyeleri dışında aktarılmaz; engel durumunda aktarılmaz. İstemci 3 saniye hareketsizlikte durur, alıcı 5.5 saniyede süreyi doldurur, görünürlük/odadan çıkış/kilit/bağlantı kopması göstergeleri temizler. Sunucuda aktifleştirmeye hız sınırı uygulanır.
- 148 JavaScript, 52 API, 6 veritabanı, 5 TURN, 35 DOM entegrasyon, 49 Chromium bileşen kontrolü başarılı (295). Güncel kanıtlar docs/madde01-ek-dogrulama/; ilk tur kanıtları docs/development-evidence/. DOM testi emüle edilmiş arayüzle gerçek lokal HTTP/WebSocket kullanır; fiziksel Android testi değildir.
- Arşiv tam uygulama kaynaklarını içerir ancak büyük emoji varlıkları önceki tam yedekte bulunur; tools/fetch_assets.py ile doğrulanmış emoji paketi geri yüklenebilir. Yeni APK veya yeni canlı dağıtım bu maddeye dahil değildir. Sonraki işlem: madde 2, çağrı zil sesi seçimi.

- Ek düzeltme: eski WebSocket kapanması yeni bağlantının yazıyor göstergesini söndürmez; özellik desteği kaybolunca gösterge temizlenir. İki yeni regresyon testi başarılı.

## Madde 2
- Telefonun varsayılanı + 5 özgün zil, ayrı Android bildirim kanalları, kalıcı cihaz ayarı ve Dinle/Kaydet ekranı. Zil varlıkları paket içindedir.
- 159 JS + 63 sunucu/DB/TURN + 37 DOM + 49 Chromium = 308 başarılı otomatik kontrol. Ayrıntılar `docs/madde02-dogrulama/SONUC.md`. Android Java kodunun SDK derlemesi ve fiziksel cihaz testi henüz yapılmadı.
- Madde 1 korunmuştur; sıradaki işlem madde 3. Mevcut canlı sürüm değiştirilmedi.

## Madde 3
- Ayarlar → Çağrı sesi: cihazda kalıcı sessiz/açık ayarı. Zil seçimi, görüşme sesi ve aranabilirlik korunur; ayrı sessiz Android kanalı.
- 165 JS + 63 sunucu/DB/TURN + 39 DOM + 49 Chromium = 316 başarılı otomatik kontrol. Kanıtlar `docs/madde03-dogrulama/`. Android SDK ve cihaz doğrulaması henüz yapılmadı.
- Madde 1–2 korunmuştur. Sonraki işlem madde 4, fotoğraf albümünü toplu indirme.

## Madde 4
- Sohbet albümündeki tüm onaylanmış fotoğrafları tek klasör seçimiyle orijinal baytları korunarak kaydetme; benzersiz dosya adları, ilerleme, iptal, kısmi hata raporu. Android SAF köprüsü ve tarayıcıda tek ZIP (128 MiB sınırı).
- 174 JS + 63 sunucu/DB/TURN + 42 DOM + 49 Chromium = 328 başarılı otomatik kontrol. Kanıtlar `docs/madde04-dogrulama/`. Android SDK derlemesi ve fiziksel cihaz testi yapılmadı.
- Madde 1–3 korundu. Sonraki işlem madde 5: dörtten fazla fotoğraf içeren albümlerin tamamını görüntüleme.

## Madde 5
- Albümün dört önizleme kutusundan herhangi biri, toplam sayı dahil, seçili fotoğraftan açılır. Önceki/sonraki, yatay kaydırma, klavye okları ve numaralı fotoğraf seçimi ile albümdeki tüm yüklenmiş ve onaylanmış üyeler erişilebilir. Tekli ve toplu indirme korunur. Her fotoğrafta bulanıklık tercihi yeniden uygulanır. Hata halinde tekrar deneme vardır. Geciken indirmeler, kilit, silme ve ekran değişikliği eski görüntüyü açamaz; geçici URL kapatılır.
- 182 JS + 63 sunucu/DB/TURN + 44 DOM + 49 Chromium = 338 başarılı otomatik kontrol. Kanıtlar `docs/madde05-dogrulama/`. Yeni galeri etkileşimi DOM emülasyonu ve gerçek lokal şifreli dosya API'sinde test edildi; fiziksel Android dokunma ve görünüm doğrulaması henüz yapılmadı.
- Madde 1–4 korunmuştur. Sonraki işlem madde 6: profil resmi altına resim değiştirme ikonu.

## Madde 6
- Kendi profil fotoğrafının altında ayrı kamera ikonlu Resmi değiştir düğmesi, tekli fotoğraf seçici ve mevcut API kayıt akışı. Başka kişilerin profillerinde düzenleme ikonu bulunmaz.
- 192 JS + 63 sunucu/DB/TURN + 46 DOM + 52 Chromium = 353 başarılı otomatik kontrol. Kanıtlar `docs/madde06-dogrulama/`. Gerçek Chromium fotoğraf seçimi, dönüştürme ve temalar arası yerleşim test edildi; Android cihaz doğrulaması ve canlı yayın yapılmadı.
- Madde 1–5 korundu. Sonraki işlem madde 7: 16 hazır kadın ve erkek avatarı.

## Madde 7
- 8 kadın, 8 erkek özgün 512×512 JPEG avatar; tümü yerel varlık, kaydetmek için mevcut profil API kullanılır. Galeriden seçim korunur.
- 200 JS + 63 sunucu/DB/TURN + 48 DOM + 54 Chromium = 365 başarılı otomatik kontrol. Kanıtlar `docs/madde07-dogrulama/`. Fiziksel Android/SDK ve canlı yayın yapılmadı.
- Madde 1–6 korundu. Sonraki işlem madde 8: profil resmine dokununca orta boy, tekrar dokununca tam ekran görüntüleme.

## Madde 8
- Kendi ve karşı tarafın profil fotoğrafı iki kademeli açılır, fotoğraf değiştirme akışından ayrıdır. Oran korunur, kilit ve ekran değişiminde görüntü temizlenir.
- 205 JS + 63 sunucu/DB/TURN + 50 DOM + 57 Chromium = 375 başarılı otomatik kontrol. Kanıtlar `docs/madde08-dogrulama/`. Android SDK/cihaz ve canlı yayın yapılmadı.
- Madde 1–7 korundu. Sonraki işlem madde 9: profil resminde yakınlaştırma, uzaklaştırma ve sürükleme.

## Madde 9
- Profil fotoğrafı yerel Pointer Events ile 1–5 kat yakınlaştırılır; iki parmakla uzaklaştırma, yakınlaştırılmış fotoğrafı dört yöne sürükleme, +/- ve sıfırlama düğmeleri, klavye ve fare tekerleği desteği. Görselin gerçek boyutlarıyla sınırlanan pan, hareket sırasında tam ekran geçişini önler. Kapanış ve kilit durumunda hareket durumu temizlenir. Madde 8'in orta boy ve tam ekran modeli korunmuştur.
- 209 JS + 63 sunucu/DB/TURN + 51 DOM + 62 Chromium = 385 başarılı otomatik kontrol. Kanıtlar `docs/madde09-dogrulama/`. Gerçek Chromium çoklu dokunma (CDP) testi başarılı; Android SDK/cihaz ve canlı yayın yapılmadı.
- Madde 1–8 korunmuştur. Sonraki işlem madde 10: Unicode emoji animasyon kapsamının genişletilmesi.

## Madde 10
- Eski 881 animasyon korunarak 2.876 ek animasyon (toplam 3.757) üretildi. Yerel sekiz kareli WebP, tam Unicode dizisine göre eşleme, eski arama güvenlik doğrulaması sırası korunur. Yeni animasyonlar programatik iç geometri hareketidir; tüm Unicode sürümleri veya benzersiz elle tasarlanmış hareketler garanti edilmez.
- 214 JS + 63 sunucu/DB/TURN + 52 DOM + 66 Chromium = 395 başarılı kontrol. Kanıtlar `docs/madde10-dogrulama/`. Yeni varlıklar arşivde, eski 881 dosya tam Native12 yedeğinde. Android cihaz / SDK ve canlı yayın yapılmadı.
- Madde 1–9 korundu. Sonraki işlem madde 11: Telegram seviyesine yakın, emojilere özel efektler.

## Madde 11
- 3.757 katalog eşleşmesinde Unicode dizisiyle deterministik semantik efekt; 44 aile, 21 hareket profili, 8 CSS rotası, özgün glif ve yerel WebP oynatma. Telegram ile birebir eşdeğerlik iddiası yoktur. Şifreli eşzamanlı olay protokolü, hareket azaltma ve önceki 10 madde korunmuştur.
- 219 JS + 63 sunucu/DB/TURN + 52 DOM + 73 Chromium = 407 başarılı otomatik kontrol. Kanıtlar docs/madde11-dogrulama/. Android SDK/cihaz ve canlı dağıtım yapılmadı.
- Sonraki işlem: madde 12, Android sınırları içinde arka plan çağrılarının iyileştirilmesi.

## Madde 12
- Yetkili bekleyen çağrı anlık görüntüsü; tüketilen olayların geri alınması, çağrı kimliği, kabul/zaman aşımı ve eski bildirim temizliği. Ağ değişiminde yeniden bağlanma, Android bildirim izni akışı ve sınırlı tekrar deneme. PIN, zil ve sessiz ayarı korunur.
- 423 başarılı otomatik kontrol. Kanıtlar `docs/madde12-dogrulama/`. Android SDK/cihaz ve canlı dağıtım yapılmadı.
- Sonraki işlem: madde 13 — güvenli, kullanıcı kontrollü şifreleme anahtarı kurtarma.

## Madde 13
- Şifreli v2 yedek: AES-256-GCM, PBKDF2-SHA256 600.000 tur, rastgele 16 bayt tuz ve 12 bayt IV; şifreli içerik hesap kimliğini ve P-256 özel anahtarı taşır. Yeni kurtarma parolası 16–256 karakter; eski v1 kaynak yedeği açılırken kullanılan hesap parolasıyla aynı olmamalıdır. Önceki yerel v1 yedek ve içe aktarma uyumluluğu korunur.
- İçe aktarma yalnız geçici aday oluşturur; hesap doğrulaması ve geçerli açık anahtar eşleşmesi olmadan cihaz anahtarı veya oturum değişmez. Kurtarma girişi anahtar rotasyonunu istemez. Eşleşen başarılı girişte anahtar ve oturum tek IndexedDB işlemiyle kayıt edilir. Yedek sunucuya gönderilmez; girişte sadece normal hesap kimlik bilgileri, açık anahtar ve gerekirse yedeğin hesap kimliği gönderilir.
- 226 JS + 68 API/DB/TURN + 55 DOM + 73 Chromium bileşen + 11 bağımsız Java = 433 başarılı otomatik kontrol. Gerçek yerel HTTP/WebSocket ile doğru hesap, hatalı hesap, iptal, yanlış kurtarma parolası, yeni cihazda eski mesajın okunması ve profil üzerinden şifreli yedek dışa aktarma (modellenmiş Android kayıt köprüsü) doğrulandı. Ek Chromium WebCrypto/IndexedDB testi sayfa navigasyonunun ortam tarafından ERR_BLOCKED_BY_ADMINISTRATOR ile engellenmesi nedeniyle çalışmadı; başarı sayısına dahil edilmedi. Kanıtlar `docs/madde13-dogrulama/`. Android SDK/cihaz ve canlı dağıtım yapılmadı.
- 1–12 maddelerin kaynakları korunmuştur. Büyük eski 881 WebP dosyası tam Native12 yedeğinin `web/emoji/` dizininden geri yüklenmelidir; 2.876 yeni WebP bu pakettedir. Derlemede güncel `web/` kullanılır; `web-patch/` tarihsel yama dosyalarıdır, güncel APK üretiminde kullanılmamalıdır.
- Sonraki işlem: madde 14 — mesaj düzenleme geçmişi ve teslim bilgileri.

## Madde 14
- Metin düzenlemeleri için önceki şifreli zarflar ve gönderici açık anahtarı atomik işlemle saklanır; 20 eski sürüm sınırı, eşzamanlı düzenleme çakışması kontrolü. Eski istemci ve canlı konum PATCH işlemleri geçmiş oluşturmaz. Geçmiş API yalnızca sohbet katılımcısının kendi zarfını döndürür; açılan geçmiş cihazda çözülür, herkesten silmede veritabanı kayıtları ve açık panel temizlenir.
- Sunucu kabulü, alıcı uygulamasının şifreyi çözerek teslimi onaylaması ve mesajın görünür ekranda bulunması ayrı gösterilir. Gerçek kişi okuması veya medya indirme garantisi değildir. İlk teslim/okuma saati korunur. Eski kayıtların kesin saati uydurulmaz. Grup durum özetleri ve katılımcı bazlı ayrıntılar mevcuttur. Teslim bildirimleri yalnız yeni istemci tarafından açık sohbet içinde onaylanır.
- 230 JS + 71 API/DB/TURN + 57 DOM + 73 Chromium bileşen + 11 bağımsız Java = 442 başarılı otomatik kontrol. Kanıtlar `docs/madde14-dogrulama/`. DOM testleri gerçek yerel API/WebSocket ve emüle edilen arayüz kullanır. MariaDB canlı motoru, fiziksel Android/SDK ve üretim dağıtımı henüz test edilmedi. Madde 13'te engellenen ilave tarayıcı anahtar deposu testi tekrar edilmedi.
- Önceki kaynaklar korunmuştur. 881 eski WebP dosyaları tam Native12 yedeğinden geri yüklenmelidir; 2.876 yeni WebP pakettedir.
- Sonraki işlem: madde 15 — internet hızına göre otomatik görüşme kalitesi.

## Madde 15
- Kullanıcının tercihi: görüntü kalitesi daima öncelikli. Normal görüntülü çağrı ve sesli çağrıdan görüntülüye geçiş, ideal 3840×2160 ve 30 FPS ile kamerayı ister; kesin alt/üst sınır konmaz. Donanımın desteklediği gerçek çözünürlük ve kare hızı WebRTC tarafından belirlenir. `contentHint=detail`, normalde `maintain-resolution`; ciddi bant genişliği düşüşü veya video paket kaybı art arda iki ölçümde görülürse `balanced`, üç sağlıklı ölçümden sonra tekrar `maintain-resolution`. Özel sabit bit hızı veya çözünürlük tavanı yoktur; native WebRTC congestion controller korunur. Seçili ICE çiftinin ölçümleri, aralık bazlı kayıp, eşzamanlı stats koruması ve biten görüşmenin stale işlemlerini engelleme. Karşıdan alınan son raporlanmış video çözünürlüğü çağrı etiketinde görünür; 4K veya gerçek zamanlı maksimum kalite garanti değildir. Ses işleme ve mevcut çağrı akışları korunur.
- 239 JS + 71 API/DB/TURN + 57 DOM + 74 Chromium + 11 bağımsız Java = 452 başarılı kontrol. Kanıtlar `docs/madde15-dogrulama/`. Yeni 9 JS testi ve gerçek Chromium RTCRtpSender üzerinde sentetik video ile 1 yeni kontrol; bu test canlı iki telefon, gerçek internet veya kamera 4K performans testi değildir. Android SDK/cihaz, üretim dağıtımı ve madde 13'te engellenen ek tarayıcı anahtar deposu kontrolü yapılmadı.
- Önceki kaynaklar korundu. Eski 881 WebP tam Native12 yedeğinden geri yüklenmelidir; 2.876 ek WebP bu pakettedir. `web/` güncel kaynak, `web-patch/` tarihsel yamadır.
- Sonraki işlem: madde 16 — gelişmiş dosya gönderim ve indirme kuyruğu.

## Madde 16 — Dosya aktarım kuyruğu + harici bağlantı düzeltmesi
- Şifreli gönderim kuyruğunda dosya başına sırada/gönderiliyor/yeniden dene durumu. Sunucu HEAD ile doğruladığı bayt konumundan devam eder. Geçici ağ hatası ve uygun HTTP hatalarında en fazla 3 tekrar, artan 500/1000/2000 ms gecikme. Onayı kaybolmuş PUT tekrar gönderilmeden önce sunucu konumu doğrulanır. 50 MB/dosya ve 20 seçili dosya sınırları, mevcut kalıcı tek bekleyen şifreli yükleme ve sabit mesaj kimliği korunur. Henüz başlamamış dosyaların listesi bellek içindedir; arka planda uygulama kapalıyken tüm kuyruğun devam etmesi iddia edilmez. Bekleyen yükleme Veri ve Depolama menüsünden devam ettirilebilir veya iptal edilebilir.
- İndirmeler FIFO, en fazla 2 eşzamanlı ağ isteği; aynı mesajın devam eden indirmesi ortak kullanılır. Kilit durumunda sıradaki işler iptal edilir, etkin ağ istekleri durdurulur, şifreli dosya boyutu doğrulanır. Yerel kayıt köprüsü oturum değişiminde işlem iptal eder. Mevcut albüm ve tek dosya işlevleri korunur.
- Bağlantı sorunu: eski WebView genel harici navigasyonu engelliyor, window.open yeni pencereyi açmıyordu. Geçerli HTTP(S) URL'ler Android ACTION_VIEW/CATEGORY_BROWSABLE ile dış uygulamaya aktarılır; güvenilir WebView'e harici sayfa yüklenmez. JS ve Java URL şeması, ana makine, kimlik bilgisi ve kontrol karakterlerini doğrular. Yol, sorgu ve fragment korunur. Harita da aynı köprüyü kullanır. Tarayıcı sürümünün güvenli popup davranışı korunur. Gerçek Android intent/uygulama işlemi fiziksel cihazda henüz doğrulanmadı.
- 249 JS + 71 API/DB/TURN + 59 DOM + 74 Chromium + 20 bağımsız Java = 473 başarılı otomatik kontrol. Yeni testler: 10 JS, 2 gerçek yerel API/DOM (model Android köprüsü ve commit edilmiş PUT yanıt kaybı), 9 Java URL doğrulama. Önceki madde 13 ek kısıtlı tarayıcı depo testi yeniden denenmedi. Kanıtlar `docs/madde16-dogrulama/`. Android SDK/cihaz ve canlı yayın yapılmadı.
- Önceki 15 madde kaynakları korunmuştur. Eski 881 WebP tam Native12 yedeğinin `web/emoji/` dizininden nihai derlemede geri yüklenmelidir; 2.876 yeni WebP pakettedir. `web/` güncel kaynak; `web-patch/` tarihsel yamadır. Bağımlılıklar ve özel imza anahtarları bu arşivde bulunmaz.
- Sonraki işlem: madde 17 — bellek, pil, hız ve genel performans optimizasyonu. Madde 18: bütün varlıkların birleştirilmesi, güvenlik/regresyon testi, canlı güncelleme ve imzalı APK. Native12 yedeği korunur.

## Madde 17 — Performans ve bellek optimizasyonu
- Sanal sohbet listesinde satır yükseklikleri ve kimlik/indeks eşlemesi yeniden kullanılır. Aynı görünür pencere içinde kaydırırken yeniden HTML oluşturulmaz; görünürlük/okundu bilgisi güncellenmeye devam eder. Yeni içerik ve ölçü değişimlerinde çizim/anchor korunur. Kapatılan liste gözlemci, RAF ve satır referanslarını bırakır.
- Küçük resim ve seslerde aynı bekleyen şifre çözme işi ortak kullanılır. LRU sınırları: küçük resim 40 kayıt/16 MiB, ses 32 kayıt/64 MiB (Blob önbelleği). Kilit/oturum değişimi ve mesaj silme geç kalan sonuçları geçersiz kılar. URL ve gözlemci temizliği yapılır. Bu sınırlar toplam uygulama RAM sınırı değildir.
- Doğrulanmış şifreli dosya uzunluğuna tek hedef tampon ayrılır; önce her parçayı saklayıp sonra ikinci tam tampon oluşturma kaldırılır. 50 MB sınırı, AES-GCM doğrulaması, zaman aşımı ve iptal korunur. Mesaj ve çağrı geçmişinin bağımsız HTTP istekleri paralel başlatılır.
- 257 JS + 71 API/DB/TURN + 59 DOM + 76 Chromium + 20 bağımsız Java = 483 başarılı otomatik kontrol. 8 yeni JS testi ve iki yeni gerçek Chromium kontrolü; 10.000 satır/1.000 aynı pencere çizim isteğinde DOM düğümleri korunur. Kanıtlar docs/madde17-dogrulama/. Gerçek Android RAM, FPS, açılış süresi ve pil tüketimi ölçülmedi. Maksimum görüntü ayarı, link düzeltmesi, dosya kuyruğu, Android ve sunucu kaynakları önceki maddeyle birebir aynı.
- Yalnız iki mevcut üretim web dosyası değiştirildi, bir yardımcı modül ve iki test eklendi. 1–16 maddeler korunmuştur. Eski 881 WebP tam Native12 yedeğinden nihai derlemede geri yüklenmelidir; 2.876 yeni WebP burada mevcuttur. Güncel web/ kaynakları kullanılmalı, tarihsel web-patch/ kullanılmamalıdır.
- Sonraki işlem: madde 18 — bütün varlıkların birleştirilmesi, kapsamlı güvenlik/regresyon, sunucu uyumluluğu ve canlı dağıtım, Android derleme ve kalıcı imza. Fiziksel test ve canlı yayın henüz yapılmadı. Madde 13 ek tarayıcı anahtar deposu testi yeniden denenmedi.

## Madde 18 — Native13 nihai sürüm adayı
- Sürüm adı 34.32, Android versionCode 13 (önceki Native12 sürüm kodu 12). Eski 881 WebP dosyası orijinal Native12 yedeğinden bayt bayt geri eklendi. Her iki katalogdaki toplam 3.757 WebP mevcut; eski katalog sırası korunuyor. `web/` güncel kaynak, `web-patch/` yalnızca tarihsel referanstır; paketlemede kullanılmaz.
- CI.13 SQLite şemasıyla oluşturulan örnek hesap, mesaj, medya, oturum, kişi ve çağrı kayıtları üzerinde ardışık iki yeni sürüm açılışı ve silme zinciri test edildi. Mevcut kayıtlar ve örnek medya değişmedi. Yeni tablolar eklemeli olarak oluşturulur. Bu bir canlı veritabanı testi değildir.
- Yeni sağlık işareti: `34.32-native13-final`. 257 JS + 72 API/DB/TURN/geçiş + 59 DOM + 76 Chromium bileşen + 20 Java = 484 başarılı otomatik kontrol. Kanıtlar `docs/madde18-dogrulama/`. Ek gerçek tarayıcı anahtar deposu denemesi önceki ortamda engellendi; CI koşumunda ayrıca çalıştırılacaktır. Mevcut yerel Python 3.13.5, Node 22.16.0 ve OpenJDK 21; CI'de sabit bağımlılıklar yeniden kurulacaktır.
- Resmi SDK indirme adresi bu çalışma ortamında DNS hatası verdi; tam Android derlemesi ve imzası yapılmadı. GitHub bağlantısında release ZIP yükleme işlemi yok. Native13 kaynak dosyası release'e yüklendikten sonra CircleCI regresyon ve native build çalıştırılır. Canlı Railway CI.13 ve `/data` volume değiştirilmedi; canlı yayın, gerçek doğrulama ve kalıcı imza bekliyor. Madde 18 henüz kapatılmadı.

- Dosya teslim boyutu nedeniyle dağıtım ZIP'inde yeni 2.876 animasyon yer alır. Önceden yüklenmiş ve SHA-256 özeti eşleşen GitHub emoji paketiyle eski 881 dosya otomatik geri yüklenir; tamamı birleştirildikten sonra 3.757 animasyon doğrulanır.

## Native13 ek geliştirmeler (nihai değil)
# Native13 ek geliştirmeler — yayın adayı, nihai sürüm değil

- Emoji katalogları ve animasyon dosyaları değiştirilmedi. Eski 881 dosya `tools/fetch_assets.py` ile SHA-256 doğrulamasından sonra geri yüklenir; 2.876 ek dosya arşiv içindedir.
- Onaylanmış gönderimler cihazda şifreli, hesap/anahtar kapsamlı atomik IndexedDB kuyruğuna alınır. En fazla 20 dosya ve 200 MB; dosya başına 50 MB. Kuyruk PIN açıldığında bağlantıyla sürdürülür. Sabit gönderim/yükleme kimliği mükerrer gönderimi engeller. İndirme kuyruğunun uygulama kapanması sonrası sürdürülmesi henüz yoktur.
- Aktif oturumda tüm sohbetlerde şifresi gerçekten açılan mesajlar için, sohbeti açmadan, okundu saymadan teslim onayı. Kilitli/kapalı istemci adına sahte teslim onayı verilmez.
- Üç veya dört üyeli gruplarda destekleyen bağlı istemciler için sesli/görüntülü arama kaynak kodu eklendi. Sunucu sinyalleşmesi ve istemci bağlantı mantığı test edildi. Gerçek cihazlar arasında medya, TURN, yeniden bağlantı ve arka plan grup çağrısı doğrulanmadı; grup özelliği bu sınırlar dışında tamamlandı sayılmaz.
- Bağımsız push sağlayıcısı henüz kurulmadı. Mevcut foreground bağlantı servisi korunmuştur. Android zorla durdurma kısıtlaması aşılamaz.
- İleri gizlilik/Signal tarzı ratchet protokolü henüz uygulanmadı. Eski şifreleme ve yönetici erişimi modeli korunmuştur. Yeni protokolün güvenli anahtar göçü ve bağımsız denetimi gereklidir.
- Bu pakette canlı yayın, Android SDK derlemesi, fiziksel telefon testi, yeni imza anahtarı ve imzalı APK bulunmaz. Eski kalıcı imza anahtarı mevcut sürüm üstüne kurulum için korunmalıdır.
- Önceki `docs/madde18-dogrulama` raporları önceki Native13'e aittir; güncel sonuçlar bu klasördedir.

## Ek üç istek – sonraki aday
- Kalıcı indirme: PIN yeniden açılınca eksik şifreli parçalar tamamlanır; yerel testler başarılı.
- Bağımsız FCM: kaynak kodu ve model taşıyıcı testleri hazır; sağlayıcı bağlantısı ve Android doğrulaması eksik.
- İleri gizlilik protokolü: henüz uygulanmadı; mevcut yönetici erişimi korunuyor.
- 508 başarılı otomatik kontrol; güncel kanıt `docs/ek-uc-dogrulama/`. Yayın ve imza yapılmadı.
