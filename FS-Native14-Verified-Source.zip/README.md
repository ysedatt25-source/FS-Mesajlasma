# FS Mesajlaşma — yeni kaynak proje

Bu proje sıfırdan yazıldı. Eski APK'nın derlenmiş JavaScript kodu kullanılmadı.
Arayüz FS referansındaki mürdüm renkler, hesap makinesi, sohbet, arama, profil,
ayarlar, medya ve kayıtlı mesaj ekranları temel alınarak oluşturuldu.

Bu bir geliştirme teslimidir; üretim yayını yapılmadı. Tüm özelliklerin ve
görselin birebir eşleştiğinin doğrulandığı bir son sürüm olarak sunulmamalıdır.

## Çalıştırma

Python 3.12+ ve Node 22+ kullanın:

```sh
python -m pip install -r server/requirements.txt
npm ci
python server/app.py
```

Yerel geliştirme adresi: `http://127.0.0.1:8787/index.html`.
Android uygulamasına gerçek sunucu için HTTPS adresi gerekir. Sunucu ayarı
giriş ekranındaki ayar düğmesinden değiştirilebilir. İnternete açık sunucu
kurulmadan iki uzaktaki telefonda hesap/sohbet/arama çalışması beklenmemelidir.

## Otomatik testler

```sh
python -m unittest discover -s tests -p 'test_*.py' -v
node --test tests/crypto.test.mjs
node tests/dom.test.mjs
python tests/benchmark.py
```

DOM testi gerçek HTTP ve WebSocket sunucusuna karşı çalışır; tarayıcı çizimi,
Android klavyesi, kamera, mikrofon veya Bluetooth testi yerine geçmez.
`tests/ui.test.cjs` gerçek Chromium ortamı için ayrıca yazıldı; bu ortamda
Chromium'un ihtiyaç duyduğu yerel soket izni olmadığından çalıştırılamadı.

## Android

`docs/BUILD.md` derleme yolunu açıklar. Paket adı `com.fs.mesajlasma`, görünen
sürüm `34.32`, dahili sürüm kodu `1`.

Bu, eski `com.ozelmesaj.calculatorchat` paketinden ayrı bir kurulumdur.
Eski uygulamanın yerini almaz ve eski cihaz verilerini taşımaz. Eski APK'nın
sertifikası ile mevcut kalıcı imza arşivindeki sertifika farklı olduğundan
yerinde güncelleme yapıldığı iddia edilmez.

## Şifreleme ve yönetici

Mesajlar ECDH P-256 ile türetilen AES-GCM anahtarlarıyla, dosyalar rastgele
AES-GCM anahtarlarıyla cihazda şifrelenir. Sunucu hesap/üyelik/zaman/çağrı
metaverilerini işler. Bu uygulama bağımsız kriptografik denetimden geçmedi;
Signal protokolü veya ileri gizlilik uygulandığı iddia edilmez.

Yönetici rolü yalnızca sunucunun yerel yönetim komutuyla verilir. Yönetici
yapılandırıldığında yeni mesaj, yöneticinin açık anahtarı için de şifrelenir.
Yönetim paneli bu içeriği yönetici cihazında çözer. Bu nedenle sistem,
yöneticinin de okuyamadığı uçtan uca şifreleme olarak tanıtılmamalıdır.
Yönetici kurulmadan gönderilmiş eski mesajlar sonradan otomatik açılamaz.

Üretim şablonunda `FS_REQUIRE_ADMIN=1` zorunludur. Önce yönetici hesabını
uygulamadan oluşturun; sohbet oluşturmadan önce sunucuda:

```sh
python server/manage.py promote YONETICI_KULLANICI_ADI --data /data
```

Kullanıcılar kayıt sırasında kabul edilen gizlilik politikasını görür.
Önceden kabul edilen politika metni `web/privacy-policy.js` içine aynen
aktarılmıştır; eski ürün adı da bu nedenle metinde korunmuştur.

## Anahtar taşıma

Profilde şifreli kişisel anahtar dosyası indirilebilir. Bu dosya, ilk kayıt
sırasındaki hesap şifresiyle korunur. Yeni cihazda girişten önce bu dosya
içe aktarılır. Sunucu cihazın farklı anahtarla giriş yapmasını sessizce
kabul etmez. Sunucuda özel anahtar veya şifresiz anahtar yedeği tutulmaz.

## Durum

Gerçek test sonuçları `docs/TEST-RESULTS.md`; kalan yayın koşulları
`docs/RELEASE-STATUS.md` içindedir. `tools/release_gate.py`, fiziksel test
kanıtları olmadan yayın durumu için başarı döndürmez.
