package com.fs.mesajlasma;

import android.content.ContentResolver;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.util.Base64;
import java.io.OutputStream;
import java.util.UUID;

/** A single user-selected SAF directory, no persistent storage grant or broad permission. */
final class AlbumExport {
 private final ContentResolver resolver;
 private String session, picker, status;
 private Uri directory, photo;
 private OutputStream stream;
 private long expected, written;
 private int saved;
 AlbumExport(ContentResolver resolver){this.resolver=resolver;}
 synchronized String begin(){if(session!=null||picker!=null)return "";session=UUID.randomUUID().toString();picker=session;status="waiting";saved=0;return session;}
 synchronized String state(String id){return id!=null&&id.equals(session)?status:"closed";}
 synchronized String picker(){return picker;}
 synchronized void selected(String id,Uri tree){
  if(id==null||!id.equals(picker))return;picker=null;
  if(!id.equals(session))return;
  if(tree==null){status="cancelled";return;}
  try{Uri parent=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));directory=DocumentsContract.createDocument(resolver,parent,DocumentsContract.Document.MIME_TYPE_DIR,"FS-Album-"+id.substring(0,8));status=directory==null?"error":"ready";}catch(Exception e){status="error";}
 }
 synchronized boolean startPhoto(String id,String name,String mime,long size){
  if(!"ready".equals(state(id))||stream!=null||photo!=null||size<1||size>50L*1024*1024||name==null||name.length()>200||name.contains("/")||name.contains("\\")||name.indexOf('\0')>=0||!name.matches("[0-9]{3,}-.*")||mime==null||!mime.matches("image/[A-Za-z0-9.+_-]{1,100}"))return false;
  try{photo=DocumentsContract.createDocument(resolver,directory,mime,name);if(photo==null)return false;stream=resolver.openOutputStream(photo,"w");if(stream==null)throw new IllegalStateException();expected=size;written=0;return true;}catch(Exception e){abortPhoto(id);return false;}
 }
 synchronized boolean append(String id,String data){
  if(!"ready".equals(state(id))||stream==null||data==null||data.length()>65536)return false;
  try{byte[] chunk=Base64.decode(data,Base64.NO_WRAP);if(chunk.length<1||written+chunk.length>expected)return false;stream.write(chunk);written+=chunk.length;return true;}catch(Exception e){abortPhoto(id);return false;}
 }
 synchronized boolean finishPhoto(String id){
  if(!"ready".equals(state(id))||stream==null||written!=expected){abortPhoto(id);return false;}
  try{stream.flush();stream.close();stream=null;photo=null;saved++;return true;}catch(Exception e){abortPhoto(id);return false;}
 }
 synchronized void abortPhoto(String id){if(id==null||!id.equals(session))return;if(stream!=null){try{stream.close();}catch(Exception ignored){}stream=null;}if(photo!=null){try{DocumentsContract.deleteDocument(resolver,photo);}catch(Exception ignored){}photo=null;}}
 synchronized void end(String id){if(id==null||!id.equals(session))return;abortPhoto(id);if(saved==0&&directory!=null){try{DocumentsContract.deleteDocument(resolver,directory);}catch(Exception ignored){}}directory=null;session=null;status=null;}
 synchronized void close(){end(session);picker=null;}
}
