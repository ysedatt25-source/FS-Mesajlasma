package com.fs.mesajlasma;

/** Per-call route preference. Only available communication devices are selected. */
final class AudioRoutePolicy {
    static boolean valid(String route) {
        return "auto".equals(route)||"bluetooth".equals(route)||"speaker".equals(route)||"earpiece".equals(route)||"wired".equals(route);
    }
    static String target(String preference, boolean video, boolean bluetooth, boolean wired, boolean earpiece, boolean speaker) {
        if ("bluetooth".equals(preference)&&bluetooth) return "bluetooth";
        if ("wired".equals(preference)&&wired) return "wired";
        if ("speaker".equals(preference)&&speaker) return "speaker";
        if ("earpiece".equals(preference)&&earpiece) return "earpiece";
        if ("auto".equals(preference)) {
            if (bluetooth) return "bluetooth";
            if (wired) return "wired";
            if (video&&speaker) return "speaker";
        }
        // A removed private output falls back to the handset, not loudspeaker.
        if (earpiece) return "earpiece";
        if (wired) return "wired";
        if (speaker) return "speaker";
        return "unknown";
    }
}
