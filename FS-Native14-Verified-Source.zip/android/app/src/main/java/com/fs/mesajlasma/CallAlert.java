package com.fs.mesajlasma;
import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.Build;
import android.os.SystemClock;
/** Verified call snapshot; no caller identity, media or token on lock screen. */
final class CallAlert {
 private static final String PREFS="fs-incoming-alert-v2";
 static final String ID="call_id";
 private static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences(PREFS,0);}
 static synchronized boolean current(Context c,String id){
  return CallWindowPolicy.valid(id,prefs(c).getString(ID,""),prefs(c).getLong("until",0),SystemClock.elapsedRealtime(),prefs(c).getLong("wallUntil",0),System.currentTimeMillis());
 }
 static synchronized String currentId(Context c){String id=prefs(c).getString(ID,"");return current(c,id)?id:"";}
 static synchronized boolean video(Context c,String id){return current(c,id)&&prefs(c).getBoolean("video",false);}
 static boolean canFullScreen(NotificationManager m){return Build.VERSION.SDK_INT<34||m.canUseFullScreenIntent();}
 private static Intent intent(Context c,Class<?> cls,String id){return new Intent(c,cls).setData(Uri.parse("fs-call://incoming/"+id)).putExtra(ID,id);}
 static synchronized boolean post(Context c,String id,long time){return post(c,id,time,false);}
 static synchronized boolean post(Context c,String id,long time,boolean video){
  return post(c,id,time,video,true);
 }
 static synchronized boolean post(Context c,String id,long time,boolean video,boolean fullScreen){
  return post(c,id,time,video,fullScreen,false);
 }
 static synchronized boolean post(Context c,String id,long time,boolean video,boolean fullScreen,boolean silent){
  // Missing, unreadable or disabled availability must never permit a call alert.
  try{if(!"true".equals(SecretStore.get(c,"available")))return false;}
  catch(Exception unavailable){return false;}
  long remaining=IncomingCallNotice.duration(time);
  if(!CallWindowPolicy.validId(id)||remaining==0)return false;
  NotificationManager manager=c.getSystemService(NotificationManager.class);
  if(!manager.areNotificationsEnabled())return false;
  String channel=CallRingtones.currentChannel(c);if(silent)channel=CallRingtones.ensureSilentChannel(c);NotificationChannel selected=manager.getNotificationChannel(channel);
  if(selected==null||selected.getImportance()==NotificationManager.IMPORTANCE_NONE)return false;
  if(current(c,id))return true; // poll + push must not re-ring the same invitation
  if(!prefs(c).edit().putString(ID,id).putLong("until",SystemClock.elapsedRealtime()+remaining).putLong("wallUntil",System.currentTimeMillis()+remaining).putBoolean("video",video).putBoolean("dismissed",false).commit())return false;
  Intent screen=intent(c,IncomingCallActivity.class,id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
  PendingIntent open=PendingIntent.getActivity(c,0,screen,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  Intent answerIntent=new Intent(screen).setData(Uri.parse("fs-call://answer/"+id)).putExtra("answer_requested",true);
  PendingIntent answer=PendingIntent.getActivity(c,0,answerIntent,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  PendingIntent decline=PendingIntent.getBroadcast(c,0,intent(c,CallDeclineReceiver.class,id),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  String title=video?"Gelen görüntülü arama":"Gelen sesli arama";
  Notification.Builder builder=new Notification.Builder(c,channel).setSmallIcon(R.drawable.ic_launcher).setContentTitle(title).setContentText("Yanıtlamak için dokun").setCategory(Notification.CATEGORY_CALL).setVisibility(Notification.VISIBILITY_PUBLIC).setContentIntent(open).setAutoCancel(false).setOnlyAlertOnce(true).setTimeoutAfter(remaining);
  if(Build.VERSION.SDK_INT>=31){builder.setStyle(Notification.CallStyle.forIncomingCall(new Person.Builder().setName(title).setImportant(true).build(),decline,answer));}
  else{builder.addAction(new Notification.Action.Builder(null,"Reddet",decline).build()).addAction(new Notification.Action.Builder(null,"Yanıtla",answer).build());}
  if(fullScreen&&selected.getImportance()>=NotificationManager.IMPORTANCE_HIGH&&canFullScreen(manager))builder.setFullScreenIntent(open,true);
  try{Notification notification=builder.build();if(!silent&&!CallRingtones.muted(c))notification.flags|=Notification.FLAG_INSISTENT;manager.notify(11,notification);
   String status="displayed";
   try{android.media.AudioManager audio=c.getSystemService(android.media.AudioManager.class);
    if(silent||CallRingtones.muted(c)||selected.getSound()==null||audio.getRingerMode()!=android.media.AudioManager.RINGER_MODE_NORMAL||audio.getStreamVolume(android.media.AudioManager.STREAM_RING)==0)status="silent";
    else if(selected.getImportance()>=NotificationManager.IMPORTANCE_DEFAULT&&manager.getCurrentInterruptionFilter()==NotificationManager.INTERRUPTION_FILTER_ALL)status="alerted";
   }catch(RuntimeException ignored){}
   CallAlertReceipt.send(c,id,status);return true;}catch(RuntimeException e){clear(c);return false;}
 }
 // Acknowledge presentation without deleting the deduplication record.
 static synchronized void dismiss(Context c){prefs(c).edit().putBoolean("dismissed",true).apply();c.getSystemService(NotificationManager.class).cancel(11);}
 static synchronized boolean visible(Context c,String id){return current(c,id)&&!prefs(c).getBoolean("dismissed",false);}
 static synchronized void dismissIfMatches(Context c,String id){if(current(c,id))dismiss(c);}
 static synchronized void clear(Context c){prefs(c).edit().clear().apply();c.getSystemService(NotificationManager.class).cancel(11);}
 private CallAlert(){}
}
