package com.fs.mesajlasma;
import android.content.Context;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
/** Receipt reports notification presentation, never microphone or physical sound. */
final class CallAlertReceipt {
 private static final ExecutorService worker=Executors.newSingleThreadExecutor();
 static void send(Context context,String id,String status){
  Context c=context.getApplicationContext();
  final String token,endpoint;
  try{token=SecretStore.get(c,"token");endpoint=SecretStore.get(c,"endpoint");}catch(Exception ex){return;}
  if(token==null||endpoint==null)return;
  worker.execute(()->{
   for(int attempt=0;attempt<2;attempt++){
    HttpURLConnection http=null;
    try{
     synchronized(SecretStore.class){if(!CallAlert.visible(c,id)||!token.equals(SecretStore.get(c,"token"))||!endpoint.equals(SecretStore.get(c,"endpoint")))return;}
     URL base=new URL(endpoint);if(!"https".equals(base.getProtocol())||base.getHost().isEmpty()||base.getUserInfo()!=null||base.getQuery()!=null||base.getRef()!=null)return;
     http=(HttpURLConnection)new URL(endpoint.replaceAll("/+$","")+"/api/calls/alert-ack").openConnection();
     http.setInstanceFollowRedirects(false);http.setConnectTimeout(2500);http.setReadTimeout(3500);http.setRequestMethod("POST");http.setRequestProperty("Authorization","Bearer "+token);http.setRequestProperty("Content-Type","application/json");
     byte[] bytes=new JSONObject().put("callId",id).put("status",status).toString().getBytes(StandardCharsets.UTF_8);http.setDoOutput(true);http.setFixedLengthStreamingMode(bytes.length);
     try(OutputStream out=http.getOutputStream()){out.write(bytes);}int code=http.getResponseCode();if(code<500)return;
    }catch(Exception ignored){}finally{if(http!=null)http.disconnect();}
   }
  });
 }
 private CallAlertReceipt(){}
}
