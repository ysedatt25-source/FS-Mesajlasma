package com.fs.mesajlasma;
import android.content.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
/** Explicit user rejection only. Session and call identity are verified by the server. */
public final class CallDeclineReceiver extends BroadcastReceiver {
 interface Result{void done(boolean success);}
 private static final ExecutorService worker=Executors.newSingleThreadExecutor();
 @Override public void onReceive(Context c,Intent intent){String id=intent.getStringExtra(CallAlert.ID);if(!CallAlert.visible(c,id))return;PendingResult pending=goAsync();decline(c,id,ok->pending.finish());}
 static void decline(Context context,String id,Result result){Context c=context.getApplicationContext();worker.execute(()->{boolean ok=false;HttpURLConnection http=null;
  try{
   String token,endpoint;synchronized(SecretStore.class){if(!CallAlert.visible(c,id)||!"true".equals(SecretStore.get(c,"available")))return;token=SecretStore.get(c,"token");endpoint=SecretStore.get(c,"endpoint");}
   if(token==null||endpoint==null)return;URL base=new URL(endpoint);if(!"https".equals(base.getProtocol())||base.getHost().isEmpty()||base.getUserInfo()!=null||base.getQuery()!=null||base.getRef()!=null)return;
   http=(HttpURLConnection)new URL(endpoint.replaceAll("/+$","")+"/api/calls/decline").openConnection();http.setInstanceFollowRedirects(false);http.setConnectTimeout(2500);http.setReadTimeout(3500);http.setRequestMethod("POST");http.setRequestProperty("Authorization","Bearer "+token);http.setRequestProperty("Content-Type","application/json");byte[] body=new JSONObject().put("callId",id).toString().getBytes(StandardCharsets.UTF_8);http.setDoOutput(true);http.setFixedLengthStreamingMode(body.length);try(OutputStream out=http.getOutputStream()){out.write(body);}int code=http.getResponseCode();
   synchronized(SecretStore.class){if((code==200||code==409)&&token.equals(SecretStore.get(c,"token"))&&endpoint.equals(SecretStore.get(c,"endpoint"))){CallAlert.dismissIfMatches(c,id);ok=true;}}
  }catch(Exception ignored){}finally{if(http!=null)http.disconnect();result.done(ok);}
 });}
}
