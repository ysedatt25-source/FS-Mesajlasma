package com.fs.mesajlasma;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;

/** Device-local preference. One persistent Android channel per ringtone. */
final class CallRingtones {
    private static final String PREFS = "fs-call-sound";
    private static final String KEY = "ringtone";
    private static final String MUTE_KEY = "muted";
    private static final String SILENT_CHANNEL = "incoming_fs_silent_v1";
    static boolean muted(Context c) { return c.getSharedPreferences(PREFS,0).getBoolean(MUTE_KEY,false); }
    static synchronized String ensureSilentChannel(Context c) {
        NotificationManager manager=c.getSystemService(NotificationManager.class);
        if(manager.getNotificationChannel(SILENT_CHANNEL)==null) {
            NotificationChannel n=new NotificationChannel(SILENT_CHANNEL,"Gelen aramalar · Sessiz",NotificationManager.IMPORTANCE_HIGH);
            n.setSound(null,null);
            n.enableVibration(false);
            manager.createNotificationChannel(n);
        }
        return SILENT_CHANNEL;
    }
    static synchronized boolean saveMuted(Context c,boolean value) {
        try {
            if(value)ensureSilentChannel(c);
            return c.getSharedPreferences(PREFS,0).edit().putBoolean(MUTE_KEY,value).commit();
        }catch(Exception e){return false;}
    }
    static boolean custom(String id){return "sura_derinlere".equals(id)||"sezen_tukenecegiz".equals(id);}
    private static boolean hasLocalFile(Context c,String id){if(!custom(id))return false;String uri=c.getSharedPreferences(PREFS,0).getString("file_"+id,"");if(uri.isEmpty())return false;try{for(android.content.UriPermission p:c.getContentResolver().getPersistedUriPermissions())if(p.isReadPermission()&&p.getUri().equals(Uri.parse(uri)))return true;}catch(Exception ignored){}return false;}
    private static boolean hasBundledFile(Context c,String id){return custom(id)&&c.getResources().getIdentifier("fs_ring_"+id,"raw",c.getPackageName())!=0;}
    static boolean hasFile(Context c,String id){return hasLocalFile(c,id)||hasBundledFile(c,id);}
    static boolean isBundled(Context c,String id){return !hasLocalFile(c,id)&&hasBundledFile(c,id);}
    static boolean saveFile(Context c,String id,Uri uri){if(!custom(id)||uri==null||!"content".equals(uri.getScheme()))return false;try{String type=c.getContentResolver().getType(uri);if(type!=null&&!type.startsWith("audio/"))return false;android.media.MediaExtractor extractor=new android.media.MediaExtractor();boolean audio=false;try{extractor.setDataSource(c,uri,null);for(int i=0;i<extractor.getTrackCount();i++){String mime=extractor.getTrackFormat(i).getString(android.media.MediaFormat.KEY_MIME);if(mime!=null&&mime.startsWith("audio/")){audio=true;break;}}}finally{extractor.release();}if(!audio)return false;c.getContentResolver().takePersistableUriPermission(uri,android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);if(!c.getSharedPreferences(PREFS,0).edit().putString("file_"+id,uri.toString()).putString("rev_"+id,java.util.UUID.randomUUID().toString()).commit())return false;return true;}catch(Exception e){return false;}}
    static boolean valid(String id) {
        return "system".equals(id) || "classic".equals(id) || "crystal".equals(id)
            || "soft".equals(id) || "pulse".equals(id) || "aurora".equals(id) || custom(id);
    }
    static String normalize(String id) { return valid(id) ? id : "system"; }
    static String selected(Context c) { String id=normalize(c.getSharedPreferences(PREFS,0).getString(KEY,"system"));return custom(id)&&!hasFile(c,id)?"system":id; }
    static String channelId(String id) { id=normalize(id); return "incoming_fs_"+id+"_v1"; }
    static AudioAttributes attributes() {
        return new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
    }
    static Uri sound(Context c,String id) {
        id=normalize(id);
        if ("system".equals(id)) return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        if(custom(id)){
            if(hasLocalFile(c,id))return Uri.parse(c.getSharedPreferences(PREFS,0).getString("file_"+id,""));
            if(!hasBundledFile(c,id))return null;
        }
        // Name-based resource URI remains valid when resource IDs change on update.
        return Uri.parse("android.resource://"+c.getPackageName()+"/raw/fs_ring_"+id);
    }
    static String label(String id) {
        switch(normalize(id)) {
            case "classic": return "Klasik";case "crystal": return "Kristal";
            case "soft": return "Yumuşak";case "pulse": return "Nabız";
            case "aurora": return "Aurora";case "sura_derinlere":return "Sura İskenderli – Derinlere İniyorum";case "sezen_tukenecegiz":return "Sezen Aksu – Tükeneceğiz";default: return "Telefonun varsayılanı";
        }
    }
    static synchronized String ensureChannel(Context c,String id) {
        id=normalize(id); String channel=custom(id)?"incoming_fs_"+id+"_"+(isBundled(c,id)?"bundled_v1":c.getSharedPreferences(PREFS,0).getString("rev_"+id,"missing")):channelId(id);
        NotificationManager manager=c.getSystemService(NotificationManager.class);
        if(manager.getNotificationChannel(channel)==null) {
            NotificationChannel n=new NotificationChannel(channel,"Gelen aramalar · "+label(id),NotificationManager.IMPORTANCE_HIGH);
            n.setSound(sound(c,id),attributes());
            n.enableVibration(true);
            // Never bypass user DND, change volume, or recreate an existing channel.
            manager.createNotificationChannel(n);
        }
        return channel;
    }
    static synchronized String currentChannel(Context c) {
        if(muted(c))return ensureSilentChannel(c);
        // Preserve an existing installation's system channel and its user settings
        // until the user explicitly saves a new sound choice.
        if(!c.getSharedPreferences(PREFS,0).contains(KEY) && c.getSystemService(NotificationManager.class).getNotificationChannel("incoming")!=null) return "incoming";
        return ensureChannel(c,selected(c));
    }
    static synchronized boolean save(Context c,String id) {
        if(!valid(id)||(custom(id)&&!hasFile(c,id)))return false;
        try{ensureChannel(c,id);return c.getSharedPreferences(PREFS,0).edit().putString(KEY,id).commit();}catch(Exception e){return false;}
    }
    private CallRingtones(){}
}
