package com.fs.mesajlasma;
import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;
public class CallService extends Service {
 @Override public void onCreate(){super.onCreate();getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel("call","Görüşme",NotificationManager.IMPORTANCE_LOW));}
 @Override public int onStartCommand(Intent i,int flags,int id){boolean video=i!=null&&i.getBooleanExtra("video",false);PendingIntent open=PendingIntent.getActivity(this,1,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE);Notification n=new Notification.Builder(this,"call").setSmallIcon(com.fs.mesajlasma.R.drawable.ic_launcher).setContentTitle("Görüşme sürüyor").setContentText("Aramaya geri dön").setContentIntent(open).setOngoing(true).build();if(Build.VERSION.SDK_INT>=29)startForeground(12,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE|(video?ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA:0));else startForeground(12,n);return START_NOT_STICKY;}
 @Override public IBinder onBind(Intent i){return null;}
}
