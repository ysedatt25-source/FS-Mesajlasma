package com.fs.mesajlasma;
/** JVM-testable call identity and lifetime checks. */
final class CallWindowPolicy {
 static boolean validId(String id){return id!=null&&id.matches("[A-Za-z0-9_-]{1,128}");}
 static boolean valid(String id,String current,long until,long now,long wallUntil,long wallNow){
  return validId(id)&&id.equals(current)&&until>now&&until-now<=45000&&wallUntil>wallNow&&wallUntil-wallNow<=45000;
 }
 private CallWindowPolicy(){}
}
