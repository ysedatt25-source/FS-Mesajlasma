package com.fs.mesajlasma;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;
import android.net.ConnectivityManager;
import android.net.Network;
import java.net.*;
import java.io.*;
import org.json.*;

/** Authenticated, same-server long poll. No microphone, camera or PIN access. */
public class ConnectionService extends Service {
 private volatile boolean running;
 private volatile HttpURLConnection connection;
 private Thread worker;
 private int latestStart;
 private final IncomingCallNotice noticeState=new IncomingCallNotice();
 private final Object retrySignal=new Object();
 private ConnectivityManager connectivity;
 private boolean networkRegistered;
 private final ConnectivityManager.NetworkCallback networks=new ConnectivityManager.NetworkCallback(){
  @Override public void onAvailable(Network network){wakePoll();}
  @Override public void onLost(Network network){wakePoll();}
 };
 private void wakePoll(){
  HttpURLConnection active=connection;if(active!=null)active.disconnect();
  synchronized(retrySignal){retrySignal.notifyAll();}
 }
 private final Handler main=new Handler(Looper.getMainLooper());
 private static final class Session {
  final String endpoint,token;
  Session(String endpoint,String token){this.endpoint=endpoint;this.token=token;}
  boolean same(Session other){return other!=null&&endpoint.equals(other.endpoint)&&token.equals(other.token);}
 }
 private Session session() throws Exception {
  synchronized(SecretStore.class){
   String endpoint=SecretStore.get(this,"endpoint"),token=SecretStore.get(this,"token");
   if(endpoint==null||token==null||!("true".equals(SecretStore.get(this,"available"))||"true".equals(SecretStore.get(this,"notifications"))))return null;
   URL url=new URL(endpoint);
   if(!"https".equals(url.getProtocol())||url.getHost().isEmpty()||url.getUserInfo()!=null||url.getQuery()!=null||url.getRef()!=null)return null;
   return new Session(endpoint.replaceAll("/+$",""),token);
  }
 }
 @Override public void onCreate(){
  super.onCreate();NotificationManager n=getSystemService(NotificationManager.class);
  n.createNotificationChannel(new NotificationChannel("connection","Aranabilirlik",NotificationManager.IMPORTANCE_LOW));
  n.cancel(20);MessageNotice.channel(this);CallRingtones.currentChannel(this);
  connectivity=getSystemService(ConnectivityManager.class);
  try{connectivity.registerDefaultNetworkCallback(networks);networkRegistered=true;}catch(RuntimeException ignored){}
 }
 private PendingIntent open(){return PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);}
 @Override public int onStartCommand(Intent i,int flags,int start){
  latestStart=start;
  Notification note=new Notification.Builder(this,"connection").setSmallIcon(R.drawable.ic_launcher).setContentTitle("Hesap Makinesi").setContentText("Bağlantı etkin").setContentIntent(open()).setOngoing(true).build();
  if(Build.VERSION.SDK_INT>=34)startForeground(10,note,ServiceInfo.FOREGROUND_SERVICE_TYPE_REMOTE_MESSAGING);else startForeground(10,note);
  if(worker==null||!worker.isAlive())startWorker();else wakePoll();
  return START_STICKY;
 }
 private void startWorker(){
  final int start=latestStart;running=true;worker=new Thread(()->poll(start),"fs-events");worker.start();
 }
 private void clearNotice(){
  CallAlert.clear(this);
  getSharedPreferences("fs-events",0).edit().remove("call").apply();
 }
 private void reconcile(Session source,JSONObject call){
  synchronized(SecretStore.class){try{
   if(!running||!source.same(session()))return;
   if(!"true".equals(SecretStore.get(this,"available"))){noticeState.reset();clearNotice();return;}
   String id=call==null?"":call.optString("callId","");
   long remaining=call==null?0:IncomingCallNotice.duration(call.optLong("remainingMs",45000));
   IncomingCallNotice.Action action=noticeState.observe(id,remaining);
   if(action==IncomingCallNotice.Action.CLEAR){clearNotice();return;}
   // Do not play the same ringtone again on every long-poll heartbeat.
   if(action==IncomingCallNotice.Action.KEEP)return;
   if(call.optBoolean("silent",false)?CallAlert.post(this,id,remaining,call.optBoolean("video",false),true,true):CallAlert.post(this,id,remaining,call.optBoolean("video",false)))noticeState.posted(id);
   // Both transports reconcile the same authenticated call and use the same alert.
  }catch(Exception ignored){}}
 }
 private JSONObject read(Session source,String previous) throws Exception {
  String avatarQuery=MessageNotice.avatarQuery(this);
  URL url=new URL(source.endpoint+"/api/events?ringing=1&messages=1&detail=1&known="+URLEncoder.encode(previous,"UTF-8")+avatarQuery);
  HttpURLConnection http=(HttpURLConnection)url.openConnection();connection=http;
  try{
   http.setInstanceFollowRedirects(false);http.setRequestProperty("Authorization","Bearer "+source.token);
   http.setConnectTimeout(8000);http.setReadTimeout(32000);
   int status=http.getResponseCode();if(status==401||status==403)throw new SecurityException("session expired");
   if(status!=200)throw new IOException("HTTP "+status);
   try(InputStream in=http.getInputStream()){
    ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;
    while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>(avatarQuery.isEmpty()?65536:262144))throw new IOException("event response too large");}
    return new JSONObject(out.toString("UTF-8"));
   }
  }finally{connection=null;http.disconnect();}
 }
 private void poll(int start){
  Session previous=null;int delay=1000;
  try{while(running){
   Session source=null;
   try{
    source=session();if(source==null)break;
    if(!source.same(previous)){synchronized(SecretStore.class){if(!running||!source.same(session()))continue;noticeState.reset();if(previous!=null)clearNotice();previous=source;}}
    JSONObject data=read(source,noticeState.known());
    if(!running||!source.same(session()))continue;
    if(data.has("messages")){synchronized(SecretStore.class){if(running&&source.same(session())){if("true".equals(SecretStore.get(this,"notifications")))MessageNotice.reconcile(this,data.optJSONArray("messages"));else MessageNotice.cancelAll(this);}}}
    if(data.has("ringing"))reconcile(source,data.optJSONObject("ringing"));
    else { // CI.13 and older servers: preserve legacy event delivery until final deployment.
     JSONArray events=data.getJSONArray("events");
     for(int j=0;j<events.length();j++){
      JSONObject event=events.getJSONObject(j);String type=event.optString("type");
      if("call".equals(type))reconcile(source,event);
      else if("hangup".equals(type)&&noticeState.matches(event.optString("callId","")))reconcile(source,null);
     }
    }
    delay=1000;
   }catch(SecurityException expired){if(source==null||source.same(session()))break;}
   catch(Exception e){if(!running)break;synchronized(retrySignal){if(running)retrySignal.wait(delay);}delay=IncomingCallNotice.nextRetry(delay);}
  }}catch(Exception ignored){}finally{
   Thread finished=Thread.currentThread();main.post(()->{if(worker!=finished)return;worker=null;if(running){if(latestStart!=start)startWorker();else{running=false;stopSelfResult(start);}}});
  }
 }
 @Override public void onDestroy(){if(networkRegistered){try{connectivity.unregisterNetworkCallback(networks);}catch(RuntimeException ignored){}networkRegistered=false;}synchronized(SecretStore.class){running=false;clearNotice();MessageNotice.cancelAll(this);}HttpURLConnection active=connection;if(active!=null)active.disconnect();if(worker!=null)worker.interrupt();worker=null;super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}
