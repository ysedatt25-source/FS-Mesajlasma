package com.fs.mesajlasma;
import java.net.URI;
// Only web URLs can leave the trusted WebView; never load remote pages into it.
final class ExternalWebLink {
 static String validate(String value){
  if(value==null||value.length()>8192||value.chars().anyMatch(c->c<32||c==127))return null;
  try{URI u=new URI(value);String scheme=u.getScheme(),host=u.getHost();if((!"https".equalsIgnoreCase(scheme)&&!"http".equalsIgnoreCase(scheme))||host==null||host.isEmpty()||u.getRawUserInfo()!=null||"appassets.androidplatform.net".equalsIgnoreCase(host))return null;return u.toASCIIString();}catch(Exception e){return null;}
 }
}
