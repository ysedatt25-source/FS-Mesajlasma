package com.fs.mesajlasma;
import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
/** Non-exported, limited incoming-call screen. Never displays chat content or starts capture. */
public final class IncomingCallActivity extends Activity {
 private final Handler handler=new Handler(Looper.getMainLooper());
 private String id; private Button reject; private TextView status;
 private final Runnable tick=new Runnable(){public void run(){if(!CallAlert.visible(IncomingCallActivity.this,id)){finish();return;}handler.postDelayed(this,300);}};
 @Override public void onCreate(Bundle b){super.onCreate(b);if(Build.VERSION.SDK_INT>=27){setShowWhenLocked(true);setTurnScreenOn(true);}else getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_SECURE);show(getIntent());}
 @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);show(intent);}
 private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
 private TextView text(String value,int size){TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(Color.WHITE);v.setGravity(Gravity.CENTER);return v;}
 private Button button(String label,int color){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(17);b.setAllCaps(false);b.setBackgroundTintList(ColorStateList.valueOf(color));return b;}
 private void show(Intent intent){
  handler.removeCallbacks(tick);id=intent.getStringExtra(CallAlert.ID);if(!CallAlert.visible(this,id)){finish();return;}
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(24),dp(32),dp(24),dp(32));root.setGravity(Gravity.CENTER);root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff367da2,0xff18394e,0xff327e72}));getWindow().setStatusBarColor(0xff367da2);getWindow().setNavigationBarColor(0xff327e72);
  root.addView(text(CallAlert.video(this,id)?"Gelen görüntülü arama":"Gelen sesli arama",24));TextView symbol=text("☎",56);root.addView(symbol,new LinearLayout.LayoutParams(-1,dp(120)));
  status=text("Yanıtlamak için güvenli giriş yap",16);root.addView(status);View spacer=new View(this);root.addView(spacer,new LinearLayout.LayoutParams(1,0,1));
  LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER);reject=button("Reddet",0xffd53b4b);Button accept=button("Yanıtla",0xff21834e);LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(0,dp(64),1);a.setMargins(dp(4),0,dp(4),0);actions.addView(reject,a);LinearLayout.LayoutParams z=new LinearLayout.LayoutParams(0,dp(64),1);z.setMargins(dp(4),0,dp(4),0);actions.addView(accept,z);root.addView(actions,new LinearLayout.LayoutParams(-1,-2));
  reject.setOnClickListener(v->{String selected=id;if(!CallAlert.visible(this,selected))return;reject.setEnabled(false);status.setText("Arama reddediliyor…");CallDeclineReceiver.decline(this,selected,ok->runOnUiThread(()->{if(!selected.equals(id)||isFinishing())return;if(ok){finish();}else{reject.setEnabled(true);status.setText("Reddedilemedi. Bağlantıyı kontrol edip tekrar dene.");}}));});
  accept.setOnClickListener(v->answer(id));setContentView(root);handler.post(tick);if(intent.getBooleanExtra("answer_requested",false)){intent.removeExtra("answer_requested");answer(id);}
 }
 private void answer(String selected){
  if(!CallAlert.visible(this,selected))return;
  KeyguardManager keyguard=getSystemService(KeyguardManager.class);
  if(keyguard.isKeyguardLocked()){keyguard.requestDismissKeyguard(this,new KeyguardManager.KeyguardDismissCallback(){@Override public void onDismissSucceeded(){openMain(selected);}});}else openMain(selected);
 }
 private void openMain(String selected){if(!CallAlert.visible(this,selected))return;startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP));finish();}
 @Override protected void onDestroy(){handler.removeCallbacks(tick);super.onDestroy();}
}
