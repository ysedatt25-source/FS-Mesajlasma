package com.fs.mesajlasma;

/** Pure notification reconciliation, independent of Android lifecycle and UI. */
final class IncomingCallNotice {
 enum Action { CLEAR, KEEP, POST }
 private String known="",notified="";
 String known(){return known;}
 void reset(){known="";notified="";}
 Action observe(String id,long remaining){
  if(id==null||!id.matches("[A-Za-z0-9_-]{1,128}")||remaining<=0){reset();return Action.CLEAR;}
  known=id;
  return id.equals(notified)?Action.KEEP:Action.POST;
 }
 void posted(String id){if(known.equals(id))notified=id;}
 boolean matches(String id){return !known.isEmpty()&&known.equals(id);}
 static long duration(long remaining){return Math.max(0,Math.min(45000,remaining));}
 static int nextRetry(int delay){return Math.min(8000,Math.max(1000,delay)*2);}
}
