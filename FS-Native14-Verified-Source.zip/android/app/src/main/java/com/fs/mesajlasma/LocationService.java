package com.fs.mesajlasma;
import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.location.*;
import android.os.*;
import android.util.Base64;
import org.json.*;
import java.net.*;
import java.io.*;
import java.security.SecureRandom;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** Explicit, time-limited background location share. No general chat key is persisted. */
public class LocationService extends Service implements LocationListener {
 private LocationManager manager;private JSONObject config;private long last;private Location latest;private final AtomicBoolean sending=new AtomicBoolean(false);private final Handler handler=new Handler(Looper.getMainLooper());
 @Override public void onCreate(){super.onCreate();manager=(LocationManager)getSystemService(LOCATION_SERVICE);getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel("location","Canlı konum",NotificationManager.IMPORTANCE_LOW));}
 @Override public int onStartCommand(Intent intent,int flags,int id){
  if(intent==null){stopSelf();return START_NOT_STICKY;}
  if(intent.getBooleanExtra("stop",false)){if(latest!=null)send(latest,true);stopSelf();return START_NOT_STICKY;}
  try{JSONObject next=new JSONObject(intent.getStringExtra("config"));long expires=next.getLong("expires");if(expires<=System.currentTimeMillis()||expires>System.currentTimeMillis()+8L*3600000)throw new Exception();if(!next.getString("room").matches("[A-Za-z0-9_-]{10,64}")||!next.getString("message").matches("[A-Za-z0-9_-]{10,64}"))throw new Exception();JSONObject keys=next.getJSONObject("keys");for(Iterator<String> it=keys.keys();it.hasNext();)if(Base64.decode(keys.getString(it.next()),Base64.NO_WRAP).length!=32)throw new Exception();config=next;latest=new Location("fs-initial");latest.setLatitude(next.getDouble("lat"));latest.setLongitude(next.getDouble("lng"));
   PendingIntent open=PendingIntent.getActivity(this,3,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE);Intent stop=new Intent(this,LocationService.class).putExtra("stop",true);PendingIntent stopIntent=PendingIntent.getService(this,4,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
   Notification n=new Notification.Builder(this,"location").setSmallIcon(com.fs.mesajlasma.R.drawable.ic_launcher).setContentTitle("Canlı konum paylaşılıyor").setContentText("Belirlediğin süre sonunda otomatik durur").setContentIntent(open).addAction(new Notification.Action.Builder(null,"Paylaşımı durdur",stopIntent).build()).setOngoing(true).build();if(Build.VERSION.SDK_INT>=29)startForeground(30,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);else startForeground(30,n);
   manager.removeUpdates(this);try{manager.requestLocationUpdates(LocationManager.GPS_PROVIDER,10000,10,this);}catch(Exception ignored){}try{manager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,10000,10,this);}catch(Exception ignored){}
   handler.removeCallbacksAndMessages(null);handler.postDelayed(()->{if(latest!=null)send(latest,true);stopSelf();},expires-System.currentTimeMillis());
  }catch(Exception e){stopSelf();}return START_NOT_STICKY;
 }
 @Override public void onLocationChanged(Location location){latest=location;if(config==null)return;if(System.currentTimeMillis()>=config.optLong("expires")){send(location,true);stopSelf();return;}if(System.currentTimeMillis()-last<10000)return;last=System.currentTimeMillis();send(location,false);}
 private void send(Location location,boolean ended){
  final JSONObject cfg=config;if(cfg==null||!sending.compareAndSet(false,true))return;
  new Thread(()->{HttpURLConnection connection=null;try{
   JSONObject payload=new JSONObject();payload.put("type","location");payload.put("text",ended?"Canlı konum sona erdi":"Canlı konum");payload.put("lat",location.getLatitude());payload.put("lng",location.getLongitude());payload.put("live",!ended);payload.put("expires",ended?System.currentTimeMillis():cfg.getLong("expires"));JSONObject envelopes=new JSONObject(),keys=cfg.getJSONObject("keys");String room=cfg.getString("room");
   for(Iterator<String> it=keys.keys();it.hasNext();){String user=it.next();byte[] iv=new byte[12];new SecureRandom().nextBytes(iv);Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(Base64.decode(keys.getString(user),Base64.NO_WRAP),"AES"),new GCMParameterSpec(128,iv));cipher.updateAAD(room.getBytes("UTF-8"));JSONObject envelope=new JSONObject();envelope.put("iv",Base64.encodeToString(iv,Base64.NO_WRAP));envelope.put("data",Base64.encodeToString(cipher.doFinal(payload.toString().getBytes("UTF-8")),Base64.NO_WRAP));envelopes.put(user,envelope);}
   String endpoint=SecretStore.get(this,"endpoint"),token=SecretStore.get(this,"token");if(endpoint==null||token==null)return;URL url=new URL(endpoint+"/api/messages/"+cfg.getString("message"));if(!url.getProtocol().equals("https"))return;connection=(HttpURLConnection)url.openConnection();connection.setRequestMethod("PATCH");connection.setConnectTimeout(10000);connection.setReadTimeout(10000);connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/json");connection.setRequestProperty("Authorization","Bearer "+token);JSONObject body=new JSONObject();body.put("envelopes",envelopes);try(OutputStream out=connection.getOutputStream()){out.write(body.toString().getBytes("UTF-8"));}connection.getResponseCode();
  }catch(Exception ignored){}finally{if(connection!=null)connection.disconnect();sending.set(false);}},"fs-location-send").start();
 }
 @Override public void onProviderEnabled(String provider){}
 @Override public void onProviderDisabled(String provider){}
 @Override public void onStatusChanged(String provider,int status,Bundle extras){}
 @Override public void onDestroy(){handler.removeCallbacksAndMessages(null);try{manager.removeUpdates(this);}catch(Exception ignored){}config=null;super.onDestroy();}
 @Override public IBinder onBind(Intent intent){return null;}
}
