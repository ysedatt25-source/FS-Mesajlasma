package com.fs.mesajlasma;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
/** Non-exported PendingIntent entry. Only opens the normal app/PIN gate. */
public final class MessageActionActivity extends Activity {
 @Override protected void onCreate(Bundle state){super.onCreate(state);Intent i=getIntent();if(MessageNotice.prepare(this,i.getStringExtra("room"),i.getStringExtra("id"),i.getStringExtra("action")))startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP));finish();}
}
