package com.fs.mesajlasma;
final class MessageAlertPolicy {
 static boolean validId(String id){return id!=null&&id.matches("[A-Za-z0-9_-]{10,64}");}
 static boolean fresh(String id,long created,String oldId,long oldCreated){return validId(id)&&created>0&&(created>oldCreated||created==oldCreated&&id.compareTo(oldId)>0);}
 static boolean suppress(boolean foreground,String visible,String room){return foreground&&validId(room)&&room.equals(visible);}
 static int count(int value){return Math.max(1,Math.min(500,value));}
 static String label(String value,boolean allowed){if(!allowed||value==null)return "Yeni mesaj";StringBuilder safe=new StringBuilder();value.codePoints().filter(cp->!Character.isISOControl(cp)&&Character.getType(cp)!=Character.FORMAT&&Character.getType(cp)!=Character.LINE_SEPARATOR&&Character.getType(cp)!=Character.PARAGRAPH_SEPARATOR).limit(80).forEach(safe::appendCodePoint);String text=safe.toString().trim();return text.isEmpty()?"Yeni mesaj":text;}
 static String description(int value){return count(value)==1?"Mesajı görmek için dokunun":count(value)+" yeni mesaj · Görmek için dokunun";}
 static final String AVATAR_PREFIX="data:image/jpeg;base64,";
 static boolean avatarCandidate(String photo){return photo!=null&&photo.length()>AVATAR_PREFIX.length()&&photo.length()<=150000&&photo.startsWith(AVATAR_PREFIX);}
 static boolean jpegHeader(byte[] data){return data!=null&&data.length>=4&&(data[0]&255)==255&&(data[1]&255)==216&&(data[2]&255)==255&&(data[data.length-2]&255)==255&&(data[data.length-1]&255)==217;}
 static int avatarSample(int width,int height){if(width<=0||height<=0||width>4096||height>4096||(long)width*height>4194304)return 0;int sample=1;while(Math.max(width,height)/sample>256)sample*=2;return sample;}
 static String avatarFingerprint(String photo){if(!avatarCandidate(photo))return "";try{return java.util.Base64.getEncoder().encodeToString(java.security.MessageDigest.getInstance("SHA-256").digest(photo.getBytes(java.nio.charset.StandardCharsets.US_ASCII)));}catch(java.security.NoSuchAlgorithmException impossible){return "";}}
 private MessageAlertPolicy(){}
}
