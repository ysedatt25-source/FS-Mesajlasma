package com.fs.mesajlasma;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import org.json.*;
import java.util.*;

/** Only authenticated metadata. Never puts message plaintext or keys in a notification. */
final class MessageNotice {
 static final String CHANNEL="chat-alerts-v1", SILENT_CHANNEL="chat-alerts-silent-v1", TAG="fs-chat:";
 private static final String PREFS="fs-message-alerts-v1";
 private static volatile boolean foreground;
 private static volatile String visibleRoom="";
 static void foreground(boolean value){foreground=value;}
 static void visibleRoom(String room){visibleRoom=valid(room)?room:"";}
 static boolean valid(String value){return MessageAlertPolicy.validId(value);}
 private static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences(PREFS,0);}
 static void channel(Context c){NotificationChannel ch=new NotificationChannel(CHANNEL,"Sohbet bildirimleri",NotificationManager.IMPORTANCE_HIGH);ch.enableVibration(true);ch.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);NotificationManager manager=c.getSystemService(NotificationManager.class);manager.createNotificationChannel(ch);NotificationChannel quiet=new NotificationChannel(SILENT_CHANNEL,"Sessiz sohbet bildirimleri",NotificationManager.IMPORTANCE_LOW);quiet.setSound(null,null);quiet.enableVibration(false);quiet.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);manager.createNotificationChannel(quiet);}
 static synchronized void details(Context c,boolean enabled){privacy(c,enabled,false);}
 static synchronized void privacy(Context c,boolean enabled,boolean avatars){avatars=enabled&&avatars;if(prefs(c).getBoolean("details",false)==enabled&&prefs(c).getBoolean("avatars",false)==avatars)return;cancelAll(c);prefs(c).edit().putBoolean("details",enabled).putBoolean("avatars",avatars).remove("active").remove("display").apply();}
 static String avatarQuery(Context c){return prefs(c).getBoolean("details",false)&&prefs(c).getBoolean("avatars",false)?"&avatars=1":"";}
 private static Bitmap avatarBitmap(String photo){
  if(!MessageAlertPolicy.avatarCandidate(photo))return null;
  try{byte[] data=android.util.Base64.decode(photo.substring(MessageAlertPolicy.AVATAR_PREFIX.length()),android.util.Base64.NO_WRAP);
   if(!MessageAlertPolicy.jpegHeader(data))return null;
   BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(data,0,data.length,options);
   int sample=MessageAlertPolicy.avatarSample(options.outWidth,options.outHeight);if(sample==0||!"image/jpeg".equals(options.outMimeType))return null;
   options.inJustDecodeBounds=false;options.inSampleSize=sample;options.inPreferredConfig=Bitmap.Config.RGB_565;
   Bitmap bitmap=BitmapFactory.decodeByteArray(data,0,data.length,options);if(bitmap==null)return null;
   if(bitmap.getWidth()>128||bitmap.getHeight()>128){float scale=128f/Math.max(bitmap.getWidth(),bitmap.getHeight());Bitmap scaled=Bitmap.createScaledBitmap(bitmap,Math.max(1,Math.round(bitmap.getWidth()*scale)),Math.max(1,Math.round(bitmap.getHeight()*scale)),true);if(scaled!=bitmap)bitmap.recycle();return scaled;}
   return bitmap;
  }catch(RuntimeException invalid){return null;}
 }
 static synchronized void clear(Context c){cancelAll(c);prefs(c).edit().clear().apply();try{SecretStore.put(c,"message-action","");}catch(Exception ignored){}}
 static synchronized void cancelAll(Context c){NotificationManager manager=c.getSystemService(NotificationManager.class);for(android.service.notification.StatusBarNotification n:manager.getActiveNotifications())if(n.getTag()!=null&&n.getTag().startsWith(TAG))manager.cancel(n.getTag(),n.getId());}
 private static JSONObject json(String raw){try{return new JSONObject(raw);}catch(Exception e){return new JSONObject();}}
 private static PendingIntent action(Context c,String room,String id,String action){Intent i=new Intent(c,MessageActionActivity.class).setData(Uri.parse("fs-message://"+action+"/"+room+"/"+id)).putExtra("room",room).putExtra("id",id).putExtra("action",action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_NO_HISTORY);return PendingIntent.getActivity(c,0,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);}
 static synchronized void reconcile(Context c,JSONArray snapshot){
  if(snapshot==null)return;NotificationManager n=c.getSystemService(NotificationManager.class);channel(c);
  JSONObject seen=json(prefs(c).getString("seen","{}")),active=json(prefs(c).getString("active","{}")),display=json(prefs(c).getString("display","{}"));Set<String> eligible=new HashSet<>();long now=System.currentTimeMillis();
  boolean permitted=n.areNotificationsEnabled();boolean details=prefs(c).getBoolean("details",false);boolean avatars=details&&prefs(c).getBoolean("avatars",false);
  Map<String,Notification> postedByRoom=new HashMap<>();for(android.service.notification.StatusBarNotification notice:n.getActiveNotifications()){String tag=notice.getTag();if(tag!=null&&tag.startsWith(TAG)&&notice.getId()==20)postedByRoom.put(tag.substring(TAG.length()),notice.getNotification());}
  for(int j=0;j<snapshot.length();j++){JSONObject m=snapshot.optJSONObject(j);if(m==null)continue;String room=m.optString("room"),id=m.optString("id");long created=m.optLong("created");if(!valid(room)||!valid(id)||created<=0)continue;
   eligible.add(room);JSONObject previous=seen.optJSONObject(room);long old=previous==null?0:previous.optLong("created");String oldId=previous==null?"":previous.optString("id");boolean fresh=MessageAlertPolicy.fresh(id,created,oldId,old);
   if(MessageAlertPolicy.suppress(foreground,visibleRoom,room)){n.cancel(TAG+room,20);active.remove(room);if(fresh)try{seen.put(room,new JSONObject().put("id",id).put("created",created).put("at",now));}catch(Exception ignored){}continue;}
   boolean silent=m.optBoolean("silent",false);String channelId=silent?SILENT_CHANNEL:CHANNEL;
   NotificationChannel targetChannel=n.getNotificationChannel(channelId);
   if(!permitted||targetChannel==null||targetChannel.getImportance()==NotificationManager.IMPORTANCE_NONE){n.cancel(TAG+room,20);active.remove(room);display.remove(room);continue;}
   int count=MessageAlertPolicy.count(m.optInt("count",1));String label=MessageAlertPolicy.label(m.optString("label"),details);
   String photo=avatars?m.optString("avatar",""):"";if(!MessageAlertPolicy.avatarCandidate(photo))photo="";
   String signature=count+":"+silent+":"+MessageAlertPolicy.avatarFingerprint(photo);
   Notification posted=postedByRoom.get(room);String postedChannel=posted==null?null:posted.getChannelId();
   if(postedChannel!=null&&!postedChannel.equals(channelId)){n.cancel(TAG+room,20);active.remove(room);display.remove(room);if(!fresh)continue;}
   if(!fresh){if(!id.equals(active.optString(room))){n.cancel(TAG+room,20);active.remove(room);display.remove(room);continue;}if(posted==null||signature.equals(display.optString(room))&&label.contentEquals(posted.extras.getCharSequence(Notification.EXTRA_TITLE,"")))continue;}
   try{
    // Persist deduplication before posting: retries or process death cannot repeat the same alert.
    if(fresh)seen.put(room,new JSONObject().put("id",id).put("created",created).put("at",now));active.put(room,id);display.put(room,signature);
    if(!prefs(c).edit().putString("seen",seen.toString()).putString("active",active.toString()).putString("display",display.toString()).commit())continue;
    Notification publicVersion=new Notification.Builder(c,channelId).setSmallIcon(R.drawable.ic_launcher).setContentTitle("Yeni bildirim").setContentText("İçeriği görmek için kilidi açın").build();
    Notification.Builder b=new Notification.Builder(c,channelId).setSmallIcon(R.drawable.ic_launcher).setContentTitle(label).setContentText(MessageAlertPolicy.description(count)).setNumber(count).setWhen(created).setShowWhen(true).setOnlyAlertOnce(!fresh).setCategory(Notification.CATEGORY_MESSAGE).setVisibility(Notification.VISIBILITY_PRIVATE).setPublicVersion(publicVersion).setContentIntent(action(c,room,id,"open")).setAutoCancel(true).setTimeoutAfter(300000).addAction(new Notification.Action.Builder(null,"Yanıtla",action(c,room,id,"reply")).build()).addAction(new Notification.Action.Builder(null,"Okundu",action(c,room,id,"read")).build());
    Bitmap image=avatarBitmap(photo);if(image!=null)b.setLargeIcon(image);
    n.notify(TAG+room,20,b.build());
   }catch(Exception ignored){}
  }
  for(String room:new ArrayList<>(keys(active)))if(!eligible.contains(room)||!permitted){n.cancel(TAG+room,20);active.remove(room);display.remove(room);}
  for(String room:new ArrayList<>(keys(seen))){JSONObject value=seen.optJSONObject(room);if(value==null||now-value.optLong("at")>86400000)seen.remove(room);}
  for(String room:keys(display))if(!active.has(room))display.remove(room);
  prefs(c).edit().putString("seen",seen.toString()).putString("active",active.toString()).putString("display",display.toString()).apply();
 }
 private static List<String> keys(JSONObject o){List<String> out=new ArrayList<>();o.keys().forEachRemaining(out::add);return out;}
 static synchronized boolean prepare(Context c,String room,String id,String action){if(!valid(room)||!valid(id)||!("open".equals(action)||"reply".equals(action)||"read".equals(action)))return false;
  if(!id.equals(json(prefs(c).getString("active","{}")).optString(room)))return false;
  try{if(SecretStore.get(c,"token")==null)return false;SecretStore.put(c,"message-action",new JSONObject().put("room",room).put("id",id).put("action",action).put("expires",System.currentTimeMillis()+300000).toString());return true;}catch(Exception e){return false;}}
 static synchronized String pending(Context c){try{JSONObject x=json(SecretStore.get(c,"message-action"));if(x.optLong("expires")>System.currentTimeMillis()&&valid(x.optString("room"))&&valid(x.optString("id")))return x.toString();SecretStore.put(c,"message-action","");}catch(Exception ignored){}return "";}
 static synchronized void complete(Context c,String raw){try{if(raw.equals(SecretStore.get(c,"message-action"))){JSONObject x=json(raw);String room=x.optString("room");JSONObject active=json(prefs(c).getString("active","{}"));if(x.optString("id").equals(active.optString(room))){c.getSystemService(NotificationManager.class).cancel(TAG+room,20);active.remove(room);JSONObject display=json(prefs(c).getString("display","{}"));display.remove(room);prefs(c).edit().putString("active",active.toString()).putString("display",display.toString()).apply();}SecretStore.put(c,"message-action","");}}catch(Exception ignored){}}
 private MessageNotice(){}
}
