package com.fs.mesajlasma;
/** One in-memory, consent-bound screen share. No frame survives cancellation. */
final class ProjectionSession {
 private String ticket="",phase="ended",frame=""; private long sequence,lastPoll;
 synchronized boolean begin(String id,long now){if(id==null||!id.matches("[a-f0-9]{32}")||!phase.equals("ended"))return false;ticket=id;phase="waiting";frame="";sequence=0;lastPoll=now;return true;}
 synchronized boolean waiting(String id){return ticket.equals(id)&&phase.equals("waiting");}
 synchronized boolean activate(String id,long now){if(!waiting(id))return false;phase="active";lastPoll=now;return true;}
 synchronized boolean alive(String id,long now){return ticket.equals(id)&&!phase.equals("ended")&&now-lastPoll<=10000;}
 synchronized void publish(String id,String jpeg){if(ticket.equals(id)&&phase.equals("active")&&jpeg!=null&&jpeg.length()<=1500000){frame=jpeg;sequence++;}}
 synchronized String poll(String id,long after,long now){if(!ticket.equals(id)||phase.equals("ended"))return "ended";if(phase.equals("active")&&now-lastPoll>10000){cancel(id);return "ended";}lastPoll=now;return phase.equals("active")&&!frame.isEmpty()&&sequence>after?"frame|"+sequence+"|"+frame:phase;}
 synchronized boolean cancel(String id){if(!ticket.equals(id)||phase.equals("ended"))return false;phase="ended";frame="";return true;}
 synchronized void cancelAll(){phase="ended";frame="";}
}
