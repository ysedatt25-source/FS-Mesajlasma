package com.fs.mesajlasma;
import android.content.Context;
/** Production FCM transport; only non-push development builds retain the visible polling service. */
final class PushSupport {
 static boolean usesFirebase(){return BuildConfig.FS_PUSH_ENABLED;}
 static void sync(Context context){invoke("sync",context);}
 static void clear(Context context){invoke("clear",context);}
 private static void invoke(String name,Context context){try{Class.forName("com.fs.mesajlasma.FirebasePush").getMethod(name,Context.class).invoke(null,context.getApplicationContext());}catch(ClassNotFoundException absent){/* Optional provider intentionally not compiled. */}catch(Exception ignored){/* Registration is retried on the next session sync/resume. */}}
 private PushSupport(){}
}
