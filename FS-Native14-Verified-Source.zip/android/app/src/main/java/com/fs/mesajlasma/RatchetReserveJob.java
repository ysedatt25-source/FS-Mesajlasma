package com.fs.mesajlasma;
import android.app.job.JobParameters;
import android.app.job.JobService;
import java.util.concurrent.*;
/** Best effort periodic job; Android force-stop disables jobs until user relaunches. */
public final class RatchetReserveJob extends JobService {
 private final ExecutorService executor=Executors.newSingleThreadExecutor();
 private Future<?> running; private int generation;
 @Override public synchronized boolean onStartJob(JobParameters p){int id=++generation;running=executor.submit(()->{try{RatchetReserve.replenish(getApplicationContext());}catch(Exception ignored){}synchronized(this){if(id==generation){running=null;jobFinished(p,false);}}});return true;}
 @Override public synchronized boolean onStopJob(JobParameters p){generation++;if(running!=null)running.cancel(true);running=null;return true;}
 @Override public synchronized void onDestroy(){generation++;if(running!=null)running.cancel(true);executor.shutdownNow();super.onDestroy();}
}
