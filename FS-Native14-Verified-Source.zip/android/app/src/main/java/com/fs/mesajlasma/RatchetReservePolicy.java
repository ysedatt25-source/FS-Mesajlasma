package com.fs.mesajlasma;
/** Public-only reserve bounds. Does not contain or derive private keys. */
final class RatchetReservePolicy {
 static final int PER_ROOM=3, TOTAL=30, TARGET=3;
 static final long DAY=86400000L;
 static boolean id(String s){return s!=null&&s.matches("[A-Za-z0-9_-]{10,64}");}
 static boolean keyId(String s){return s!=null&&s.matches("[a-f0-9]{32}");}
 static boolean live(long expiry,long now){return expiry>now+DAY&&expiry<=now+7*DAY+60000;}
 static boolean needs(int count){return count>=0&&count<TARGET;}
 private RatchetReservePolicy(){}
}
