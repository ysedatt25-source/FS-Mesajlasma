package com.fs.mesajlasma;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.util.Base64;
import android.util.DisplayMetrics;
import java.io.ByteArrayOutputStream;

/** User-consented MediaProjection; memory-only latest JPEG, bounded frame rate/size.
 * WebView consumes the frame into its existing WebRTC video sender. No audio captured. */
public final class ScreenShareService extends Service {
 static final ProjectionSession SESSION=new ProjectionSession();
 static final String ID="ticket",CONSENT="consent",STOP="com.fs.mesajlasma.STOP_PROJECTION";
 private HandlerThread thread; private Handler worker; private String ticket="";
 private MediaProjection projection; private VirtualDisplay display; private ImageReader reader;
 private int width,height,density; private long lastFrame; private boolean receiverRegistered;
 private final BroadcastReceiver screenOff=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){SESSION.cancelAll();stopSelf();}};
 private final Runnable watchdog=new Runnable(){public void run(){if(!SESSION.alive(ticket,SystemClock.elapsedRealtime())){stopSelf();return;}worker.postDelayed(this,1000);}};
 private final MediaProjection.Callback projectionCallback=new MediaProjection.Callback(){
  @Override public void onStop(){SESSION.cancel(ticket);stopSelf();}
  @Override public void onCapturedContentResize(int w,int h){if(projection!=null)try{resize(w,h);}catch(RuntimeException ex){SESSION.cancel(ticket);stopSelf();}}
 };
 @Override public void onCreate(){super.onCreate();thread=new HandlerThread("fs-screen-share");thread.start();worker=new Handler(thread.getLooper());
  NotificationManager n=getSystemService(NotificationManager.class);n.createNotificationChannel(new NotificationChannel("screen-share","Ekran paylaşımı",NotificationManager.IMPORTANCE_LOW));
  IntentFilter filter=new IntentFilter(Intent.ACTION_SCREEN_OFF);if(Build.VERSION.SDK_INT>=33)registerReceiver(screenOff,filter,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(screenOff,filter);receiverRegistered=true;
 }
 @Override public int onStartCommand(Intent i,int flags,int startId){
  if(i==null){stopSelf();return START_NOT_STICKY;}
  if(STOP.equals(i.getAction())){if(SESSION.cancel(i.getStringExtra(ID)))stopSelf();return START_NOT_STICKY;}
  String id=i.getStringExtra(ID);Intent consent=i.getParcelableExtra(CONSENT);
  if(consent==null||!SESSION.waiting(id)||!ticket.isEmpty()){if(SESSION.waiting(id))SESSION.cancel(id);if(ticket.isEmpty())stopSelf();return START_NOT_STICKY;}
  ticket=id;
  try{Intent stop=new Intent(this,ScreenShareService.class).setAction(STOP).putExtra(ID,id).setData(android.net.Uri.parse("fs-share://stop/"+id));
   PendingIntent end=PendingIntent.getService(this,0,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
   Notification n=new Notification.Builder(this,"screen-share").setSmallIcon(R.drawable.ic_launcher).setContentTitle("Ekran paylaşılıyor").setContentText("Paylaşımı durdurmak için dokun").setContentIntent(end).addAction(new Notification.Action.Builder(null,"Durdur",end).build()).setOngoing(true).build();
   if(Build.VERSION.SDK_INT>=29)startForeground(13,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);else startForeground(13,n);
   worker.post(()->open(consent));
  }catch(RuntimeException ex){SESSION.cancel(id);stopSelf();}return START_NOT_STICKY;
 }
 private void open(Intent consent){try{
  if(!SESSION.waiting(ticket)){stopSelf();return;}
  projection=getSystemService(MediaProjectionManager.class).getMediaProjection(Activity.RESULT_OK,consent);if(projection==null)throw new IllegalStateException();
  projection.registerCallback(projectionCallback,worker);
  DisplayMetrics m=new DisplayMetrics();((android.view.WindowManager)getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(m);density=m.densityDpi;
  resize(m.widthPixels,m.heightPixels);
  if(!SESSION.activate(ticket,SystemClock.elapsedRealtime())){stopSelf();return;}worker.post(watchdog);
 }catch(RuntimeException ex){SESSION.cancel(ticket);stopSelf();}}
 private void resize(int w,int h){if(w<=0||h<=0)return;double scale=Math.min(1d,1280d/Math.max(w,h));int nw=Math.max(2,(int)(w*scale)/2*2),nh=Math.max(2,(int)(h*scale)/2*2);if(nw==width&&nh==height&&reader!=null)return;
  ImageReader fresh=ImageReader.newInstance(nw,nh,PixelFormat.RGBA_8888,2);fresh.setOnImageAvailableListener(this::frame,worker);
  ImageReader old=reader;try{if(display==null)display=projection.createVirtualDisplay("FS screen share",nw,nh,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,fresh.getSurface(),null,worker);else{display.resize(nw,nh,density);display.setSurface(fresh.getSurface());}if(display==null)throw new IllegalStateException();reader=fresh;width=nw;height=nh;}catch(RuntimeException ex){fresh.close();throw ex;}if(old!=null)old.close();
 }
 private void frame(ImageReader source){try(Image image=source.acquireLatestImage()){
  long now=SystemClock.elapsedRealtime();if(image==null||source!=reader||now-lastFrame<100||!SESSION.alive(ticket,now))return;lastFrame=now;
  Image.Plane p=image.getPlanes()[0];int w=image.getWidth(),h=image.getHeight();if(p.getPixelStride()!=4)return;
  java.nio.ByteBuffer src=p.getBuffer(),packed=java.nio.ByteBuffer.allocate(w*h*4);int base=src.position();
  for(int y=0;y<h;y++){int offset=base+y*p.getRowStride();java.nio.ByteBuffer row=src.duplicate();row.position(offset);row.limit(offset+w*4);packed.put(row);}packed.flip();
  Bitmap bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);try{
   bitmap.copyPixelsFromBuffer(packed);ByteArrayOutputStream out=new ByteArrayOutputStream();bitmap.compress(Bitmap.CompressFormat.JPEG,80,out);SESSION.publish(ticket,Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP));
  }finally{bitmap.recycle();}
 }catch(RuntimeException ignored){/* malformed/transitional frame: drop, never save */}}
 @Override public void onConfigurationChanged(Configuration config){super.onConfigurationChanged(config);if(Build.VERSION.SDK_INT<34&&worker!=null)worker.post(()->{if(projection!=null)try{DisplayMetrics m=new DisplayMetrics();((android.view.WindowManager)getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(m);resize(m.widthPixels,m.heightPixels);}catch(RuntimeException ex){SESSION.cancel(ticket);stopSelf();}});}
 @Override public void onDestroy(){SESSION.cancel(ticket);if(receiverRegistered)unregisterReceiver(screenOff);if(worker!=null){worker.removeCallbacksAndMessages(null);worker.post(()->{if(display!=null)display.release();if(reader!=null)reader.close();if(projection!=null){projection.unregisterCallback(projectionCallback);projection.stop();}thread.quitSafely();});}stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}
