package com.fs.mesajlasma;

import android.app.NotificationManager;
import android.os.Build;
import androidx.work.*;
import java.util.concurrent.TimeUnit;
import android.content.Context;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Map;

/** Optional FCM wakeup. No caller details, session tokens, or message text enter FCM.
 * A received wakeup is never itself authority to announce a call. */
public final class FirebasePush extends FirebaseMessagingService {
 private static final ExecutorService worker=Executors.newSingleThreadExecutor();
 private static final SecureRandom random=new SecureRandom();
 private static boolean syncing;
 static final class Session {
  final String endpoint,token,binding;
  Session(String e,String t,String b){endpoint=e;token=t;binding=b;}
  boolean same(Session other){return other!=null&&endpoint.equals(other.endpoint)&&token.equals(other.token)&&binding.equals(other.binding);}
 }
 static Session session(Context c,boolean create) throws Exception {
  synchronized(SecretStore.class){
   if((!allowed(c,"available")&&!allowed(c,"notifications"))||!c.getSystemService(NotificationManager.class).areNotificationsEnabled())return null;
   String e=SecretStore.get(c,"endpoint"),t=SecretStore.get(c,"token");if(e==null||t==null)return null;
   URL url=new URL(e);if(!"https".equals(url.getProtocol())||url.getHost().isEmpty()||url.getUserInfo()!=null||url.getQuery()!=null||url.getRef()!=null)return null;
   String binding=SecretStore.get(c,"push-binding"),owner=SecretStore.get(c,"push-owner");
   // A new login or server always gets a new random binding.
   String fingerprint=android.util.Base64.encodeToString(java.security.MessageDigest.getInstance("SHA-256").digest((e+"\n"+t).getBytes(StandardCharsets.UTF_8)),android.util.Base64.NO_WRAP);
   if(!fingerprint.equals(owner)||binding==null||binding.isEmpty()){if(!create)return null;byte[] bytes=new byte[24];random.nextBytes(bytes);binding=android.util.Base64.encodeToString(bytes,android.util.Base64.URL_SAFE|android.util.Base64.NO_WRAP|android.util.Base64.NO_PADDING);SecretStore.put(c,"push-owner",fingerprint);SecretStore.put(c,"push-binding",binding);}
   return new Session(e.replaceAll("/+$",""),t,binding);
  }
 }
 static JSONObject request(Session s,String path,String method,JSONObject data) throws Exception {
  HttpURLConnection http=(HttpURLConnection)new URL(s.endpoint+path).openConnection();
  try{
   http.setInstanceFollowRedirects(false);http.setRequestMethod(method);http.setConnectTimeout(1500);http.setReadTimeout(2000);http.setRequestProperty("Authorization","Bearer "+s.token);http.setRequestProperty("X-FS-Push-Binding",s.binding);
   if(data!=null){byte[] bytes=data.toString().getBytes(StandardCharsets.UTF_8);http.setDoOutput(true);http.setRequestProperty("Content-Type","application/json");http.setFixedLengthStreamingMode(bytes.length);try(OutputStream out=http.getOutputStream()){out.write(bytes);}}
   int status=http.getResponseCode();if(status==401||status==403)throw new SecurityException("Push session rejected");if(status!=200)throw new IOException("Push API rejected request");
   try(InputStream in=http.getInputStream()){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[1024];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>(path.equals("/api/push/messages?detail=1&avatars=1")?262144:path.equals("/api/push/messages?detail=1")?65536:16384))throw new IOException("Push response too large");}return new JSONObject(out.toString("UTF-8"));}
  }finally{http.disconnect();}
 }
 private static void register(Context c,Session before,String registration){try{if(!before.same(session(c,false)))return;request(before,"/api/push/registration","POST",new JSONObject().put("registration",registration).put("binding",before.binding));}catch(Exception ignored){}}
 public static synchronized void sync(Context c){
  if(syncing)return;syncing=true;
  try{Session before=session(c,true);if(before==null){syncing=false;return;}FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task->{try{if(task.isSuccessful()&&task.getResult()!=null)worker.execute(()->{try{register(c,before,task.getResult());}finally{done();}});else done();}catch(Exception e){done();}});}catch(Exception e){syncing=false;}
 }
 private static synchronized void done(){syncing=false;}
 public static void clear(Context c){synchronized(SecretStore.class){try{SecretStore.put(c,"push-binding","");SecretStore.put(c,"push-owner","");}catch(Exception ignored){}}}
 @Override public void onNewToken(String token){try{Session before=session(this,true);if(before!=null)register(this,before,token);}catch(Exception ignored){}}
 static boolean allowed(Context c,String flag) throws Exception {return "true".equals(SecretStore.get(c,flag));}
 @Override public void onMessageReceived(RemoteMessage msg){
  try{
   Map<String,String> data=msg.getData();if(data.size()!=2)return;String kind=data.get("kind");if(!"call-wakeup-v1".equals(kind)&&!"message-wakeup-v1".equals(kind)&&!"call-refresh-v1".equals(kind))return;
   Session before=session(this,false);if(before==null||!before.binding.equals(data.get("binding")))return;
   if("message-wakeup-v1".equals(kind)){
    if(!allowed(this,"notifications"))return;
    OneTimeWorkRequest.Builder job=new OneTimeWorkRequest.Builder(MessagePushWorker.class).setInputData(new Data.Builder().putString("binding",before.binding).putLong("deadline",System.currentTimeMillis()+300000).build()).setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).setBackoffCriteria(BackoffPolicy.LINEAR,10,TimeUnit.SECONDS);
    if(Build.VERSION.SDK_INT>=31&&msg.getPriority()==RemoteMessage.PRIORITY_HIGH)job.setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST);
    WorkManager.getInstance(this).enqueueUniqueWork("fs-message-wakeup-"+before.binding,ExistingWorkPolicy.REPLACE,job.build());return;
   }
   if(!allowed(this,"available"))return;
   String prior=CallAlert.currentId(this);
   JSONObject result=request(before,"/api/push/ringing","GET",null),call=result.optJSONObject("ringing");
   synchronized(SecretStore.class){if(!allowed(this,"available")||!before.same(session(this,false)))return;
    // A late empty snapshot must not dismiss a newer invitation.
    if(call==null){if(result.has("ringing")&&result.isNull("ringing")&&!prior.isEmpty())CallAlert.dismissIfMatches(this,prior);return;}
    // Refresh is reconciliation only, never a new ringtone. The original high-priority wakeup handles incoming calls.
    if("call-refresh-v1".equals(kind)){if(!prior.isEmpty()&&!prior.equals(call.optString("callId")))CallAlert.dismissIfMatches(this,prior);return;}
    CallAlert.post(this,call.optString("callId"),call.optLong("remainingMs",0),call.optBoolean("video",false),true,call.optBoolean("silent",false));}
  }catch(Exception ignored){} // never bypass PIN; poll and ordinary app launch still work.
 }
}
