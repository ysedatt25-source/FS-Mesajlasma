package com.fs.mesajlasma;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import org.json.JSONObject;

/** Fetch the authorized snapshot after a content-free signal. Never store a session token in WorkManager. */
public final class MessagePushWorker extends Worker {
 public MessagePushWorker(@NonNull Context c,@NonNull WorkerParameters params){super(c,params);}
 @NonNull @Override public Result doWork(){
  Context c=getApplicationContext();String binding=getInputData().getString("binding");long expires=getInputData().getLong("deadline",0);
  if(binding==null||System.currentTimeMillis()>=expires||isStopped())return Result.success();
  try{
   FirebasePush.Session before=FirebasePush.session(c,false);
   if(before==null||!binding.equals(before.binding)||!FirebasePush.allowed(c,"notifications"))return Result.success();
   JSONObject result=FirebasePush.request(before,"/api/push/messages?detail=1"+MessageNotice.avatarQuery(c),"GET",null);
   synchronized(SecretStore.class){
    if(isStopped()||System.currentTimeMillis()>=expires||!before.same(FirebasePush.session(c,false))||!FirebasePush.allowed(c,"notifications"))return Result.success();
    MessageNotice.reconcile(c,result.optJSONArray("messages"));
   }
   return Result.success();
  }catch(SecurityException e){return Result.success();}catch(Exception e){return getRunAttemptCount()<3&&System.currentTimeMillis()<expires?Result.retry():Result.success();}
 }
}
