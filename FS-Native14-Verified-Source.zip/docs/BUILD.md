# Android derlemesi

Linux x86_64 ve Java 17+ çalışma ortamı kullanılır. Android Studio/Gradle
projesi `android/` altında da bulunur. Yerel derleme yolunda Eclipse ECJ,
Android API 35, aapt2, D8, zipalign ve apksigner kullanılır.

```sh
python tools/setup_android.py
python tools/build_android.py
```

İlk komut Google'ın Android deposu ve Maven Central'dan sabit sürümleri
indirir, SHA-256 özetlerini doğrular. İkinci komut varsayılan olarak imzasız
bir paket oluşturur. Derleme araçları arşive dahil değildir.

İmzalama için mevcut anahtarınızı ortam değişkenleriyle verin:

- `FS_KEYSTORE`: PKCS12/JKS dosyasının mutlak yolu
- `FS_KEY_ALIAS`: anahtar takma adı
- `FS_KEYSTORE_PASSWORD`: depo parolası
- `FS_KEY_PASSWORD`: farklıysa anahtar parolası

Parolalar komut satırına yazılmaz ve kaynak arşivine dahil edilmez.
Anahtarlar yeniden oluşturulmaz. İmzalama sonunda APK doğrulaması yapılır.
`FS_ANDROID_TOOLS`, derleme araçları dizinini değiştirmek için kullanılabilir.

Gradle ile derlemede Android SDK 35 ve uyumlu JDK/Gradle kurulumu gerekir.
Yerel ECJ yolunda yalnızca derleme aşamasında kullanılan LambdaMetafactory
tür tanımı D8'in lambda dönüştürmesi için kullanılır; APK'ya eklenmez.

Bu derleme, gerçek telefona kurulum testi yerine geçmez. ABI'ye özel yerel
kütüphane kullanılmaz; Android System WebView gereklidir.
