# Telefon hesap makinesi referansı

Gönderilen beş ekran esas alınmıştır: açık gri temel ekran, bilimsel 5×7 tuş düzeni, işlem yazarken canlı önizleme, Türkçe sayı gösterimi ve küçük pencere. 45×45 yazarken önizleme 2.025, eşittirden sonra ifade üstte ve sonuç büyük görünür. Sin/cos/tan, log/ln, parantez, inv (ters trigonometrik fonksiyon), rad/deg, faktöriyel, üs, karekök, π ve e kullanılabilir.

Android küçük pencere SYSTEM_ALERT_WINDOW iznini yalnız kullanıcı küçük pencere düğmesine bastığında ister. Pencere sürüklenir, sağ alt köşeden boyutlandırılır, küçültülünce simgeye dönüşür; tam ekran ve kapatma seçenekleri vardır. Ayrı WebView yalnız calculator-window.html ve hesaplama modüllerini yükler; ağ erişimi, sohbet/oturum veya kamera/mikrofon köprüsü yoktur. Küçük pencerede PIN sohbete geçirmez; tam ekran uygulamada geçer. Hesaplama durumu tam ekran geçişine aktarılır.

OEM sistem penceresinin özel animasyonları ve Android süreç yönetimi birebir kopyalanmaz; uygulama işlemi işletim sistemi tarafından sonlandırılırsa pencere kapanır. Yeni bir arka plan hizmeti veya ona ait bildirim eklenmedi. Donanım üzerinde sürükleme/izin/ekran döndürme kabul testi henüz yapılmadı. Yazılım/DOM testleri ve Android API35 derlemesi ayrı doğrulamalardır.
