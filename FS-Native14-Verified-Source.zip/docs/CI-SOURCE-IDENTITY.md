# FS 34.32 — CircleCI kaynak kimliği

Regresyon, derleme ve imzalama işleri doğrulanmış kaynak manifestinin SHA-256 özeti ile birbirine bağlanır. Regresyon sonuçlarının özeti, imzasız APK ve derleme meta verilerinin özetleri çalışma alanında sonraki aşamaya taşınır. Eksik veya başarısız test, farklı kaynak veya değişen APK/meta veri imzalamayı engeller. Bu mekanizma gerçek cihaz kabulünün veya bağımsız güvenlik denetiminin yerine geçmez.

Yerel kontrol: `python -m unittest discover -s tests -p test_ci_source_identity.py -v` (7/7). Önceki nihai kontrol testleri (7/7). CircleCI YAML ayrıştırıldı; gerçek CircleCI derlemesi yapılmadı. Canlı sunucu ve GitHub değiştirilmedi.

Kurulum: ZIP dosyasını erişilebilir HTTPS adresine yükleyin; CircleCI ortamında `FS_FINAL_SOURCE_URL` ve `FS_FINAL_SOURCE_SHA256` değerlerini bu ZIP için ayarlayın. Arşivdeki `.circleci/config.yml` dosyasını mevcut repoya uygulayın. Önceki Firebase ve imzalama ayarlarını koruyun. Emoji dosyaları önceki altı doğrulanmış arşivden geri yüklenir.
