# GitHub / CircleCI

CircleCI runs the server, encryption and DOM tests, restores the SHA-256 verified emoji archive from this repository's development release, and compiles the Android APK. Build logs and the unsigned APK are stored as artifacts. No private signing key or production credentials belong in the repository.

The existing signed development APK remains available in GitHub Releases. The CI artifact is explicitly unsigned and cannot replace an installed signed version. Signing new releases requires the owner's existing key in protected CI secrets or a separate trusted signing step.

This pipeline does not provision a persistent API server, MariaDB service or TURN relay. A successful CI run is not evidence that live messaging or physical device tests passed. The release gate remains independent.

For local builds, run `python tools/fetch_assets.py` before `python tools/setup_android.py` and `python tools/build_android.py`.
