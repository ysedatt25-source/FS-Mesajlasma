# FS Mesajlaşma 34.32 – ci.12 birleşik yayın adayı

**Durum: Yerel entegrasyon tamamlandı; üretim dağıtımı ve üretim imzası tamamlanmadı.**

Taban: kullanıcının sağladığı `FS-source-34.32-ci.12.zip`, SHA-256 `62cb178dd463c70472c237e41133bc14b100a1812d0f0f033ec2dbc7f99ee26a` (canlı Railway kaynak arşiviyle eşleşti). Önceki eski kaynak tabanlı sunucu dosyasının tamamı kopyalanmamıştır.

- Canlı tabanın `database.py`, `turn.py`, SQLite ve MariaDB şemaları, mesajların gönderici anahtarı geçmişi, alıcı anahtarı değişikliği kontrolü, TURN kimlik bilgileri ve yeniden bağlantı bekleme süresi korunur.
- İstemci kaynakları son PIN, telefonla yeniden giriş, mesaj seçimi/yanıtı, emoji, klavye/çağrı, gönder butonu ve ikon düzenlemeleriyle birleşmiştir; gönderici anahtarı geçmişi ve alıcı anahtar sürümü kontrolü yeniden entegrasyona dahil edilmiştir.
- Yeni API özellikleri: `emoji-interaction-v1`, `direct-delete-everyone-v1`, `presence-lease-v1`, `message-cache-check-v1`, `call-id-v1`. Yeni istemci yetenekleri sunucudan öğrenir; eski çağrı istemcileri desteklenir.
- Telefon eşdeğer yazımları, mükerrer hesap önleme, yeni cihazda doğru hesap şifresi ve anahtar doğrulaması, önceki oturumun iptali. Eski şifreli geçmiş, eski özel anahtar yoksa okunamaz.
- Kullanıcının kalıcı üretim veritabanına değişiklik yapılmamıştır. Yeniden kurulum fiziksel cihazda test edilmemiştir.

## Doğrulama – bu birleşik kaynak
49 HTTP/WebSocket API testi, 79 yeni bağımsız JS testi, 6 SQL adaptörü birim testi, 5 TURN birim testi ve 31 izole Chromium arayüz kontrolü başarılı (170 kontrol). Ayrıca gerçek ECDH/AES-GCM ile 3 emoji aktarımı ve kalıcı kayıt oluşmaması testi geçti. Eski JS test komutunun erişilebilir 10 testi başarılı; beş test dosyası eksik happy-dom/fake-indexeddb bağımlılıkları nedeniyle çalışmadı. Üretim MariaDB bağlantısı veya canlı TURN medya aktarımı doğrulanmadı. Eski docs/test-evidence dosyaları önceki sürüme aittir; güncel sonuçlar docs/ci12-merged-evidence altındadır.

## Dağıtım ve imzalama
Bu arşiv orijinal ci.12 ile aynı kaynak dizin yapısını kullanır. Mevcut Railway projesi fs-api, production, /data kalıcı volume ve mevcut ortam ayarları korunmalıdır. Yeni arşiv yetkili GitHub/CI ortamına yüklenmeli; önce geçici sentetik veriyle test edilmeli; üretim yayını yalnız onaylı dağıtımla yapılmalı. /health içinde integration=34.32-ci12-merged ve özellik listesi görünmelidir. Önceki yayın geri dönüş için korunmalıdır. Yayın ve doğrulama burada yapılmamıştır.

Android için orijinal asset arşivi araçla geri yüklenir (`python tools/fetch_assets.py`), ardından güvenli Android derleme ortamı gerekir. Emoji animasyon arşivi (ayrı release asset) bu küçük kaynak arşivine dahil değildir. Premium temel APK'sının mevcut web varlıkları üzerinde imza uyumlu güncelleme için `tools/prepare_apk.py` ve `web-patch/` sağlanmıştır. Script yalnız doğrulanmış Premium APK temelini ve mevcut sertifikayı kabul eder; orijinal anahtar güvenli imzalama ortamında kullanılmalıdır (FS_KEYSTORE, FS_KEY_ALIAS, FS_KEYSTORE_PASSWORD, FS_KEY_PASSWORD). Anahtar/parola sohbette paylaşılmamalı. Sertifika SHA-256 `30a4f0f403108ce30d349576d5f999df2c12f4dc839e90731bb93b136a487428`. Fiziksel Android kurulum, PIN, Bluetooth, iki telefonla arama, arka plan çağrısı, performans ve Telegram görsel uyumu ayrı yayın kabul testleridir. Mevcut uygulamayı kaldırmayın.
