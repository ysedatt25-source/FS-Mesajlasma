# 10–11. aşama: Fiziksel cihaz kabul planı

Kaynak/CI testleri fiziksel Android cihazı, Firebase teslimini veya pil tüketimini kanıtlamaz. V10 ile yeni kalıcı imzalı aday aynı cihazda, aynı ağ, ekran parlaklığı, yenileme hızı ve pil durumunda karşılaştırılmalıdır. Gerçek kullanıcı verisi yerine test hesapları kullanılmalıdır.

## Bildirim kabulü

- Android bildirim izni açık; kişi/grup adı ve profil resmi ayrı tercihlerdir. İkisi açıkken yalnızca yetkili bire bir sohbetin mevcut profil JPEG'i kullanılabilir. Kapalıyken avatar gönderilmez. Grup fotoğrafı bu modelde yoktur. Büyük veya geçersiz JPEG, ağ bütçesi aşımı halinde genel simgeye düşülür.
- Android kilit ekranı genel bildirimi gösterir; işletim sistemi gizlilik tercihleri geçerlidir. PIN kilitliyken mesaj metni ve medya bildirim içeriğine yazılmaz. Aç eylemi PIN sonrasında hedef sohbeti açar ve yüklü mesajı üç saniye vurgular. Yanıtla güvenli yazma alanını açar; otomatik göndermez.
- İki test hesabında açık sohbet, başka sohbet, arka plan, ekran kilidi, normal kapatma, yeniden açma, sessiz kanal, izin reddi, Bluetooth ve gerçek çağrı kabul/reddini ayrı doğrulayın. Android'in zorla durdurma ve pil kısıtlamaları teslimi engelleyebilir; başarı iddia edilmemelidir.
- Aynı sohbette iki yeni mesaj tek kart ve doğru sayıyla görünmeli; bildirimden okundu işlemi sadece hedefe kadar olan mesajları kapsamalı. Oturum değişikliği, ayar kapatma ve eski eylemlerin yeni bildirimi kaldırmaması test edilmeli.
- Firebase gerçek teslimi, canlı sunucu servis hesabı ve kayıt bağlama ile ayrıca doğrulanmalı; gerçek anahtarlar rapora alınmamalı.

## Performans ölçümü

Yetkili USB ADB ve kurulu imzalı APK gerekir. Araç, yalnızca `dumpsys meminfo`, `gfxinfo framestats` ve `battery` değerlerini özetler. Sohbet içeriği, ekran görüntüsü, logcat, token veya anahtar toplamaz. APK kurmaz, uygulama verisini silmez veya istatistikleri sıfırlamaz.

```sh
python tools/device_performance.py --scenario chat-scroll --seconds 120 --output chat-scroll.json
python tools/device_performance.py --scenario photo --seconds 120 --output photo.json
python tools/device_performance.py --scenario call --seconds 120 --output call.json
python tools/device_performance.py --scenario idle --seconds 600 --output idle.json
python tools/device_performance.py --scenario background --seconds 600 --output background.json
```

Her senaryoyu eski ve yeni sürümde en az üç kez tekrarlayın. PSS medyan/tepe, örneklenen kare süreleri p95 ve jank oranını kıyaslayın; süreç değişimi veya şarj bağlantısı değişimi olan ölçümü geçersiz sayın. Android `gfxinfo` WebView veya görüşme video FPS'sini tam olarak ölçmez; gerçek video FPS için görüşmenin WebRTC istatistikleri ve kontrollü ekran kaydı/Perfetto ölçümü gerekir. Pil verisi tüm cihazın değişimidir; uygulamaya özgü tüketim sayısı olarak sunulmaz. Düşük pil ölçüm çözünürlüğünde daha uzun eş süreli koşu gerekir. Test tamamlanana kadar 10–11. aşamalar cihaz doğrulaması bekliyor sayılır.
