# Tek sunucu hazırlığı

`deploy/compose.yaml` API, SQLite ve HTTPS vekilini aynı sunucuda çalıştırmak
için bir şablondur. Dosyayı hazırlamak yayın yapmak değildir.

- Gerçek alan adını `FS_DOMAIN` olarak belirleyin.
- Aynı sunucuda coturn kurun; örnek yapılandırmayı doldurun.
- `FS_TURN_HOST` ve en az 32 karakterlik rastgele `FS_TURN_SECRET` verin.
- 80/443 TCP, 3478 UDP/TCP ve seçilen TURN röle portlarını yapılandırın.
- TURN için yerel/özel ağ adreslerine röle erişimini kapalı tutun.
- Yönetici hesabını sohbetler oluşturulmadan önce yerel komutla yapılandırın.
- Yönetici ve diğer hesapların kişisel anahtar dosyalarını kullanıcıların
  kendi cihazlarında koruyun; sunucuya özel anahtar yüklemeyin.

Çağrı medyası kaydedilmez. STUN/TURN bağlantı sağlar; bir görüşme kayıt
servisi uygulanmadı. Uygulama kendi otomatik veri yedekleme işi oluşturmaz.
Ancak sunucu sağlayıcısının altyapı yedekleme ve kayıt davranışı ayrıca
doğrulanmalıdır. Ücretsiz kota veya sıfır yedek garantisi verilmez.

Android'in eski (push içermeyen) varyantı kendi sunucusuna uzun istek yapan
ön plan servisini kullanır. FCM push varyantı ise bu servisi kullanmaz;
sunucuda `FS_FCM_PROJECT` ve eşleşen Firebase kimliği (`FS_FCM_SERVICE_ACCOUNT_JSON`
veya Application Default Credentials) yapılandırılmalı, cihazda bildirim
izni verilmelidir. Hizmet hesabı özel anahtarı yalnızca korunan sunucu
ortamında tutulur; APK, kaynak deposu veya Android CI ortamına eklenmez.
İstemci yapılandırması ile sunucu kimliğinin aynı Firebase projesine ait
olduğunu kontrol edin. Gerçek cihazlarda arka plan çağrı ve mesaj teslimi,
Doze ve pil davranışı sınanmadan sürekli ulaşılabilirlik garantisi verilmez.
Android tarafından zorla durdurulan uygulama için çağrı teslimi garanti edilmez.

Canlı MariaDB geçişinden önce mevcut verinin yedeği ve geri yükleme testi,
izole veritabanında şema geçişi ve geri dönüş planı doğrulanmalıdır.
Yöneticiye ayrıca şifrelenmiş zarf sunulan sohbetler, yönetici erişimini
engelleyen Signal eşdeğeri uçtan uca şifreleme olarak tanımlanmamalıdır.
