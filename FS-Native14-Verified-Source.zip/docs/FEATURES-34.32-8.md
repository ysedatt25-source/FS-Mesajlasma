# FS Mesajlaşma 34.32 / Android sürüm kodu 8

## Uygulanan özellikler
1. Sohbet bazında metin taslağı, yanıt hedefi ve kaydırma konumu cihazda şifreli saklanır. Aynı hesapla yeniden girişte taslak geri gelir.
2. Son sohbetler ve mesaj sayfaları cihazdaki şifreli önbellekten açılır; ağ yanıtları arka planda yenilenir. Geçici ağ hatasında PIN ile önbellekteki sohbetlere erişilir. Geçersiz/sona ermiş oturum için yeniden giriş gerekir.
3. Çevrimdışı gönderilen metinler açık bir gönderim kuyruğunda gösterilir. Bağlantı geri gelince aynı mesaj kimliği kullanılır; sunucu tekilleştirmesi korunur. Kuyrukta yeniden deneme ve kaldırma vardır. Yerel saklama başarısızsa mesajın korunduğu iddia edilmez. Kuyruk metin içindir ve 100 öğeyle sınırlıdır.
4. Tümü, Okunmamış, Gruplar ve Arşiv filtreleri; sabitleme, arşivleme ve arşivden çıkarma eklendi. Bu tercihler bu cihaz ve hesap içindir.
5. Sohbet içinde Türkçe metin/dosya adı arama, tarihe göre filtre ve asıl mesaja atlama eklendi. İlk arama yüklenen mesajları kapsar; “Daha eski geçmişte ara” her basışta en fazla 800 ek mesajı tarar. Tüm geçmiş baştan indirilmez.
6. Ses kaydında yukarı sürükleyerek veya düğmeyle kilitleme, duraklatma/devam, bitirip dinleme ve vazgeçme eklendi. Sayaca duraklama süresi dahil edilmez. Web Audio desteklendiğinde gerçek mikrofon örneklerinden ses seviyesi gösterilir; destek yoksa bu açıkça belirtilir.
7. Mesaj seslerinde 1×, 1,5× ve 2× hız; kaldığı saniyeyi ve hızı hatırlama eklendi. Oynatma konumu cihazda şifreli saklanır.
8. Medya ilk 100 kayıtla açılır, eski sayfalar istek üzerine yüklenir. Dosya adı, tür ve tarih filtreleri eklendi. Filtreleme ve toplu indirme yüklenmiş dosyaları kapsar.
9. Dosya indirme ilerlemesi dosyanın yanında gösterilir. Hata halinde yeniden deneme vardır; tam dosya isteği yeniden başlatılır. Yarım indirmeyi bayt seviyesinde sürdürme eklenmedi. Mevcut parçalı yüklemeye devam özelliği korunur.
10. Kayıtlı mesajlarda yerel etiketler, metin/etiket arama, sohbet filtresi ve asıl mesaja dönme eklendi.
11. Okunmamış mesaj ayracı ve en yeniye dönüş düğmesi eklendi. Eski mesaj okunurken yeni mesaj geldiğinde zorla aşağı kaydırılmaz. Okundu işareti listenin sonuna ulaşınca güncellenir.
12. Çağrı için bağlanıyor/yeniden bağlanıyor durumu ve RTT/paket kaybına dayalı basit ağ zayıflığı göstergesi eklendi. Gerçek cihaz ağ geçişi/Bluetooth testinin yerine geçmez.
13. Yeşil/kırmızı müsaitlik tiki ve iki saniyelik küçük durum yazısı, alan bazında kayıt uyarıları ve önceki sürüm düzeltmeleri korunur. Yeni sistem/mesaj bildirimleri eklenmedi.

## Akıcılık değişiklikleri
- Ölçülen yüksekliklerle yalnız görünür bölgeye yakın mesaj satırları DOM'a eklenir. Kaydırma konumu bir mesaj kimliği ve satır içi farkla korunur; eski sayfa eklendiğinde kayma azaltılır.
- Tepki, anket oyu ve yanıt bulma için bir kez indeks hazırlanır. Görünmeyen mesajların HTML'i hazırlanmaz.
- WebSocket olayları kısa aralıkta birleştirilir. Okundu olayları tüm listeyi sunucudan tekrar istemeden uygulanır.
- Destekli WebView'da dosya şifreleme ve küçük resim hazırlığı ayrı iş parçacığında yapılır; destek yoksa işlevsel geri dönüş vardır. Büyük dosya hazırlıkları sırayla yürür.
- Küçük resimler görünürken açılır; nesne URL önbellekleri sınırlıdır. Yerel mesaj önbelleği en fazla 10 sohbet sayfası × 80 mesajdır; her sayfa ayrıca yaklaşık 300.000 JSON karakteriyle sınırlıdır. Son 40 sohbetin metaverisi saklanır. Yerel önbellek sağlayıcı yedeği değildir; yeni sunucu yedeklemesi açılmadı.

## Doğrulama ve sınırlar
40 JavaScript testi, 32 DOM + gerçek yerel HTTP/WebSocket senaryosu, 41 Python testi geçti (113 kontrol). Medya işçisi bağımsız Node iş parçacığında şifreleyip çözme testiyle doğrulandı. Ses testleri sentetik kayıt olayları ve WAV verisi kullanır.

Sentetik Happy DOM ölçümünde 10.000 mesaj için 14 satır bağlı kaldı; indeks yaklaşık 1,5 ms ve ilk pencere yaklaşık 4,3 ms ölçüldü. Bu, yürütme ortamına ait sentetik sonuçtur; Android ekran çizimi, FPS, internet gecikmesi veya WhatsApp karşılaştırması değildir.

Android API35 derleme ve mevcut anahtarla APK imzası doğrulanır. Fiziksel telefonlarda mikrofon/codec, Bluetooth, kamera, Doze, küçük pencere, gerçek çağrı ve 60 FPS kabul testleri tamamlanmadı. Telefonun zorunlu sistem hizmeti göstergeleri Android kurallarına tabidir.

Sunucu kodu ve canlı veritabanı bu sürümde değiştirilmedi. Korunan diğer siteler ve veritabanlarına dokunulmadı.
