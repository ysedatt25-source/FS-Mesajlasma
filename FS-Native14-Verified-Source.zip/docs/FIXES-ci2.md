# 34.32 / versionCode 2

Screenshot protection removed at the Android window. Account registration now accepts 6–256 characters; calculator PIN remains at least 6 digits.

Registration 404 root cause: the APK used appassets.androidplatform.net as its API origin when no server was configured. This is an asset host, not a backend. The client now rejects it before any credentials are sent. A server must pass an identifiable health check before registration or saving a changed endpoint. Invalid URLs and unavailable servers show actionable errors; failed endpoint checks preserve the current session.

No persistent live backend has been deployed. Registration succeeds against the local integration-test API with a six-character password. Production registration still requires a deployed updated API. This is not a full production release or a physical-device test report.
