# FS Mesajlaşma 34.32 / sürüm kodu 6 genel inceleme

İncelenen alanlar: kayıt/giriş ve oturum, şifreleme/anahtar yedeği, sohbet/yanıt/sayfalama, kişi arama/sekmeler, dosya yükleme/indirme, ses kaydı/oynatma, emoji, arama sinyalleri/izinler, canlı konum, anket/grup/etkinlik, profil/ayarlar, hesap makinesi ve Android köprüsü.

Düzeltmeler:
1. Geciken mesaj gönderim onayı farklı sohbetin mesaj listesine eklenmez.
2. Başarısız gönderim, kullanıcı o sırada yeni metin yazdıysa bu metni silmez; eski taslak da korunur.
3. Sohbet değişiminde yanıt ve tepki hedefi temizlenir; farklı sohbet mesajına yanıt gönderilmez. Geciken gönderim yeni yanıt seçimini temizlemez.
4. Önceki mesaj sayfası, ekran veya sohbet değiştikten sonra yeni listeye karışmaz.
5. Kişiler/Aramalar yanıtı, kullanıcı sekme değiştirdiyse yeni sekmenin içeriğini değiştirmez.
6. Kullanıcı aramasında yalnız son isteğin ve açık formun sonuçları gösterilir.
7. Sohbet yenilemeleri sıraya alınır; eşzamanlı yeni sohbet oluşturma ve WebSocket yenilemesi birbirinin sonucunu geçersiz kılmaz.
8. Tek bekleyen şifreli yükleme için eşzamanlı başlatma/devam ettirme engellenir. Devam eden yükleme sırasında silme yarışı önlenir.
9. Yükleme ofsetinin tam sayı ve beklenen uzunlukta ilerlediği doğrulanır; bozuk yanıtta sonsuz döngüye girilmez. Bulunamayan sohbet için sessiz başarı verilmez.
10. Gönderilecek içerik de şemadan doğrulanır; alıcıda açılamayacak aşırı uzun anket seçeneği gibi içerikler gönderilmez.
11. Grup ve etkinlik formundaki asenkron hatalar yakalanıp açıklanır. Ana liste yükleme hatası görünür olur.
12. Oturum değiştikten sonra eski kimlikle gelen API yanıtı kullanılmaz; çıkışta kişi/yanıt/anahtar önbelleği ve yeniden bağlanma zamanlayıcısı temizlenir.
13. Çıkışta tarayıcı canlı konum izleyicileri durdurulur; geç gelen koordinat/izin sonucu eski oturumla gönderilmez.
14. Arama yapılandırması beklenirken çağrı kapandıysa mikrofon açılmaz. Geciken medya hazırlığı kapatılmış bağlantıda SDP/teklif işlemi başlatmaz; kapatılan çağrının ICE/track dinleyicileri temizlenir.
15. Android'de eşzamanlı mikrofon/kamera izin istekleri bekleyen isteğin üzerine yazılmaz.

Doğrulama: 27 JavaScript birim testi, 19 DOM + gerçek yerel HTTP/WebSocket senaryosu ve 41 Python testi geçti (87 kontrol). Geciken sekme yanıtı, başka sohbet sırasında gönderim onayı, başarısız gönderim sırasında yeni taslak ve eşzamanlı dosya yükleme için yeni senaryolar eklendi. Android derleme ve imza ayrıca doğrulanır.

Sınır: DOM emülasyonu fiziksel cihaz testi değildir. Gerçek Android mikrofon/codec, Bluetooth, Doze, kamera, küçük pencere ve iki telefon araması kabul testleri tamamlanmadı. İnceleme tüm uygulamanın hatasız olduğu garantisi değildir. Sunucu kodu ve canlı veritabanında bu sürümde değişiklik yapılmadı.
