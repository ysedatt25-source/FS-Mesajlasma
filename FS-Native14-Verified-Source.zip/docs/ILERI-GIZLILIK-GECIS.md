# İleri gizlilik sağlayan protokole geçiş

Durum: Uygulanmadı. Mevcut şifreleme ve kullanıcı kontrollü anahtar yedeği korunmuştur. Bu aday Signal uyumlu veya Double Ratchet uygulaması değildir.

Mevcut `web/crypto.js` ECDH P-256 anahtarlarıyla zarf şifrelemesi kullanır. `server/app.py` içindeki `validate_envelopes` oda üyelerine ve yapılandırılmış yönetici denetim hesabına ayrı zarfı zorunlu tutar. Dolayısıyla uzun ömürlü anahtarın ele geçirilmesine karşı eski mesajların ileri gizliliği, Signal düzeyinde garanti edilemez. Yönetici erişimi önceki açık tasarım şartıdır; sessizce kaldırılmaz. Yöneticiye yeni mesaj zarfı gönderilmeye devam ettiği sürece sistem yalnızca sohbet katılımcılarının eriştiği bir Signal eşdeğeri değildir.

Uygulama öncesi güvenlik tasarımı: bakımı sürdürülen ve uygun lisanslı denetlenmiş ratchet kütüphanesi seçimi, kimlik ve ön anahtar doğrulaması, tek kullanımlık ön anahtar tüketimi, oturum ve ratchet durumunun atomik yerel kaydı, sırasız teslimat/tekrar saldırısı sınırları, grup üye değişiminde anahtar döndürme, cihaz değişimi ve güvenlik numarası doğrulaması. Yeni protokol sürümlendirilmeli, eski mesajların şifreli geçmişi ayrı okunmalı, güvenlik sessizce düşürülmemeli. Yönetici erişimi korunacaksa yönetici ayrı yetkili alıcı olarak açıkça belirtilmeli ve anahtarları ayrı değerlendirilmeli; yalnızca katılımcılara erişim isteniyorsa yeni mesajların yönetici zarfı kaldırılmalı. Geçmişi saklama politikası cihaz ele geçirilmesi tehdidinden ayrı değerlendirilmelidir. Kütüphane entegrasyonu, protokol test vektörleri, cihazlar arası entegrasyon ve bağımsız güvenlik incelemesi tamamlanmadan üretime geçilmemeli.

Resmi protokol: https://signal.org/docs/specifications/doubleratchet/ ; kütüphane: https://github.com/signalapp/libsignal

## Yeni adayın durumu

FCM derleme hazırlığı güvenlik protokolünü değiştirmez. `web/crypto.js`, `web/app.js`, mevcut gizlilik metni ve emoji katalogları önceki adayla birebir karşılaştırılmıştır. Signal'ın güncel libsignal Android kütüphanesi Maven üzerinden kullanılabilir, ancak Signal dışı kullanım resmi olarak desteklenmez. Lisans uyumu, güvenli kalıcı ratchet deposu, ön anahtar servisleri, anahtar değişimi, medya ve grup şifrelemesi, sürüm azaltma saldırılarına karşı koruma ve bağımsız inceleme olmadan ileri gizlilik etiketi eklenmemiştir. Yeni mesajların yöneticiye de açılacağı model ile yalnızca sohbet katılımcılarının okuyabildiği model açıkça ayrılmalıdır. Bkz. https://github.com/signalapp/libsignal .
