# FS Mesajlaşma 34.32 / Android 5 etkileşim düzeltmeleri

1. Ses kaydının görünmez durumu: mikrofon izni bekleme, kırmızı kayıt noktası, “Ses kaydediliyor”, dakika/saniye sayacı ve hazırlama durumu eklendi.
2. Kaydı göndermeden dinleme ve vazgeçme eklendi. Önizleme kapatılsa bile sohbet üzerinde “Ses kaydı hazır / Dinle-Gönder” kalır.
3. Parmak mikrofon izni gelmeden bırakılırsa sonradan açılan mikrofon hemen kapanır; boş kayıt oluşmaz.
4. Pointer iptalinde kayıt atılır. Pointer-up ve lost-pointer-capture birlikte gelirse tamamlanan kayıt yanlışlıkla iptal edilmez.
5. Sohbet değiştirme, kilitleme, çağrıya geçme veya uygulamanın arka plana alınması sırasında devam eden kayıt iptal edilir ve mikrofon bırakılır. Tamamlanan kayıt başka sohbete taşınmaz.
6. Cihazın desteklediği ses biçimi seçilir; mp4 için m4a, ogg için ogg, webm için webm uzantısı kullanılır.
7. 300 ms altı/boş kayıt gönderilmez; izin reddi ve kayıt hatası için açık açıklama verilir. Kayıt süresi 10 dakika ile sınırlıdır.
8. Çift gönderim engellendi. Gönderim hatasında kayıt korunur; aynı bekleyen ses dosyası varsa kaldığı yerden yüklenir.
9. Emoji dokunma efektindeki sabit kelebek kaldırıldı. Efekt doğrudan mesajın emoji verisini kullanır; görüntü alt metni, zaman damgası ve tepki yazılarıyla karışmaz.
10. Bayrak, ten rengi, birleşik aile ve tuş emojileri tek emoji olarak tanınır. Emoji metninin dışındaki normal yazılar efekt üretmez.
11. Hızlı dokunmalarda efektler üst üste birikmez; azaltılmış hareket ayarı korunur. Emoji görseli yüklenmezse metin emojisine dönüşür.
12. Profil fotoğrafı seçimi çoklu seçim ayarını kapalı bırakıyordu; galeri/belge açılırken yeniden ayarlanır.
13. Dosya seçici açıkken sohbet değişse bile dosya ilk seçilen sohbete gönderilir.
14. Ses indirilirken sohbetten çıkıldığında olmayan ses öğesine erişim hatası önlendi. Aynı anda bir mesaj sesi çalar; yeni kayıt başlarken önceki mesaj sesi durur.
15. Ses URL önbelleği 32 öğeyle sınırlandı. Çıkışta ses/önizleme URL'leri ve ekrandaki hesap verileri temizlenir. Sunucuya ulaşılamasa da yerel oturum kapanır; uzaktaki oturumun kapandığı iddia edilmez.

Doğrulama: 27 JavaScript testi, 15 DOM/gerçek yerel HTTP-WSS senaryosu, 41 Python testi geçti. Yeni testler geç izin, tekrarlı bırakma, iptal, MIME, çok kısa kayıt, emoji kimliği/tekillik ve azaltılmış hareket durumlarını içerir. Android derleme ve imza ayrıca doğrulanır. Testlerde sentetik ses parçası kullanılır; gerçek Android mikrofon/codec, Bluetooth ve iki telefon araması kabul testi yapılmış sayılmaz. Bütün uygulamanın hatasız olduğu iddia edilmez.
