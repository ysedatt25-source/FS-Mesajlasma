# 34.32 / versionCode 3

Independent Railway API: https://fs-api-production-db5b7157.up.railway.app
Persistent storage: fs-data, 500 MB, /data. No previous sites/databases modified. No automatic application backup job created. Provider billing/retention is not claimed free or absent indefinitely.

Default Android API endpoint is bundled, so first-time users do not need to enter a server URL. Six-character account minimum and six-digit calculator PIN retained. Screenshot protection remains removed.

Live synthetic tests passed: HTTPS registration/login and Android-origin CORS; private username search and room creation; WSS encrypted messages and peer decryption; encrypted file upload/download/decryption; call signaling invite/accept/hangup. Test message and file were removed. Two synthetic test accounts remain.

Fixed same-millisecond pagination with timestamp + ID cursor and validated malformed registration field types. STUN-only configuration no longer reports TURN ready.

Remaining limitations: no configured TURN relay, no physical two-phone media/Bluetooth/Doze validation, no complete admin UI/security audit/visual parity certification. The admin-device audit identity is not provisioned in the live service; existing code can support it after owner setup. API messages are not evidence of successful audio/video media. No zero-defect or WhatsApp speed claim.
