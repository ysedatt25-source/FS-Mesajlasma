# FS Mesajlaşma 34.32 / Android sürüm kodu 9 — yeniden kurulumda giriş

- Temiz kurulumda ilk ekran mevcut hesaba giriş ekranıdır. Kayıt ayrı ve isteğe bağlıdır.
- Kullanıcı adı veya telefon ve hesap şifresiyle aynı kullanıcı kimliğine giriş yapılır. Türkçe 05… / +905… telefon biçimleri girişte eşleştirilir.
- Yeni kurulumda doğru parola doğrulandıktan sonra yeni cihazın P-256 açık anahtarı doğrulanır ve hesaba bağlanır. Eski oturumlar geçersiz kılınır; açık bağlantılar ve eski çağrı durumu kapatılır. Aynı anahtarla normal giriş diğer oturumları değiştirmez.
- Hesap, profil, kişiler, grup ve sohbet üyelikleri korunur. Yeniden üyelik ve davet kodu istenmez.
- Girişten sonra bu kurulum için bir kez en az 6 rakamlık hesap makinesi kilidi oluşturulur. Bu yerel kilit hesap şifresinden ayrıdır.
- Özel anahtar buluta yedeklenmez. Uygulama silinince eski cihaz anahtarı, taslaklar ve yerel önbellek kaybolur. Önceki anahtar yedeği yoksa yeniden kurulan cihaz eski şifreli mesajları açamaz. Giriş ve yeni mesajlaşma çalışır. Yedeği olan kullanıcı girişten önce içe aktararak eski anahtarını koruyabilir.
- Her mesajın gönderici açık anahtarı kaydedilir. Bir kullanıcının cihazı değişince karşı taraf kendi mevcut anahtarıyla önceki mesajları açmaya devam edebilir. Bu desteği kullanmak için güncel APK gerekir.
- Güncel istemci alıcının anahtarını doğrulatarak gönderir; anahtar değişmişse sohbet anahtarları bir kez yenilenip aynı mesaj kimliğiyle tekrar denenir.

Doğrulama: 40 JavaScript testi, 34 DOM + gerçek yerel HTTP/WebSocket senaryosu ve 45 Python testi geçti (119 kontrol). Tamamen boş IndexedDB ve yeni cihaz kimliğiyle aynı hesaba giriş, yerel kilit oluşturma, eski oturum geçersizliği ve karşı tarafın eski/yeni anahtarlı mesajları çözmesi test edildi. Yanlış parola, bozuk/özel anahtar içeren JWK ve eski alıcı anahtarı reddi doğrulandı.

Fiziksel Android kaldır/kur testi yapılmadı; temiz cihaz durumu DOM/HTTP testinde taklit edildi. Bluetooth, kamera, Doze ve iki telefonla arama kabul testleri bu değişiklik kapsamında tamamlanmış sayılmaz.

Sunucu değişikliği yalnız bağımsız FS API içindir. Mevcut tablolara veri silen bir geçiş uygulanmaz; açık mesaj anahtarlarını tutan ek tablo oluşturulur. Diğer siteler/veritabanları değiştirilmez. Sağlayıcı yedeklemesi açılmaz.
