# Native14 yayın ve geri dönüş planı

Mevcut canlı sunucu sürümü: Railway deployment a5325ef3-b1dc-4425-9ac2-9d43b20b06df. Kaynak referansı 0e4074b38fdf1b10a9948cbb7bd6946bf3bff8c6; canlı /data/fs.sqlite dosyası korunacaktır.

1. Tüm testlerin ve imza karşılaştırmasının geçmesi gerekir. Native14 sürüm kodu 14, paket com.fs.mesajlasma; eski APK kodu ayrıca aapt ile kontrol edilmelidir.
2. Önce staging ortamında boş ve eski şemalı sentetik veritabanlarında geçiş doğrulanır. Gerçek kullanıcı kayıtları test ortamına kopyalanmaz.
3. Canlı geçişten önce kullanıcı onayı alınır. Onay; yeni tabloların oluşturulmasını, yeni sunucu kodunun başlatılmasını ve kontrollü kısa bakım süresini kapsar. /data birimi yeniden oluşturulmaz; kullanıcı veya şifreleme anahtarı silinmez.
4. Veri geri dönüşü gerekiyorsa, canlı yazmaları durdurarak yalnızca kullanıcı onayıyla kısa ömürlü, erişimi sınırlı bir geçiş kopyası alınır. Kalıcı otomatik yedekleme kendiliğinden etkinleştirilmez. Kopyanın saklama/silme süresi onayda belirlenir.
5. Geçiş sonrası /health, mevcut veritabanı bütünlüğü, eski kullanıcı giriş uyumluluğu ve WebSocket kontrol edilir. Canlı test hesabı oluşturulması ayrıca açıkça işaretlenir.
6. Hata varsa yeni sürüm durdurulur ve önceki kaynak/başlatma komutu geri yüklenir. Yeni kullanıcı yazıları alındıktan sonra eski veritabanı kopyası doğrudan geri yüklenmez; yeni yazılar kaybedilmemelidir.
7. Android sürüm düşürme normal kurulumla desteklenmez. APK geri dönüşü aynı anahtar ile daha yüksek versionCode içeren önceki çalışan kaynak derlemesiyle yapılır. Kullanıcıdan uygulamayı silmesi istenmez.

Bu belge bir hazırlık planıdır. Canlı geçiş veya veri kopyalama yapılmış olduğunu göstermez.
