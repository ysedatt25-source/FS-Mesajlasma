# Plesk / MariaDB uyarlaması — kurulum bekliyor

Ekran görüntüsünde MariaDB 11.4.13 ve localhost:3306 görülüyor.
Bu, sürekli çalışan Python/aiohttp API, WebSocket ve TURN çalıştırma hakkını
kanıtlamaz. Plesk'in WSGI Python uzantısı tek başına aiohttp sunucusunu çalıştırmaz.
SSH + sürekli servis veya Docker ve WebSocket ters vekil desteği doğrulanmalıdır.
Paylaşımlı PHP/MariaDB paketi mevcut sunucu kodu için yeterli değildir.

## Veritabanı formu

- Veritabanı adı: `fs_mesajlasma`; uygulama görünen adı: FS Mesajlaşma.
- Sunucu: ekranda görülen yerel MariaDB. API aynı makinede çalışacaksa 127.0.0.1:3306.
  Docker içinde localhost konteynerdir; yönetici uygun özel ağ adresini belirlemelidir.
- Ayrı veritabanı kullanıcısı; yalnızca bu veritabanına erişim.
- “Tüm veritabanlarına erişim” kapalı kalır.
- Var olan sitenin veritabanını, kullanıcısını ve verilerini değiştirmeyin.
- Üretilen parola yalnızca sunucudaki web kökü dışındaki ortam dosyasına girilir.

## Sunucu kurulumu

`deploy/plesk/fs.env.example` gerçek panelde oluşan veritabanı ve kullanıcı adıyla
uyarlanır. `FS_DB_BACKEND=mariadb` MariaDB sürücüsünü etkinleştirir; varsayılan
SQLite yerel testler için korunur. `server/requirements.txt` bağımlılıkları kurulur.
`schema.mariadb.sql` InnoDB, utf8mb4, yabancı anahtarlar ve oda/zaman indeksini içerir;
uygulama başlangıcında tabloları yeni FS veritabanında oluşturur. Bu otomatik işlem
mevcut SQLite geçmişini taşımaz; bu çalışma alanındaki geçmiş test verisidir.
Gerçek geçmiş varsa ayrı yedekleme ve doğrulanmış taşıma gerekir.

Hizmet örneği /opt/fs-mesajlasma altında ayrı Linux kullanıcısı ve sanal ortam
varsayar. /var/lib/fs-mesajlasma bu kullanıcıya ait, 0700 olmalıdır; ortam dosyası
root tarafından okunabilir 0600 tutulmalıdır. SQL tablosu kurulumu CREATE/INDEX
hakları gerektirir; çalışma hesabı yalnız FS veritabanıyla sınırlanır.
`fs-mesajlasma.service` ve `nginx.conf.example` yönetici uyarlaması gerektiren
şablonlardır; otomatik kurulum veya yayın yapıldığı anlamına gelmez.

İlk yönetici hesabı uygulamada oluşturulduktan sonra aynı ortam değişkenleriyle
`python server/manage.py promote KULLANICI_ADI` çalıştırılır.
Şifreli dosyalar FS_DATA altında tutulur; MariaDB kimlik ve mesaj kayıtlarını tutar.
MariaDB portu internete açılmaz. Harici DB gerekiyorsa FS_DB_TLS_CA ile sunucu
sertifikası ve adı doğrulanır. APK yalnız HTTPS API adresini bilir.

TURN için aynı sağlayıcıda coturn ve gerekli UDP/TCP portlarına izin gerekir.
Yalnız MariaDB oluşturmak sesli/görüntülü görüşme altyapısını tamamlamaz.

## Kontrol durumu

MariaDB sürücüsü, şema, kullanıcı oluşturma ve yönetici komutu uyarlanmıştır.
Yerel SQLite API testleri MariaDB üzerinde test yapılmış anlamına gelmez.
Gerçek MariaDB bağlantısı, panel yetkileri, HTTPS/WebSocket, TURN ve iki Android
cihazla test henüz yapılmadı. Tüm ürünün hazır olduğu söylenemez.
