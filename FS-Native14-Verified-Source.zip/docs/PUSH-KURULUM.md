# İsteğe bağlı Firebase Cloud Messaging (FCM) kurulumu

Durum: sunucu ve Android kaynak kodu eklenmiştir. Gerçek Firebase projesi, SDK derlemesi, canlı sunucu ve fiziksel cihaz teslimi henüz doğrulanmamıştır. Varsayılan mevcut APK derleme yolu push çeşidini içermez. Canlı sistem değiştirilmemiştir.

1. Firebase projesinde Android uygulaması olarak `com.fs.mesajlasma` kaydedilir. Projenin `google-services.json` dosyası `android/app/google-services.json` veya `android/app/src/push/google-services.json` konumuna yerel olarak eklenir.
2. Sunucuda mevcut gereksinimlerin yanında `server/requirements-push.txt` yüklenir. `FS_FCM_PROJECT` gerçek Firebase proje kimliğine ayarlanır. Firebase Admin SDK için Application Default Credentials güvenli şekilde sağlanır (örneğin `GOOGLE_APPLICATION_CREDENTIALS` dosya yolu). Hizmet hesabı anahtarını public GitHub ZIP'ine veya sohbet mesajına koymayın. Android yapılandırması sunucu hizmet hesabı anahtarı değildir.
3. `python tools/fetch_assets.py` ve `python tools/verify_release_assets.py` çalıştırılır. Uyumlu Gradle/JDK 17, Android SDK 35 ile `cd android && gradle -PfsPush :app:assemblePushRelease` çalıştırılır. Önceki manuel Android derleyicisi Firebase bağımlılıklarını içermez; nihai CI akışı buna göre değiştirilmelidir. İmzalama mevcut kalıcı anahtarla, özel olarak yapılır.
4. Sunucu ve APK birlikte test ortamında çalıştırılır. Oturum, izin, kayıt iptali, tekil bildirim, grup çağrısı, arka plan, kilit, ağ değişimi ve gerçek FCM teslimi doğrulanır. Android zorla durdurma ve üretici pil kısıtları altında teslim garanti edilmez.

FCM veri sinyali yalnızca `kind` ve rastgele `binding` içerir. Uygulama geçerli çağrıyı yetkili olarak API'den kontrol eder. Mesaj metni veya arayan kimliği FCM yükünde bulunmaz. Sağlayıcının cihaz/hedef tokenı ve teslim metaverisini işlemesi gerekir.

Resmi kaynaklar: https://firebase.google.com/docs/android/setup ; https://firebase.google.com/docs/cloud-messaging/android/receive ; https://firebase.google.com/docs/cloud-messaging/auth-server

## Bu adayda tamamlanan derleme düzeni

- `tools/build_push_ci.sh` ile SHA-256 doğrulamalı Gradle 8.9, SDK 35 ve `assemblePushRelease` kullanılır. Kaynaklar ve 3.757 emoji paketi doğrulanır; push alıcısı, Firebase SDK sınıfı ve oluşturulan Firebase kaynakları APK içinde yoksa derleme başarısız sayılır.
- CircleCI ortam değişkenleri: `FS_FCM_PROJECT` ve `FS_GOOGLE_SERVICES_JSON_B64` (Android uygulamasının google-services.json dosyasının Base64 kodlaması). Hizmet hesabı anahtarı CircleCI'ye konulmamalıdır. Geçici Android dosyası arşivlenmez.
- Railway ortam değişkenleri: `FS_FCM_PROJECT` ve güvenli, tercihen sealed `FS_FCM_SERVICE_ACCOUNT_JSON` (aynı Firebase projesinden, FCM gönderim yetkili servis hesabı), veya ADC. `server/requirements-push.txt` ayrıca yüklenmelidir. Anahtar bellekte okunur, diske yazılmaz ve loglanmaz. Proje uyuşmazlığı veya eksik ayar yanlışlıkla etkin bir sağlayıcı gibi gösterilmez.
- Yerel testler sentetik yapılandırma ve test taşıyıcısı kullanır. Gerçek Firebase projesi oluşturulmadı; Railway yetkilendirmesi doğrulanmadı; Gradle SDK/APK ve telefon teslimi bu ortamda doğrulanmadı. Bu arşiv üretim sürümü değildir.

Gradle resmi uyumluluk tablosu: https://developer.android.com/build/releases/past-releases/agp-8-7-0-release-notes . Gradle dağıtım özeti: https://gradle.org/release-checksums/ . FCM yetkilendirme: https://firebase.google.com/docs/cloud-messaging/send/v1-api .
