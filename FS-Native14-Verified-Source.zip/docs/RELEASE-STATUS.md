# Yayın durumu: BEKLİYOR

Bu teslimde hiçbir eski sağlayıcı yeniden yapılandırılmadı ve uygulama
internete yayınlanmadı. Sunucu hazırlığı dosya şablonları düzeyindedir.

## Yazılan ve otomatik olarak kontrol edilenler

- Hesap, davet kodu, SMS'siz kayıt, yerel PIN ve hesap makinesi.
- Kullanıcı adıyla kişi bulma; numara gizliliği; kişi silme/geri alma;
  engelleme; birebir/grup odaları ve üyelik denetimi.
- Cihazda şifreli mesaj/dosya; yanlış anahtar ve değiştirilmiş içerik reddi;
  şifreli anahtar dışa/içe aktarımı.
- Gerçek HTTP/WebSocket üzerinden mesaj gönderimi ve karşı tarafta çözme.
- Mesaj düzenleme/silme/kaydetme, anket, emoji seçimi, tema ve profil akışları.
- 50 MB sınırı, parçalı yükleme, sürdürme ve yetkisiz dosya erişiminin reddi.
- Mesaj silindiğinde ona bağlı son dosya kopyasının sunucudan kaldırılması.
- Yönetici yetki kontrolü ve yönetici için ek şifreli içerik zarfı.
- Arama başlatma/kabul/bitirme sinyalleri ve aranabilirlik kontrolü.
- Sohbet üyeliğine bağlı okundu makbuzları; tek tik sunucuda kayıt, çift tik
  en az bir diğer katılımcının mesajı okuduğunu bildirir.

## Kodu yazılan, gerçek Android cihazda doğrulanması gerekenler

- Kamera ve dosya seçici, son fotoğraflar şeridi, ses kaydı/sohbet içinde oynatma, indirme ve paylaşma.
- Süreli arka plan konum servisi; servis anahtarları yalnızca bellekte tutulur,
  süre dolunca veya kullanıcı durdurunca paylaşım kapanır. Gerçek GPS/ağ ve
  uygulama kapatma testleri yapılmadı.
- Son fotoğraflar şeridi ve Android 14 seçili fotoğraf izinleri gerçek
  cihazda denenmedi; kod derleme kontrolünden geçmelidir.
- Sesli/görüntülü görüşme medyası, kamera açma/kapatma, Bluetooth, hoparlör,
  küçük görüntü taşıma/değiştirme ve görüşme sürerken sohbet.
- Arka planda kendi sunucusuna uzun bağlantı; çağrı/mesaj bildirimleri,
  Android izinleri, Doze ve üretici pil yönetimi.
- Klavye, farklı ekran boyları, kaydırarak seçim ve erişilebilirlik.
- QR kodun gerçek kamerayla okunması, rehberden davet ve kişisel anahtarın
  ikinci fiziksel Android telefona aktarımı.
- İki telefonun farklı operatör/ağlarda TURN üzerinden görüşmesi.

## Henüz tam kapsamı karşılamayanlar

- Arayüz renkleri ve ekran akışları referans alınmıştır; referans görselle
  birebir piksel karşılaştırması yapılmadı. Poster portreleri temsili veridir;
  gerçek uygulamada kullanıcılar kendi profil fotoğraflarını seçer.
- Animasyonlu katalog 881 dosyadır. Diğer Unicode emojiler metin olarak
  gönderilebilir; tüm Unicode emojileri için ayrı animasyon dosyası yoktur.
- Silinen içeriğin önceden dışa kaydedilmiş dosyalardan, sağlayıcı sistem
  yedeklerinden veya tüm çevrimdışı cihazlardan kesin olarak yok edildiği
  iddia edilmez. İstemci önbelleği ve çevrimdışı silme eşitlemesi ayrıca
  uçtan uca doğrulanmalıdır.
- Kriptografi ve yerel WebView köprüsü bağımsız güvenlik denetiminden geçmedi.
- Canlı HTTPS/TURN sunucusu seçilmedi, kurulmadı; tek sağlayıcı ve ücretsiz
  kota koşulları doğrulanmadı. Fiziksel telefon erişimi bu ortamda yok.

## Performans

Mesajlar ağ cevabını beklemeden yerel ekrana eklenir. Anahtarlar ve çözülmüş
mesajlar bellekte önbelleklenir; mesaj düğümleri anahtarlarına göre güncellenir;
emoji dosyaları ve medya önizlemeleri ihtiyaç oldukça yüklenir. Bunlar
uygulanan iyileştirmelerdir, gerçek telefon hız ölçümü değildir.

WhatsApp'tan hızlı olduğu veya hatasız çalıştığı doğrulanmadı. Aynı iki
telefonda soğuk açılış, sohbet açma, kaydırma kare süreleri, mesaj gecikmesi,
arama kurulumu ve büyük dosya aktarımı karşılaştırılmadan böyle bir sonuç
bildirilmemelidir. Yerel API testi yalnızca kendi dar kapsamını ölçer.
