# FS 34.32 — Telegram karşılaştırması ve yayın kontrolü

Bu güncelleme uygulama tasarımını veya mesajlaşma davranışını değiştirmez; önceki 1–40 kaynaklarını korur. Yeni araçlar aynı fiziksel cihazda tekrarlanabilir ölçümü ve kaynak/APK'ya bağlı kabul denetimini sağlar.

## Cihaz ölçümü (yetkili Android ADB, kurulu iki uygulama)

Aynı cihaz, ağ, ekran yenileme hızı, sıcaklık, güç koşulları, test hesabı içeriği ve hareket senaryosunu kullanın. Gerçek konuşmaları değil sentetik test verilerini kullanın. Her uygulamada aynı senaryoyu en az üç kez tekrarlayın. Her ölçüm öncesi ilgili uygulamayı açın. Telegram'ın resmî web APK'sı kullanılıyorsa paket `org.telegram.messenger.web` olabilir.

```sh
python tools/device_performance.py --package com.fs.mesajlasma --scenario chat-scroll --seconds 120 --interval 5 --output fs-scroll.json
python tools/device_performance.py --package org.telegram.messenger --scenario chat-scroll --seconds 120 --interval 5 --output telegram-scroll.json
python tools/compare_device_performance.py fs-scroll.json telegram-scroll.json --output comparison-scroll.json
```

Diğer senaryolar: idle, photo, call, background. Süre, cihaz, uygulama sürümü ve süreç devamlılığı karşılaştırılır. Örneklenmiş kare süresi, takılma oranı ve PSS RAM karşılaştırması üretilir. Eksik örnekler null gösterilir. Ham seri numarası, mesaj içeriği, ekran görüntüsü ve logcat alınmaz; cihaz seri numarasının özeti yalnızca yerel raporda yer alır. Ölçüm CPU, uygulamaya özel pil tüketimi, video FPS, çağrı kalitesi veya piksel eşitliği kanıtı değildir. Bu konular için kontrollü ayrı test ve görsel inceleme gerekir.

## Yayın kapısı

`tools/release_gate.py` önceki 12 gerçek kabul koşulunu korur; ek olarak `build/test-evidence/release-approval.json` içinde `source_manifest_sha256` (FS-FINAL-SHA256.txt dosyasının özeti) ve `signed_apk_sha256` (imzalı APK özeti) alanlarını bekler. Kaynak manifestindeki dosyaları yeniden doğrular. Android SDK apksigner ile imzayı ve mevcut sabit sertifika özetini doğrulamadan geçmez. Kabul beyanları gerçek test kayıtlarına dayanmalıdır; araç bunların doğruluğunu kendi başına kanıtlayamaz.

```sh
python tools/release_gate.py --apk build/ci/signed/FS-Mesajlasma-34.32-Native13-imzali.apk --evidence build/test-evidence/release-approval.json
```

Bu komut dağıtım yapmaz. ADB, Android SDK, mevcut imzalama anahtarı, iki fiziksel cihaz ve FCM/TURN ortamı bu denetimde erişilebilir değildir. CircleCI ve canlı sunucu değiştirilmemiştir. Önceki yapılandırma tam kaynak manifesti ve emoji arşivlerini doğrulamaya devam eder. npm bağımlılıkları ağ/DNS engeli nedeniyle kurulamadığı için 12 JS test dosyası açılamamıştır. Nihai onay verilmemiştir.
