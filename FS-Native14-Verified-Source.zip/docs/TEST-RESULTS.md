# Test sonuçları

Tarih: 22 Kasım 2026. Bunlar bu kaynak ağacında çalıştırılan gerçek yerel
kontrollerdir; fiziksel telefon veya gerçek tarayıcı çizim testi değildir.

| Kontrol | Sonuç | Kapsam |
|---|---:|---|
| Sunucu testleri | 24 geçti | Hesap, yetki, mesaj, dosya, yönetici, engelleme, makbuz, sinyalleşme |
| Şifreleme ve hesaplama | 7 geçti | AES-GCM, ECDH, yanlış anahtar, veri değişikliği, PIN, anahtar taşıma |
| DOM + gerçek API/WS akışları | 13 geçti | Kayıt, PIN, kişi, mesaj, yönetici çözmesi, anket, emoji, dosya, tema, canlı durum, çıkış |
| Android derleme ve APK imzası | Derlendi; imza doğrulandı | Kurulum ve donanım testi yerine geçmez |
| Gerçek Chromium çizimi | Çalıştırılamadı | Ortam yerel soket izni vermedi |
| Fiziksel Android | Yapılmadı | Bu ortamda bağlı fiziksel Android cihazı yok |

## Yerel gecikme ölçümü

100 örnekte, aynı makinede HTTP ile mesaj kaydı ve diğer WebSocket'e olay
ulaşması ölçüldü. P50: 0.674 ms; P95: 1.538 ms;
en yüksek: 2.855 ms. Bu test taklit şifreli veriyle protokolü
ölçer. Telefon render süresi, gerçek internet, operatör veya WhatsApp
karşılaştırması içermez.

Ham test kayıtları `docs/test-evidence/` içindedir.
