# Turnix FS bağlantısı

TURNIX_API_TOKEN yalnız sunucunun gizli ortam değişkeninde bulunur. /api/config oturum doğrulamasından sonra sağlayıcının planını ve kotasını kontrol eder. FREE plan ve is_overage_available=false doğrulanmadan TURN kimliği üretilmez. Kota dolduğunda 503 ve Türkçe açıklama döner; otomatik ücretli plana geçiş yoktur. Kalıcı API anahtarı istemciye gönderilmez. İstemci yalnız süreli WebRTC kullanıcı bilgilerini alır.

Bu koruma sağlayıcıdaki aboneliği değiştirmez; ücretli abonelik açılmamalı ve kart eklenmemelidir. 41 Python testi geçmiştir. Gerçek canlı röle testi dağıtımdan sonra yapılmalıdır. İki fiziksel Android cihazı, Bluetooth ve Doze doğrulaması ayrı kabul testleridir.
