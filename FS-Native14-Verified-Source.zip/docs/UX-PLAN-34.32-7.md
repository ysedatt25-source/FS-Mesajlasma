# FS Mesajlaşma: etkileşim düzeni ve akıcılık planı

## Bu sürümde uygulananlar
- Aranabilirlik yeşil veya kırmızı tik. Yalnız sunucu kaydı başarılıysa durum değişir.
- Yeşil “Müsaitim”, kırmızı “Müsait değilim” yazısı; kompakt, iki saniyelik uygulama içi geri bildirim. Art arda dokunma sırasında aynı ayarın paralel gönderilmesi engellenir.
- Kaydedilen profil/tema/ayarlar ve kişi işlemlerinde yeşil başarı; kaydetme/bağlantı hatalarında kırmızı açıklama. Normal gezinme, mesaj gönderme veya emoji seçme için yeni başarı balonu eklenmez. Telefonun bildirim paneline yeni bildirim eklenmez.
- Kayıtta ad, kullanıcı adı, telefon, davet kodu, gizlilik kabulü ve altı karakterlik hesap şifresi doğrulanır. Hatalı alanlara açıklama, erişilebilir işaret ve ilk hatalı alana odak eklenir. Sunucu doğrulaması korunur.
- Profil ve ayar formlarında kaydetme hataları yakalanır; kaydetme sürerken çift gönderim engellenir.

## Resmî ürün akışlarının karşılaştırılması
İnceleme resmî ürün açıklamalarına ve FS kaynak koduna dayanır; WhatsApp/Telegram Android uygulamaları bu ortamda fiziksel cihazda çalıştırılmadı.

- WhatsApp: sohbet filtreleri; ses kaydında duraklatma/devam, dalga gösterimi, göndermeden dinleme, kaldığı yerden oynatma ve 1,5/2 kat hız.
  https://about.fb.com/news/2024/04/whatsapp-chat-filters/
  https://about.fb.com/news/2022/03/new-voice-message-features-on-whatsapp/
- Telegram: kayıtlı mesajları sohbetlere/etiketlere göre düzenleme; medya takvimi, tarihe hızlı geçiş; ses kaydını duraklatıp sürdürme.
  https://telegram.org/blog/new-saved-messages-and-9-more/
  https://telegram.org/blog/shared-media-scrolling-calendar-join-requests-and-more/pt-br?setln=en

## Sonraki geliştirmeler — henüz uygulanmadı
1. Sohbet bazında şifreli yerel taslak, yanıt hedefi ve kaydırma konumu; çevrimdışı görüntüleme ve açık gönderim kuyruğu. Kapatıp açmada doğru sohbeti ve yazıyı koruma.
2. Tümü/Okunmamış/Gruplar filtreleri, sabitleme/arşiv, sohbet içinde arama ve tarihe atlama.
3. Ses kaydını kilitleme, duraklatma/devam, gerçek dalga gösterimi; oynatma hızları ve kaldığı saniyeyi hatırlama. Mevcut sayaç/önizleme korunur.
4. Fotoğraf/video küçük önizlemesi, kaliteli kopyayı isteğe göre indirme; indirme durumunu dosya üzerinde gösterme, yeniden deneme, medya takvimi.
5. Kayıtlı mesajlarda etiketler/sohbete göre filtreler; tam mesajına geri dönme.
6. Çağrı ekranında bağlanıyor/yeniden bağlanıyor/ağ zayıf durumlarını açık gösterme; cihazda ses yönlendirme ve ağ geçişi testleri.
7. Konuşmalarda okunmamış ayıracı ve yeni mesaj sayacı; kullanıcı eski mesaj okuyorsa zorla aşağı kaydırmama.

## Akıcılık için teknik öncelikler — hedef, ölçülmüş sonuç değil
- İlk ekranda tüm geçmişi beklemek yerine doğrulanmış yerel son sayfayı açıp farkları arka planda almak.
- Uzun listede yalnız görünür mesajları oluşturmak; tepki ve anketleri her mesaj için tekrar taramak yerine bir kez indekslemek.
- WebSocket olaylarını kısa aralıkta birleştirmek; her olayda tüm sohbetleri ve mesajları yeniden istememek. Silme/sıralama/okundu olaylarını kaybetmeden fark güncellemek.
- Medya şifreleme, küçük resim ve dosya hazırlığını ana arayüzden ayırmak; aynı anda işlenen büyük dosya sayısını sınırlamak.
- Şifreli yerel önbellek sınırı ve gereksiz nesne URL temizliği; otomatik sağlayıcı yedeği açmamak.
- Sürükleme ve animasyonda transform/opacity; 60 Hz cihazda kare bütçesi yaklaşık 16,7 ms. Orta sınıf Android'de dokunma geri bildirimi için p95 <100 ms hedefi, önbellekli sohbet açılışı için p95 <200 ms hedefi. Bunlar kabul hedefleridir, ölçüm sonucu değildir.
- Ölçüm matrisi: 100/1.000/10.000 mesaj, yavaş ağ/ağ kesintisi, düşük bellek, Wi-Fi-mobil geçişi, Bluetooth bağlantısı, uygulama arka planı. İki gerçek cihazla çağrı ve Android enerji kısıtları ayrı doğrulanmalı.

WhatsApp'tan daha hızlı olduğu veya tüm cihazlarda hatasız çalıştığı ölçüm olmadan iddia edilmez. Yönetici erişimli mevcut mesaj mimarisi, başka ürünlerin uçtan uca şifreleme iddialarıyla eşdeğer sayılmaz; politika ve mevcut yetkiler bu sürümde değiştirilmedi.
