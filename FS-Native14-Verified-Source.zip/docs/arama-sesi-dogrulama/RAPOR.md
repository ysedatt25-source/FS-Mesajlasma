# FS Mesajlaşma 34.32 — Arama ve zil sesi düzeltmesi

32. madde kaynak paketi temel alındı. Doğrudan sesli/görüntülü aramada yerel arama tonu, Android iletişim ses akışı ve otomatik cihaz seçimi; yanıt/reddetme/kapatma/kilit/zaman aşımı durumlarında temizlik; alıcıda mevcut Android çağrı bildirim kanalları ve kişi/sohbet sessiz ayarıyla uyum uygulandı. Android bildirim kanalı/DND/ses ayarları aşılmaz. Zil sesi önizlemesi MediaPlayer ile medya ses seviyesinden oynatılır. Beş hazır özgün WAV dosyası korunur. İki şarkı için yerel ses dosyası seçim yuvaları eklendi; şarkı kayıtları pakete dahil değildir. Seçilen dosyanın ses parçası içerdiği ve kalıcı URI okuma izni doğrulanır; dosyanın telif durumu ve eser kimliği uygulama tarafından doğrulanamaz. Android bildirim oynatıcısının belge sağlayıcı URI desteği fiziksel cihazda doğrulanmalıdır.

## Kontroller
- Node: 65/65 hedefli test (7 yeni dahil).
- Android bağımsız ses yönlendirme politikası: 25/25.
- Java: 27 kaynak dosyası sözdizimi analizi (SDK derlemesi değil).
- Sunucu: 3/3 hedefli test (sessiz kişi, push yetkilendirmesi, tekrar bildirim); ayrıca 1 push yenileme ve 3 native çağrı penceresi testi başarılı.
- Hazır WAV dosyaları boş değil, beş farklı özgün sinyal mevcut. Ringback WAV 4 saniye (1 saniye ton, 3 saniye sessizlik).

## Yayın engelleri
Android SDK/Gradle derlemesi, gerçek Bluetooth ve ahize/hoparlör ses çıkışı, telefon sessiz/titreşim/DND ayarları, bildirim izinleri, dosya seçimi ve özel zil sesinin sistem bildirim kanalında oynatılması fiziksel Android cihazda test edilmedi. Eski kullanıcı bildirim kanalları korunur; titreşim/ses kapalıysa Android çağrı sesi ayarlarından kontrol edilmelidir. Tarayıcıdaki arama tonu cihaz çıkışını yönetemez. Giden arama tonu yerel bir sinyaldir; alıcı telefonunun gerçekten çaldığını kanıtlamaz. Grup giden çağrı mantığı bu yamanın kapsamı dışındadır. Önceki 32. madde paketindeki 881 temel emoji varlığı arşiv dışında, geri yükleme betiğiyle geri getirilmeli. Tam regresyon ve canlı yayın yapılmadı.
