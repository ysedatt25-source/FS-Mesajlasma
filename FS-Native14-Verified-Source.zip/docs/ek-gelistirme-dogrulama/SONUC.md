# Native13 ek geliştirmeler — yayın adayı, nihai sürüm değil

- Emoji katalogları ve animasyon dosyaları değiştirilmedi. Eski 881 dosya `tools/fetch_assets.py` ile SHA-256 doğrulamasından sonra geri yüklenir; 2.876 ek dosya arşiv içindedir.
- Onaylanmış gönderimler cihazda şifreli, hesap/anahtar kapsamlı atomik IndexedDB kuyruğuna alınır. En fazla 20 dosya ve 200 MB; dosya başına 50 MB. Kuyruk PIN açıldığında bağlantıyla sürdürülür. Sabit gönderim/yükleme kimliği mükerrer gönderimi engeller. İndirme kuyruğunun uygulama kapanması sonrası sürdürülmesi henüz yoktur.
- Aktif oturumda tüm sohbetlerde şifresi gerçekten açılan mesajlar için, sohbeti açmadan, okundu saymadan teslim onayı. Kilitli/kapalı istemci adına sahte teslim onayı verilmez.
- Üç veya dört üyeli gruplarda destekleyen bağlı istemciler için sesli/görüntülü arama kaynak kodu eklendi. Sunucu sinyalleşmesi ve istemci bağlantı mantığı test edildi. Gerçek cihazlar arasında medya, TURN, yeniden bağlantı ve arka plan grup çağrısı doğrulanmadı; grup özelliği bu sınırlar dışında tamamlandı sayılmaz.
- Bağımsız push sağlayıcısı henüz kurulmadı. Mevcut foreground bağlantı servisi korunmuştur. Android zorla durdurma kısıtlaması aşılamaz.
- İleri gizlilik/Signal tarzı ratchet protokolü henüz uygulanmadı. Eski şifreleme ve yönetici erişimi modeli korunmuştur. Yeni protokolün güvenli anahtar göçü ve bağımsız denetimi gereklidir.
- Bu pakette canlı yayın, Android SDK derlemesi, fiziksel telefon testi, yeni imza anahtarı ve imzalı APK bulunmaz. Eski kalıcı imza anahtarı mevcut sürüm üstüne kurulum için korunmalıdır.
- Önceki `docs/madde18-dogrulama` raporları önceki Native13'e aittir; güncel sonuçlar bu klasördedir.
