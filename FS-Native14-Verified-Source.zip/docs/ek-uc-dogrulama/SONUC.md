# Native13 — üç ek istek, yayın adayı değil

- Kalıcı indirme: şifreli parçalar IndexedDB üzerinde atomik kayıt; 1 MiB HTTP Range; uygulama yeniden açılıp PIN girildiğinde sürdürme. Hesap ve anahtar ayrımı, yetkili mesaj bağlantısı, silinen mesaj kontrolü. Tamamlanan dosyanın dışa aktarılması kullanıcı onayına bağlı. En fazla 20 görev, 200 MB toplam, dosya başına 50 MB; büyük albümde sınır üstü normal akış. Android süreci kapalı veya kilitli iken indirme devam etmez. Albümün bütün dışa aktarma oturumu değil, kaydedilmiş dosya görevleri kurtarılır.
- FCM: isteğe bağlı sunucu ve Android kaynakları eklendi, sahte taşıyıcıyla gerçek HTTP/WebSocket testleri geçti. Sağlayıcı kurulumu, gerçek FCM, Android SDK derlemesi ve telefon testi bekliyor. Bkz. PUSH-KURULUM.md.
- Signal benzeri ileri gizlilik: uygulanmadı; mevcut protokol korunuyor. Bkz. ILERI-GIZLILIK-GECIS.md.
- Emoji dosyaları değiştirilmedi. 2876 yeni varlık arşiv içinde; sabit 881 eski varlık önceki dağıtım biçimiyle doğrulanmış ayrı paketten yüklenir. SHA-256: e5c03330fe4b6293df99d148f19cc84fb2b5c664643a04d89435224c5a50f20a.
- 272 JavaScript + 78 Python (66 sunucu, 6 DB, 5 TURN, 1 geçiş) + 62 DOM tam entegrasyon + 76 Chromium + 20 bağımsız Java kontrolü = 508 başarılı kontrol. Ek gerçek Android SDK/FCM derlemesi yapılmadı; Java sayısı Android derlemesi değildir. Testler mevcut yerel paketlerle çalıştırılmıştır. Önceki raporlar tarihsel kanıtlardır.
- Canlı Railway, mevcut APK ve imzalama anahtarı değiştirilmedi. Önceki CircleCI yapılandırması bu yeni paketin özetiyle güncellenmeden kullanılmamalı.
