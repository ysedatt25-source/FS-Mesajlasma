# Madde 1 — ek düzeltme ve doğrulama

- Eski WebSocket kapanınca yeni WebSocket üzerinden devam eden yazma aktivitesinin yanlışlıkla silinmesi, yeni iki bağlantılı API testiyle yeniden üretildi. Önceki hata kanıtı: `yeniden-baglanti-once.log` (bilerek başarısız eski sürüm testi).
- Sunucuda her bağlantı için yalnızca RAM'de 5,5 saniyelik aktivite kaydı tutulur; son geçerli bağlantı durduğunda gösterge temizlenir. Taslak içerik ve veritabanı kaydı yoktur.
- İstemcide özellik yeteneği kaybedilirse ekrandaki eski gösterge temizlenir; profil güncellemelerinde gösterge yeniden değerlendirilir.
- Yerel testler: 148 JavaScript, 52 API, 6 veritabanı, 5 TURN, 35 DOM entegrasyon, 49 Chromium bileşen kontrolü; toplam 295 başarılı. Tüm komutlar 0 koduyla tamamlandı. Node 22.16.0, aiohttp 3.13.3. Gerçek Android istemcisi testi, yeni APK ve canlı yayın henüz yapılmadı.
- Yalnızca madde 1 güncellendi; sıradaki geliştirme madde 2. Büyük emoji varlıkları önceki doğrulanmış tam kaynak yedeğinden veya tools/fetch_assets.py ile alınmalıdır.
