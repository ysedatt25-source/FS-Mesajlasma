# Madde 02 – Görüşme sesi, Native13 kaynak güncellemesi

Ayarlar → Görüşme sesim → Normal ses / Kadın sesi / Erkek sesi. Seçim cihazda hesap bazında saklanır. Yeni bire bir sesli, görüntülü ve grup aramalarının giden ses kaynağı için uygulanır. Normal mod orijinal mikrofon track'ini kullanır. Diğer modlarda AudioWorklet ile çift gecikme hattı, Hann çapraz geçişi, hafif frekans zarfı düzeltmesi ve dinamik sınırlama kullanılır. Ses yerelde işlenir, ayrı bir sağlayıcıya yüklenmez; mevcut arama aktarımı kullanılır. Dönüştürücü başlatılamazsa orijinal ses yerine hata oluşur; çalışma sırasında motor hata verirse görüşme kapatılır. Kilit ve arama kapanışında kaynaklar serbest bırakılır.

Bu ilk DSP sürümü ses perdesi ve tınıyı değiştirir; bağımsız formant dönüştürme veya doğrulanmış sinir ağı tabanlı doğal ses sentezi değildir. Doğallık, gerçek ses gecikmesi, WebView AudioWorklet desteği, arka plan davranışı ve karşı telefona aktarım kanıtlanmadı. Kişiyi anonimleştirdiği de iddia edilemez. Arama sırasında mod geçişi ve Bluetooth testi Madde 03 kapsamındadır.

Doğrulama: 44 Node testi başarılı (6 yeni test ve ilgili gerileme testleri). Chromium bileşen testi sentetik 200 Hz giriş için normal 200 Hz, kadın 270 Hz, erkek 157 Hz ve gerçek RTCRtpSender SDP ses hattı oluşturulmasını doğruladı. Tam güvenli-origin AudioWorklet/WebRTC loopback testi bu ortamda tarayıcı gezinmesi ERR_BLOCKED_BY_ADMINISTRATOR nedeniyle çalışmadı; gerçek telefon testi yapılmadı. Bu nedenle üretim kabulü tamamlandı sayılmaz. Canlı sistem ve imzalı APK değiştirilmedi.

Komutlar:
```
node --check web/app.js
node --test tests/async-lock-races.test.mjs tests/call-voice.test.mjs tests/group-call.test.mjs tests/call-quality.test.mjs tests/call-chat-fixes.test.mjs tests/access-gate.test.mjs
python tests/test_call_voice_sender_browser.py
python tests/test_call_voice_browser.py  # güvenli localhost erişimi ve Playwright/Chromium gerekli
```
