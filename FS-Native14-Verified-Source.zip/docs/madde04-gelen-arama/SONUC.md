# Madde 04 — Gelen arama görünümü

Temel sürüm: Madde 01 kaynak yedeği + Madde 02 + Madde 03 güncellemeleri. Değişiklik yalnızca uygulama içindeki gelen arama görünümü ve ilgili işlem kontrollerini kapsar.

- Gelen birebir ve grup aramalarında ayrı, markasız tam ekran görünüm. Arayanın mevcut oturumdaki kimliği ve profil resmi, arama türü, grupta grup adı, kabul/reddet ve mesajla yanıtla.
- Gelen arama görünümü, aktif görüşme görünümünden önce seçilir. Kabul öncesinde ses/video oynatma veya kamera önizlemesi oluşturulmaz.
- Kabul işlemi sürerken tekrar kabul ve mesajla yanıtla devre dışı kalır; reddetme kullanılabilir. Eski asenkron medya işlemi yeni çağrıyı sonlandıramaz. Sinyal gönderim hatasında yerel çağrı temizlenir.
- Önceki görüşme arayüzü, ses dönüştürme, zil sesi ve müsaitlik kuralları korunur. Kullanıcı adı HTML olarak yorumlanmaz.

## Doğrulama
- Node testleri: 57/57 (yeni gelen arama testleri, arama durumu, grup, zil sesi ve ses dönüştürme regresyonları).
- Chromium: 6 farklı ekran boyutu, 2 tema, 2 arama türü = 24 kombinasyon. Profil fotoğrafı, görünür butonlar, tıklamalar, grup ve uzun adlar, kabul beklerken iptal kontrolü başarılı. Bu test bileşen düzeyindedir; canlı çağrı veya Android cihaz testi değildir.
- Android kilit ekranı ve arka plan tam ekran bildirim/izin bağlantısı Madde 05 kapsamındadır. APK derlemesi, imzalama ve fiziksel cihazda çağrı doğrulaması yapılmadı.
