# Madde 05 – Gelen arama: Android kilit ekranı ve arka plan

## Değişiklikler
- Doğrulanmış poll ve FCM çağrı davetleri için `USE_FULL_SCREEN_INTENT`, Android 14+ yetki kontrolü ve ayarlar bağlantısı. Yüksek önem ve tam ekran izni varsa OS tam ekran açabilir, aksi halde çağrı bildirimi kullanılır. Android 12+ CallStyle; API 26–30 eylem düğmeleri.
- Dışarıya kapalı IncomingCallActivity; süre ve kimlik denetimi, kilit ekranı, ekran açma, cevap/ret düğmeleri. Çağrı türü dışında kişisel bilgi gösterilmez. Yanıtla cihazın kilit doğrulamasını ve ardından mevcut uygulama girişini korur; gerçek çağrıyı kabul etme uygulamadaki mevcut kabul düğmesiyle yapılır. Kamera/mikrofon arka planda kendiliğinden açılmaz. Sistem bildirimi gerçek uygulama kimliğini gösterebilir.
- Yeni oturumda önceki bildirim temizlenir; aynı arama kimliği yeniden çalmaz; yanlış kimlik yeni aramayı kapatamaz. Eski bildirim 45 saniyelik davet süresini aşamaz. Seçili zil sesi ve sessiz kanal korunur.
- `POST /api/calls/decline` sadece doğrulanmış ve halen çalan alıcı çağrısını reddeder; birebir ve grup için. Başka kullanıcı, arayan, kabul edilmiş veya eski çağrı reddedilemez. Sunucu yanıtı olmadan başarılı ret gösterilmez. HTTP 409 ilgili çağrının artık reddedilebilir olmadığını belirtir. Eski canlı API bu yeni işlemi henüz desteklemez.
- FCM sadece bağlama ait opak uyandırma verisi taşır; ses/görüntü bilgisi doğrulanmış HTTPS anlık çağrı yanıtından gelir. Bildirim izinleri, DND ve cihaz pil yönetimi önceliklidir.

## Yerel doğrulama
- Mevcut sunucu testleri: 66/66.
- Yeni API entegrasyon testleri: 3/3 (kimlik, yetki, çağrı değişimi/kabulü ve grup reddi).
- Seçili Node regresyon testleri: 57/57.
- Saf JVM: 11 çağrı penceresi koşulu ve 11 eski çağrı bildirimi koşulu başarılı.
- Java kaynak sözdizimi, JS sözdizimi ve AndroidManifest XML kontrolleri başarılı.

## Açık durum / yayın kapısı
Android SDK 35 ve fiziksel cihaz yok; derleme ve API tip çözümleme, gerçek kilit ekranı, cihaz üreticisi/pil kısıtları, gerçek push ve zil sesi testleri yapılmadı. FCM sağlayıcı kurulumu 7. maddede; uygulama işlemi işletim sistemi tarafından öldürüldüğünde güvenilir uyanma buna bağlıdır. Kullanıcı tarafından zorla durdurulmuş uygulama için çağrı garantisi yoktur. Sistem tam ekran iznini veya bildirimleri engellerse ekran davranışı değişir. Canlı sunucu ve APK değiştirilmedi. Yeni API yayınlanana kadar yerel ret eylemi eski sunucuda çalışmayabilir. Önceki 02–04 yamaları üzerine uygulanır.
