# Madde 7 — Hazır profil avatarları

- Sekiz kadın ve sekiz erkek, özgün 512×512 JPEG çizim; tüm 16 varlık uygulamadaki `web/profile-avatars.js` içinde. Kaynak üretici `tools/generate_avatars.py`; çalışma zamanında harici servis yok.
- Profilim → Resmi değiştir → Galeriden fotoğraf seç veya Hazır avatar seç → Avatarı kaydet. Seçim kaydetmeden profili değiştirmez; önceden kaydedilen avatar tekrar seçili görünür. Galeri özelliği korunur.
- Gerçek JPEG mevcut yetkili profil API'sine gönderilir. Sunucu kodu, veri modeli ve canlı sistem değiştirilmedi. Avatar seçimi çevrimdışı yapılabilir; sunucuya kayıt internet gerektirir. İptal, geçersiz seçim, yinelenen gönderim, geç kalan yanıt ve kilit değişimi test edildi.
- Otomatik doğrulama: 200 JavaScript, 63 API/veritabanı/TURN, 48 yerel HTTP/WebSocket DOM entegrasyonu, 54 gerçek Chromium bileşen kontrolü = 365 başarılı. Loglar bu klasördedir.
- Fiziksel Android, yeni SDK derlemesi ve canlı yayın yapılmadı. Madde 8–9 (görüntüleme ve yakınlaştırma) henüz uygulanmadı.
- Büyük emoji varlıkları önceki tam Native12 yedeğinde; arşiv kaynak güncellemesidir, kurulabilir APK değildir.
