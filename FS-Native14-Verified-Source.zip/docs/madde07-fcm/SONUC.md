# Madde 07 – Firebase bağımsız bildirim entegrasyonu

Temel kaynak: Native13 + Madde02–06 kaynak güncellemeleri (önceki kodlar korunmuştur).

## Gerçekleştirilen kod değişiklikleri
- FCM daha önce sadece çağrı uyandırıyordu. Yeni mesaj kaydından sonra alıcılar için ayrı `message-wakeup-v1` sinyali oluşturulur. Mesaj içeriği, kimlik, oda, PIN, oturum anahtarı FCM veri yüküne konulmaz. Yalnızca sinyal türü ve rastgele cihaz-oturum bağlama değeri bulunur. FCM taşıyıcısı kayıt tokenı ve teslim metaverisini işler.
- Sinyal üretimi ve teslimden hemen önce sessize alma, engelleme, okunma, silinme, mesaj yaşı ve oturum doğrulanır. Alıcı mesaj bildirimleri, arama müsaitliğinden bağımsızdır. Yinelenen POST yeni sinyal üretmez. Son mesaj oda başına esas alınır; önceki uzun sorgu bildirim mekanizması korunur.
- Android FCM alıcısı hem arama hem mesaj türünü tanır. Mesajlar ağ erişimi gerektiren WorkManager göreviyle yetkili API'den alınır. Android 12+ yüksek öncelikli mesajlarda expedited çalışma istenir; kotada normal işe geri düşebilir. Android 8–11'de standart iş olarak planlanır. Görev girişi yalnızca bağlama değeri ve süre sınırı içerir. Oturum anahtarı depolanan iş girdisine eklenmez. Yeni giriş/çıkış ve ayar değişiklikleri yeniden kontrol edilir. Mevcut PIN ve bildirim gizleme davranışı korunur.
- Push APK için WorkManager bağımlılığı ve AndroidX ayarı eklendi. APK doğrulayıcısı yeni çalışan sınıfı arar. Sunucu Dockerfile Firebase Admin SDK bağımlılığını içerir. Sağlayıcı ayarı yoksa API eski aktarım yolunu korur.

## Testler (sentetik taşıyıcı, gerçek FCM değil)
- 72 mevcut sunucu ve sohbet bildirimi testi geçti (66 genel + 6 özel).
- 8 yeni FCM mesaj testi geçti.
- 9 yapılandırma testi geçti.
- Java sözdizimi çözümlemesi geçti; Android SDK tür denetimi veya APK derlemesi değildir.
- Python derleme denetimi geçti.

## Açık kalanlar
Bu oturumda gerçek Firebase projesine erişim, FS_FCM_PROJECT, Android istemci yapılandırması, hizmet hesabı/ADC ve Android SDK mevcut değildi. Firebase eklentisi bağlı değil. Gerçek sağlayıcı oluşturulmadı, kimlik bilgileri üretilmedi, Railway/CircleCI ayarları değiştirilmedi, APK imzalanmadı. Mevcut arama FCM sinyalinin kısa doğrudan API isteği, mesaj WorkManager teslimi, Android Doze, süreç ölümü, ağ değişimi ve fiziksel cihazlar üzerinde test gereklidir. Android zorla durdurma, üretici pil kısıtları, Play Services olmayan cihazlar ve FCM kota/teslim sınırlamaları altında garanti verilmez. Mesaj bildirimindeki doğrudan satır içi yanıt Madde06'dan kalan ayrı iştir. Push kuyruğu bellektedir, sunucu yeniden başlatıldığında kaybolabilir; mevcut sunucu sorgusu yedek yol olarak kalır. FCM gerçek cihaz teslimi olmadan madde tam kapanmış sayılmaz.

## Güvenli etkinleştirme
1. Firebase'de mevcut veya yeni Android kaydı: com.fs.mesajlasma. Uygun proje ve Android istemci yapılandırması sağlanmalı.
2. CircleCI: FS_FCM_PROJECT ve FS_GOOGLE_SERVICES_JSON_B64 (yalnızca Android istemci config). `tools/build_push_ci.sh` ile push çeşidi derlenir; kaynak/emojiler önce hazırlanır. Sunucu özel anahtarını CI veya ZIP'e koymayın.
3. Railway: aynı FS_FCM_PROJECT, FCM gönderim yetkili hizmet hesabı için güvenli ortam değişkeni FS_FCM_SERVICE_ACCOUNT_JSON veya ADC. Sunucu Dockerfile değişikliği nihai canlı güncellemede doğru kaynağa uygulanmalı. Özel anahtarı sohbet, public depo veya APK'ya koymayın.
4. Gerçek iki hesap ve iki telefonla arama/mesaj teslimi, sessiz sohbet, müsait değilken mesaj, kilit, süreç ölümü, logout, ağ kesintisi, mükerrer bildirim ve izin reddi doğrulanır.

Resmi kılavuz: https://firebase.google.com/docs/cloud-messaging/android-message-priority ; https://firebase.google.com/docs/cloud-messaging/android/receive-messages
