# Madde 08 — Double Ratchet araştırma çekirdeği (üretim dışı)

Durum: KISMİ. 24.11.2026. Kaynak tabanı: FS 34.32 Native13 + Madde01–07.

## Mevcut uygulamanın durumu
- `web/crypto.js` `peerKey`: uzun ömürlü P-256 ECDH kimlik anahtarından AES-GCM anahtarı türetiyor. Her mesajda yeni rastgele IV olsa da bu, tek başına ileri gizlilik değildir.
- `web/app.js` `envelopes`: üyeler ve varsa `room.audit` için ayrı şifreli kopya üretiyor. `server/app.py` `audit_user`, `validate_envelopes`, `recipient_keys_match` bunu doğruluyor. Yönetici alıcısı varsa yalnız iki uç arasında gizlilik iddiası yapılamaz. Bu çalışmada bu davranış değiştirilmedi. Yönetici erişimi ve gizlilik politikası ayrı, açık bir ürün kararı gerektirir.
- `decode`, mesaj geçmişi, düzenleme, dosyalar, grup üyeliği, tekrar yükleme ve `LocationService` (native canlı konum) eski şifreleme akışına bağlıdır. Bunlar yeni protokole sessizce düşürülemez veya kayıpsız aktarılmış sayılmaz.

## Eklenen kaynak
`web/ratchet-prototype.js` ayrı ve uygulamaya bağlanmamış bir araştırma modülüdür. Önceden güvenli biçimde oluşturulmuş 32 bayt ortak sır ve doğrulanmış başlangıç anahtarı ile çalışır. WebCrypto P-256 ECDH, HKDF-SHA256, HMAC-SHA256 ve AES-GCM kullanarak iki yönlü DH ve simetrik zincir adımları, her mesaj için yeni mesaj anahtarı, doğrulanmış başlık/bağlam, sırası değişen mesajlar için en fazla 128 atlanan anahtar, tekrar/replay kontrolü ve hatalı doğrulamada durumun ilerlememesi davranışlarını uygular. Oturum içi işlemler seri gerçekleştirilir. Bu özel prototip Signal ile uyumlu değildir; anahtar anlaşması veya uç kimliği doğrulaması yapmaz. Güvenlik denetimi yapılmamıştır. Anahtar referansları düşürülür fakat JS ortamında güvenli fiziksel bellek silme garantisi yoktur. Atlanan anahtar sınırı dolarsa ilerleme engellenir; oturum yenileme politikası henüz yoktur.

## Testler
`node --test tests/ratchet-prototype.test.mjs tests/portable-crypto.test.mjs`: 20/20 (14 yeni, 6 eski). Çalıştırılan Node.js 22.16.0. Ayrıntı: node-tests.log. Bu sonuçlar ileri gizlilik veya ele geçirilme sonrası güvenliğin formal kanıtı değildir. Android, gerçek API aktarımı, Signal uyumluluğu, kalıcı durum ve fiziksel cihaz testleri yapılmamıştır.

## Üretim entegrasyonu için açık işler (Madde08 tamamlanma kriteri)
1. Üretim için bakımı yapılan, denetlenmiş protokol kütüphanesi seçimi; libsignal Java/Android entegrasyonunun API, sürüm ve lisans değerlendirmesi. Üçüncü taraf kullanımının desteklenmediği göz önüne alınmalı. Prototip doğrudan canlıya alınmamalı.
2. Kimliğe bağlı, imzalı ve tek kullanımlık ön anahtarlar (uygun güncel protokolle ör. PQXDH); sunucu atomik ön anahtar tüketimi, iki cihazda kimlik parmak izi doğrulaması ve anahtar değişiminde açık uyarı. Eski statik ECDH ortak anahtarı yeni oturumun tek başlangıç sırrı olarak kullanılmamalı.
3. Android tarafında güvenli anahtar saklama ve sürümlü, atomik oturum/outbox/inbox işlemleri; yeniden başlatma, ağ kesintisi, tekrar teslim, mesaj düzenleme ve eşzamanlı alım. Tarihçe için anahtarları süresiz saklama yerine açık yerel veri politikası; yeniden kurulum/kurtarma davranışı ayrı tanımlanmalı.
4. Şifreleme zarfı sürümleme, eski istemcilerle geçiş, yeni güvenli oturumun eski protokole otomatik düşmesinin engellenmesi, cihaz başına anahtar, grup üyeliği/ayrılması, medya anahtarları, arama ve canlı konum değerlendirmesi.
5. Yönetici mesaj kopyası ile uç gizliliği hedefinin uyumlu hale getirilmesi; eski veriler değiştirilmemeli. Güvenli yeni oturumlar için yalnız yetkili ve kullanıcı tarafından bilinen uçlar.
6. Test vektörleri, bağımsız güvenlik incelemesi, ileri gizlilik/ele geçirilme sonrası toparlanma senaryoları, Android derlemesi, iki gerçek cihaz, çoklu cihaz ve migrasyon testleri. Eski sohbetlerin çözülmesi doğrulanmadan geçiş yok.

Kaynaklar: https://signal.org/docs/specifications/doubleratchet/ ; https://signal.org/docs/specifications/pqxdh/ ; https://github.com/signalapp/libsignal .

Canlı sunucu, APK, uygulamanın kullanılan şifreleme kodu ve mevcut kullanıcı verileri değiştirilmedi.
