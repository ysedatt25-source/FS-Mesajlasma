# FS 34.32 — Madde 08 / Birebir sohbet geçiş koruması

Durum: Deneysel, üretime hazır değil. Eski sistem veya canlı veri değiştirilmedi.

## Eklenenler
- Mevcut birebir odaya bağlı deneysel ratchet oturumuna geçiş için iki gerçek oda üyesinin aynı oturuma açık onayı gerekir. İstemci önce yerel oturumu açıp senkronize eder; kullanıcı daha önce yönetici için oluşturulmuş kopyaların değişmeyeceği konusunda uyarılır. Bekleyen onay 10 dakika geçerlidir ve etkinleşmeden önce geri çekilebilir. Farklı oturumlar etkinleştirmez. Üçüncü kişiler ve grup odaları reddedilir.
- Etkin geçişten sonra eski mesaj POST ve PATCH işlemleri hem istemci tarafında hem sunucuda reddedilir. Sunucu oda kilidi ve transaction içinde yeniden kontrol eder. Eski geçmiş okunabilir; önceki yönetici kopyaları korunur. Oda ana ekranında eski yazma formu gizlenir, deneysel güvenli yazma ekranı açılabilir. Bekleyen eski metin kuyruğu otomatik olarak yeni şifreleme ile yeniden gönderilmez; diğer odaların kuyruğunu engellemeden bekler. Canlı mesaj olayları, normal mesaj balonları, grup mesajları ve tüm medya türleri henüz yeni sisteme taşınmadı.
- Varsayılan kapalı iki ayrı bayrak: FS_EXPERIMENTAL_RATCHET=1 ve FS_EXPERIMENTAL_RATCHET_CUTOVER=1. Yalnızca sentetik test ortamı için. Etkin oda için bayraklar kapatılsa bile eski kanal yeniden açılmaz. Geri dönüş veya cihaz anahtarı kaybı halinde güvenli yeniden oturum açma/rotasyon tasarımı eksiktir. Pilot oturumda 100 mesaj sınırı vardır; bu nedenle gerçek kullanıcı odalarında etkinleştirilmemelidir.

## Doğrulama
- 66 sunucu, 6 veritabanı adaptörü, 5 TURN testi: 77/77.
- 7 pilot/sunucu test senaryosu: 7/7 (yerel HTTP, SQLite, gerçek Node WebCrypto, iki hesap, onay, geri çekme, farklı/eskimiş onay, yetkisiz kullanıcı, eski mesajların korunması, yeni şifreli mesaj, eski gönderim/düzenleme reddi, özellik kapalıyken eski kanala dönmeme).
- 46 taşınabilir JavaScript/kriptografi testi: 46/46. Toplam 130 başarılı test. Ek crypto.test.mjs ve durable-downloads.test.mjs paketleri fake-indexeddb bağımlılığı eksik olduğu için çalıştırılamadı. İlk deneme başarısızlık kaydı eklenmiştir. JavaScript/Python sözdizimi kontrolü başarılı.
- Fiziksel Android, gerçek IndexedDB, MariaDB sunucu testi ve bağımsız güvenlik denetimi yapılmadı. Grup anahtar dağıtımı/üyelik değişiklikleri, normal sohbet işlevlerinin tam eşdeğerliği, push bildirimleri, oturum rotasyonu, kapalı Android sürecinde anahtar yönetimi tamamlanmadı. Deneysel kriptografi Signal düzeyi olarak sunulamaz.

## Uygulama
Önce FS-34.32-Madde08-Medya-Yonetimi-On-Anahtar-Bakimi.zip paketini uygulanmış kaynak köküne bu güncellemenin apply.py dosyasını `python apply.py /kaynak/dizin` ile uygulayın. Manifest tüm dosyaların önceki ve sonraki SHA-256 değerlerini denetler. Canlı sistemde etkinleştirmeyin. Çalıştırılan testlerin günlükleri payload/docs/madde08-cutover altında.
