# Madde 8 — Profil fotoğrafı iki kademeli görüntüleme

- Kendi ve karşı tarafın profil sayfasındaki fotoğraf düğmesi ayrı görüntüleyiciyi açar. İlk dokunuş orta boy; ikinci dokunuş tam WebView ekranı; sonraki dokunuş orta boy. Fotoğrafın oranı korunur, kayıtlı fotoğraf değişmez. Fotoğrafı olmayan profilde görüntüleme düğmesi devre dışıdır. Değiştirme ikonu ve 16 avatar seçicisi ayrıdır.
- Geri/kapat, görünürlük değişimi, sayfa geçişi, yeni diyalog veya kilit durumunda görüntüleyici temizlenir. Eski düğmenin başka oturumda görüntüleyiciyi değiştirmesi önlenir; hatalı görsel için uyarı gösterilir.
- 205 JS + 63 API/DB/TURN + 50 yerel gerçek HTTP/WebSocket DOM entegrasyonu + 57 Chromium bileşen kontrolü = 375 başarılı. Chromium testinde gerçek JPEG, dokunma, 280/360/540 piksel genişlikler, 720x360 yatay ekran ve iki tema doğrulandı. Testler fiziksel Android cihaz testi değildir.
- Madde 1–7 korundu. Madde 9 (yakınlaştırma/uzaklaştırma/sürükleme) bu turda yapılmadı. SDK derlemesi, yeni APK ve canlı dağıtım bekliyor. Büyük emoji varlıkları önceki tam Native12 yedeğinde saklıdır.
