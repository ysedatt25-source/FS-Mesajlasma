# Madde 08 devamı — deneysel entegrasyon katmanı

**Durum: Kısmi. Üretimde kullanmayın.** Native13 + Madde01–07 + Madde08 prototipi üzerine uygulanır. `app.js`, sunucu, mevcut mesaj biçimi, canlı kullanıcı verileri ve yönetici kopyaları değiştirilmedi.

Yeni kod:
- `web/ratchet-handshake.js`: ECDSA P-256 imzalı, kısa ömürlü, iki tarafın çevrimiçi olmasını gerektiren geçici ECDH anlaşması. Kimlik anahtarı parmak izinin ayrı güvenilir kanaldan doğrulanması zorunlu; oda, taraf kimlikleri, nonce ve anahtarlar transkripte bağlanır. Bu, X3DH/PQXDH veya Signal Protocol değildir.
- `web/ratchet-storage.js`: AES-GCM ile şifrelenen zincir durumları, dışarı aktarılamayan WebCrypto anahtarları, IndexedDB yerel depolama, atomik sürüm karşılaştırma. Ratchet özel anahtarı dışarı aktarılamayan CryptoKey olarak yerel kayıtta tutulur. Anahtar donanımsal güvenceye sahip değildir. Aynı origin'deki zararlı kod veya eski depolama görüntüsünün geri yüklenmesine karşı koruma iddiası yoktur.
- Ratchet durumunun gönderme/alma işlemi başarılı olmadan ilerlememesi, kalıcı kayıt başarısız olunca paketin döndürülmemesi.
- Test: 11 yeni test, 14 önceki ratchet testi ve 6 eski şifreleme testi. Node bellek tabanlı CAS taklidi test edildi; gerçek IndexedDB ve Android test edilmedi.

Üretim için kalan işler:
1. Önce denetlenmiş Signal uyumlu kütüphane seçimi ve lisans/Android uyumluluğu. Deneysel modüller üretim kütüphanesi değildir. https://signal.org/docs/specifications/pqxdh/ ve https://signal.org/docs/specifications/doubleratchet/ referansları.
2. Cihaz kimlikleri, kimlik doğrulama UI ve prekey sunucusu; çevrimdışı oturum başlatma, çoklu cihaz, anahtar değişiklik uyarısı, replay saklama ve süre sonu temizliği.
3. Yeni sürümlü paket biçimi, sunucu yetki ve boyut kontrolleri, downgrade engeli. Şifreli giden kutusu ve ratchet durumunun aynı transaction içinde kaydedilmesi; tekrar gönderimde aynı şifreli paketin kullanımı. Gelen mesajların güvenli yerel saklama ve deduplikasyon stratejisi (geçmişi yeniden açmak için eski ratchet anahtarlarını saklamak doğru değildir).
4. Geçmiş mesajlar için mevcut şifre çözme yolu ve açık bir geçiş planı, yeni mesajlarda eski yönteme sessiz düşüş olmaması. Grup, düzenleme, reaksiyon, dosya anahtarı, saklanan mesaj ve geri yükleme ayrıca ele alınmalı.
5. Mevcut sunucu `validate_envelopes` ve istemci `envelopes` oda üyeleri + audit alıcısını kullanır. İki uç dışında bir alıcıya çözülebilir kopya sağlanırsa yalnız taraflara özel E2EE iddiası yapılamaz. Bu politika ve kullanıcıya şeffaf bildirim çözülmeden canlı geçiş yapılmamalı.
6. Bağımsız kriptografi güvenlik incelemesi, gerçek Android derlemesi ve cihaz testleri. Bu paket APK değildir; üretim yayınlanmadı.
