# FS 34.32 — Madde 08 / Otomatik yenileme, grup medya ve dönem geçmişi

Önkoşul: FS-34.32-Madde08-Oturum-Sayfalama-Grup-Arayuzu.zip ve önceki sıralı güncellemeler uygulanmış kaynak ağacı. `python apply.py /path/to/project` yalnızca beklenen SHA-256 değerleriyle eşleşen dosyalara güncelleme yapar. Bu bir APK veya tam kaynak yedeği değildir.

## Yapılanlar
- Birebir pilotta, iki tarafın bağımsız doğruladığı kimlik koduyla açıkça otomatik yenilemeyi etkinleştirmesinden sonra 80 mesaj eşiğinde deterministik başlatıcı yeni ön anahtar oturumu teklif eder. Karşı taraf doğrular ve aynı oturuma oy verir. Ekran açıkken 10 saniyelik kontrol. Eski oturum salt okunur kalır. 100 mesaj sınırı, karşı taraf onaylayana kadar korunur. HTTP testinde eşik 2 olarak ayarlanmıştır; önceki 100+1 manuel yenileme regresyonu da geçti. Yeni oturumda ilk mesajı başlatıcı göndermelidir.
- Grup pilotu: 50 MiB dosya için ayrı yükleme, şifreli dosya tanımı, imzalı grup zarfı, mesajla atomik bağlama, sahiplik ve dönem üyeliği kontrolü. Mevcut genel yükleme ve yönetici indirme uçları bu dosyaları reddeder. Dosya 3 üyeye 50 MiB olarak birebir doğrulandı; gönderen silme ve diğer üyenin silme reddi test edildi. Yarım yükleme aynı ekran içinde sürdürülür; süreç kapanınca kalıcı devam ve yetim dosya temizliği yoktur.
- Grup geçmişi: mevcut ve geçmiş dönem üyeliği ile onaylı dönemlerin listelenmesi, salt okunur sayfalama ve yerel dönem anahtarıyla açma arayüzü. Yeni üye eski dönem erişiminden, çıkarılan üye tüm yeni sunucu erişiminden men edilir. Eski dönem anahtarları saklandığı sürece geçmiş okunur; bu saklama grup ileri gizliliği değildir.

## Testler
- Node seçili ratchet çekirdeği 37 + grup medya 2 = 39 test.
- Python sunucu 66, veritabanı adaptör kontrolleri 6, TURN 5, pilot HTTP 11 = 88. Toplam 127 çalıştırılan test.
- Test ortamı: Node WebCrypto, yerel aiohttp ve SQLite; gerçek Android, MariaDB ve IndexedDB çalıştırılmadı. UI sözdizimi kontrolü gerçek cihaz/DOM davranış testi değildir.

## Açık kalanlar
- Normal ve grup sohbetlerinin tüm mevcut işlevleriyle (mesaj düzenleme, silme, bildirim, arama, vb.) üretim şifreleme protokolüne geçişi yapılmadı. Yönetici içerik kopyası ile iki uç dışında kimsenin içeriği okuyamaması birlikte sağlanamaz. Eski politikaya dokunulmadı.
- Tam kapalı Android işleminde güvenli anahtar yönetimi yapılmadı; mevcut WebCrypto IndexedDB ve PIN kontrolü atlanmamalı. Native Android Keystore mimarisi ve cihaz testleri gereklidir.
- Grup pilotu gerçek Signal/MLS değildir; aynı dönem içinde ileri gizlilik sağlamaz. Bağımsız güvenlik incelemesi zorunludur. Pilot bayrakları kapalı bırakıldı. Canlı dağıtım yapılmadı.
