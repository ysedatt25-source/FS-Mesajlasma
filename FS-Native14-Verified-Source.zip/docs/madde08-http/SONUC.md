# Madde 8 — gerçek HTTP pilot entegrasyonu (üretim onayı yok)

Bu güncelleme Native13 + Madde01–07 + iki Madde08 prototip paketinin üzerine uygulanır. Normal sohbet gönderimi, geçmişi ve yönetici kopyaları değiştirilmemiştir. Yeni akış ayrı, deneysel, metin ve birebir sohbetlerle sınırlıdır. Varsayılan olarak kapalıdır; yalnızca test sunucusunda `FS_EXPERIMENTAL_RATCHET=1` ile etkinleştirin. Canlı sunucuya, APK'ya veya GitHub'a yüklenmemiştir.

## Yerel doğrulama ve kullanım

1. Güncelleme ZIP'ini açın, `python apply.py /path/to/project` komutuyla önceki paketlerle birleştirilmiş kaynak ağacına uygulayın. Dosyalar SHA-256 ile önceden doğrulanır.
2. Proje dizininde `python -m unittest discover -s tests -p test_ratchet_pilot.py -v` (Node 22+, aiohttp gerektirir) ve `node --test tests/ratchet-prototype.test.mjs tests/ratchet-integration.test.mjs tests/portable-crypto.test.mjs` çalıştırın. Test iki hesapla gerçek yerel HTTP üzerinden çalışır.
3. Test ortamında ortam değişkenini etkinleştirin. Birebir sohbet > Sohbet seçenekleri > Deneysel güvenli metin sohbeti. Karşı tarafın kodunu bağımsız güvenilir kanaldan doğrulayın. Teklifi başlatan ekranı açık tutar, alıcı teklifi kabul eder, başlatan yenileyip bağlantıyı doğrular ve ilk mesajı gönderir. Alıcı mesajları getirip yanıtlar. Sonraki mesajlar aynı oturumdan devam eder. İki dakika içinde ilk anahtar anlaşması tamamlanmalıdır.

## Kapsam ve sınırlar
- Sunucu iki üye dışındaki hesapları (yönetici dahil) reddeder; pilot şifreli paketler normal mesaj tablosu ve yönetici içerik kopyasından ayrıdır. Sunucu yine de üyelik, zaman, mesaj boyutu ve trafik bilgisi görür; oda/hesap silme yetkisi ayrı konudur.
- İmzalı interaktif ECDH, Double Ratchet prototipi, nonce ile oturum kimliği bağlama, şifreli yerel mesaj günlüğü ve ratchet durumunun aynı CAS ile kaydı; ağ yanıtı kaybında aynı ciphertext yeniden gönderilir.
- 100 mesaj/oturum ve 30 oturum/oda sınırı, manuel yenileme. Çevrimdışı ilk anahtar anlaşması, çoklu cihaz, grup, medya, normal sohbet bildirimleri, düzenleme/silme UI, geçmişin taşınması henüz yok. İlk teklif RAM'de; kapanınca yeni teklif gerekir. Yerel günlük geçmişi okunabilir tutmak için cihaz anahtarıyla şifrelenir; cihaz anahtarı ele geçirilirse yerel arşiv risktedir. IndexedDB/Android Keystore ve süreç kesintileri gerçek cihazda doğrulanmamıştır.
- Bu özgün deneysel protokol Signal Protocol/libsignal, X3DH/PQXDH değildir. Bağımsız kriptografi denetimi ve güvenli üretim geçiş planı olmadan etkinleştirilmemelidir. Normal sohbetler ileri gizlilik iddiası taşımaz; yönetici kopyası kaldırılmamıştır. Yeni pilot mesajlarda yönetici kopyası yoktur; politika ve yönetim davranışı üretim öncesi güncellenmelidir.
- SQLite gerçek HTTP testi 2/2 (alt senaryolar: doğrulanmamış pin, çift yönlü gerçek ciphertext, idempotent retry, oturum restorasyonu, üyelik ve engel, admin dışarıda, devre dışı bayrak, eski mesaj, grup yasağı). Portable Node 31/31; önceki sunucu regresyonu 66/66. Node crypto.test.mjs fake-indexeddb olmadığı için yüklenemedi (ayrı kayıt). MariaDB üzerinde çalışma ve UI/Android testi yapılmadı. Testler üretim güvenliği kanıtı değildir.
