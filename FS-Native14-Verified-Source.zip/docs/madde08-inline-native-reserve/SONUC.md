# FS 34.32 — Madde 08 / Birebir sohbet ekranı ve Android açık ön anahtar rezervi

Önkoşul: FS-34.32-Madde08-Grup-Medya-Gecmis-Otomatik-Yenileme.zip ve önceki sıralı güncellemeler uygulanmış kaynak ağacı. `python apply.py /path/to/project` yalnızca beklenen SHA-256 değerleriyle eşleşen dosyalara uygulanır. APK veya tam kaynak yedeği değildir.

## Gerçek değişiklikler
- Karşılıklı onayla deneysel geçişi etkinleşmiş birebir odada normal sohbet ekranının içinde yeni güvenli metin alanı, etkin oturumun doğrulanması, geçmiş metinlerin görüntülenmesi ve 6 saniyelik eşitleme. Eski gönderim devre dışı; sunucu eski kanala dönüşü zaten reddeder. PIN kilidinde ve sohbetten çıkışta yeni transport kapanır. Eski sohbet geçmişi korunur. Dosyalar ve önceki güvenli oturumlar mevcut ayrı yönetim ekranından erişilir.
- Aynı oturumda aynı metnin yeniden gönderimi sabit mesaj kimliği ile tekrarlanır; yanıt kaybolduğunda ikinci kayıt oluşmaz. Bu tekrar anahtarı yalnızca aynı açık ekranın ömrü boyunca tutulur; kalıcı taslak taşıma değildir.
- Android JobScheduler için 15 dakikalık, işletim sisteminin koşullarına bağlı en iyi gayretli periyodik görev. Uygulama/PIN açıkken WebCrypto ile üretilmiş, özel kısmı IndexedDB'ye yazılmış en fazla iki yedek ön anahtarın YALNIZCA imzalı açık paketi AndroidKeyStore AES-GCM ile korunan mevcut SecretStore kuyruğuna geçer. İş, oturum/HTTPS adresi bağlılığını kontrol ederek kullanılabilir uzak ön anahtar havuzu üçten az olduğunda önceden hazırlanmış açık paketi yayımlar. Toplam 30 paket, oda başına 3 üst sınırı, süre ve alan doğrulamaları, oturum değişimi/çıkışta temizleme. Açık paketin yayımlanması için özel anahtar okunmaz, dışarı aktarılmaz, mesaj çözülmez. Rezerv bitince yeni özel anahtar üretebilmek için uygulamanın tekrar açılması gerekir. Android force-stop, yeniden başlatma ve pil/işletim sistemi kısıtları nedeniyle zamanında iş garantisi yoktur. Cihazdaki iş fiilen çalıştırılmamıştır.

## Doğrulama
- Node seçili ratchet paketleri (9 yeni test dahil): 48/48.
- Python: 66 sunucu, 6 veritabanı adaptörü, 5 TURN, 12 pilot HTTP = 89/89. Yeni yerel HTTP testinde rezervden açık anahtar yayını, çevrimdışı ilk anlaşma, çift yönlü inline metin ve kayıp HTTP yanıtı sonrası tek mesaj doğrulandı.
- JVM: 16 saf politika kontrolü; 4 Java kaynak dosyasının javac AST ayrıştırması (Android derleme DEĞİL). JS sözdizimi ve Android manifest XML kontrolü.
- Toplam 137 Node/Python testi; 16 ek JVM politika kontrolü. Android SDK, gerçek cihaz, gerçek Keystore, IndexedDB tarayıcı/DOM ve MariaDB üretim testi yapılmadı.

## Açık kalanlar / güvenlik sınırı
- Normal sohbetin tamamı (medya, mesaj düzenleme/silme, arama, bildirimler, grup arayüzü) henüz yeni protokole taşınmadı. Grup pilotu ayrı; mevcut grup şifrelemesi Signal/MLS veya aynı anahtar dönemi içinde ileri gizlilik değildir.
- Özel anahtarların Keystore içinde oluşturulması, ECDH/imza işlemlerinin native protokole taşınması ve tamamen kapalıyken sınırsız özel anahtar yönetimi yapılmadı. Native rezerv yalnızca önceden imzalanmış açık anahtarları yayımlar. PIN güvenliği atlanmadı.
- Yöneticiye içerik kopyası ile yalnızca iki uçta çözüm ilkesi bir arada sağlanamaz. Eski politika değiştirilmedi; pilot kanalda yöneticiye içerik kopyası üretilmez. Üretim geçişinden önce açık politika kararı ve bağımsız kriptografi incelemesi gereklidir. Pilot bayrakları değiştirilmedi, canlı dağıtım yapılmadı.
