# FS 34.32 — Madde 08: 50 MiB medya ve ön anahtar havuzu

**Deneysel; üretime hazır değildir.** `FS_EXPERIMENTAL_RATCHET` varsayılan olarak kapalı. Canlı sisteme değişiklik yapılmadı. Normal ve grup sohbetleri eski protokolde kalır.

## Uygulama
Önceki `Madde08-Cevrimdisi-Sifreli-Medya-Pilotu` uygulanmış kaynak ağacına bu ZIP açıldıktan sonra `python apply.py /path/to/project` çalıştırılır. Dosya çakışmalarında durur. Yalnızca yalıtılmış test sisteminde etkinleştirilmelidir.

## Eklenenler
- Pilot birebir kanalda 50 MiB (52.428.800 bayt) dosya sınırı. Dosya için rastgele AES-256-GCM anahtarı; oda, oturum, gönderici, dosya adı, boyut ve yükleme kimliği AAD ile bağlanır. Dosya tanımı ve anahtar ratchet mesajının içinde şifrelenir. Sunucuya mevcut yükleme API'si üzerinden en fazla 1 MiB parçalar halinde şifreli dosya gönderilir. Dosya bütünlüğü indirme sırasında doğrulanır. 40 KiB eski pilot mesajları okunabilir.
- Ön anahtar havuzu: pilot ekranı açılırken, elle yenilemede ve teklif kabulünde en az üç kullanılabilir yerel anahtar hedeflenir. 24 saatten az ömrü kalanlar sayılmaz. Özel anahtar yerelde oluşturulur, yayımlamadan önce saklanır; sunucu yalnız açık anahtarı alır.

## Test
38 Node testi (ratchet ve portable-crypto); 4 pilot HTTP testi; 66 mevcut sunucu testi: toplam 108 başarılı. Gerçek yerel HTTP üzerinde 50 MiB rastgele dosya, yeniden oturum açma, bayt eşitliği, 50 MiB üstü reddi, değişmiş şifreli dosya ve bağlam reddi, ön anahtar havuzunun doldurulması, tekrarlı yenileme, tüketim sonrası tamamlama, üçüncü hesap erişim reddi. `crypto.test.mjs` fake-indexeddb bağımlılığı olmadığından çalıştırılamadı (log dahil).

## Kalanlar ve riskler
- Pilot dışı birebir ve grup sohbetleri yeni protokole geçirilmedi. Normal sohbette yönetici kopyası davranışı değişmedi. Grup için doğrulanmış üyelik sürümleri, üyelik değişiminde anahtar yenileme, cihaz başına oturumlar ve güvenli geçiş gerekir. Uygulama genelinde otomatik eski şifrelemeye dönüş olmamalıdır.
- 50 MiB dosya bütün olarak bellekte şifrelenip çözülür. Aktarımın uygulama kapatıldıktan sonra devamı, pilot dosyasının mesaj silme yaşam döngüsüne bağlanması, yetkili silme ve yarım/orphan yükleme temizliği eksiktir. Dosya metadatası sunucuda görülebilir (oda, gönderen, şifreli boyut); dosya adı ve anahtarı şifreli zarftadır.
- Ön anahtar havuzu yalnız pilot ekranındaki olaylarda yenilenir; uygulama genelinde zamanlanmış arka plan yenilemesi, süresi dolmuş yerel anahtarların temizlenmesi, çoklu cihaz ve çapraz sekme yarışlarına yönelik doğrulama eksiktir.
- Bu özel protokol Signal/libsignal, X3DH veya PQXDH değildir. Güvenlik denetimi, fiziksel Android, gerçek IndexedDB ve MariaDB testleri bekliyor.
