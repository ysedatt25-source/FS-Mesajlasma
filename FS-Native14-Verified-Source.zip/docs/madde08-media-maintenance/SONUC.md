# FS 34.32 – Madde 08: medya bağlantısı, kalıcı indirme ve ön anahtar bakımı

**Durum: deneysel birebir kanal geliştirmesi; üretim geçişi tamamlanmadı.**

- Pilot medya mesajı, sunucuda yalnızca sahibi tarafından yüklenen ve aynı odaya ait tamamlanmış dosya kimliğiyle atomik olarak ilişkilendirilir. Yeni bağlantılı medya normal mesajlara eklenemez; genel indirme ve yönetici dosya indirme uçlarından erişilemez. İlgili oturum ve mesajın üyeleri Range isteği yapabilir. Gönderen DELETE ile dosyayı sunucudan kaldırabilir. Silme işareti tutulur; şifreli mesaj sırası korunur; silme tekrarlanabilir. Daha önce alıcı tarafından kaydedilmiş kopyalar, yedekler veya yerel şifreli mesaj anahtarları silinmiş sayılmaz. Eski pilot dosyalar bu yeni bağlantı tablosuna geriye dönük taşınmadı.
- Mevcut DurableDownloads kuyruğu ayrı `ratchet-downloads-v1` alanıyla kullanılır. Şifreli parça ve ilerleme atomik kayda yazılır. Oturum, hesap ve silme durumu kontrol edilir. İndirme tamamlandığında ratchet dosya tanımıyla AES-GCM doğrulanır. Kesinti sonrası pilot ekranından aynı dosyaya yeniden dokunarak devam edilir. Otomatik Android kapalı süreç indirmesi eklenmedi.
- Etkin pilot odalarında ön anahtar bakımı, PIN açıldıktan sonra oda yenilemesi, bağlantı geri gelmesi, ekran yeniden görünmesi ve 65 saniyelik zamanlayıcı üzerinden başlar. Bir turda en fazla iki oda; eşzamanlı çalıştırma önlenir. Kilitli veya oturumu değişmiş cihazda yeni işlemler başlatılmaz. Android tamamen durmuşken anahtar üretilmez. Pilot özellik bayrağı varsayılan kapalı kalır.

## Doğrulama

- 60/60 JavaScript testi (ratchet ve portable testleri), 4/4 yerel HTTP/SQLite entegrasyon testi, 66/66 genel sunucu regresyon testi. Yeni HTTP testinde 50 MiB dosya, HTTP 206 aralığı, yetkisiz silme reddi, tekrar silme, 410 cevabı ve dosya kimliği yeniden kullanımı reddi doğrulandı. İndirme kuyruğu testleri enjekte edilmiş bellek deposunda gerçekleştirildi; fiziksel IndexedDB/Android doğrulaması yapılmadı.
- Android APK derlemesi, gerçek MariaDB testi, fiziksel cihaz, bağımsız kriptografi denetimi yapılmadı. Canlı sunucu veya kullanıcı verisi değiştirilmedi.
- Eski normal ve grup sohbetleri mevcut protokolde kalır. Yeni pilot protokolü Signal olarak tanımlanamaz. Üretim için denetlenmiş protokol/uygulama, doğrulanmış cihaz kimliği, grup üyeliği değişiminde anahtar yenileme, eksik cihaz/oturum yönetimi ve eski sohbet politikası gerekir. Mevcut yöneticiye ayrı şifreli kopya gönderilmesi, yalnızca katılımcılarca okunabilen uçtan uca gizlilikle bağdaşmaz. Bu politika sessizce değiştirilmedi.

## Kurulum

Önceki Madde08-50MiB-Medya-On-Anahtar-Havuzu güncellemesi uygulanmış kaynak kökünde `python apply.py /kaynak/dizin` çalıştırın. Uygulayıcı dosya SHA-256 değerlerini kontrol eder, beklenmeyen kaynak sürümünde değişiklik yapmaz. Üretimde etkinleştirmeyin.
