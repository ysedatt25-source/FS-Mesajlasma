# FS 34.32 – Madde 08, çevrimdışı ön anahtar ve küçük medya pilotu

**Durum:** Deneysel, üretime hazır değil. FS_EXPERIMENTAL_RATCHET varsayılan olarak kapalıdır. Canlı sunucu ve mevcut veriler değiştirilmedi.

## Uygulama
1. Önceki Madde08-Gercek-HTTP-Sifreli-Sohbet-Pilot paketi uygulanmış kaynak ağacına bu ZIP'i açıp `python apply.py /path/to/project` çalıştırın. Manifest tüm değişiklikleri önce/sonra SHA-256 ile denetler; çakışmada durur.
2. Yerel, yalıtılmış test sunucusu dışında etkinleştirmeyin. `FS_EXPERIMENTAL_RATCHET=1` pilotu açar. Sohbet ekranında yalnızca etkin birebir odalarda ayrı deneysel güvenli sohbet düğmesi vardır.
3. Alıcı önceden oda bazında imzalı tek kullanımlık ön anahtar yayımlar. İki taraf birbirinin imza kimliği parmak izini bağımsız kanalda doğrular. Gönderen alıcı çevrimdışıyken yeni oturum başlatabilir ve mesaj/dosya gönderebilir. Alıcı yeniden açtığında teklifi doğrular, yerel ön anahtarı kullanır ve mesajları getirir. Özel ön anahtar gönderilmez. Sunucu tüketimi koşullu UPDATE ile işlem içinde gerçekleştirir. İstemcide ayrı oturuma yeniden bağlanması engellenir.
4. Medya pilotu tek ratchet mesajında en fazla 40 KiB ikili dosyayı, adıyla beraber şifreler. Tür bağımsız indirme; otomatik açma/önizleme yok. Normal 50 MB medya sistemi değişmedi.

## Testler
- Node: 36/36 (ratchet-prototype, ratchet-integration, ratchet-offline, portable-crypto).
- Python: 80/80 (3 pilot HTTP, 66 sunucu, 6 veritabanı, 5 TURN).
- Alıcı kapalıyken ilk mesaj, 40 KiB rastgele baytların birebir çözülmesi, yanlış parmak izi, değiştirilmiş imza, yanlış oda, kullanılan ön anahtar, yeniden başlatma, üçüncü üye erişiminin reddi ve eski sohbet regresyonu.
- `crypto.test.mjs` fake-indexeddb bulunmadığından çalışmadı; ayrı log korunmuştur. HTTP testi bellek CAS deposu kullanır, gerçek IndexedDB/Android doğrulaması değildir. MariaDB şema eklentisi yazıldı, MariaDB sunucusunda çalıştırılmadı.

## Açık riskler / kapsam dışı
- Özel deneysel protokol; libsignal, X3DH/PQXDH değildir. Bağımsız kriptografik denetim gereklidir. İleri gizlilik veya Signal eşdeğerliği garantisi yoktur.
- Normal sohbetler, geçmiş, grup mesajları, 50 MB dosyalar, çağrı medyası, bildirimler ve gerçek üretim geçişi kapsam dışıdır. Eski yöneticiye şifreli kopya davranışı normal sohbette devam eder. Deneysel kanal yöneticiye ayrı kopya oluşturmaz.
- Tek cihaz; otomatik ön anahtar havuzu, süre dolan yerel anahtarların temizliği, oturum açılışı ağ hatasında kayıp teklif kurtarma, çoklu cihaz ve anahtar değişimi yönetimi tamamlanmadı. Mevcut pilotun 100 mesaj/30 oturum sınırları korunur. Sunucu metadata görebilir. Yerel anahtarlar donanım destekli kasa değildir; saklanan mesaj geçmişi cihaz ele geçirilmesine karşı ileri gizlilik garantisi vermez.
- Normal sohbete sessiz geçiş veya eski şifrelemeye otomatik geri dönüş uygulanmadı. Android derleme/cihaz, gerçek IndexedDB ve güvenlik denetimi tamamlanmadan üretime almayın.
