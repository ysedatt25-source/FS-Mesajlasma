# Madde 08 — Oturum arşivi, ön anahtar havuzu, grup pilotu arayüzü
24 Kasım 2026 | 34.32 | Deneysel kaynak güncellemesi

Taban: FS-34.32-Madde08-Grup-Sifreleme-Oturum-Yenileme-Pilotu.zip uygulanmış kaynak ağacı. Önceki paketlerin sırası korunmalıdır. `python apply.py /path/to/project` dosya hash önkoşullarını denetler; canlı sistem değiştirilmez.

## Değişiklikler
- Birebir tamamlanmış oturumların toplam 30 sınırı kaldırıldı. GET listesi en fazla 30 öğe döndürür; `before` ile eski sayfa okunur. Bekleyen çevrimiçi tekliflerin 30 sınırı ve mevcut hız sınırları korunur. 100 mesaj/oturum sınırı, bütün mesaj günlüğünü tek CAS kaydında saklayan tasarım nedeniyle korunur; önceki karşılıklı yenileme sistemi kullanılır.
- Kullanılmış ön anahtarlar aktif havuz kotasına dahil edilmez. Kullanılmış kayıtlar mevcut sona erme tarihine kadar sunucuda korunur, kullanılabilir listeye dönmez. 30 aktif ön anahtar sınırı korunur. Arka plan/PIN kilidi davranışı değişmedi.
- Grup döneminde 100 mesaj yazma sınırı kaldırıldı; okuma 100 mesajlık sayfalarla devam eder. Yeni kayıtların zaman sırası kilitli işlemde monoton artırılır. Geçersiz veya başka döneme ait imleç reddedilir. Mevcut hız sınırlaması korunur.
- Grup sohbetinin içinde ayrı deneysel şifreli metin ekranına giriş eklendi. Bağımsız doğrulama kodu ve tüm üyelerin anahtar onayı gereklidir. Grup dönemi özel anahtarı yayımdan önce hesap+oda+dönem bağlamında IndexedDB'ye kaydedilmek üzere kodlandı. Yeniden açıldığında aynı anahtar kullanılır; kullanıcı her açılışta üye kimliklerini doğrulamalıdır. Gönderim yanıtı kaybolduğunda açık ekran içindeki aynı şifreli paket tekrar denenebilir. Geçmiş görüntülemesi yalnızca güncel dönem içindir; eski dönem kayıtları sunucuda tutulur. Kalıcı gönderim kuyruğu/tekrar saldırısı kaydı bu arayüzde yoktur.

## Doğrulama
- 48 Node birim/kriptografi testi, 10 pilot Python/HTTP testi, 66 genel sunucu, 6 veritabanı ve 5 TURN testi: 135/135.
- 35 arşivlenmiş oturumdan sonra yeni teklif oluşturma ve 30+5 sayfa; 35 kullanılmış ön anahtarın yeni anahtarı engellememesi: sunucu politikası testi (sentetik eski kayıtlar).
- Gerçek yerel HTTP: 101 grup mesajı, 100+1 sayfa ve tekrar/atlama kontrolü, ikinci sayfadaki mesajın alıcıda çözülmesi. Önceki 50 MiB medya, birebir 101. mesaj ve erişim regresyonları tekrar başarılı.
- Yeni JS dosyaları için `node --check`, Python dosyaları için `py_compile` kontrolü. Gerçek IndexedDB, tarayıcı UI, Android, MariaDB, bağımsız kriptografi denetimi yapılmadı. Node oturum saklama testleri bellek temelli CAS kullanır.

## Üretim engelleri
Normal sohbet/normal grup taşıması eksik; ayrı deneysel ekran varsayılan olarak kapalıdır. Yönetici kopyası içeren eski kanal değişmedi. Grup protokolü MLS/Signal Sender Keys değildir, dönem içinde ileri gizlilik sağlamaz. Grup medya, eski grup dönemi geçmişi, üyelik değiştirme API'si, tam otomatik doğrulanmış birebir oturum yenileme, kilitli/kapalı uygulamada ön anahtar bakımı, üretim boyutunda güvenli saklama/temizleme stratejisi ve fiziksel cihaz doğrulaması bekler. Bu paket üretim sürümü değildir; herhangi bir güvenlik garantisi vermez.
