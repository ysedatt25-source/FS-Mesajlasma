# Madde 9 — Profil fotoğrafı yakınlaştırma ve sürükleme

- 1–5 kat ölçek, parmak orta noktasına sabitlenen zoom, dört yöne sınırlandırılmış pan, +/- ve Sıfırla düğmeleri. Yalnızca fotoğraf görüntüsü ölçeklenir. Fotoğraf kaydı ve diğer ekranlar değişmez. Tek dokunuşla orta/tam ekran geçişi korunur; pinch ve sürükleme tıklamaya dönüşmez. Kapanışta pointer capture ve ResizeObserver temizlenir.
- 209 JavaScript, 52 API, 6 DB, 5 TURN, 51 gerçek yerel HTTP/WebSocket DOM emülasyonu ve 62 gerçek Chromium bileşen kontrolü başarılı: toplam 385 otomatik kontrol. Beş yeni Chromium senaryosu gerçek çoklu dokunma girdisi (CDP), doğrultulu sürükleme, uzaklaştırma, sınır/sıfırlama, ekran dönüşü ve kapatıp tekrar açmayı sınar.
- Tüm altı test grubunun exit kodu 0. Loglar ve DOM raporu bu klasörde.
- Android fiziksel cihaz testi, SDK derlemesi ve üretim dağıtımı yapılmamıştır. Büyük emoji varlıkları önceki tam Native12 yedeğinde saklıdır.
