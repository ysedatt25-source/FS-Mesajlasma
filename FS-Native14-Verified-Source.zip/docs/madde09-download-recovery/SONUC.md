# Madde 09 – Kesintiden sonra indirme
- Mevcut şifreli kalıcı indirme kuyruğunda, kaydedilmiş son konum yeniden okunuyor; eski çağıran konumu tekrar yazmıyor.
- Uygulama ön plana dönünce, bağlantı yeniden gelince ve sunucu özelliği doğrulanınca otomatik sürdürme tetiklenir.
- Geçici ağ/sunucu hatalarına kademeli yeniden deneme; PIN kilidi veya ağ kopması bekleyen tetikleyiciyi iptal eder. Yetki ve silinmiş dosya hataları tekrar denenmez.
- 50 MiB dosya için 3 MiB'de ağ kesintisi ve yeni kuyruk nesnesiyle devam testi; çözülmüş verinin SHA-256 özeti eşleşti. Test bellek tabanlı depolama adaptörü kullanır, gerçek Android süreç ölümü testi değildir.
- 16 otomatik test başarılı (download-recovery, ratchet-download, album-download). JavaScript sözdizimi kontrolü başarılı.
- Android süreç kapalıyken sürekli arka plan aktarımı eklenmedi. PIN kilidi açıldığında devam edecek; gerçek IndexedDB/Android süreç ölümünden sonra veri kalıcılığı ayrıca doğrulanmalıdır. Pilot ratchet indirmelerinin yeniden açıldığında aynı dosya seçilerek sürmesi mevcut davranıştır; otomatik ön plan zamanlayıcısı normal indirme kuyruğuna eklenmiştir. Canlı sunucu ve APK değiştirilmedi.
