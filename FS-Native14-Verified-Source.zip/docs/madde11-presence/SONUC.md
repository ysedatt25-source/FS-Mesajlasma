# FS 34.32 — Madde 11: Durum ve yazıyor göstergesi

- WebSocket v2 foreground durumu her bağlantıya özeldir. Eski bağlantının kapanması yeni bağlantının durumunu silmez. Eski HTTP istemcisi uyumluluğu korunur.
- Android onPause bildirimi ve native foreground kontrolü eklenmiştir. PIN kilidi ve arka plan durumu çevrimdışı olur. Normal bağlantıda durum hemen iletilir; kopmada son başarılı heartbeat sonrası 25 saniye lease, 1 saniye süpürme aralığı. 8 saniyede heartbeat. Gerçek ağda anlık teslim garantisi yoktur.
- Çevrimdışı/meşgul tercihleri korunur. Müsaitlik yalnız arama kabulünü etkiler. Yazıyor verisi metin içeriği içermez, arka plana geçişte durdurulur, sunucudaki süresi dolmuş kayıtlar temizlenir.
- 20 Node testi, 69 sunucu testi başarılı (3 presence testi 69'a dahildir). Java parser kontrolü: android derlemesi değildir.
- Gerçek Android cihaz ve canlı sunucu testi yapılmadı. Önceki maddelerin kaynak paketleri uygulanmış olmalıdır; Firebase yapılandırması ve eski güvenlik doğrulamaları ayrıdır. SQLite yerel testleri, MariaDB doğrulaması değildir.
