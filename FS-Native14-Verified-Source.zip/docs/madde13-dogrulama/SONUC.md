# Madde 13 — Kullanıcı kontrollü anahtar kurtarma

Taban: FS-34.32-Madde12-Arka-Plan-Cagri-Kaynak.zip.

- Yeni v2 dışa aktarımlar AES-256-GCM, PBKDF2 SHA-256 (600.000 tur), 16 bayt rastgele tuz ve 12 bayt rastgele IV kullanıyor. Hesap kimliği ve P-256 özel anahtarı şifreli içerikte bulunuyor. Kurtarma parolası en az 16 karakter; eski hesap parolasıyla aynı parola seçilemez (v1 kaynakla dışa aktarım). v1 yerel eski paketler, eski parola ile okunmaya devam eder. Yeni dışa aktarma mevcut yerel kaynak yedeği değiştirmez; dosya kaydetme penceresi iptal edilse bile eski paket korunur. Android kayıt köprüsü kaydetmenin başlatıldığını bildirir, fiziksel kaydın tamamlandığı iddia edilmez.
- Dosya doğrulaması kalıcı depoyu değiştirmez. Hesap doğrulaması ve sunucuda geçerli açık anahtar eşleşmesi zorunludur; yedek aktarırken `new_device=false`. v2 için hesap kimliği de doğrulanır. Başarılı girişten sonra özel anahtar (nonextractable CryptoKey), şifreli yedek ve oturum tek IndexedDB işlemiyle kaydedilir. Yanlış/iptal edilen giriş anahtarı değiştirmez. Kilitlenen oturumun aday anahtarı bellekten bırakılır. Yedek dosyası veya kurtarma parolası API'ye gönderilmez. Önceki sunucuda yeni `recovery_account` alanı kontrol edilmese bile anahtar rotasyonu istenmez ve istemci hesap kimliğini doğrular. Canlı yayın yapılmadı.
- Yedeksiz silinmiş özel anahtar, sunucudan silinmiş mesajlar ve sunucunun artık farklı açık anahtar kaydettiği eski cihaz anahtarı geri yüklenemez. Doğrulama, sunucuda var olan ve geçerli hesaba ait şifreli eski mesajlar içindir. Bağımsız kriptografik güvenlik denetimi yapılmadı.

## Gerçek çalıştırma sonuçları
- JS testleri: 226/226; test dosyalarının her biri bir kez sayıldı, ayrı odak testi toplamda yeniden sayılmadı.
- Python API 57 + DB 6 + TURN 5: 68/68.
- DOM entegrasyonu: 55/55 (Happy DOM ve fake IndexedDB ile gerçek yerel HTTP/WebSocket; Android kayıt köprüsü modellenmiş). Yeni testler yanlış parola, doğru yedek, iptal, farklı hesap, dönüş ve yeni cihazda geçmiş mesajın okunmasını kapsar.
- Chromium bileşenleri: 73/73. Bağımsız Java bildirim mantığı: 11/11.
- Toplam 433 başarılı kontrol. Ek bağımsız gerçek Chromium WebCrypto/IndexedDB denemesi, test sayfasına navigasyon `ERR_BLOCKED_BY_ADMINISTRATOR` nedeniyle başlamadı. Ayrı `recovery-browser.exit` ve hata günlüğü saklandı; başarıya dahil edilmedi. Uygun test ortamında `python tests/key_recovery_browser_probe.py` çalıştırılabilir.
- Android SDK derlemesi, fiziksel cihaz testi, gerçek Android dosya kayıt penceresi ve canlı sunucu dağıtımı bekliyor. Bir sonraki geliştirme madde 14.
