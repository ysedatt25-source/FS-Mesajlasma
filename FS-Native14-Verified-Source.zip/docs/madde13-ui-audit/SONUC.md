# Madde 13 — Arayüz ve komut denetimi (24 Kasım 2026)
Temel: Madde 12 uygulanmış birikimli yerel kaynak. Canlı sunucu ve APK değiştirilmedi.

## Değişiklikler
- Geçersiz oda kimliği, aktif sohbetin sanal listesini ve arayüzünü bozmadan reddedilir; geçerli sohbet açılırken modal kapatılır.
- Bildirim ayarları açıklaması gerçek kullanıcı ayarını gösterir.
- Karşı taraf profilindeki durum salt okunur; grup profilinde üyeler gösterilir; sohbet başlığında grup üye sayısı ve grup avatarı kullanılır. Kendi durumunu değiştirme düğmesi açık erişilebilirlik etiketine sahiptir.
- Sohbet araması diyalog içinde doğrudan seçilebilir sonuç, Türkçe eşleşme, arşivli sohbetler ve boş sonuç durumu sunar; ana listeyi görünmez filtreye sokmaz.
- Silinen kişiyi geri alma ve kalıcı silme sonrasında liste yenilenir.
- Tema değişimi mevcut ayar/profil sayfasını korur; Android geri işlemi alt sayfalarda arayüzdeki Geri davranışıyla eşleşir.
- Görüşme doğrulaması aynı çağrı nesnesi ve aynı SDP ile sınırlıdır. Mesajla yanıtlama odayı iki defa açmaz ve devre dışı yazma alanına yazmaz.

## Testler
- 66/66 seçilmiş JavaScript testi başarılı. Statik kontrol: 139 sabit/yardımcı işlevle oluşturulan eylem adı, 149 switch dalı; eşleşmeyen sabit komut yok. Dinamik komutlar, bağımsız olay dinleyicileri ve API davranışının tamamı bu statik kontrolle kanıtlanmaz.
- 10/10 yeni Chromium kontrolü (gerçek kaynak işlem dağıtıcısı ve şablonları; yerel sahte API).
- 28/28 önceki Chromium kontrolü (7 composer, 7 incoming, 6 viewport, 8 profile). Toplam 38 Chromium kontrolü.
- Tam DOM entegrasyonu ve ayrı profile-viewer.test.mjs, happy-dom bağımlılığı eksikliği nedeniyle başlatılamadı; loglar dahil. Bu testleri başarılı saymadık. Gerçek cihaz, gerçek tüm API uçları, tüm ekran/komut işlevleri ve nihai şifreleme pilotu doğrulanmış değildir.
- Güncelleme yalnızca değişen app.js, yeni testler ve logları içerir; önceki tüm paketlerin yerine geçmez.
