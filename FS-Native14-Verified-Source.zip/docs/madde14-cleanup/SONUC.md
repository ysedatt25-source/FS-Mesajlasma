# Madde 14 — Kaynak kodu temizliği
- Güncel `web/` yerine eski `web-patch/` kullanan tarihsel APK hazırlama aracının yayın/imzalama yolu kapatıldı. Arşiv için yalnızca açıkça belirtilen `--legacy-archive-only --prepare-only` seçeneği kaldı; eski kaynak dosyaları silinmedi.
- WebSocket yeniden bağlanma zamanlayıcısının iki ayrı tanımı tekleştirildi; tekrar eden readyState kontrolü ve erişilemeyen read koşulu kaldırıldı.
- Kullanılmayan dört import ve bir yardımcı fonksiyon temizlendi. PIN kilidinde hassas DOM, potansiyel olarak hata veren şifreleme ve native temizleme işlemlerinden önce gizlenir. Bu hata durumları ayrıca test edildi.
- Üç eski VM test düzeneğinin kaynak dilimleme/sahte bağımlılıkları güncel kodla uyumlu hale getirildi, güvenlik beklentileri korunarak.
- 322 Node testi başarılı; 10 test dosyası happy-dom/fake-indexeddb bulunmadığından başlatılamadı. Ayrı DOM paketi çalıştırılmadı. 80 tamamlanan sunucu/veritabanı/TURN testi başarılı; 3 yeni kaynak temizleme testi başarılı. 59 JS (vendor dahil), 23 Python ve 24 Java dosyasının sözdizimi kontrolü geçti; Java Android SDK ile derlenmedi.
- 58 uygulama JS modülünde üst düzey çift tanım ve eksik göreli statik import tespit edilmedi. Dinamik olarak kullanılan tüm kodların gereksiz olduğu ispatlanmadı. Geçmiş kaynaklar, deneysel şifreleme ve kullanıcı verileri silinmedi. Canlı sistem değiştirilmedi.
