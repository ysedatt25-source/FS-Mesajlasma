# Madde 15 — Yerel güvenlik iyileştirmesi
- HTTP Bearer ve WebSocket oturum anahtarları biçim doğrulaması; JSON gövdesinden sonra tekrar yetki kontrolü.
- Cihaz değişimi sırasında eski oturum oluşturmayı önleyen son anahtar kontrolü; parola hesaplaması sırasında silinen hesabın reddi.
- Dosyaların yeni mesaja bağlanmasında sahiplik, oda, tamamlanma ve yinelenen kimlik kontrolü. Dosya iletimi zaten yeni yükleme oluşturur.
- Normal ve grup dosya yüklemelerinde gövde beklemesinin ardından oturum kontrolü; silinen yükleme 404 döner. Pilot medya dosya uzunluğu kontrolü.
- Kaydedilmiş mesaj listesinde güncel üyelik kontrolü; profil alanlarında tür ve uzunluk kontrolü; süresi dolmuş hız sınırı kayıtlarının temizlenmesi.
- Yeni güvenlik testleri 8/8; API regresyonu 69/69; veri tabanı adaptörü 6/6; deneysel şifreleme HTTP testleri 12/12. Toplam 95. Python derleme/sözdizimi geçti. İlk regresyonda yardımcı işlev adı mevcut yerel değişkenle çakıştı; düzeltildi, son çalıştırmalar başarılı.
- Yerel SQLite ve sentetik test hesapları kullanıldı. MariaDB gerçek sunucusu, üretim TLS/yetki yapılandırması, bağımlılık CVE taraması, fiziksel Android, bağımsız sızma testi yapılmadı. Yönetici kopyalı eski şifreleme ve deneysel yeni protokolün mimari çelişkisi sürüyor. Telefon numarası doğrulaması mevcut tasarımda yok; davet kodu ve mevcut parola minimumu değiştirilmedi. Çoklu sunucu yarış koşulları ve genel kötüye kullanım sınırlandırması ayrıca değerlendirilmelidir. Sıfır açık veya Signal düzeyi güvenlik garantisi verilmez.
