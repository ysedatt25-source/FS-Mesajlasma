# Madde 16 — Performans
- WebSocket olaylarının tetiklediği oda ve mesaj yenilemelerinde aynı kapsam için tek çalışan ve tek bekleyen toplu iş. 70 ms ilk toplama aralığı. Devam eden istekten sonra gelen olaylar kaybolmaz. Eski oturum/rota için bekleyen iş başlatılmaz. Doğrudan kullanıcı işlemlerinin yenileme davranışı değiştirilmedi.
- Kaydırma olayları animasyon karesi başına tek işlemde toplanır; eski ekran callback'i etkisizdir. Okunmamış rozetinin değişmeyen metni tekrar yazılmaz.
- Süresi dolmuş canlı konum etiketi tekrar taranmaz; gizli belgede konum etiketi taraması yapılmaz. Ön plana dönünce kontrol edilir.
- /rooms isteğinde yönetici kaydı oda başına değil bir kez okunur. 13 odalı HTTP testi: 13 yerine 1 yönetici sorgusu.
- 19 Node testi (6 yeni + 13 regresyon), 69 mevcut sunucu ve 1 yeni HTTP testi, 19 Chromium kontrolü (2 sanal liste, 8 son mesaj, 9 klavye). Toplam 108 başarılı test/kontrol. 10.000 satırlık sanal liste testi mevcut davranışın korunduğunu doğrular, yeni bir hız ölçümü değildir.
- Gerçek telefon FPS, gecikme, pil, RAM ve CPU ölçümü yapılmadı; genel hızlanma yüzdesi iddia edilemez. Android SDK derlemesi, tam CI, gerçek ağ ve canlı sunucu testi bu paketin kapsamı dışında. Önceki maddelerin açık güvenlik/entegrasyon işlemleri sürüyor. Canlı sisteme müdahale edilmedi.
