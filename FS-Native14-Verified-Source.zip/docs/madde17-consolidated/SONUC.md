# FS 34.32 – Madde 17, birleştirilmiş kaynak ve CI adayı

- Native13 Madde01 bütünlük manifesti kontrol edildi. 26 yama paketi kronolojik sırayla her dosyanın önce/sonra SHA-256 değeri doğrulanarak uygulandı; çakışma yok.
- Node: 328 test başarılı; 12 test dosyası eksik npm bağımlılığı nedeniyle başlatılamadı (happy-dom, fake-indexeddb, playwright). npm ci offline: ENOTCACHED; online: EAI_AGAIN. Bu nedenle tüm testler yeşil değil.
- Python: 12 test paketi, 200 başarılı test çalıştırması; bazı genel testler tekrar çalıştı. 131 bağımsız test gibi yorumlanmamalı. Yerel aiohttp 3.13.3, sabitlenmiş requirements 3.14.5 ile aynı değil. PyMySQL bulunmadı; SQL adaptör testleri gerçek MariaDB testi değildir.
- Chromium: 16 paket başarılı, 2 paket başarısız/engelli (gerçek WebRTC bağlantı zaman aşımı ve yerel HTTP erişim engeli); yeniden çalıştırmada da ikisi çıkış kodu 1. Ses işleme ve RTP teklif kontrolleri başarılı; uçtan uca ses ve yeniden bağlantı doğrulanmadı.
- 24 Java dosyası sözdizimi kontrolü ve 5 JVM politika test programı başarılı; Android derlemesi değildir. 60 JS ve 24 Python kaynak dosyasının sözdizimi kontrolü başarılı. CI YAML yerelde parse edildi, uzakta doğrulanmadı.
- Android API 35, build tools ve ECJ bulunmadığı için yerel APK derlemesi başarısız. CircleCI yapılandırması hazır; uzaktaki çalıştırma, tam kaynak yükleme ve Firebase istemci yapılandırması bekliyor. Canlı sunucu/veri tabanı değişmedi.
- Şifreleme pilotu ve önceki cihaz doğrulaması eksikleri hâlâ geçerli; nihai yayıma hazır değil.

## CircleCI
Bu arşivi ayrı bir GitHub sürüm varlığı olarak yükleyin (veya bütün ağacı bir geliştirme dalında tutun). `.circleci/config.yml` dosyasını o dalda kullanın. Arşivden geri yükleme için `FS_SOURCE_URL` ve `FS_SOURCE_SHA256` zorunludur. `FS_FCM_PROJECT` ve `FS_GOOGLE_SERVICES_JSON_B64` yalnız Android istemci yapılandırması için korumalı CI değişkenleridir. Sunucu servis hesabı anahtarı Android derleme ortamına konmaz. `tools/ci_verify.py` başarısız testleri gizlemeden raporlar. Derleme yalnız regresyon kapısı başarılı olduğunda başlar. Üretilen APK imzasızdır.
