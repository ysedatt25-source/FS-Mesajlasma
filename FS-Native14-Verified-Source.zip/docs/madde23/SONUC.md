# FS 34.32 — Madde 23: Sesli mesaj sistemi

Taban: FS-34.32-Telegram-Madde22-Dogrulanmis-Birlesik-Kaynak.zip. Bu arşiv önceki birleştirilmiş yamayı ve Madde 23 değişikliklerini içerir; tek başına eksiksiz uygulama kaynak ağacı değildir. Tam sabit kaynak üzerine uygulanır. Önceki source-madde17.sha256 tarihsel taban manifestidir; yeni yama için SHA256-MADDE23.txt kullanılır.

- Yeni kayıt modülü: açık mikrofon izni, Opus/MP4/OGG MIME seçimi, gerçek ses seviyesi, duraklatma ve devam, izin beklerken bırakma/iptal, track kaybında temizleme, süre ve dosya sınırı. Kayıt en fazla 30 dakika ve şifreleme payı için 49 MiB; mevcut 50 MB medya politikasının üstüne çıkmaz.
- Var olan basılı tutma akışına yukarı kaydırarak kilitleme, sola kaydırarak iptal, önizleme ve açık gönderim entegre edildi. Gönderim mevcut kalıcı yükleme kuyruğuna bağlanır; gecikmiş işlem başka sohbetin modalını kapatmaz. Gerçek sunucuya gönderim doğrulanmadı.
- Sohbet içi ses oynatma/duraklatma, süre, konum kaydırıcı, 1/1.5/2 hız, son talebin geçerli olması ve eşzamanlı tek oynatma. Kaydın süre ipucu yeni ses dosyasının adında yer alır; sunucu şeması değişmez.
- Görsel yerleşim: 280, 320, 390, 640, 800 piksel genişliklerde kontrol.

## Test kanıtı
Node: yeni 9 kontrol geçti. Video ve mesaj etkileşimi ile beraber toplam 33 kontrol geçti. Fotoğraf testi başlangıçta album-viewer.js taban dosyası eksik olduğu için çalışamadı (1 başarısız test dosyası). Chromium: 5 senaryo geçti (sentetik ses akışı ile gerçek MediaRecorder ve HTMLAudioElement; fiziksel Android mikrofonu değil). Madde 22 video tarayıcı regresyonu: 8 senaryo geçti. JavaScript sözdizimi kontrolü geçti.

## Yayın kapısı
Pakette app.js tarafından içe aktarılan 34 taban modülü mevcut değil. Tam taban paketi, gerçek iki cihaz testi, Android derlemesi, CircleCI, imzalı APK ve canlı ortam yayını doğrulanmadı; bu yama yayın onayı değildir. Önceki dosyaların tamamı korundu, yalnız app.js ve style.css değişti, iki yeni JS modülü ve iki test dosyası eklendi. Tam kaynak üzerine uygulandıktan sonra testleri yeniden çalıştırın.

Komutlar:
```
node --experimental-default-type=module --test tests/voice-recorder.test.mjs
python tests/test_voice_recorder_browser.py
python tests/test_video_player_browser.py
```
