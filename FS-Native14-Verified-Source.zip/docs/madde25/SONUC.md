# FS 34.32 — Madde 25: Tek görüntülemelik medya

Taban: FS-34.32-Telegram-Madde24-Birlesik-Kaynak.zip. Birleştirilmiş kaynak yaması; eksiksiz depo, imzalı APK veya canlı yayın değildir. Önceki maddeler ve tarihsel SHA256 manifestleri korunmuştur.

## Uygulama
- Bire bir sohbetlerde desteklenen tek fotoğraf veya video için 1 · Bir kez düğmesi; 50 MiB sınırı. Gönderim öncesi dosya düzenleme mümkündür. Özel gönderim internete bağlıdır, şifreli içerik ve aynı yükleme/mesaj kimliği ile açık oturumda yeniden deneme yapılabilir. Normal kalıcı aktarım kuyruğuna alınmaz; süreç kapanırsa gönderim taslağı korunmaz.
- Sunucuda yükleme başlangıcında özel rezervasyon, yayınlandığında tek alıcıya bağlama. İkinci açılışı veritabanı koşullu UPDATE işlemi reddeder. Normal yükleme GET, mesaj indirme, medya galerisi, kaydetme ve normal yönetici indirmesi kapalıdır. Şifreli dosyanın açılış hakkı yanıt gönderilmeden tüketilir; yanıt kaybında hak geri verilmez. Başarılı hak tüketiminde şifreli dosya silinmeye çalışılır; fiziksel silme, yedek kopya veya cihaz ekran kaydına karşı garanti yoktur.
- İstemci ayrı görüntüleyici kullanır; küçük önizleme, albüm, kalıcı indirme ve paylaşım yollarını devre dışı bırakır. Modal kapandığında, ekran değiştiğinde, PIN kilitlenince veya uygulama arka plana gidince nesne URL'si kaldırılır. Gönderen tekrar açamaz. Özel medya için standart yönetici indirmesinin kapatılması bir tasarım tercihidir; genel yönetim işlevleri değiştirilmemiştir.
- Grup, gelişmiş ratchet sohbeti, süreç kapandıktan sonra özel gönderim sürdürme ve ekran görüntüsünün kesin engellenmesi bu yama kapsamında değildir. Gönderim sırasında terk edilmiş sunucu rezervasyonlarının süreye bağlı temizliği henüz yoktur. Gerçek cihaz, MariaDB, eksik ratchet uçları ve tüm sunucu entegrasyonu doğrulanmamıştır. İstemci şifreleme modülü mevcut arşivde bulunmadığından şifreli gerçek medya gönderimi uçtan uca test edilmemiştir.

## Test kanıtı
- 12/12: üretim işleyicilerinin AST üzerinden izole yürütülmesi, gerçek SQLite şeması ve test adaptörüyle; gönderen/yabancı/gizlenen mesaj erişimi, normal indirme ve yönetici indirme reddi, Range reddi, bozuk uzunluk, dosyanın kaldırılması ve 16 eşzamanlı SQLite bağlantısında yalnızca tek atomik hak tüketimi. Gerçek sunucu kimlik doğrulaması bu izolasyon testinde taklit edilmiştir.
- 56/56 Node: 8 yeni tek görüntüleme testi ve 48 önceki aktarım, mesaj etkileşimi, ses/video testi.
- Chromium: 5 ekran boyutunda örnek özel medya kartı, düğmeleri ve önizleme geometrisi. Bu test tam uygulama arayüzü değildir.
- Python ve JS sözdizimi kontrolleri başarılı. Tam sunucu testi database.py eksikliğiyle başlatılamadı; app.js 34 eksik yerel içe aktarım içeriyor. Kaynağın tamamına uygulandıktan sonra tam CI, Android cihaz testi ve gerçek gönderim doğrulaması gereklidir.
