# FS 34.32 — Madde 26: Profesyonel sohbet görünümü

Taban: FS-34.32-Telegram-Madde25-Birlesik-Kaynak.zip. Bu paket mevcut birleştirilmiş yamanın devamıdır; tam depo, APK veya canlı yayın değildir.

## Uygulama
- FS mor/orkide renk paleti korundu. Açık ve koyu tema için gelen/giden mesaj yüzeyi, yazı rengi, kenarlık ve saat/teslim bilgisi ayrı düzenlendi. Metin 15px, saat 11px; daha sade yüzeyler, daha az gölge ve tutarlı boşluklar.
- Aynı gönderenin iki dakika içinde, aynı gün gönderdiği komşu normal metinler görsel olarak gruplandırılır. Okunmamış ayırıcı, farklı gönderen, tek emoji, medya ve arama kaydı grubu keser. Bu iki dakikalık eşik bir tasarım kararıdır. Grup bilgisi tam görünür mesaj dizisinden hesaplanır, sanal pencerenin DOM komşusuna bağlı değildir. Mesaj kimliği, sıralama, içeriği ve teslim bilgisi değiştirilmedi.
- Uzun metin, dosya adı, alıntı, tek görüntüleme, ses kartı ve albümün sınırlandırılması; emoji arka planı şeffaf kaldı. Üst başlık ve yazma alanı ikonları yeniden ölçülendirildi. Mikrofon, telefon ve video SVG yolları yenilendi (ortak ikonlar kullanan diğer ekranlarda da şekil güncellenir; eylem adları değişmedi).
- Sohbet açılırken yalnız başlık ve yazma çubuğunda 140ms saydamlık geçişi. Azaltılmış hareket tercihinde devre dışı. Kaydırma hareketlerine yeni animasyon eklenmedi. Dar ve düşük yükseklikteki görünüm için mevcut klavye/visual viewport mantığı korundu.
- Önceki madde testlerinin izolasyon bağlamına tek görüntüleme modülü bağımlılığı eklendi (test_madde09_layout_browser.py, test_video_player_browser.py, test_message_selection_browser.py). Test beklentileri kaldırılmadı veya gevşetilmedi.

## Doğrulama
- 7/7 yeni grup mantığı testi; seçilen eski Node paketleriyle birlikte 63/63.
- Gerçek Chromium: üretim sohbet şablonu ve renderMessage işlevi izole olarak çalıştırıldı. 6 ekran boyutu x 2 tema (12/12); 280px seçim işaretleri ve azaltılmış hareket (2/2). Ağ, mesaj şifreleme ve giriş bağımlılıkları izole edildi. 390x300 görünüm klavye yüksekliğini taklit eder, gerçek Android klavye testi değildir.
- Önceki Chromium test paketleri: seçim, alıntı/iletişim kutusu, video oynatıcı, ses kaydı, dosya aktarım ve tek görüntüleme yerleşimi başarılı. Ses için sentetik akış kullanılır. Sonuç kayıtları bu klasörde.
- Tam composer DOM testi mevcut kaynakta composer-action.js olmadığından başlatılamadı. 34 önceki eksik app.js içe aktarımı (database.py ayrıca yok) tam uygulama ve Android derlemesini engelliyor. Sürüm 34.32 korunmuştur; canlı yayın, imza, cihaz performansı ve gerçek klavye entegrasyonu doğrulanmamıştır.
