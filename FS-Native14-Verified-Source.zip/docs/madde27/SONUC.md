# FS 34.32 — Devam paketi 27: performans ve akıcılık

Taban: FS-34.32-Telegram-Madde26-Birlesik-Kaynak.zip. Orijinal 27. madde başlığı erişilebilen önceki kayıtlardan doğrulanamadı; sohbet performansı ve eksik yenileme modülünün yeniden oluşturulması seçildi. Bu bir birleşik yama paketidir, tam depo veya APK değildir.

## Değişiklikler
- Mevcut app.js içe aktarımı için eksik `web/refresh-batch.js` yeniden uygulandı. Aynı olay döngüsündeki aynı anahtarlı yenilemeler birleşir; devam eden yenileme sırasında gelen yeni olaylar bir sonraki yenilemede işlenir. Oturum/sohbet anahtarları ayrıdır. Geçersiz işler çalıştırılmaz; istek hatası ilgili çağrılara aktarılır ve sonraki yenileme engellenmez. Kaydırma olayları tek animasyon karesinde birleştirilir. Eski dosyanın bire bir geri yüklenmesi değildir.
- `web/chat-performance.js`: okunmamış mesaj zamanları, değişmez mesaj dizisi referansına bağlı WeakMap önbelleğinde saklanır. Okuma zamanı değişince ikili arama yapılır. Yeni mesaj dizisi, oda/kullanıcı değişikliği, yerel gizleme dizisi değişikliği ve silme revizyonu önbelleği geçersiz kılar. Son okunabilir mesajı bulurken dizinin tamamını kopyalamak yerine sondan arama yapılır. 10.000 mesaj/120 güncelleme testinde 10.000 filtre çağrısı (eski tam tarama yapısı 1.200.000); bu işlem sayısıdır, gerçek cihaz hız ölçümü değildir.
- Mesaj tasarımı, 50 MB aktarım sınırı, ses/video özellikleri ve mevcut güvenlik politikaları değiştirilmedi. Sunucu ve Android dosyaları değiştirilmedi.

## Doğrulama
- 13/13 yeni Node testi; 63/63 seçili önceki Node regresyon testi.
- İzole Chromium testinde üretim `updateLatestButton` işleviyle 5/5 kontrol: okunmamış sayaç, yerel gizleme, silme, en alta inme, gerçek animasyon karesi birleştirme.
- Önceki sohbet yerleşimi: 12 ekran/tema kombinasyonu, seçim geometrisi ve azaltılmış hareket dahil 14/14 kontrol.
- `node --check web/app.js` başarılı. Eksik doğrudan göreli app.js içe aktarımları 34'ten 33'e düştü; `server/database.py` hâlâ yok. Gerçek WebSocket/HTTP sunucusu entegrasyonu, cihaz performansı, tam derleme, imzalama ve yayın doğrulanmadı. Sürüm 34.32 korunmuştur.
