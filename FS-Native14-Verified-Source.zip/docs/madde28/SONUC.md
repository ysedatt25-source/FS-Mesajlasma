# FS 34.32 — Madde 28: sohbet klasörleri

Taban: FS-34.32-Telegram-Madde27-Birlesik-Kaynak.zip. Bu dosya tam depo değil, birleştirilmiş yama paketidir. 25 Kasım tarihli Telegram tarzı geliştirme listesindeki 28. madde sohbet klasörleridir. Önceki paket korunmuştur.

## Geliştirmeler
- Tümü / Okunmamış / Gruplar / Arşiv filtrelerine ek olarak 12 özel klasör, oluşturma, yeniden adlandırma, üyelik düzenleme ve onaylı silme.
- Bir sohbet birden fazla klasöre eklenebilir. Klasör silmek sohbetleri veya mesajları silmez. Seçili klasör silinirse Tümü görünümüne dönülür.
- Türkçe büyük/küçük harf duyarlı olmayan benzersiz ad kontrolü (32 karakter), eski tercih biçimine uyumluluk, yüklenmemiş oda üyeliklerini koruma ve çıktı kaçışları.
- Klasörler mevcut cihaz/hesap bazlı workspace kayıt mekanizmasına eklenir. Sunucu eşitlemesi eklenmedi. Özel klasör görünümü mevcut Tümü listesini filtreler; arşivlenmiş sohbetler mevcut arşiv görünümünde kalır.
- Kayıt hatası durumunda bellek içi klasör değişikliği geri alınır; eski oturumdan kalan form yeni hesabı düzenleyemez.

## Doğrulama ve sınırlar
- Yeni Node testleri 13/13. İzole Chromium testleri 11/11 (üretim klasör işlevleri ve eylem işleyicileri; çalışma alanı deposu test taklidi, gerçek kalıcı depolama değil). Beş ekran boyutu 320–768 px.
- Geniş Node taramasında 174 başarılı (13 yeni test dahil), 1 başarısız test dosyası: `photo-gestures.test.mjs`, mevcut `album-viewer.js` eksikliği nedeniyle. 7 başka test dosyası eksik doğrudan modül/fixture nedeniyle başlatılmadı.
- `node --check web/app.js` ve klasör modülü başarılı. `app.js` içindeki eksik göreli modül sayısı 33, `server/database.py` bulunmuyor. GitHub temel arşivine bu oturumda erişilemedi (ağ DNS hatası, dosya API 404). Eksik güvenlik modülleri tahminle yeniden yazılmadı.
- Sunucu, Android ve şifreleme modülleri değiştirilmedi. Gerçek cihaz, gerçek yerel kalıcı depolama, tam derleme ve canlı yayın doğrulanmadı. Sürüm 34.32.
