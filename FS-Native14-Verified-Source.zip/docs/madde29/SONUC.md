# FS 34.32 — Madde 29: Maksimum uygulama hızı

Taban: Madde28 birleşik yama paketi. Tam kaynak depo değildir. Sürüm değiştirilmedi.

- Bağımsız emoji katalog yüklemesi ve cihaz kimliği hazırlığı paralel başlatılır. PIN ekranı için her iki hazırlığın bitmesi hâlâ zorunlu; güvenlik kapısı ve sabit doğrulama emoji sırası korunur.
- Aynı gönderen ve aynı açık anahtar için paralel anahtar türetme istekleri birleştirilir. Hesap, token, sunucu, cihaz kimliği ve erişim epoch'u eşleşmesi gerekir; hatalar önbelleğe alınmaz, eski oturum sonucu kabul edilmez. Kriptografi algoritması değişmedi.
- Sohbet değiştiğinde eski ağ yanıtı için gereksiz mesaj çözme/render iptal edilir; başlamış şifre çözme işlemi sonucu da yeni sohbeti değiştirmez.
- Mesaj ve medya kimliği indeksleri değişmez dizi referansı üzerinden zayıf önbelleğe alınır. Görünür mesaj seçimi, önizleme, fotoğraf uygunluğu ve sesli mesaj erişimi için yeniden kullanılır. Güncel liste değiştiğinde indeks yenilenir; gizli/silinmiş medya uygunluk kontrolleri korunur.
- Her komşu mesaj çifti için gruplama bir kez hesaplanır ve tarih biçimleyici yeniden kullanılır.
- Emoji seçicide 'Diğer emojiler' yalnızca yeni elemanları ekler. Eski resim düğümleri ve kaynakları korunur; kategori, arama veya azaltılmış hareket tercihi değiştiğinde liste yeniden çizilir. Emoji ve medya dosyalarının kalitesi, kodlama ve bit hızı değiştirilmedi.

## Doğrulama
- 11/11 yeni Node testi. 80 eşzamanlı aynı anahtar isteği için sahte türetme işlevi 1 çağrı (eski algoritmada 80); 10.000 kayıt/120 sorgu için 10.000 kimlik erişimi (120 tam tarama olsaydı 1.200.000). 1.000 mesaj için 999 komşu çifti değerlendirmesi (önceki iki yönlü çağrılar 2.000, sınırdaki iki çağrı boş komşuyla). Bunlar işlem sayılarıdır, gerçek cihaz süreleri değil.
- İzole Chromium: emoji seçici 6/6; sohbet arayüzü 14/14; önceki performans 5/5. Sentetik emoji dosyaları, gerçek üretim animasyon kataloğu değil. Tam cihaz/uygulama benchmarkı değil.
- Node regresyonu: 185 başarılı, 2 test dosyası başlatılamadı (`fake-indexeddb` bağımlılığı ve `album-viewer.js` yok). 5 ek test dosyası eksik doğrudan import nedeniyle denenmedi. Tam DOM paketi çalıştırılmadı.
- app.js ve yeni modül sözdizimi doğrulandı; 33 göreli import hâlâ eksik, `server/database.py` yok. Bu yüzden tam uygulama derlemesi, canlı sunucu, fiziksel cihazda ilk açılış süresi, gerçek animasyon/medya açılış hızı doğrulanmadı. Önceki paket korunmuştur; bu ZIP birleşik yamadır, kurulabilir APK değildir.
