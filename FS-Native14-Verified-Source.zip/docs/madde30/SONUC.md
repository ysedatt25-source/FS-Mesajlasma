# FS 34.32 — Madde 30: RAM, pil ve internet optimizasyonu

Taban: Madde29 birleşik yama paketi. Sürüm 34.32. Tam kaynak depo değildir.

- Çözülmüş mesaj önbelleği tüm yazma yollarında 512 kayıt ve yaklaşık 16 MiB ağırlıkla sınırlı. En son kullanılan kayıtlar öncelikli; limit dışı kayıtlar yalnızca önbellekten çıkarılır. Asıl mesaj, medya, yerel kayıt ve sunucu verisi silinmez. Ağırlık UTF-16 dize uzunluğu ve yaklaşık nesne maliyetidir, gerçek heap ölçümü değildir. Bellekteki diğer listeler/medya dahil toplam RAM limiti değildir.
- Türetilmiş eş anahtarların bellek önbelleği en fazla 256 kayıt; oturum değişiminde önceki temizlik ve epoch kontrolleri korunur. Kripto algoritması ve anahtar saklama politikası değişmedi.
- WebSocket başarısızlıklarında 2 saniyeden 30 saniyeye kadar artan, rastgele küçük sapmalı tekrar denemesi; offline durumda planlanmış tekrar iptal edilir. Online olayı mevcut akışla yeniden bağlantı başlatır. Sunucu oturumu doğruladığında sayaç sıfırlanır. Aktif görüşme sırasında online yeniden bağlanma gecikmesi önceki 2 saniyedir. Mevcut WebSocket bağlantısı sırf uygulama arka plana geçti diye kapatılmaz. Çağrı kurtarma, push, şifreli anahtar bakımı ve aktarım mekanizmaları değiştirilmedi.
- Arka planda görünmeyen canlı konum etiketleri ve ön plan presence heartbeat zamanlayıcıları durdurulur; tekrar görünür olduğunda tek örnek olarak başlatılır. Mevcut görünürlük durum güncellemeleri korunur. Konum doğruluğu, arama ve görsel kalite ayarlarına dokunulmadı.

## Doğrulama
- 14/14 yeni Node testi; 120 saniyelik sürekli sunucu kesintisi simülasyonunda sabit 2 saniye ile 60, yeni politika ile (orta jitter) 7 tekrar denemesi. Gerçek internet tüketimi ölçümü değildir.
- 512 sentetik önizlemeli kayıttan 149 tanesi yaklaşık 16 MiB önbellek sınırında kaldı (16.762.202 tahmini bayt); orijinal kayıt dizisi değişmedi. Gerçek cihaz RAM ölçümü değil.
- İzole Chromium 6/6 (görünürlük olayları simüle edildi), önceki sohbet performansı 5/5. Yeni testler de dahil Node regresyonu 199 başarılı, 1 test dosyası `album-viewer.js` eksikliği nedeniyle başlatılamadı. Altı ek test dosyası doğrudan eksik modül yüzünden, tam DOM testi ise eksik tam kaynak nedeniyle çalıştırılmadı.
- app.js ve resource-budget.js sözdizimi doğrulandı. 33 göreli import ve server/database.py hâlâ eksik. Tam Android derlemesi, gerçek cihaz RAM/pil/internet ölçümü, arka planda çağrı ve canlı sunucu testleri yapılamadı. Bu ZIP birleştirilmiş yamadır, kurulabilir APK değildir.
