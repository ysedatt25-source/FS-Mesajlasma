# FS Mesajlaşma 34.32 — Madde 32 kapsamlı denetim (yayın adayı değil)

## Birleştirme ve kaynak bütünlüğü
- Tam kaynak tabanı: FS-34.32-Tek-Kaynak-Paketi.zip, SHA-256 `83de006dcd53949f58aa0c0be920af03a425c6447fca1944ac0494cd1bf1489b`.
- Madde 31 birleştirilmiş yaması ve CI düzeltmeleri uygulandı; Madde 31'deki güncel dosyalar eski sürümlerle ezilmedi. CI 03'teki dört kayıp Android yapılandırma dosyası, tarihî manifest SHA-256 değerleriyle eşleşerek geri yüklendi; yeni MainActivity korundu. İki kayıp test dosyası önceki CI 01/03 arşivinden doğrulanarak geri yüklendi.
- 881 eski emoji dosyası mevcut imzasız APK'dan orijinal hashlerle kurtarıldı. 3.757 emoji dosyasının tamamı tarihî SHA-256 manifestiyle eşleşti. 4.829 tarihî manifest yolundan eksik kalan yok; değiştirilmiş geliştirme dosyaları eski hashle aynı olmak zorunda değildir. Bu sürüm için SHA256-MADDE32.txt yeniden üretildi.
- Kayıtlı `.circleci/config.yml` artık Madde 32 kaynak manifestini kullanıyor, eski sürümden otomatik geri dönüş yok. Gerçek CircleCI çalıştırılmadı.

## Düzeltmeler
- PIN kilidini ve hassas ekranın gizlenmesini tek görüntülemelik medya temizliğinden önce uygula. Albüm, ratchet, emoji ve ses kaydı dahil çeşitli temizleme adımlarını birbirinden bağımsız hata yakalama ile çalıştır. Medya temizliği hata verse bile kilit ekranı açılmalı. Son fotoğraf seçiminde merkezi kilit kontrolünü açıkça uygula.
- Firebase üretim varyantında arka planda gereksiz ConnectionService kaldırma, BuildConfig bayrağı ve APK kontrolü geri getirildi. Etkin arama ve konum servisleri korunur.
- Eski regresyon testlerindeki eksik test bağlamları (tek görüntüleme, yeni mesaj indeksleri, emoji tıklama gecikmesi, MediaStream getAudioTracks ve değişen kayıt durumları) gerçek güncel üretim fonksiyonlarına uyumlu hale getirildi. Test iddiaları korunarak yeniden çalıştırıldı.

## Son yerel sonuçlar
- Node: 521 başarılı, 11 test dosyası başlatılamadı (`happy-dom`, `fake-indexeddb`; npm DNS EAI_AGAIN). Ayrı DOM entegrasyonu da happy-dom eksikliği nedeniyle başlatılamadı. `node-final.log`, `dom.log`, `npm-install.log`.
- Python: 19 test grubunda 244 başarılı test (70 HTTP sunucu, 6 veritabanı, 4 Firebase idle guard ve diğer güvenlik/şifreleme/aktarım kontrolleri). SQLite kullanıldı, gerçek MariaDB sunucusu doğrulanmadı. `python-unit-results.json` ve ilgili loglar.
- Chromium: 45 test dosyasından 42 başarılı. Üç kalan: `test_call_recovery_browser.py` (bağlantı zaman aşımı), `test_call_verification_transport_browser.py` (yerel DTLS bağlantısı/sertifika istatistiği yok), `test_call_voice_browser.py` (yerel HTTP erişimi ortam tarafından engellendi). Bu üçü başarısız/doğrulanmamış olarak tutuldu; gerçek çağrı davranışı kanıtlanmadı. `browser-final.json` ve önceki/yeni loglar.
- Java: 27 kaynak dosya sözdizimi ayrıştırıldı; 7 bağımsız JVM politika testi başarılı. Bu Android derlemesi değildir.
- APK varlık doğrulaması 881/881 + 2876/2876. Kodlama, çözünürlük veya kareler değiştirilmedi. Madde 31 boyut ölçümü eski APK üzerinde yapıldı; bu arşivden APK üretilmedi.

## Yayın engelleri ve kalan inceleme
Android SDK/Gradle, FCM proje yapılandırması, kalıcı imzalama anahtarı ve gerçek fiziksel cihaz kanıtı bu ortamda yok/doğrulanmadı. Canlı veritabanı/yayın değiştirilmedi. Gerçek cihazlar arası sesli/görüntülü görüşme, Bluetooth, arka plan bildirimleri, pil/RAM ve performans kıyaslaması, üretim bağımlılık güvenlik taraması ve bütün regresyonlar tamamlanmadan yayın yapılmamalı. `release_gate.py` doğru biçimde başarısız döndü. Yönetici erişimi olan standart sohbetler, yalnızca katılımcıların okuyabildiği Signal eşdeğeri uçtan uca şifreleme olarak tanımlanmamalı. Tek görüntülemelik medya için yönetici indirme istisnası ile mevcut gizlilik politikası uyumu ayrıca kontrol edilmeli. Bu dosya nihai güvenlik sertifikası değildir.

## Teslim arşivi
Tam kaynak + tüm emoji arşivinin yüklenmesi başarısız olduğu için 881 büyük eski WebP dosyası teslim ZIP'inde ayrı tutuldu. Diğer 2.876 emoji ve tüm uygulama kaynakları mevcut. Önceki Native13 APK ile `python tools/restore_web_assets_from_apk.py /yol/eski.apk` komutu eksik dosyaları içerik değiştirmeden geri yükler. Ardından `python tools/verify_release_assets.py` ve `sha256sum -c SHA256-MADDE32.txt` çalıştırılmalıdır. CI, eski emoji arşivini sabit hash ile doğrulayarak geri yükler veya sağlanan eski APK yolundan kurtarır. Eksik varlıklar veya hash uyuşmazlıkları varsa derleme durur. Bu ZIP doğrudan kurulabilir APK değildir.
