// Integrate AFTER existing websocket authentication. No database writes, no offline queue.
// roomForMember(uid,room) returns {id, members:[{id},..]} or null; messageInRoom(room,id) verifies membership of the referenced record.
// deliver(uid,event) sends to authenticated currently connected sockets for that member.
const TYPE='emoji-interaction-v1';
const id=x=>typeof x==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(x);
const envelope=x=>x&&typeof x.iv==='string'&&/^[A-Za-z0-9+/=_-]{12,32}$/.test(x.iv)&&typeof x.data==='string'&&/^[A-Za-z0-9+/=_-]{16,2048}$/.test(x.data);
export function createEmojiRelay({roomForMember,messageInRoom,deliver,now=Date.now}){
 const rates=new Map();
 return async function relay(uid,b){
  if(b?.type!==TYPE)return false;
  if(!id(uid)||!id(b.room)||!id(b.target)||!id(b.id)||!b.envelopes||typeof b.envelopes!=='object'||Array.isArray(b.envelopes))return true;
  const t=now();for(const [k,v] of rates)if(t-v.start>=1000)rates.delete(k);const rate=rates.get(uid)||{start:t,count:0,ids:new Set()};if(rate.count>=12||rate.ids.has(b.id))return true;rate.count++;rate.ids.add(b.id);rates.set(uid,rate);if(rates.size>10000)rates.delete(rates.keys().next().value);
  const room=await roomForMember(uid,b.room);if(!room||room.id!==b.room||!room.members?.some(m=>m.id===uid)||!await messageInRoom(b.room,b.target))return true;
  const peers=room.members.filter(m=>m.id!==uid&&id(m.id));
  if(peers.length>200||Object.keys(b.envelopes).length>200)return true;
  await Promise.allSettled(peers.map(m=>{const packet=Object.hasOwn(b.envelopes,m.id)?b.envelopes[m.id]:null;if(envelope(packet))return deliver(m.id,{type:TYPE,room:b.room,target:b.target,id:b.id,from:uid,ts:t,envelope:{iv:packet.iv,data:packet.data}});}));return true;
 };
}
// Apply only in existing authenticated DELETE handler, before the existing transactional delete + room-wide broadcast.
export function canDeleteForEveryone({uid,room,message}){return !!(uid&&room&&message&&message.room===room.id&&room.members?.some(m=>m.id===uid)&&(message.sender===uid||room.kind==='direct'));}
