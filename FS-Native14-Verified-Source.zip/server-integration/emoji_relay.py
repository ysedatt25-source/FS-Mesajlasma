"""Async Python integration for authenticated FS websocket handlers.
No payload persistence. Storage, transport and authentication supplied by existing server.
"""
import asyncio
import re
import time
from collections import OrderedDict

TYPE = 'emoji-interaction-v1'
ID = re.compile(r'[A-Za-z0-9_-]{1,128}\Z')
B64_IV = re.compile(r'[A-Za-z0-9+/=_-]{12,32}\Z')
B64_DATA = re.compile(r'[A-Za-z0-9+/=_-]{16,2048}\Z')

def valid_id(value):
    return isinstance(value, str) and ID.fullmatch(value) is not None

def valid_envelope(value):
    return (isinstance(value, dict) and isinstance(value.get('iv'), str)
            and B64_IV.fullmatch(value['iv']) is not None
            and isinstance(value.get('data'), str) and B64_DATA.fullmatch(value['data']) is not None)

def can_delete_for_everyone(uid, room, message):
    """Re-evaluate inside existing delete transaction; not a delete operation."""
    return bool(valid_id(uid) and room and message and message.get('room') == room.get('id')
                and any(m.get('id') == uid for m in room.get('members', []))
                and (message.get('sender') == uid or room.get('kind') == 'direct'))

class EmojiRelay:
    def __init__(self, room_for_member, message_in_room, deliver, *, clock=time.monotonic, wall=time.time):
        self.room_for_member = room_for_member
        self.message_in_room = message_in_room
        self.deliver = deliver
        self.clock, self.wall = clock, wall
        self.rates = OrderedDict()
        self.seen = OrderedDict()

    async def handle(self, uid, event):
        if not isinstance(event, dict) or event.get('type') != TYPE:
            return False
        room_id, target, event_id = (event.get(k) for k in ('room', 'target', 'id'))
        packets = event.get('envelopes')
        if not all(map(valid_id, (uid, room_id, target, event_id))) or not isinstance(packets, dict) or len(packets) > 200:
            return True
        now = self.clock()
        while self.seen and next(iter(self.seen.values())) + 12 <= now:
            self.seen.popitem(last=False)
        while self.rates and next(iter(self.rates.values()))[0] + 1 <= now:
            self.rates.popitem(last=False)
        start, count = self.rates.get(uid, (now, 0))
        if count >= 12 or (uid, event_id) in self.seen:
            return True
        self.rates[uid] = (start, count + 1)
        self.seen[(uid, event_id)] = now
        while len(self.rates) > 10000:
            self.rates.popitem(last=False)
        while len(self.seen) > 120000:
            self.seen.popitem(last=False)
        room = await self.room_for_member(uid, room_id)
        if not room or room.get('id') != room_id:
            return True
        members = {m.get('id') for m in room.get('members', []) if isinstance(m, dict) and valid_id(m.get('id'))}
        if uid not in members or len(members) > 201 or not await self.message_in_room(room_id, target):
            return True
        ts = int(self.wall() * 1000)
        async def send(peer):
            packet = packets.get(peer)
            if valid_envelope(packet):
                await self.deliver(peer, {'type': TYPE, 'room': room_id, 'target': target, 'id': event_id, 'from': uid,
                                          'ts': ts, 'envelope': {'iv': packet['iv'], 'data': packet['data']}})
        await asyncio.gather(*(send(peer) for peer in members - {uid}), return_exceptions=True)
        return True

class PresenceLeases:
    """Single-process foreground session leases; caller broadcasts changed effective status.
    Never mark available merely because push/background call transport is connected.
    A fresh foreground heartbeat is required. Expire leases via periodic sweep.
    """
    def __init__(self, ttl=45, clock=time.monotonic):
        self.ttl, self.clock = ttl, clock
        self.sessions = {}

    def heartbeat(self, uid, session, foreground, preference='online'):
        if not valid_id(uid) or not valid_id(session):
            return
        if foreground is not True or preference == 'offline':
            self.disconnect(uid, session)
            return
        self.sessions[(uid, session)] = (self.clock() + self.ttl, 'busy' if preference == 'busy' else 'online')

    def disconnect(self, uid, session):
        self.sessions.pop((uid, session), None)

    def sweep(self):
        now = self.clock()
        expired = {uid for (uid, sid), (until, _) in self.sessions.items() if until <= now}
        self.sessions = {k: v for k, v in self.sessions.items() if v[0] > now}
        return expired

    def status(self, uid):
        now = self.clock()
        states = [status for (owner, _), (until, status) in self.sessions.items() if owner == uid and until > now]
        return 'online' if 'online' in states else 'busy' if 'busy' in states else 'offline'
