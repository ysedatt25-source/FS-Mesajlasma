import unittest
from emoji_relay import EmojiRelay, PresenceLeases, can_delete_for_everyone, TYPE

P = {'iv': 'A'*16, 'data':'B'*24}
ROOM = {'id':'r','kind':'direct','members':[{'id':'a'},{'id':'b'}]}
MSG = {'room':'r','sender':'b'}

class RelayTest(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.out = []
        self.t = 1
        async def room(uid, rid): return ROOM if rid == 'r' and uid in ('a','b') else None
        async def msg(rid, target): return rid == 'r' and target == 'm'
        async def deliver(uid, event): self.out.append((uid,event))
        self.relay = EmojiRelay(room, msg, deliver, clock=lambda:self.t, wall=lambda:100)
    def event(self, **kwargs):
        return {'type':TYPE,'room':'r','target':'m','id':'x','from':'spoof','envelopes':{'a':P,'b':P,'outsider':P},**kwargs}
    async def test_authenticated_sender_envelope_only(self):
        self.assertTrue(await self.relay.handle('a', self.event()))
        self.assertEqual(self.out, [('b',{'type':TYPE,'room':'r','target':'m','id':'x','from':'a','ts':100000,'envelope':P})])
    async def test_outside_membership_and_missing_target(self):
        await self.relay.handle('outsider',self.event()); await self.relay.handle('a',self.event(target='other'))
        self.assertFalse(self.out)
    async def test_invalid_envelope(self):
        await self.relay.handle('a',self.event(envelopes={'b':{'iv':'bad','data':'bad'}})); self.assertFalse(self.out)
    async def test_replay_across_rate_window(self):
        await self.relay.handle('a',self.event()); self.t+=2;await self.relay.handle('a',self.event());self.assertEqual(len(self.out),1)
    async def test_rate_limit(self):
        for i in range(20): await self.relay.handle('a',self.event(id=f'x{i}'))
        self.assertEqual(len(self.out),12)
    async def test_other_event_unhandled(self):
        self.assertFalse(await self.relay.handle('a',{'type':'call'}))
    async def test_two_way(self):
        await self.relay.handle('a',self.event());await self.relay.handle('b',self.event(id='y'))
        self.assertEqual([i[0] for i in self.out],['b','a'])
    def test_deletion(self):
        self.assertTrue(can_delete_for_everyone('a',ROOM,MSG));self.assertFalse(can_delete_for_everyone('a',{**ROOM,'kind':'group'},MSG));self.assertFalse(can_delete_for_everyone('x',ROOM,MSG));self.assertFalse(can_delete_for_everyone('a',ROOM,{**MSG,'room':'other'}))

class PresenceTest(unittest.TestCase):
    def setUp(self):
        self.t=0;self.p=PresenceLeases(clock=lambda:self.t)
    def test_offline_by_default_and_on_background(self):
        self.assertEqual(self.p.status('a'),'offline');self.p.heartbeat('a','s',True);self.assertEqual(self.p.status('a'),'online');self.p.heartbeat('a','s',False);self.assertEqual(self.p.status('a'),'offline')
    def test_expiry_without_disconnect(self):
        self.p.heartbeat('a','s',True);self.t=46;self.assertEqual(self.p.status('a'),'offline');self.assertEqual(self.p.sweep(),{'a'})
    def test_multiple_sessions(self):
        self.p.heartbeat('a','s',True);self.p.heartbeat('a','t',True,'busy');self.p.disconnect('a','s');self.assertEqual(self.p.status('a'),'busy');self.p.disconnect('a','t');self.assertEqual(self.p.status('a'),'offline')
    def test_offline_preference(self):
        self.p.heartbeat('a','s',True);self.p.heartbeat('a','s',True,'offline');self.assertEqual(self.p.status('a'),'offline')

if __name__=='__main__':unittest.main()
