"""Authenticated email verification; pending challenges intentionally expire on restart."""
import asyncio, hashlib, hmac, os, re, secrets, smtplib, ssl, time
from email.message import EmailMessage
from aiohttp import web
from database import transaction

def valid_code(code):
    return isinstance(code,str) and re.fullmatch(r"[A-Za-z0-9_-]{32}",code) is not None

def valid_email(email):
    if not isinstance(email,str): return False
    email=email.strip()
    if len(email)>254 or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+",email): return False
    try: email.encode("utf-8")
    except UnicodeEncodeError: return False
    return not any(ord(c)<32 or ord(c)==127 for c in email)

def valid_password(password):
    if not isinstance(password,str) or not 6<=len(password)<=256:
        return False
    try: password.encode("utf-8")
    except UnicodeEncodeError: return False
    return True

def install(app, auth, rate):
    pending = {}
    recovery = {}
    async def status(request):
        user=auth(request)
        row=app['store'].one('SELECT email,verified FROM account_emails WHERE user_id=?',(user,))
        return web.json_response({'email':row['email'] if row else '','verified':bool(row and row['verified'])})
    async def start(request):
        user=auth(request); rate(request,'email-verify-start',3)
        b=await request.json(); email=b.get('email') if isinstance(b,dict) else None
        if not valid_email(email):
            raise web.HTTPBadRequest(text='Geçerli e-posta adresi girin.')
        email=email.strip().lower(); t=time.monotonic()
        password=b.get('password')
        row=app['store'].one('SELECT password,salt FROM users WHERE id=?',(user,))
        if not row or not valid_password(password):
            raise web.HTTPUnauthorized(text='Mevcut hesap şifrenizi girin.')
        hashed=await asyncio.to_thread(hashlib.scrypt,password.encode(),salt=row['salt'],n=16384,r=8,p=1)
        if not hmac.compare_digest(hashed,row['password']):raise web.HTTPUnauthorized(text='Hesap şifresi yanlış.')
        if auth(request)!=user:raise web.HTTPUnauthorized()
        current=app['store'].one('SELECT password,salt FROM users WHERE id=?',(user,))
        if not current or current['password']!=row['password'] or current['salt']!=row['salt']:raise web.HTTPUnauthorized()
        for k,v in list(pending.items()):
            if v[2]<=t:pending.pop(k,None)
        if user in pending and pending[user][2]>t+540:raise web.HTTPTooManyRequests()
        if len(pending)>=10000:raise web.HTTPServiceUnavailable()
        code=secrets.token_urlsafe(24)
        entry=(email,hashlib.sha256(code.encode()).digest(),t+600,row['password'],row['salt'])
        pending[user]=entry
        try:await asyncio.to_thread(app['email_sender'],email,code)
        except Exception:
            if pending.get(user)==entry:pending.pop(user,None)
            raise web.HTTPServiceUnavailable(text='E-posta gönderilemedi.')
        return web.json_response({'ok':True})
    async def finish(request):
        user=auth(request);rate(request,'email-verify-finish',5)
        b=await request.json();code=b.get('code') if isinstance(b,dict) else None
        if auth(request)!=user:raise web.HTTPUnauthorized()
        entry=pending.get(user)
        if not entry or entry[2]<=time.monotonic() or not valid_code(code) or not hmac.compare_digest(entry[1],hashlib.sha256(code.encode()).digest()):
            raise web.HTTPBadRequest(text='Doğrulama kodu geçersiz veya süresi dolmuş.')
        s=app['store']
        current=s.one('SELECT password,salt FROM users WHERE id=?',(user,))
        if not current or current['password']!=entry[3] or current['salt']!=entry[4]:
            pending.pop(user,None);raise web.HTTPUnauthorized()
        with transaction(s.db):
            s.db.execute('DELETE FROM account_emails WHERE user_id=?',(user,))
            s.db.execute('INSERT INTO account_emails(user_id,email,verified) VALUES(?,?,1)',(user,entry[0]))
        pending.pop(user,None)
        return web.json_response({'ok':True})
    async def recovery_start(request):
        rate(request,'password-recovery-start',3)
        b=await request.json()
        email=b.get('email') if isinstance(b,dict) else None
        phone=b.get('phone') if isinstance(b,dict) else None
        from app import phone_aliases, phone_matches
        aliases=phone_aliases(phone)
        if not valid_email(email) or not aliases:
            raise web.HTTPBadRequest(text='Telefon ve e-posta adresini kontrol edin.')
        email=email.strip().lower(); t=time.monotonic()
        for key,entry in list(recovery.items()):
            if entry[2]<=t:recovery.pop(key,None)
        store=app['store']
        matches=phone_matches(store,aliases)
        rows=[r for r in matches if store.one('SELECT user_id FROM account_emails WHERE user_id=? AND email=? AND verified=1',(r['id'],email))]
        if len(rows)==1 and len(recovery)<10000:
            row=rows[0]; user=row['id']
            if user not in recovery or recovery[user][2]<=t+540:
                code=secrets.token_urlsafe(24)
                entry=(email,hashlib.sha256(code.encode()).digest(),t+600,row['password'],row['salt'])
                recovery[user]=entry
                try:await asyncio.to_thread(app['email_sender'],email,code)
                except Exception:
                    if recovery.get(user)==entry:recovery.pop(user,None)
        return web.json_response({'ok':True})
    async def recovery_finish(request):
        rate(request,'password-recovery-finish',5)
        b=await request.json()
        if not isinstance(b,dict):raise web.HTTPBadRequest()
        from app import phone_aliases, phone_matches, password_hash
        email,code,password=b.get('email'),b.get('code'),b.get('password')
        aliases=phone_aliases(b.get('phone'))
        if not aliases or not valid_email(email) or not valid_code(code) or not valid_password(password):
            raise web.HTTPBadRequest(text='Kurtarma bilgilerini kontrol edin.')
        email=email.strip().lower(); s=app['store']
        rows=[r for r in phone_matches(s,aliases) if s.one('SELECT 1 FROM account_emails WHERE user_id=? AND email=? AND verified=1',(r['id'],email))]
        user=rows[0]['id'] if len(rows)==1 else None
        entry=recovery.get(user)
        def valid():
            return entry and recovery.get(user)==entry and entry[0]==email and entry[2]>time.monotonic() and hmac.compare_digest(entry[1],hashlib.sha256(code.encode()).digest())
        if not valid():raise web.HTTPBadRequest(text='Kurtarma kodu geçersiz veya süresi dolmuş.')
        salt=secrets.token_bytes(16); hashed=await asyncio.to_thread(password_hash,password,salt)
        current=s.one('SELECT password,salt FROM users WHERE id=?',(user,))
        if not valid() or not current or current['password']!=entry[3] or current['salt']!=entry[4] or not s.one('SELECT 1 FROM account_emails WHERE user_id=? AND email=? AND verified=1',(user,email)):
            raise web.HTTPBadRequest(text='Kurtarma kodu geçersiz veya süresi dolmuş.')
        with transaction(s.db):
            s.db.execute('UPDATE users SET password=?,salt=? WHERE id=?',(hashed,salt,user))
            s.db.execute('DELETE FROM sessions WHERE user=?',(user,))
        recovery.pop(user,None);pending.pop(user,None)
        async def revoke(ws):
            try:await ws.close(code=4001)
            except (ConnectionError,RuntimeError):pass
        try:await asyncio.wait_for(asyncio.gather(*(revoke(ws) for ws in tuple(s.sockets.get(user,())))),timeout=2)
        except asyncio.TimeoutError:pass
        return web.json_response({'ok':True,'keyRecoveryRequired':True})
    app.router.add_post('/api/account/recovery/finish',recovery_finish)
    app.router.add_post('/api/account/recovery/start',recovery_start)
    app['email_sender']=send_email
    app.router.add_get('/api/account/email',status)
    app.router.add_post('/api/account/email/start',start)
    app.router.add_post('/api/account/email/finish',finish)

def send_email(address,code):
    host=os.environ['FS_SMTP_HOST']; sender=os.environ['FS_SMTP_FROM']
    msg=EmailMessage();msg['From']=sender;msg['To']=address;msg['Subject']='FS e-posta doğrulama';msg.set_content('Doğrulama kodunuz: '+code+'\n10 dakika geçerlidir.')
    mode=os.environ.get('FS_SMTP_MODE','ssl').lower()
    if mode not in ('ssl','starttls'): raise ValueError('SMTP TLS mode required')
    context=ssl.create_default_context()
    port=int(os.environ.get('FS_SMTP_PORT','465' if mode=='ssl' else '587'))
    connection=(smtplib.SMTP_SSL(host,port,context=context,timeout=15) if mode=='ssl' else smtplib.SMTP(host,port,timeout=15))
    with connection as smtp:
        if mode=='starttls':
            smtp.ehlo(); smtp.starttls(context=context); smtp.ehlo()
        smtp.login(os.environ['FS_SMTP_USER'],os.environ['FS_SMTP_PASSWORD'])
        refused=smtp.send_message(msg)
        if refused: raise smtplib.SMTPRecipientsRefused(refused)
