"""FS single-provider API. Message/attachment plaintext never enters this service."""
import asyncio, base64, hashlib, hmac, json, os, re, secrets, sqlite3, time
from collections import defaultdict, deque
from pathlib import Path
from aiohttp import web, WSMsgType
from database import connect, transaction
from account_verify import install as install_account_verify
from view_once import private_upload, private_message, claim
from transfer_parts import check_prefix, write_chunk, MissingPrefix
from turn import TurnCredentials
from stories import install as install_stories, sweep as sweep_stories
from emoji_relay import EmojiRelay, PresenceLeases, valid_id
from group_calls import GroupCalls, CALL_DISCONNECT_GRACE
from ratchet_pilot import install as install_ratchet_pilot
from ratchet_group_pilot import install as install_ratchet_group_pilot
from ratchet_cutover import install as install_ratchet_cutover, active as cutover_active, lock_room, reject_legacy_write
from push_calls import FirebaseTransport,PushCalls,register as register_push,remove as remove_push,valid_registration

ROOT = Path(__file__).resolve().parents[1]
MAX_FILE = 50 * 1024 * 1024
def now(): return int(time.time()*1000)
def uid(): return secrets.token_urlsafe(18)
def password_hash(password, salt):
    return hashlib.scrypt(password.encode(), salt=salt, n=16384, r=8, p=1)
def device_public_key(pub):
    if not isinstance(pub,dict) or pub.get('kty')!='EC' or pub.get('crv')!='P-256' or 'd' in pub:raise ValueError()
    coords=[]
    for field in ('x','y'):
        value=pub.get(field)
        if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9_-]{43}',value):raise ValueError()
        raw=base64.urlsafe_b64decode(value+'=')
        if len(raw)!=32 or base64.urlsafe_b64encode(raw).decode().rstrip('=')!=value:raise ValueError()
        coords.append(int.from_bytes(raw,'big'))
    x,y=coords;p=0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff
    b=0x5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b
    if x>=p or y>=p or (y*y-x*x*x+3*x-b)%p:raise ValueError()
    return dict(kty='EC',crv='P-256',x=pub['x'],y=pub['y'],ext=True,key_ops=[])

def public_key_matches(a,b):return a.get('x')==b.get('x') and a.get('y')==b.get('y') and a.get('crv')==b.get('crv')

def recipient_keys_match(s,room,keys):
    if keys is None:return True # Backward compatible with older installed clients.
    rows=s.all('SELECT u.id,u.pub FROM users u JOIN members m ON m.user=u.id WHERE m.room=?',(room,))
    admin=audit_user(s)
    expected={r['id']:json.loads(r['pub']) for r in rows}
    if admin:expected[admin['id']]=admin['pub']
    return isinstance(keys,dict) and set(keys)==set(expected) and all(isinstance(keys[k],dict) and public_key_matches(keys[k],v) for k,v in expected.items())

def public_user(row, store):
    s=json.loads(row['settings'])
    return dict(id=row['id'],nick=row['nick'],name=row['name'],pub=json.loads(row['pub']),
                status=store.presence.status(row['id']),available=s.get('available',True),about=s.get('about',''),avatar=s.get('avatar',''))
def audit_user(s):
    row=s.one("SELECT u.* FROM users u JOIN app_config c ON c.value=u.id WHERE c.key='admin'")
    return public_user(row,s) if row else None
def auth_admin(request):
    u=auth(request);admin=audit_user(request.app['store'])
    if not admin or admin['id']!=u:raise web.HTTPForbidden(text='Yönetici yetkisi gerekiyor.')
    return u
def blocked(s,a,b):
    return bool(s.one('SELECT 1 FROM blocks WHERE (owner=? AND peer=?) OR (owner=? AND peer=?)',(a,b,b,a)))
def hidden_for(s,u,mid):
    return bool(s.one('SELECT 1 FROM hidden_messages WHERE user=? AND message=?',(u,mid)))
def stamp_expiry(s,room,mid,created):
    policy=s.one('SELECT seconds FROM room_auto_delete WHERE room=?',(room,))
    if policy and policy['seconds']:
        s.db.execute('INSERT INTO message_expiry VALUES(?,?)',(mid,created+policy['seconds']*1000))
def erase_message_row(s,mid,room):
    # Caller owns the transaction; queue ciphertext cleanup only after all checks.
    files=s.all('SELECT upload FROM message_uploads WHERE message=?',(mid,))
    s.db.execute('INSERT OR IGNORE INTO deleted_message_ids VALUES(?,?)',(mid,room))
    s.db.execute('DELETE FROM messages WHERE id=?',(mid,))
    for file in files:
        ident=file['upload']
        if not s.one('SELECT 1 FROM message_uploads WHERE upload=?',(ident,)):
            s.db.execute('INSERT OR IGNORE INTO deleted_upload_queue VALUES(?)',(ident,))

def erase_message(s,mid):
    with transaction(s.db):
        row=s.one('SELECT room FROM messages WHERE id=?',(mid,))
        if row:erase_message_row(s,mid,row['room'])
    clean_deleted_uploads(s)

def clean_deleted_uploads(s):
    # Persistent queue covers a crash between removing the message and unlinking ciphertext.
    for item in s.all('SELECT upload FROM deleted_upload_queue LIMIT 100'):
        ident=item['upload']
        if s.one('SELECT 1 FROM message_uploads WHERE upload=?',(ident,)):
            s.run('DELETE FROM deleted_upload_queue WHERE upload=?',(ident,));continue
        try:(s.dir/ident).unlink(missing_ok=True)
        except OSError:continue # retry on next sweep; never serve a queued deletion
        s.run('DELETE FROM uploads WHERE id=?',(ident,))

class Store:
    def __init__(self,path):
        self.dir=Path(path);self.dir.mkdir(parents=True,exist_ok=True)
        os.chmod(self.dir,0o700)
        self.db=connect(self.dir)
        self.presence=PresenceLeases();self.socket_tokens={};self.presence_sockets={};self.typing_leases={};self.batch_delete_sockets=set()
        self.relay=EmojiRelay(self.relay_room,self.relay_message,self.emit)
        self.sockets=defaultdict(set);self.limits=defaultdict(deque);self.calls={};self.events=defaultdict(lambda:asyncio.Queue(maxsize=100));self.group_calls=GroupCalls(self,blocked);self.push=None
    def all(self,sql,args=()): return [dict(x) for x in self.db.execute(sql,args).fetchall()]
    def one(self,sql,args=()): return self.db.execute(sql,args).fetchone()
    def run(self,sql,args=()):
        cur=self.db.execute(sql,args);self.db.commit();return cur
    def member(self,user,room):
        if not self.one('SELECT 1 FROM members WHERE room=? AND user=?',(room,user)):
            raise web.HTTPForbidden(text='Bu sohbete erişiminiz yok.')
    async def relay_room(self,user,room):
        row=self.one('SELECT r.* FROM rooms r JOIN members m ON r.id=m.room WHERE r.id=? AND m.user=?',(room,user))
        if not row:return None
        members=self.all('SELECT user AS id FROM members WHERE room=?',(room,))
        if any(m['id']!=user and blocked(self,user,m['id']) for m in members):return None
        return {**dict(row),'members':members}
    async def relay_message(self,room,mid):
        return bool(self.one('SELECT 1 FROM messages WHERE id=? AND room=?',(mid,room)))
    async def relay_typing(self,user,room,active,source,kind='typing-v1'):
        # One ephemeral lease per socket: closing an old connection must not
        # cancel a newer connection's activity. No drafts or DB writes.
        if not active:
            self.typing_leases.pop(source,None)
            clock=time.monotonic()
            if any(u==user and r==room and event==kind and until>clock for u,r,until,event in self.typing_leases.values()):return True
        members=await self.relay_room(user,room)
        if not members:return False
        if active:self.typing_leases[source]=(user,room,time.monotonic()+5.5,kind)
        for member in members['members']:
            if member['id']!=user:await self.emit(member['id'],{'type':kind,'room':room,'from':user,'active':active})
        return True
    async def notify_profile(self,user):
        peers=self.all('SELECT DISTINCT m.user FROM members m JOIN members n ON n.room=m.room WHERE n.user=? AND m.user!=?',(user,user))
        for peer in peers:await self.emit(peer['user'],{'type':'profile','from':user})
    async def emit(self,user,event):
        if self.push and event.get('type')=='call' and event.get('from')!=user:self.push.wake(user)
        if self.push and event.get('type') in ('hangup','accepted','call-rejected'):self.push.wake_refresh(user)
        if event.get('type') in ('hangup','accepted','call-rejected','message-alert-refresh') or event.get('type') in ('call','message') and event.get('from')!=user:
            queue=self.events[user]
            if queue.full():queue.get_nowait()
            queue.put_nowait(event)
        for socket in tuple(self.sockets[user]):
            token_hash=self.socket_tokens.get(socket)
            if not token_hash or not self.one('SELECT 1 FROM sessions WHERE token=? AND user=? AND expires>?',(token_hash,user,now())):
                continue
            try:
                if event.get('deleted') and isinstance(event.get('ids'),list) and socket not in self.batch_delete_sockets:
                    # Earlier APKs know single-ID events only; preserve their cache invalidation.
                    legacy={k:v for k,v in event.items() if k!='ids'}
                    for mid in event['ids']:await socket.send_json({**legacy,'id':mid})
                else:await socket.send_json(event)
            except (ConnectionError,RuntimeError): self.sockets[user].discard(socket);self.batch_delete_sockets.discard(socket)
    async def broadcast(self,room,event):
        for m in self.all('SELECT user FROM members WHERE room=?',(room,)):await self.emit(m['user'],event)

@web.middleware
async def boundary(request,handler):
    try:
        origin=request.headers.get('Origin')
        allowed=request.app['origins']
        if origin and origin not in allowed and origin != f'{request.scheme}://{request.host}':
            raise web.HTTPForbidden(text='Kaynak adresi izinli değil.')
        if request.method=='OPTIONS':response=web.Response(status=204)
        else:response=await handler(request)
    except web.HTTPException as e:response=web.json_response({'error':e.text},status=e.status)
    except (ValueError,KeyError,TypeError,json.JSONDecodeError):response=web.json_response({'error':'Geçersiz istek.'},status=400)
    if request.headers.get('Origin') in request.app['origins']:
        response.headers['Access-Control-Allow-Origin']=request.headers['Origin']
        response.headers['Vary']='Origin'
        response.headers['Access-Control-Allow-Headers']='Authorization, Content-Type, Upload-Offset, Range'
        response.headers['Access-Control-Allow-Methods']='GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS'
        response.headers['Access-Control-Expose-Headers']='Upload-Offset, Content-Range, Content-Length'
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['Referrer-Policy']='no-referrer'
    response.headers['Cache-Control']='no-store'
    return response

def validated_token_hash(token):
    # Issued tokens are URL-safe, 32 random bytes; reject malformed input before DB lookup.
    if not isinstance(token,str) or not re.fullmatch(r'[A-Za-z0-9_-]{43}',token):
        raise web.HTTPUnauthorized(text='Geçersiz oturum anahtarı.')
    return hashlib.sha256(token.encode()).hexdigest()

def auth(request):
    header=request.headers.get('Authorization','')
    if not header.startswith('Bearer '):raise web.HTTPUnauthorized(text='Oturum gerekli.')
    row=request.app['store'].one('SELECT user FROM sessions WHERE token=? AND expires>?',(validated_token_hash(header[7:]),now()))
    if not row:raise web.HTTPUnauthorized(text='Oturum süresi doldu. Yeniden giriş yapın.')
    return row['user']
async def body(request):
    b=await request.json()
    if request.path!="/api/session":auth(request)
    if not isinstance(b,dict):raise ValueError()
    return b
def rate(request,key,limit=10):
    q=request.app['store'].limits[(request.remote,key)];t=time.monotonic()
    while q and q[0]<t-60:q.popleft()
    if len(q)>=limit:raise web.HTTPTooManyRequests(text='Çok fazla deneme. Bir dakika bekleyin.')
    q.append(t)
def phone_aliases(value):
    """Accept legacy Turkish spellings without merging accounts. Return exact normalized first."""
    if not isinstance(value,str) or not re.fullmatch(r'\+?[0-9(). \-]+',value.strip()):return ()
    raw=re.sub(r'[(). \-]','',value.strip());digits=raw.lstrip('+')
    if not re.fullmatch(r'[0-9]{10,15}',digits):return ()
    variants=[raw]
    national=None
    if re.fullmatch(r'0[0-9]{10}',digits):national=digits[1:]
    elif re.fullmatch(r'90[0-9]{10}',digits):national=digits[2:]
    elif re.fullmatch(r'0090[0-9]{10}',digits):national=digits[4:]
    elif not raw.startswith('+') and re.fullmatch(r'5[0-9]{9}',digits):national=digits
    if national and national.startswith('5'):
        variants.extend(['+90'+national,'90'+national,'0090'+national,'0'+national,national])
    elif raw.startswith('+'):variants.extend([digits,'00'+digits])
    elif digits.startswith('00'):variants.append('+'+digits[2:])
    return tuple(dict.fromkeys(variants))

def phone_matches(store,aliases):
    if not aliases:return []
    return store.db.execute('SELECT * FROM users WHERE phone IN ('+','.join('?' for _ in aliases)+')',aliases).fetchall()

async def session(request):
    rate(request,'login');s=request.app['store'];b=await body(request)
    changed_device=False
    password=b.get('password','')
    if not isinstance(password,str) or not 6<=len(password)<=256:raise web.HTTPBadRequest(text='Hesap şifresi en az 6 karakter olmalı.')
    if b.get('register'):
        if 'recovery_account' in b:raise web.HTTPBadRequest(text='Anahtar yedeği ile yeni hesap açılamaz.')
        if b.get('privacy_accepted') is not True:raise web.HTTPBadRequest(text='Devam etmek için gizlilik politikasını okuyup kabul edin.')
        if not all(isinstance(b.get(k),str) for k in ('nick','name','phone')):raise ValueError()
        nick=b['nick'].strip();name=b['name'].strip();aliases=phone_aliases(b['phone']);phone=aliases[0] if aliases else ''
        if not re.fullmatch(r'[A-Za-z0-9_]{3,32}',nick) or not 1<=len(name)<=120 or not re.fullmatch(r'\+?[0-9]{10,15}',phone):
            raise web.HTTPBadRequest(text='Ad, telefon ve 3–32 karakterlik kullanıcı adını kontrol edin.')
        if b.get('invite')!='0032':raise web.HTTPBadRequest(text='Davet kodu geçersiz.')
        email=b.get('email')
        if email is not None:
            if not isinstance(email,str) or len(email.strip())>254 or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email.strip()):raise web.HTTPBadRequest(text='Geçerli e-posta adresi girin.')
            email=email.strip().lower()
        pub=device_public_key(b['pub'])
        salt=secrets.token_bytes(16);hashed=await asyncio.to_thread(password_hash,password,salt)
        user=uid()
        if phone_matches(s,aliases):raise web.HTTPConflict(text='Telefon numarası kayıtlı. Mevcut hesabınızla giriş yapın.')
        try:
            with transaction(s.db):
                s.db.execute('INSERT INTO users(id,nick,name,phone,password,salt,pub,settings,created) VALUES(?,?,?,?,?,?,?,?,?)',(user,nick,name,phone,hashed,salt,json.dumps(pub),'{}',now()))
                if email:s.db.execute('INSERT INTO account_emails(user_id,email,verified) VALUES(?,?,0)',(user,email))
        except sqlite3.IntegrityError:raise web.HTTPConflict(text='Telefon veya kullanıcı adı kayıtlı.')
    else:
        if not isinstance(b.get('login'),str) or not isinstance(b.get('pub'),dict):raise ValueError()
        login=b['login'].strip();aliases=phone_aliases(login)
        if aliases:
            matches=phone_matches(s,aliases)
            exact=[r for r in matches if r['phone']==aliases[0]]
            row=exact[0] if exact else matches[0] if len(matches)==1 else None
        else:row=s.one('SELECT * FROM users WHERE nick=? COLLATE NOCASE',(login,))
        salt=row['salt'] if row else b'nonexistent-user'
        hashed=await asyncio.to_thread(password_hash,password,salt)
        if not row or not hmac.compare_digest(hashed,row['password']):raise web.HTTPUnauthorized(text='Kullanıcı adı veya hesap şifresi yanlış.')
        user=row['id'];current=s.one('SELECT * FROM users WHERE id=?',(user,))
        # Account may have been deleted while scrypt ran in a worker.
        if not current or current['password']!=row['password'] or current['salt']!=row['salt']:
            raise web.HTTPUnauthorized(text='Oturum değişti. Yeniden giriş yapın.')
        row=current;pub=json.loads(row['pub'])
        # Validate same-key login too; keep the legacy 409 for a mismatched key.
        if public_key_matches(b['pub'],pub):b['pub']=device_public_key(b['pub'])
        if 'recovery_account' in b:
            if b['recovery_account']!=user or b.get('new_device') is True or not public_key_matches(b['pub'],pub):raise web.HTTPConflict(text='Anahtar yedeği bu hesabın geçerli anahtarıyla eşleşmiyor.')
        if not public_key_matches(b['pub'],pub):
            if b.get('new_device') is not True:raise web.HTTPConflict(text='Bu cihazın şifreleme anahtarı farklı. Uygulamayı güncelleyin veya kişisel anahtar yedeğinizi içe aktarın.')
            new_pub=device_public_key(b['pub'])
            with transaction(s.db):
                s.db.execute('INSERT OR IGNORE INTO message_keys(message,sender_pub) SELECT id,? FROM messages WHERE sender=?',(row['pub'],user))
                s.db.execute('UPDATE users SET pub=? WHERE id=?',(json.dumps(new_pub),user))
                s.db.execute('DELETE FROM sessions WHERE user=?',(user,))
            changed_device=True
            for owner,sid in tuple(s.presence.sessions):
                if owner==user:s.presence.disconnect(owner,sid)
            await s.group_calls.leave(user,'device_changed')
            current=s.calls.pop(user,None)
            if current:
                s.calls.pop(current['peer'],None)
                s.run("UPDATE calls SET ended=?,status='device_changed' WHERE id=?",(now(),current['id']))
                await s.emit(current['peer'],{'type':'hangup','from':user,'room':current['room'],'callId':current['id']})
            s.events.pop(user,None)
            old_sockets=tuple(s.sockets.pop(user,set()))
            async def revoke(socket):
                try:
                    await socket.send_json({'type':'session-revoked'})
                    await socket.close(code=4001)
                except (ConnectionError,RuntimeError):pass
            try:await asyncio.wait_for(asyncio.gather(*(revoke(socket) for socket in old_sockets)),timeout=2)
            except asyncio.TimeoutError:pass
            targets=s.all('SELECT DISTINCT m.user FROM members m JOIN members n ON n.room=m.room WHERE n.user=? AND m.user!=?',(user,user))
            if audit_user(s) and audit_user(s)['id']==user:targets=s.all('SELECT DISTINCT user FROM members WHERE user!=?',(user,))
            for peer in targets:await s.emit(peer['user'],{'type':'profile','from':user,'deviceChanged':True})
    # A concurrent device replacement during awaited cleanup must not mint a stale session.
    latest=s.one('SELECT pub,password,salt FROM users WHERE id=?',(user,))
    if not latest or latest['password']!=hashed or latest['salt']!=salt:
        raise web.HTTPUnauthorized(text='Oturum değişti. Yeniden giriş yapın.')
    if not latest or not public_key_matches(b['pub'],json.loads(latest['pub'])):
        raise web.HTTPConflict(text='Cihaz anahtarı değişti. Yeniden giriş yapın.')
    token=secrets.token_urlsafe(32)
    s.run('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),user,now()+30*86400000))
    row=s.one('SELECT * FROM users WHERE id=?',(user,))
    return web.json_response(dict(token=token,deviceChanged=changed_device,user=public_user(row,s),settings={**json.loads(row['settings']),'notifications':False},isAdmin=bool(audit_user(s) and audit_user(s)['id']==user)))
async def me(request):
    u=auth(request);s=request.app['store']
    if request.method=='PATCH':
        b=await body(request);previous_status=s.presence.status(u);row=s.one('SELECT * FROM users WHERE id=?',(u,));settings=json.loads(row['settings'])
        for k in ['status','available','about','theme','notifications','blur','language','avatar','mutedPeers','mutedRooms','messageAlerts','silentMessageAlerts','notificationDetails','notificationAvatars','discoverByPhone','discoverByEmail']:
            if k in b:settings[k]=b[k]
        settings['notifications']=False
        for key in ('mutedPeers','mutedRooms'):
            muted=settings.get(key,[])
            if not isinstance(muted,list) or len(muted)>1000 or any(not isinstance(x,str) or len(x)>64 or not valid_id(x) for x in muted):raise ValueError()
        if any(not isinstance(settings.get(key,default),bool) for key,default in (('messageAlerts',True),('silentMessageAlerts',False),('notificationDetails',False),('notificationAvatars',False),('discoverByPhone',False),('discoverByEmail',False))):raise ValueError()
        for k,maximum in (('about',1000),('theme',64),('language',32)):
            if k in settings and (not isinstance(settings[k],str) or len(settings[k])>maximum):raise ValueError()
        if 'name' in b and (not isinstance(b['name'],str) or not 1<=len(b['name'].strip())<=120):raise ValueError()
        if settings.get('avatar') and (not isinstance(settings['avatar'],str) or len(settings['avatar'])>150000 or not settings['avatar'].startswith('data:image/jpeg;base64,')):raise ValueError()
        if settings.get('status','offline') not in ['online','offline','busy']:raise ValueError()
        if not isinstance(settings.get('available',True),bool):raise ValueError()
        if any(k!='status' for k in b):
            s.run('UPDATE users SET settings=?,name=? WHERE id=?',(json.dumps(settings),str(b.get('name',row['name']))[:80],u))
        if 'status' in b:
            token_hash=hashlib.sha256(request.headers['Authorization'].removeprefix('Bearer ').encode()).hexdigest()
            if not any(s.socket_tokens.get(ws)==token_hash for ws in s.presence_sockets):
                s.presence.heartbeat(u,token_hash,b['status']!='offline',b['status'])
    row=s.one('SELECT * FROM users WHERE id=?',(u,))
    if request.method=='PATCH' and (previous_status!=s.presence.status(u) or any(k!='status' for k in b)):
        await s.notify_profile(u)
        if any(k in b for k in ('messageAlerts','mutedPeers','mutedRooms','silentMessageAlerts','notificationDetails')):await s.emit(u,{'type':'message-alert-refresh'})
    return web.json_response(dict(user=public_user(row,s),settings={**json.loads(row['settings']),'notifications':False},isAdmin=bool(audit_user(s) and audit_user(s)['id']==u)))
async def logout(request):
    u=auth(request);token=request.headers['Authorization'].removeprefix('Bearer ')
    request.app['store'].run('DELETE FROM sessions WHERE token=?',(hashlib.sha256(token.encode()).hexdigest(),))
    s=request.app['store'];token_hash=hashlib.sha256(token.encode()).hexdigest();old=s.presence.status(u);s.presence.disconnect(u,token_hash)
    if old!=s.presence.status(u):await s.notify_profile(u)
    await s.group_calls.leave(u,'logout')
    for ws in tuple(s.sockets[u]):
        if s.socket_tokens.get(ws)==token_hash:await ws.close(code=4001)
    return web.json_response({'ok':True})
async def people(request):
    u=auth(request);rate(request,'people-search',30);q=request.query.get('q','').strip();s=request.app['store']
    if not 3<=len(q)<=254:return web.json_response([])
    if '@' in q and not q.startswith('@'):
        rows=s.db.execute('SELECT u.* FROM users u JOIN account_emails e ON e.user_id=u.id WHERE e.email=? AND e.verified=1',(q.lower(),)).fetchall()
        rows=[r for r in rows if json.loads(r['settings']).get('discoverByEmail',False) is True] if len(rows)==1 else []
        return web.json_response([public_user(r,s) for r in rows if r['id']!=u and not blocked(s,u,r['id'])])
    if q.startswith('@'):q=q[1:];aliases=()
    else:aliases=phone_aliases(q)
    if aliases and len(re.sub(r'[^0-9]','',q))>=10:
        matches=phone_matches(s,aliases)
        rows=matches if len(matches)==1 else []
        rows=[r for r in rows if json.loads(r['settings']).get('discoverByPhone',False) is True]
    else:rows=s.db.execute('SELECT * FROM users WHERE nick=? COLLATE NOCASE',(q,)).fetchall()
    return web.json_response([public_user(r,s) for r in rows if r['id']!=u and not blocked(s,u,r['id'])])
async def contacts(request):
    u=auth(request);s=request.app['store']
    if request.method=='POST':
        b=await body(request);peer=b['peer']
        if peer==u or not s.one('SELECT 1 FROM users WHERE id=?',(peer,)):raise ValueError()
        s.run('INSERT INTO contacts VALUES(?,?,0) ON CONFLICT(owner,peer) DO UPDATE SET deleted=0',(u,peer))
    return web.json_response([{**public_user(r,s),'deleted':r['deleted']} for r in s.db.execute('SELECT u.*,c.deleted FROM contacts c JOIN users u ON u.id=c.peer WHERE c.owner=?',(u,))])
async def contact_delete(request):
    u=auth(request);s=request.app['store'];peer=request.match_info['peer']
    with transaction(s.db):
        if request.query.get('permanent')=='1':s.db.execute('DELETE FROM contacts WHERE owner=? AND peer=?',(u,peer))
        else:s.db.execute('UPDATE contacts SET deleted=1 WHERE owner=? AND peer=?',(u,peer))
        s.db.execute('DELETE FROM story_close_friends WHERE owner=? AND peer=?',(u,peer))
    return web.json_response({'ok':True})
async def rooms(request):
    u=auth(request);s=request.app['store']
    if request.method=='POST':
        b=await body(request);members=set(b['members'])|{u}
        if os.environ.get('FS_REQUIRE_ADMIN')=='1' and not audit_user(s):raise web.HTTPServiceUnavailable(text='Sunucu yöneticisi henüz yapılandırılmadı.')
        if len(members)<2 or len(members)>100:raise ValueError()
        for m in members:
            if not s.one('SELECT 1 FROM users WHERE id=?',(m,)):raise ValueError()
            if m!=u and blocked(s,u,m):raise web.HTTPForbidden(text='Bu kişiyle bağlantı engellenmiş.')
        if len(members)==2:
            found=s.one("SELECT r.id FROM rooms r JOIN members m ON m.room=r.id WHERE r.kind='direct' AND m.user IN (?,?) GROUP BY r.id HAVING count(*)=2",tuple(members))
            if found:
                s.run('UPDATE room_history_actions SET hidden=0 WHERE room=? AND user=?',(found['id'],u))
                return web.json_response({'id':found['id']})
        room=uid();s.run('INSERT INTO rooms VALUES(?,?,?,?)',(room,str(b.get('title',''))[:80],'direct' if len(members)==2 else 'group',now()))
        s.db.executemany('INSERT INTO members VALUES(?,?)',[(room,m) for m in members]);s.db.commit()
        await s.broadcast(room,{'type':'rooms'})
        return web.json_response({'id':room},status=201)
    rows=s.all('SELECT r.* FROM rooms r JOIN members m ON m.room=r.id WHERE m.user=? ORDER BY r.created DESC',(u,))
    # Only receipts issued after successful client decryption qualify for this count.
    # One grouped query, scoped to authenticated membership; never decrypt payloads.
    counts={x['room']:int(x['n']) for x in s.all("""SELECT m.room,count(*) n FROM message_receipts mr
        JOIN messages m ON m.id=mr.message JOIN members mb ON mb.room=m.room AND mb.user=?
        WHERE mr.user=? AND mr.read_at IS NULL AND m.sender!=?
        AND NOT EXISTS(SELECT 1 FROM hidden_messages hm WHERE hm.message=m.id AND hm.user=?)
        GROUP BY m.room""",(u,u,u,u))} if rows else {}
    admin=audit_user(s) if rows else None
    blocked_peers={x['peer'] for x in s.all('SELECT peer FROM blocks WHERE owner=? UNION SELECT owner AS peer FROM blocks WHERE peer=?',(u,u))} if rows else set()
    for r in rows:
        r['ratchet_pilot']=bool(request.app.get('ratchet_pilot') and r['kind']=='direct')
        r['ratchet_group_pilot']=bool(request.app.get('ratchet_group_pilot') and r['kind']=='group')
        r['ratchet_cutover_available']=bool(r['ratchet_pilot'] and request.app.get('ratchet_cutover'))
        r['ratchet_cutover_active']=bool(cutover_active(s,r['id']))
        r['audit']=admin
        r['unread_delivered_count']=counts.get(r['id'],0)
        r['members']=[public_user(x,s) for x in s.db.execute('SELECT u.* FROM users u JOIN members m ON m.user=u.id WHERE m.room=?',(r['id'],))]
        for person in r['members']:
            if person['id']!=u and person['id'] not in blocked_peers:
                person['last_seen']=s.presence.last_seen(person['id'])
        r['auto_delete_seconds']=(s.one('SELECT seconds FROM room_auto_delete WHERE room=?',(r['id'],)) or {'seconds':0})['seconds']
        last=s.one('SELECT * FROM messages WHERE room=? AND NOT EXISTS(SELECT 1 FROM hidden_messages h WHERE h.message=messages.id AND h.user=?) ORDER BY created DESC,id DESC LIMIT 1',(r['id'],u))
        r['last']=message_for(last,u,s) if last else None
        action=s.one('SELECT revision,hidden FROM room_history_actions WHERE room=? AND user=?',(r['id'],u))
        if action:
            r['history_revision']=action['revision']
            # A new visible message or call revives a personally removed direct room.
            r['hidden_from_home']=bool(action['hidden'] and not last and not s.one('SELECT 1 FROM calls c WHERE c.room=? AND NOT EXISTS(SELECT 1 FROM hidden_calls h WHERE h.call_id=c.id AND h.user=?) LIMIT 1',(r['id'],u)))
    return web.json_response(rows)
def message_for(row,u,s):
    d=dict(row);d['silent']=bool(s.one('SELECT 1 FROM silent_messages WHERE message=?',(d['id'],)));d['envelope']=json.loads(d.pop('envelopes')).get(u)
    once=private_message(s,d['id'])
    if once:d.update(view_once=True,view_once_opened=once['opened'] is not None)
    expiry=s.one('SELECT due FROM message_expiry WHERE message=?',(d['id'],))
    if expiry:d['delete_at']=expiry['due']
    key=s.one('SELECT sender_pub FROM message_keys WHERE message=?',(d['id'],))
    if key:d['sender_pub']=json.loads(key['sender_pub'])
    d['history_count']=s.one('SELECT count(*) n FROM message_revisions WHERE message=?',(d['id'],))['n']
    d['receipts_v2']=s.all('SELECT user,delivered,read_at FROM message_receipts WHERE message=?',(d['id'],))
    return d
def validate_envelopes(s,room,envelopes):
    members={x['user'] for x in s.all('SELECT user FROM members WHERE room=?',(room,))}
    admin=audit_user(s)
    if admin:members.add(admin['id'])
    if not isinstance(envelopes,dict) or set(envelopes)!=members:raise ValueError()
    for e in envelopes.values():
        if set(e)!= {'iv','data'} or len(base64.b64decode(e['iv'],validate=True))!=12 or len(e['data'])>100000:raise ValueError()
        base64.b64decode(e['data'],validate=True)
async def messages(request):
    u=auth(request);s=request.app['store'];room=request.match_info['room'];s.member(u,room)
    if request.method=='POST':
        direct=s.one('SELECT kind FROM rooms WHERE id=?',(room,))
        if direct and direct['kind']=='direct':
            peers=s.all('SELECT user FROM members WHERE room=? AND user!=?',(room,u))
            if any(blocked(s,u,p['user']) for p in peers):raise web.HTTPForbidden(text='Bu kişiyle bağlantı engellenmiş.')
        b=await body(request);s.member(u,room);silent=b.get('silent',False)
        if direct and direct['kind']=='direct':
            peers=s.all('SELECT user FROM members WHERE room=? AND user!=?',(room,u))
            if any(blocked(s,u,p['user']) for p in peers):raise web.HTTPForbidden(text='Bu kişiyle bağlantı engellenmiş.')
        if type(silent) is not bool:raise ValueError()
        reject_legacy_write(s,room);validate_envelopes(s,room,b['envelopes']);mid=b.get('id',uid())
        if not re.fullmatch(r'[A-Za-z0-9_-]{10,64}',mid):raise ValueError()
        if s.one('SELECT 1 FROM deleted_message_ids WHERE id=?',(mid,)):raise web.HTTPConflict(text='Bu mesaj daha önce silindi.')
        existing=s.one('SELECT * FROM messages WHERE id=?',(mid,))
        if existing:
            if existing['sender']!=u or existing['room']!=room or hidden_for(s,u,mid):raise web.HTTPConflict()
            return web.json_response(message_for(existing,u,s))
        if not recipient_keys_match(s,room,b.get('recipient_pubs')):return web.json_response({'error':'Kişinin cihaz anahtarı değişti. Sohbeti yenileyip tekrar gönderin.','code':'KEY_CHANGED'},status=409)
        reply=b.get('reply')
        if reply and (hidden_for(s,u,reply) or not s.one('SELECT 1 FROM messages WHERE id=? AND room=?',(reply,room))):raise ValueError()
        uploads=b.get('uploads',[])
        if not isinstance(uploads,list) or len(uploads)>10:raise ValueError()
        if any(not valid_id(i) for i in uploads) or len(set(uploads))!=len(uploads):raise ValueError()
        once=b.get('view_once',False)
        if type(once) is not bool:raise ValueError()
        if once and (len(uploads)!=1 or not direct or direct['kind']!='direct' or len(peers)!=1):raise web.HTTPBadRequest(text='Tek görüntüleme yalnızca bire bir sohbette bir dosya için kullanılabilir.')
        for ident in uploads:
            reservation=private_upload(s,ident)
            if bool(reservation)!=once or (reservation and reservation['message'] is not None):raise web.HTTPConflict(text='Tek görüntüleme rezervasyonu geçersiz.')
            if (s.one('SELECT 1 FROM ratchet_pilot_media WHERE upload_id=?',(ident,)) or s.one('SELECT 1 FROM ratchet_group_uploads WHERE upload_id=?',(ident,))):raise web.HTTPConflict(text='Dosya güvenli sohbete bağlı.')
            if s.one('SELECT 1 FROM deleted_upload_queue WHERE upload=?',(ident,)) or not s.one('SELECT 1 FROM uploads WHERE id=? AND room=? AND complete=1 AND owner=?',(ident,room,u)):
                raise web.HTTPForbidden(text='Dosya bu göndericiye ait değil.')
        with transaction(s.db):
            lock_room(s,room);s.member(u,room);reject_legacy_write(s,room);validate_envelopes(s,room,b['envelopes'])
            if s.one('SELECT 1 FROM scheduled_messages WHERE id=?',(mid,)):raise web.HTTPConflict()
            if s.one('SELECT 1 FROM deleted_message_ids WHERE id=?',(mid,)):raise web.HTTPConflict()
            created=now();s.db.execute('INSERT INTO messages VALUES(?,?,?,?,?,?,?)',(mid,room,u,json.dumps(b['envelopes']),created,None,reply));stamp_expiry(s,room,mid,created)
            s.db.execute('INSERT INTO message_keys VALUES(?,?)',(mid,s.one('SELECT pub FROM users WHERE id=?',(u,))['pub']))
            for ident in uploads:
                reservation=private_upload(s,ident)
                if bool(reservation)!=once or (reservation and reservation['message'] is not None):raise web.HTTPConflict()
                if once:
                    if s.one('SELECT 1 FROM message_uploads WHERE upload=?',(ident,)):raise web.HTTPConflict()
                    if s.db.execute('UPDATE view_once_uploads SET message=?,recipient=? WHERE upload=? AND message IS NULL',(mid,peers[0]['user'],ident)).rowcount!=1:raise web.HTTPConflict()
                s.db.execute('INSERT INTO message_uploads VALUES(?,?)',(mid,ident))
            if silent:s.db.execute('INSERT INTO silent_messages VALUES(?)',(mid,))
        if not silent and s.push and s.push.transport:
            for member in s.all('SELECT user FROM members WHERE room=? AND user!=?',(room,u)):
                s.push.wake_message(member['user'],room,mid)
        await s.broadcast(room,{'type':'message','room':room,'id':mid,'from':u})
        return web.json_response(message_for(s.one('SELECT * FROM messages WHERE id=?',(mid,)),u,s),status=201)
    before=int(request.query.get('before',now()+1));before_id=request.query.get('before_id','~');rows=s.db.execute('SELECT * FROM messages WHERE room=? AND NOT EXISTS(SELECT 1 FROM hidden_messages h WHERE h.message=messages.id AND h.user=?) AND (created<? OR (created=? AND id<?)) ORDER BY created DESC,id DESC LIMIT 80',(room,u,before,before,before_id)).fetchall()
    receipts=s.all('SELECT user,ts FROM receipts WHERE room=?',(room,))
    return web.json_response([{**message_for(r,u,s),'read_by':list(dict.fromkeys([p['user'] for p in receipts if p['ts']>=r['created']]+[p['user'] for p in s.all('SELECT user FROM message_receipts WHERE message=? AND read_at IS NOT NULL',(r['id'],))]))} for r in reversed(rows)])

async def scheduled_messages(request):
    u=auth(request);s=request.app['store'];room=request.match_info['room'];s.member(u,room)
    if request.method=='GET':
        rows=s.all('SELECT id,due,reply,silent,error,envelopes,sender_pub FROM scheduled_messages WHERE room=? AND sender=? ORDER BY due,id',(room,u))
        return web.json_response([{**{k:r[k] for k in ('id','due','reply','silent','error')},'envelope':json.loads(r['envelopes']).get(u),'sender_pub':json.loads(r['sender_pub'])} for r in rows])
    if request.method=='DELETE':
        with transaction(s.db):
            lock_room(s,room)
            if not s.one('SELECT 1 FROM scheduled_messages WHERE id=? AND room=? AND sender=?',(request.match_info['id'],room,u)):raise web.HTTPNotFound()
            s.db.execute('DELETE FROM scheduled_messages WHERE id=? AND room=? AND sender=?',(request.match_info['id'],room,u))
        return web.json_response({'ok':True})
    b=await body(request);mid=b.get('id');due=b.get('due');silent=b.get('silent',False);reply=b.get('reply');keys=b.get('recipient_pubs')
    if not isinstance(mid,str) or not re.fullmatch(r'[A-Za-z0-9_-]{10,64}',mid) or type(due) is not int or type(silent) is not bool:raise ValueError()
    if due<now()+5000 or due>now()+365*86400000 or not isinstance(keys,dict):raise ValueError()
    with transaction(s.db):
        lock_room(s,room);s.member(u,room);reject_legacy_write(s,room)
        existing=s.one('SELECT * FROM scheduled_messages WHERE id=?',(mid,))
        if existing:
            if existing['sender']!=u or existing['room']!=room:raise web.HTTPConflict()
            return web.json_response({'id':mid,'due':existing['due']})
        if s.one('SELECT 1 FROM messages WHERE id=?',(mid,)) or s.one('SELECT 1 FROM deleted_message_ids WHERE id=?',(mid,)):raise web.HTTPConflict()
        if s.one('SELECT count(*) n FROM scheduled_messages WHERE sender=?',(u,))['n']>=100:raise web.HTTPTooManyRequests(text='En fazla 100 zamanlanmış mesaj.')
        if any(blocked(s,u,m['user']) for m in s.all('SELECT user FROM members WHERE room=? AND user!=?',(room,u))):raise web.HTTPForbidden()
        validate_envelopes(s,room,b['envelopes'])
        if not recipient_keys_match(s,room,keys):raise web.HTTPConflict(text='Cihaz anahtarları değişti. Sohbeti yenileyin.')
        if reply and (hidden_for(s,u,reply) or not s.one('SELECT 1 FROM messages WHERE id=? AND room=?',(reply,room))):raise ValueError()
        s.db.execute('INSERT INTO scheduled_messages VALUES(?,?,?,?,?,?,?,?,?,?)',(mid,room,u,json.dumps(b['envelopes']),json.dumps(keys),s.one('SELECT pub FROM users WHERE id=?',(u,))['pub'],due,reply,int(silent),None))
    return web.json_response({'id':mid,'due':due},status=201)

async def dispatch_scheduled(s):
    for item in s.all('SELECT id,room FROM scheduled_messages WHERE error IS NULL AND due<=? ORDER BY due,id LIMIT 50',(now(),)):
        room=item['room'];mid=item['id'];published=None
        with transaction(s.db):
            lock_room(s,room)
            row=s.one('SELECT * FROM scheduled_messages WHERE id=? AND error IS NULL AND due<=?',(mid,now()))
            if not row:continue
            u=row['sender'];failure=None
            if not s.one('SELECT 1 FROM members WHERE room=? AND user=?',(room,u)):failure='Sohbet üyeliği sona erdi.'
            elif cutover_active(s,room):failure='Sohbet güvenli kanala geçti.'
            elif any(blocked(s,u,m['user']) for m in s.all('SELECT user FROM members WHERE room=? AND user!=?',(room,u))):failure='Sohbet bağlantısı engellendi.'
            elif not recipient_keys_match(s,room,json.loads(row['recipient_pubs'])):failure='Cihaz anahtarı değişti. Yeniden zamanlayın.'
            elif row['reply'] and (hidden_for(s,u,row['reply']) or not s.one('SELECT 1 FROM messages WHERE id=? AND room=?',(row['reply'],room))):failure='Yanıtlanan mesaj silindi.'
            if failure:
                s.db.execute('UPDATE scheduled_messages SET error=? WHERE id=?',(failure,mid));continue
            created=now();s.db.execute('INSERT INTO messages VALUES(?,?,?,?,?,?,?)',(mid,room,u,row['envelopes'],created,None,row['reply']));stamp_expiry(s,room,mid,created)
            s.db.execute('INSERT INTO message_keys VALUES(?,?)',(mid,row['sender_pub']))
            if row['silent']:s.db.execute('INSERT INTO silent_messages VALUES(?)',(mid,))
            s.db.execute('DELETE FROM scheduled_messages WHERE id=?',(mid,));published=(u,row['silent'])
        if published:
            u,silent=published
            if not silent and s.push and s.push.transport:
                for m in s.all('SELECT user FROM members WHERE room=? AND user!=?',(room,u)):s.push.wake_message(m['user'],room,mid)
            await s.broadcast(room,{'type':'message','room':room,'id':mid,'from':u})

async def pending_delivery(request):
    u=auth(request);s=request.app['store']
    after=int(request.query.get('after','0'));after_id=request.query.get('after_id','')
    if after<0 or after>now()+60000 or len(after_id)>64 or (after_id and not valid_id(after_id)):raise ValueError()
    rows=s.all("SELECT m.* FROM messages m JOIN members mb ON mb.room=m.room AND mb.user=? LEFT JOIN message_receipts mr ON mr.message=m.id AND mr.user=? WHERE m.sender!=? AND mr.message IS NULL AND NOT EXISTS(SELECT 1 FROM hidden_messages h WHERE h.message=m.id AND h.user=?) AND (m.created>? OR (m.created=? AND m.id>?)) ORDER BY m.created,m.id LIMIT 40",(u,u,u,u,after,after,after_id))
    return web.json_response([message_for(r,u,s) for r in rows])

async def check_messages(request):
    """Reconcile client cache without retaining deleted message IDs or contents."""
    u=auth(request);s=request.app['store'];room=request.match_info['room'];s.member(u,room)
    b=await body(request);ids=b.get('ids')
    if not isinstance(ids,list) or len(ids)>200 or any(not isinstance(x,str) or not re.fullmatch(r'[A-Za-z0-9_-]{10,64}',x) for x in ids):raise ValueError()
    ids=list(dict.fromkeys(ids))
    if not ids:return web.json_response({'existing':[]})
    placeholders=','.join('?' for _ in ids)
    rows=s.all(f'SELECT id FROM messages WHERE room=? AND NOT EXISTS(SELECT 1 FROM hidden_messages h WHERE h.message=messages.id AND h.user=?) AND id IN ({placeholders})',(room,u,*ids))
    return web.json_response({'existing':[r['id'] for r in rows]})
async def hide_messages(request):
    u=auth(request);s=request.app['store'];room=request.match_info['room'];s.member(u,room)
    b=await body(request);ids=b.get('ids')
    if not isinstance(ids,list) or not 1<=len(ids)<=200 or any(not valid_id(i) for i in ids):raise ValueError()
    ids=list(dict.fromkeys(ids))
    with transaction(s.db):
        lock_room(s,room)
        for mid in ids:
            row=s.one('SELECT room FROM messages WHERE id=?',(mid,))
            if row and row['room']!=room:raise web.HTTPNotFound()
            if row:
                s.db.execute('INSERT OR IGNORE INTO hidden_messages VALUES(?,?)',(u,mid))
                s.db.execute('DELETE FROM saved WHERE user=? AND message=?',(u,mid))
    for mid in ids:await s.emit(u,{'type':'message','room':room,'id':mid,'deleted':True,'personal':True,'from':u})
    await s.emit(u,{'type':'message-alert-refresh'})
    return web.json_response({'ok':True,'ids':ids})

async def batch_delete_messages(request):
    u=auth(request);s=request.app['store'];room=request.match_info['room'];s.member(u,room)
    b=await body(request);ids=b.get('ids');call_ids=b.get('call_ids',[]);scope=b.get('scope')
    if scope not in ('self','everyone') or not isinstance(ids,list) or not isinstance(call_ids,list) or not 1<=len(ids)+len(call_ids)<=1000 or any(not valid_id(i) for i in ids+call_ids) or (call_ids and scope!='self'):raise ValueError()
    ids=list(dict.fromkeys(ids));call_ids=list(dict.fromkeys(call_ids))
    with transaction(s.db):
        locked=lock_room(s,room)
        if not locked:raise web.HTTPNotFound()
        s.member(u,room)
        rows=[]
        for mid in ids:
            row=s.one('SELECT room,sender FROM messages WHERE id=?',(mid,))
            if not row:
                tombstone=s.one('SELECT room FROM deleted_message_ids WHERE id=?',(mid,))
                if tombstone and tombstone['room']==room:continue
                raise web.HTTPNotFound()
            if row['room']!=room:raise web.HTTPNotFound()
            if scope=='everyone' and (hidden_for(s,u,mid) or (row['sender']!=u and locked['kind']!='direct')):raise web.HTTPForbidden()
            rows.append(mid)
        for cid in call_ids:
            if not s.one('SELECT 1 FROM calls WHERE id=? AND room=?',(cid,room)):raise web.HTTPNotFound()
        for cid in call_ids:s.db.execute('INSERT OR IGNORE INTO hidden_calls VALUES(?,?)',(u,cid))
        for mid in rows:
            if scope=='everyone':erase_message_row(s,mid,room)
            else:
                s.db.execute('INSERT OR IGNORE INTO hidden_messages VALUES(?,?)',(u,mid))
                s.db.execute('DELETE FROM saved WHERE user=? AND message=?',(u,mid))
    if scope=='everyone':clean_deleted_uploads(s)
    event={'type':'message','room':room,'ids':ids+['call_'+cid for cid in call_ids],'deleted':True,'from':u,'personal':scope=='self'}
    if scope=='self':
        await s.emit(u,event);await s.emit(u,{'type':'message-alert-refresh'})
    else:
        await s.broadcast(room,event)
        for member in s.all('SELECT user FROM members WHERE room=?',(room,)):await s.emit(member['user'],{'type':'message-alert-refresh'})
    return web.json_response({'ok':True,'ids':ids,**({'call_ids':call_ids} if call_ids else {})})

async def auto_delete_policy(request):
    u=auth(request);s=request.app['store'];room=request.match_info['room'];s.member(u,room)
    b=await body(request);seconds=b.get('seconds')
    if type(seconds) is not int or seconds not in (0,3600,86400,604800,2592000):raise ValueError()
    with transaction(s.db):
        lock_room(s,room)
        row=s.one('SELECT kind FROM rooms WHERE id=?',(room,))
        if row['kind']!='direct' or cutover_active(s,room):raise web.HTTPForbidden(text='Bu sohbet türünde otomatik silme desteklenmiyor.')
        s.db.execute('DELETE FROM room_auto_delete WHERE room=?',(room,))
        if seconds:s.db.execute('INSERT INTO room_auto_delete VALUES(?,?)',(room,seconds))
    await s.broadcast(room,{'type':'rooms','room':room,'from':u})
    return web.json_response({'seconds':seconds})

async def expire_messages(s):
    clean_deleted_uploads(s)
    for row in s.all('SELECT m.id,m.room FROM message_expiry x JOIN messages m ON m.id=x.message WHERE x.due<=? ORDER BY x.due LIMIT 100',(now(),)):
        erase_message(s,row['id'])
        await s.broadcast(row['room'],{'type':'message','room':row['room'],'id':row['id'],'deleted':True,'expired':True})
        for member in s.all('SELECT user FROM members WHERE room=?',(row['room'],)):await s.emit(member['user'],{'type':'message-alert-refresh'})

async def read_room(request):
    u=auth(request);s=request.app['store'];room=request.match_info['room'];s.member(u,room);b=await body(request)
    m=s.one('SELECT created FROM messages WHERE id=? AND room=?',(b['message'],room))
    if not m or hidden_for(s,u,b['message']):raise web.HTTPNotFound()
    previous=s.one('SELECT ts FROM receipts WHERE room=? AND user=?',(room,u))
    if not previous or previous['ts']<m['created']:
        s.run('INSERT INTO receipts VALUES(?,?,?) ON CONFLICT(room,user) DO UPDATE SET ts=max(ts,excluded.ts)',(room,u,m['created']))
        await s.broadcast(room,{'type':'read','room':room,'from':u,'ts':m['created']})
        await s.emit(u,{'type':'message-alert-refresh'})
    return web.json_response({'ok':True})
async def change_message(request):
    u=auth(request);s=request.app['store'];mid=request.match_info['id'];r=s.one('SELECT * FROM messages WHERE id=?',(mid,))
    if not r:raise web.HTTPNotFound()
    s.member(u,r['room'])
    if hidden_for(s,u,mid):raise web.HTTPNotFound()
    room=s.one('SELECT kind FROM rooms WHERE id=?',(r['room'],))
    if r['sender']!=u and not (request.method=='DELETE' and room and room['kind']=='direct'):
        raise web.HTTPForbidden(text='Bu mesajı değiştirme veya silme yetkiniz yok.')
    if request.method=='DELETE':erase_message(s,mid)
    else:
        if private_message(s,mid):raise web.HTTPForbidden(text='Tek görüntülemelik medya düzenlenemez.')
        b=await body(request);reject_legacy_write(s,r['room']);validate_envelopes(s,r['room'],b['envelopes'])
        if not recipient_keys_match(s,r['room'],b.get('recipient_pubs')):return web.json_response({'error':'Kişinin cihaz anahtarı değişti. Sohbeti yenileyip tekrar deneyin.','code':'KEY_CHANGED'},status=409)
        # Explicit text edits retain ciphertext only. Legacy PATCH and live
        # location updates never create a revision. One atomic commit.
        with transaction(s.db):
            lock_room(s,r['room']);reject_legacy_write(s,r['room'])
            r=s.one('SELECT * FROM messages WHERE id=?'+(' FOR UPDATE' if hasattr(s.db,'connection') else ''),(mid,))
            if not r:raise web.HTTPNotFound()
            if r['sender']!=u:raise web.HTTPForbidden()
            if b.get('save_revision') is True:
                if 'expected_edited' not in b or b['expected_edited']!=r['edited']:
                    raise web.HTTPConflict(text='Mesaj değişti. Sohbeti yenileyip tekrar deneyin.')
                if s.one('SELECT count(*) n FROM message_revisions WHERE message=?',(mid,))['n']>=20:
                    raise web.HTTPConflict(text='Bu mesaj için 20 düzenleme sınırına ulaşıldı.')
                key=s.one('SELECT sender_pub FROM message_keys WHERE message=?',(mid,))
                edited=max(now(),(r['edited'] or r['created'])+1)
                s.db.execute('INSERT INTO message_revisions VALUES(?,?,?,?,?)',(mid,r['edited'] or r['created'],edited,r['envelopes'],key['sender_pub'] if key else None))
            else:edited=max(now(),(r['edited'] or r['created'])+1)
            s.db.execute('UPDATE messages SET envelopes=?,edited=? WHERE id=?',(json.dumps(b['envelopes']),edited,mid))
            pub=s.one('SELECT pub FROM users WHERE id=?',(u,))['pub']
            s.db.execute('UPDATE message_keys SET sender_pub=? WHERE message=?',(pub,mid))
            s.db.execute('INSERT OR IGNORE INTO message_keys VALUES(?,?)',(mid,pub))
    await s.broadcast(r['room'],{'type':'message','room':r['room'],'id':mid,'from':u,'deleted':request.method=='DELETE'})
    if request.method=='DELETE':
        for member in s.all('SELECT user FROM members WHERE room=?',(r['room'],)):await s.emit(member['user'],{'type':'message-alert-refresh'})
    return web.json_response({'ok':True})
async def message_history(request):
    u=auth(request);s=request.app['store'];mid=request.match_info['id']
    m=s.one('SELECT room FROM messages WHERE id=?',(mid,))
    if not m:raise web.HTTPNotFound()
    s.member(u,m['room'])
    if hidden_for(s,u,mid):raise web.HTTPNotFound()
    rows=s.all('SELECT revision,replaced,envelopes,sender_pub FROM message_revisions WHERE message=? ORDER BY replaced DESC',(mid,))
    # Return only the requesting member's original encrypted envelope/key.
    return web.json_response([dict(revision=r['revision'],replaced=r['replaced'],envelope=json.loads(r['envelopes']).get(u),sender_pub=json.loads(r['sender_pub']) if r['sender_pub'] else None) for r in rows])

async def manage_room_history(request):
    """Explicit history removal or membership departure, all selected rooms atomically.
    Shared removal is limited to legacy direct rooms; secure history is rejected without modification.
    """
    u=auth(request);s=request.app['store'];b=await body(request)
    ids=b.get('rooms');op=b.get('operation');scope=b.get('scope','self')
    if scope not in ('self','everyone') or (scope=='everyone' and op!='clear'):raise ValueError()
    if op not in ('clear','delete','leave') or not isinstance(ids,list) or not 1<=len(ids)<=100 or any(not valid_id(i) for i in ids):raise ValueError()
    ids=sorted(set(ids));results=[];departed=[];shared=[]
    with transaction(s.db):
        for room in ids:
            row=lock_room(s,room)
            if not row:raise web.HTTPNotFound()
            s.member(u,room)
            if scope=='everyone' and row['kind']!='direct':raise web.HTTPForbidden(text='İki taraflı geçmiş temizleme yalnızca bire bir sohbetlerde kullanılabilir.')
            if op=='leave':
                if row['kind']!='group':raise web.HTTPBadRequest(text='Yalnızca gruptan ayrılabilirsiniz.')
                if any(c['room']==room for c in s.group_calls.calls.values()):raise web.HTTPConflict(text='Aktif grup araması bittikten sonra ayrılabilirsiniz.')
            elif op=='delete' and row['kind']!='direct':raise web.HTTPBadRequest(text='Grubu kaldırmak için gruptan ayrılın.')
            if op!='leave' and (cutover_active(s,room) or s.one('SELECT 1 FROM ratchet_pilot_messages p JOIN ratchet_pilot_sessions r ON r.id=p.session_id WHERE r.room=? LIMIT 1',(room,)) or s.one('SELECT 1 FROM ratchet_group_epochs WHERE room=? LIMIT 1',(room,))):
                raise web.HTTPConflict(text='Bu sohbetin güvenli geçmişi henüz toplu temizlemeyi desteklemiyor. Hiçbir kayıt değiştirilmedi.')
        for room in ids:
            if op=='leave':
                # Freeze missing historical sender keys before removing the member.
                s.db.execute('INSERT OR IGNORE INTO message_keys(message,sender_pub) SELECT m.id,u.pub FROM messages m JOIN users u ON u.id=m.sender WHERE m.room=? AND m.sender=?',(room,u))
                s.db.execute('DELETE FROM scheduled_messages WHERE room=? AND sender=?',(room,u))
                s.db.execute('DELETE FROM saved WHERE user=? AND message IN (SELECT id FROM messages WHERE room=?)',(u,room))
                s.db.execute('DELETE FROM members WHERE room=? AND user=?',(room,u))
                departed.append(room);results.append({'room':room,'left':True});continue
            if scope=='everyone':
                # Lock and delete the entire legacy message snapshot, not only the loaded page.
                for m in s.all('SELECT id FROM messages WHERE room=?',(room,)):erase_message_row(s,m['id'],room)
                revision=uid()
                for member in s.all('SELECT user FROM members WHERE room=?',(room,)):
                    member_id=member['user']; previous=s.one('SELECT hidden FROM room_history_actions WHERE room=? AND user=?',(room,member_id))
                    s.db.execute('DELETE FROM room_history_actions WHERE room=? AND user=?',(room,member_id))
                    s.db.execute('INSERT INTO room_history_actions(room,user,revision,hidden) VALUES(?,?,?,?)',(room,member_id,revision,int(previous['hidden']) if previous else 0))
                    shared.append((room,member_id))
                results.append({'room':room,'history_revision':revision,'scope':'everyone'});continue
            s.db.execute('INSERT OR IGNORE INTO hidden_messages(user,message) SELECT ?,id FROM messages WHERE room=?',(u,room))
            s.db.execute('INSERT OR IGNORE INTO hidden_calls(user,call_id) SELECT ?,id FROM calls WHERE room=?',(u,room))
            s.db.execute('DELETE FROM saved WHERE user=? AND message IN (SELECT id FROM messages WHERE room=?)',(u,room))
            revision=uid();s.db.execute('DELETE FROM room_history_actions WHERE room=? AND user=?',(room,u))
            s.db.execute('INSERT INTO room_history_actions(room,user,revision,hidden) VALUES(?,?,?,?)',(room,u,revision,int(op=='delete')))
            results.append({'room':room,'history_revision':revision,'hidden_from_home':op=='delete'})
    if shared:clean_deleted_uploads(s)
    for room,member in shared:
        await s.emit(member,{'type':'rooms','room':room});await s.emit(member,{'type':'message-alert-refresh'})
    # Personal changes remain scoped to the requesting account.
    for row in results:
        if row.get('scope')!='everyone':await s.emit(u,{'type':'rooms','room':row['room']})
    for room in departed:await s.broadcast(room,{'type':'rooms','room':room})
    await s.emit(u,{'type':'message-alert-refresh'})
    return web.json_response({'ok':True,'rooms':results})

async def read_delivered_room(request):
    """Explicit list action: never manufacture delivery receipts for unreadable messages."""
    u=auth(request);s=request.app['store'];room=request.match_info['room'];stamp=now()
    with transaction(s.db):
        lock_room(s,room);s.member(u,room)
        rows=s.all("SELECT m.id,m.sender,mr.delivered FROM messages m JOIN message_receipts mr ON mr.message=m.id AND mr.user=? WHERE m.room=? AND m.sender!=? AND mr.read_at IS NULL AND NOT EXISTS(SELECT 1 FROM hidden_messages h WHERE h.message=m.id AND h.user=?)",(u,room,u,u))
        for m in rows:s.db.execute('UPDATE message_receipts SET read_at=? WHERE message=? AND user=? AND read_at IS NULL',(stamp,m['id'],u))
    for m in rows:await s.emit(m['sender'],{'type':'receipt-v2','room':room,'id':m['id'],'receipt':{'user':u,'delivered':m['delivered'],'read_at':stamp}})
    if rows:await s.emit(u,{'type':'message-alert-refresh'})
    return web.json_response({'ok':True,'count':len(rows)})

async def acknowledge_messages(request):
    u=auth(request);s=request.app['store'];room=request.match_info['room'];s.member(u,room);b=await body(request)
    delivered=b.get('delivered',[]);read=b.get('read',[])
    if any(not isinstance(ids,list) or len(ids)>80 or any(not valid_id(i) for i in ids) for ids in (delivered,read)):raise ValueError()
    ids=list(dict.fromkeys(delivered+read));read=set(read)
    if len(ids)>80:raise ValueError()
    changed=[];stamp=now()
    with transaction(s.db):
        s.member(u,room)
        for mid in ids:
            m=s.one('SELECT sender FROM messages WHERE id=? AND room=?',(mid,room))
            # Messages deleted during a refresh are ignored. No cross-room ack.
            if not m or m['sender']==u or hidden_for(s,u,mid):continue
            old=s.one('SELECT delivered,read_at FROM message_receipts WHERE message=? AND user=?',(mid,u))
            if not old:
                s.db.execute('INSERT OR IGNORE INTO message_receipts VALUES(?,?,?,?)',(mid,u,stamp,stamp if mid in read else None))
            elif mid in read and old['read_at'] is None:
                s.db.execute('UPDATE message_receipts SET read_at=? WHERE message=? AND user=? AND read_at IS NULL',(stamp,mid,u))
            else:continue
            record=s.one('SELECT user,delivered,read_at FROM message_receipts WHERE message=? AND user=?',(mid,u))
            changed.append((m['sender'],mid,dict(record)))
    if changed and read:await s.emit(u,{'type':'message-alert-refresh'})
    for sender,mid,record in changed:
        await s.emit(sender,{'type':'receipt-v2','room':room,'id':mid,'receipt':record})
    return web.json_response({'ok':True,'receipts':{mid:dict(r) for mid in ids if (r:=s.one('SELECT mr.user,mr.delivered,mr.read_at FROM message_receipts mr JOIN messages m ON m.id=mr.message WHERE mr.message=? AND mr.user=? AND m.room=?',(mid,u,room)))}})

async def saved(request):
    u=auth(request);s=request.app['store']
    if request.method=='POST':
        b=await body(request);r=s.one('SELECT room FROM messages WHERE id=?',(b['id'],))
        if not r:raise web.HTTPNotFound()
        s.member(u,r['room']);
        if hidden_for(s,u,b['id']):raise web.HTTPNotFound()
        if private_message(s,b['id']):raise web.HTTPForbidden(text='Tek görüntülemelik medya kaydedilemez.')
        s.run('INSERT OR IGNORE INTO saved VALUES(?,?)',(u,b['id']))
    return web.json_response([message_for(r,u,s) for r in s.db.execute('SELECT m.* FROM messages m JOIN saved v ON v.message=m.id JOIN members mm ON mm.room=m.room AND mm.user=v.user WHERE v.user=? AND NOT EXISTS(SELECT 1 FROM hidden_messages h WHERE h.message=m.id AND h.user=v.user) ORDER BY m.created DESC',(u,))])
async def unsave(request):
    u=auth(request);request.app['store'].run('DELETE FROM saved WHERE user=? AND message=?',(u,request.match_info['id']))
    return web.json_response({'ok':True})
async def upload(request):
    u=auth(request);s=request.app['store'];b=await body(request);s.member(u,b['room']);size=int(b['size'])
    if size<1 or size>MAX_FILE+16:raise web.HTTPRequestEntityTooLarge(max_size=MAX_FILE,actual_size=size)
    once=b.get('view_once',False)
    if type(once) is not bool:raise ValueError()
    if once:
        room=s.one('SELECT kind FROM rooms WHERE id=?',(b['room'],))
        if not room or room['kind']!='direct' or cutover_active(s,b['room']):raise web.HTTPForbidden(text='Bu sohbet tek görüntülemeyi desteklemiyor.')
    ident=b.get('client_id')
    if ident is not None:
        if not valid_id(ident):raise ValueError()
        if (s.one('SELECT 1 FROM ratchet_pilot_media WHERE upload_id=?',(ident,)) or s.one('SELECT 1 FROM ratchet_group_uploads WHERE upload_id=?',(ident,))):raise web.HTTPConflict(text='Dosya kimliği güvenli sohbette kullanıldı.')
        existing=s.one('SELECT owner,room,size,received,complete FROM uploads WHERE id=?',(ident,))
        if existing:
            if existing['owner']!=u or existing['room']!=b['room'] or existing['size']!=size or bool(private_upload(s,ident))!=once:raise web.HTTPConflict()
            return web.json_response({'id':ident,'offset':existing['received'],'complete':bool(existing['complete'])})
    pending=s.one('SELECT count(*) n FROM uploads WHERE owner=? AND complete=0',(u,))['n']
    if pending>=8:raise web.HTTPTooManyRequests(text='Bekleyen yüklemeleri tamamlayın.')
    ident=ident or uid()
    with transaction(s.db):
        s.db.execute('INSERT INTO uploads(id,owner,room,size,created) VALUES(?,?,?,?,?)',(ident,u,b['room'],size,now()))
        if once:s.db.execute('INSERT INTO view_once_uploads(upload) VALUES(?)',(ident,))
    return web.json_response({'id':ident,'offset':0},status=201)
async def upload_part(request):
    u=auth(request);s=request.app['store'];ident=request.match_info['id'];r=s.one('SELECT * FROM uploads WHERE id=?',(ident,))
    if not r or s.one('SELECT 1 FROM deleted_upload_queue WHERE upload=?',(ident,)):raise web.HTTPNotFound()
    s.member(u,r['room']);path=s.dir/ident
    if (s.one('SELECT 1 FROM ratchet_pilot_media WHERE upload_id=?',(ident,)) or s.one('SELECT 1 FROM ratchet_group_uploads WHERE upload_id=?',(ident,))):raise web.HTTPForbidden(text='Güvenli sohbet dosyası yalnızca ilgili mesajdan erişilebilir.')
    if request.method=='DELETE':
        if r['owner']!=u:raise web.HTTPForbidden()
        if s.one('SELECT 1 FROM message_uploads WHERE upload=?',(ident,)):raise web.HTTPConflict(text='Bu yükleme bir mesaja bağlı. İlgili mesajı silin.')
        path.unlink(missing_ok=True);s.run('DELETE FROM uploads WHERE id=?',(ident,));return web.json_response({'ok':True})
    if request.method=='GET':
        if private_upload(s,ident):raise web.HTTPForbidden(text='Tek görüntülemelik medya normal indirme ile açılamaz.')
        if not r['complete']:raise web.HTTPConflict(text='Yükleme henüz tamamlanmadı.')
        if s.one('SELECT 1 FROM message_uploads WHERE upload=?',(ident,)) and not s.one('SELECT 1 FROM message_uploads f WHERE f.upload=? AND NOT EXISTS(SELECT 1 FROM hidden_messages h WHERE h.message=f.message AND h.user=?)',(ident,u)):raise web.HTTPNotFound()
        return web.FileResponse(path,headers={'Content-Type':'application/octet-stream','Content-Disposition':'attachment'})
    if r['owner']!=u:raise web.HTTPForbidden()
    if request.method=='HEAD':
        try:check_prefix(path,r['received'],bool(r['complete']))
        except MissingPrefix:raise web.HTTPConflict(text='Dosya sunucuda eksik; yüklemeyi iptal edip tekrar gönderin.')
        return web.Response(headers={'Upload-Offset':str(r['received'])})
    offset=int(request.headers.get('Upload-Offset','-1'))
    if offset!=r['received'] or r['complete']:raise web.HTTPConflict(text=str(r['received']))
    data=await request.read()
    # A slow body may outlive logout, deletion, or a change of ownership.
    auth(request)
    r=s.one('SELECT * FROM uploads WHERE id=?',(ident,))
    if not r:raise web.HTTPNotFound()
    s.member(u,r['room'])
    if r['owner']!=u or s.one('SELECT 1 FROM ratchet_pilot_media WHERE upload_id=?',(ident,)) or s.one('SELECT 1 FROM ratchet_group_uploads WHERE upload_id=?',(ident,)):raise web.HTTPForbidden()
    if offset!=r['received'] or r['complete']:raise web.HTTPConflict(text=str(r['received']))
    if not data or len(data)>1024*1024 or offset+len(data)>r['size']:raise ValueError()
    try:total=write_chunk(path,offset,data)
    except MissingPrefix:raise web.HTTPConflict(text='Dosya sunucuda eksik; yüklemeyi iptal edip tekrar gönderin.')
    s.run('UPDATE uploads SET received=?,complete=? WHERE id=?',(total,int(total==r['size']),ident))
    return web.json_response({'id':ident,'offset':total,'complete':total==r['size']})
async def download_message_file(request):
    u=auth(request);s=request.app['store'];mid=request.match_info['id'];ident=request.match_info['upload']
    r=s.one('SELECT u.* FROM uploads u JOIN message_uploads f ON f.upload=u.id JOIN messages m ON m.id=f.message WHERE m.id=? AND u.id=? AND m.room=u.room AND u.complete=1',(mid,ident))
    if not r:raise web.HTTPNotFound()
    s.member(u,r['room']);
    if hidden_for(s,u,mid):raise web.HTTPNotFound()
    if private_upload(s,ident):raise web.HTTPForbidden(text='Tek görüntülemelik medya normal indirme ile açılamaz.')
    path=s.dir/ident
    if not path.is_file() or path.stat().st_size!=r['size']:raise web.HTTPNotFound()
    return web.FileResponse(path,headers={'Content-Type':'application/octet-stream','Content-Disposition':'attachment'})
async def open_view_once(request):
    u=auth(request);s=request.app['store'];mid=request.match_info['id']
    if request.headers.get('Range'):raise web.HTTPBadRequest(text='Parçalı tek görüntüleme desteklenmiyor.')
    r=s.one('SELECT v.*,m.room,m.sender,u.size,u.complete FROM view_once_uploads v JOIN messages m ON m.id=v.message JOIN uploads u ON u.id=v.upload WHERE v.message=?',(mid,))
    if not r or r['recipient']!=u or r['sender']==u or hidden_for(s,u,mid):raise web.HTTPNotFound()
    s.member(u,r['room'])
    if blocked(s,u,r['sender']):raise web.HTTPForbidden()
    if r['opened'] is not None:raise web.HTTPGone(text='Bu medya daha önce açıldı.')
    if not r['complete'] or s.one('SELECT 1 FROM deleted_upload_queue WHERE upload=?',(r['upload'],)):raise web.HTTPNotFound()
    path=s.dir/r['upload']
    if not path.is_file() or path.stat().st_size!=r['size'] or not 1<=r['size']<=MAX_FILE+16:raise web.HTTPNotFound()
    data=path.read_bytes()
    if len(data)!=r['size']:raise web.HTTPNotFound()
    # UPDATE is conditional and committed before any bytes are returned.
    if not claim(s,r['upload'],mid,u,now()):raise web.HTTPGone(text='Bu medya daha önce açıldı.')
    # Best-effort removal; committed state still denies subsequent reads if unlink fails.
    try:path.unlink(missing_ok=True)
    except OSError:pass
    return web.Response(body=data,headers={'Content-Type':'application/octet-stream','Cache-Control':'no-store, private','Pragma':'no-cache','X-Content-Type-Options':'nosniff'})

async def socket(request):
    ws=web.WebSocketResponse(heartbeat=25,max_msg_size=150000);await ws.prepare(request);s=request.app['store'];u=None;typing_room=None;typing_kind='typing-v1';typing_at=-100.0;typing_rate=deque();presence_key=None;foreground=False
    try:
        first=await asyncio.wait_for(ws.receive_json(),timeout=8)
        if not isinstance(first,dict):raise ValueError()
        token_hash=validated_token_hash(first.get('token'))
        r=s.one('SELECT user FROM sessions WHERE token=? AND expires>?',(token_hash,now()))
        if not r:await ws.close(code=4001);return ws
        strict_call_ids=first.get('callIds') is True
        u=r['user'];s.socket_tokens[ws]=token_hash;s.sockets[u].add(ws)
        if first.get('batchDelete') is True:s.batch_delete_sockets.add(ws)
        if u in s.calls:s.calls[u].pop('disconnect_marker',None)
        await ws.send_json({'type':'connected','features':['emoji-interaction-v1','direct-delete-everyone-v1','history-clear-everyone-v1','batch-delete-v1','call-history-hide-v1','presence-lease-v1','presence-socket-v2','message-cache-check-v1','call-id-v1','call-alert-ack-v1','typing-v1','recording-v1','message-details-v1','durable-upload-v1','delivery-sync-v1','group-call-v1','durable-download-v1','send-options-v1','message-delete-v2','view-once-v1','stories-v1']})
        if first.get('presenceSocket') is True:
            presence_key=uid();s.presence_sockets[ws]=presence_key
        if first.get('groupCalls') is True:await s.group_calls.connected(u,ws)
        async for msg in ws:
            if msg.type!=WSMsgType.TEXT:continue
            if not s.one('SELECT 1 FROM sessions WHERE token=? AND expires>?',(token_hash,now())):
                await ws.close(code=4001);break
            b=json.loads(msg.data)
            if not isinstance(b,dict):raise ValueError()
            if isinstance(b,dict) and b.get('type')=='presence-socket-v2':
                if not presence_key:continue
                visible,preference=b.get('foreground'),b.get('preference')
                if type(visible) is not bool or preference not in ('online','offline','busy'):continue
                # Off/background transitions always pass, even during a rapid foreground cycle.
                # Ordered WebSocket frames cannot resurrect a closed socket's lease.
                old=s.presence.status(u);foreground=visible
                s.presence.heartbeat(u,presence_key,visible,preference)
                if not visible and typing_room:
                    await s.relay_typing(u,typing_room,False,ws,typing_kind);typing_room=None
                if old!=s.presence.status(u):await s.notify_profile(u)
                continue
            if isinstance(b,dict) and b.get('type') in ('typing-v1','recording-v1'):
                room,active,kind=b.get('room'),b.get('active'),b['type']
                if not valid_id(room) or type(active) is not bool:continue
                if active:
                    if presence_key and not foreground:continue
                    clock=time.monotonic()
                    while typing_rate and clock-typing_rate[0]>=1:typing_rate.popleft()
                    if len(typing_rate)>=6 or (typing_room==room and typing_kind==kind and clock-typing_at<1.5):continue
                    typing_rate.append(clock);typing_at=clock
                    if typing_room and (typing_room!=room or typing_kind!=kind):await s.relay_typing(u,typing_room,False,ws,typing_kind);typing_room=None
                    if await s.relay_typing(u,room,True,ws,kind):typing_room=room;typing_kind=kind
                elif typing_room==room and typing_kind==kind:
                    typing_room=None;await s.relay_typing(u,room,False,ws,kind)
                continue
            if await s.group_calls.handle(u,ws,b):continue
            if await s.relay.handle(u,b):continue
            room=b['room'];s.member(u,room)
            if b['type']=='call':
                requested_id=b.get('callId')
                if (strict_call_ids or requested_id is not None) and not valid_id(requested_id):continue
                members=s.all('SELECT user FROM members WHERE room=? AND user!=?',(room,u))
                if len(members)!=1:continue
                peer=members[0]['user'];pr=s.one('SELECT settings FROM users WHERE id=?',(peer,));settings=json.loads(pr['settings'])
                if blocked(s,u,peer) or not settings.get('available',True) or peer in s.calls or u in s.calls or s.group_calls.busy(peer) or s.group_calls.busy(u):
                    await ws.send_json({'type':'call-rejected','room':room,'callId':requested_id});continue
                ident=requested_id or uid();started=now();video=bool(b.get('video'))
                if s.one('SELECT 1 FROM calls WHERE id=?',(ident,)):
                    await ws.send_json({'type':'call-rejected','room':room,'callId':ident});continue
                s.run('INSERT INTO calls(id,room,caller,callee,video,started) VALUES(?,?,?,?,?,?)',(ident,room,u,peer,int(video),started))
                s.calls[u]={'peer':peer,'room':room,'id':ident,'initiator':u,'video':video,'started':started};s.calls[peer]={'peer':u,'room':room,'id':ident,'initiator':u,'video':video,'started':started}
                async def expire(caller,callee,call_id,call_room):
                    await asyncio.sleep(45)
                    current=s.calls.get(caller)
                    if current and current['id']==call_id:
                        row=s.one('SELECT connected FROM calls WHERE id=?',(call_id,))
                        if row and row['connected'] is None:
                            s.calls.pop(caller,None);s.calls.pop(callee,None)
                            s.run("UPDATE calls SET ended=?,status='missed' WHERE id=?",(now(),call_id))
                            await s.broadcast(call_room,{'type':'hangup','room':call_room,'from':'server','callId':call_id})
                task=asyncio.create_task(expire(u,peer,ident,room));request.app['tasks'].add(task);task.add_done_callback(request.app['tasks'].discard)
            if b['type'] in ['call','accepted','offer','answer','ice','hangup','call-rejected','restart-request']:
                if b['type']!='call' and s.calls.get(u) is None:continue
                if s.calls[u]['room']!=room:continue
                active=s.calls[u];incoming_id=b.get('callId')
                if b['type']!='call' and (strict_call_ids or incoming_id is not None) and incoming_id!=active['id']:continue
                if b['type']=='restart-request':
                    row=s.one('SELECT connected FROM calls WHERE id=?',(active['id'],))
                    if active['initiator']==u or not row or row['connected'] is None:continue
                    stamp=time.monotonic()
                    if stamp-active.get('restart_requested_at',-1000)<2:continue
                    active['restart_requested_at']=stamp
                    await s.emit(active['initiator'],{'type':'restart-request','room':room,'from':u,'callId':active['id']});continue
                if b['type']=='accepted' and (active['initiator']==u or ringing_call(s,u) is None):continue
                if b['type']=='accepted':s.run("UPDATE calls SET connected=?,status='connected' WHERE id=?",(now(),s.calls[u]['id']))
                if b['type'] in ['hangup','call-rejected']:
                    peer=s.calls.pop(u,None)
                    if peer:
                        s.calls.pop(peer['peer'],None)
                        s.run('UPDATE calls SET ended=?,status=? WHERE id=?',(now(),'rejected' if b['type']=='call-rejected' else 'ended',peer['id']))
                await s.broadcast(room,{**b,'from':u,'callId':active['id']})
    except (asyncio.TimeoutError,ValueError,KeyError,web.HTTPException):await ws.close(code=4000)
    finally:
        if u:
            if typing_room:await s.relay_typing(u,typing_room,False,ws,typing_kind)
            s.group_calls.disconnected_socket(u,ws)
            s.sockets[u].discard(ws);s.batch_delete_sockets.discard(ws);session_hash=s.socket_tokens.pop(ws,None)
            old=s.presence.status(u)
            if presence_key:
                s.presence_sockets.pop(ws,None);s.presence.disconnect(u,presence_key)
            if session_hash and not any(s.socket_tokens.get(sock)==session_hash for sock in s.sockets[u]):
                s.presence.disconnect(u,session_hash)
            if old!=s.presence.status(u):await s.notify_profile(u)
            if not s.sockets[u] and s.calls.get(u):
                call_id=s.calls[u]['id'];marker=object();s.calls[u]['disconnect_marker']=marker
                async def disconnect_later():
                    await asyncio.sleep(CALL_DISCONNECT_GRACE)
                    current=s.calls.get(u)
                    row=s.one('SELECT connected FROM calls WHERE id=?',(call_id,))
                    if not s.sockets[u] and current and current['id']==call_id and current.get('disconnect_marker') is marker and row and row['connected'] is not None:
                        peer=s.calls.pop(u);s.calls.pop(peer['peer'],None)
                        s.run("UPDATE calls SET ended=?,status='disconnected' WHERE id=?",(now(),call_id))
                        await s.emit(peer['peer'],{'type':'hangup','from':u,'room':peer['room'],'callId':peer['id']})
                task=asyncio.create_task(disconnect_later());request.app['tasks'].add(task);task.add_done_callback(request.app['tasks'].discard)
    return ws
async def config(request):
    u=auth(request);servers=json.loads(os.environ.get('FS_ICE_SERVERS','[]'))
    host=os.environ.get('FS_TURN_HOST','');secret=os.environ.get('FS_TURN_SECRET','')
    if host and len(secret)>=32 and re.fullmatch(r'[A-Za-z0-9.-]+',host):
        username=str(int(time.time())+3600)+':'+u
        credential=base64.b64encode(hmac.new(secret.encode(),username.encode(),hashlib.sha1).digest()).decode()
        servers=[{'urls':['stun:'+host+':3478']},{'urls':['turn:'+host+':3478?transport=udp','turn:'+host+':3478?transport=tcp'],'username':username,'credential':credential}]
    cloud_servers=await request.app['turn'].get(u)
    if cloud_servers is not None: servers=cloud_servers
    return web.json_response({'iceServers':servers,'notificationTransport':'fcm-and-same-server-long-poll' if request.app['store'].push.transport else 'same-server-long-poll','turnConfigured':any(str(url).startswith(('turn:','turns:')) for server in servers for url in ([server.get('urls')] if isinstance(server.get('urls'),str) else server.get('urls',[])))})
async def health(request):return web.json_response({'ok':True,'service':'fs-mesajlasma','version':'34.32','apiReady':True,'passwordDeviceLogin':True,'integration':'34.32-native14-candidate','pushConfigured':bool(request.app['store'].push.transport),'features':['emoji-interaction-v1','direct-delete-everyone-v1','history-clear-everyone-v1','batch-delete-v1','call-history-hide-v1','presence-lease-v1','presence-socket-v2','message-cache-check-v1','call-id-v1','call-alert-ack-v1','typing-v1','recording-v1','message-details-v1','durable-upload-v1','delivery-sync-v1','group-call-v1','durable-download-v1','send-options-v1','message-delete-v2','view-once-v1','stories-v1']})
def ringing_call(s,u):
    """An authoritative, short-lived invitation, independent of queue consumption."""
    c=s.calls.get(u)
    if not c or c['initiator']==u or not c.get('started'):return None
    remaining=45000-(now()-c['started'])
    if remaining<=0:return None
    user=s.one('SELECT settings FROM users WHERE id=?',(u,))
    row=s.one('SELECT connected,ended FROM calls WHERE id=?',(c['id'],))
    if not user or not json.loads(user['settings']).get('available',True) or blocked(s,u,c['peer']):return None
    if not row or row['connected'] is not None or row['ended'] is not None:return None
    settings=json.loads(user['settings']);silent=c['initiator'] in settings.get('mutedPeers',[]) or c['room'] in settings.get('mutedRooms',[])
    return {'type':'call','room':c['room'],'from':c['initiator'],'video':c['video'],'callId':c['id'],'remainingMs':min(45000,remaining),**({'silent':True} if silent else {})}

def ringing_for_push(s,u):
    return ringing_call(s,u) or s.group_calls.ringing(u)
def push_session(request):
    user=auth(request);session=hashlib.sha256(request.headers['Authorization'].removeprefix('Bearer ').encode()).hexdigest();return user,session
async def push_registration(request):
    u,session=push_session(request);s=request.app['store']
    if request.method=='DELETE':remove_push(s,session);return web.json_response({'ok':True})
    if not s.push.transport:raise web.HTTPServiceUnavailable(text='Push sağlayıcısı yapılandırılmadı.')
    rate(request,'push:'+u,12);b=await body(request)
    token,binding=b.get('registration'),b.get('binding')
    if not valid_registration(token,binding):raise web.HTTPBadRequest()
    if not register_push(s,session,token,binding):raise web.HTTPConflict()
    return web.json_response({'ok':True})
async def push_ringing(request):
    u,session=push_session(request);s=request.app['store'];binding=request.headers.get('X-FS-Push-Binding','')
    if not s.push.transport or not s.one('SELECT 1 FROM push_registrations WHERE session_id=? AND binding=?',(session,binding)):raise web.HTTPForbidden()
    call=ringing_for_push(s,u)
    return web.json_response({'ringing':{'callId':call['callId'],'remainingMs':call['remainingMs'],'video':bool(call['video']),**({'silent':True} if call.get('silent') is True else {})} if call else None})
async def push_messages(request):
    u,session=push_session(request);s=request.app['store'];binding=request.headers.get('X-FS-Push-Binding','')
    if not s.push.transport or not s.one('SELECT 1 FROM push_registrations WHERE session_id=? AND binding=?',(session,binding)):raise web.HTTPForbidden()
    return web.json_response({'messages':message_alerts(s,u,request.query.get('detail')=='1',request.query.get('avatars')=='1')})
async def decline_incoming(request):
    u=auth(request);s=request.app['store'];b=await body(request)
    ident=b.get('callId') if isinstance(b,dict) else None
    if not valid_id(ident):raise web.HTTPBadRequest()
    call=ringing_call(s,u)
    if call and call['callId']==ident:
        active=s.calls.pop(u);s.calls.pop(active['peer'],None)
        s.run("UPDATE calls SET ended=?,status='rejected' WHERE id=?",(now(),ident))
        await s.broadcast(active['room'],{'type':'call-rejected','from':u,'room':active['room'],'callId':ident})
        return web.json_response({'ok':True})
    group=s.group_calls.ringing(u)
    if group and group['callId']==ident:
        await s.group_calls.leave(u,'rejected')
        return web.json_response({'ok':True})
    raise web.HTTPConflict() # stale ID, caller, already accepted or unauthorized
def notification_avatar(raw):
    # The existing public profile JPEG is optional metadata, never message content.
    try:
        photo=json.loads(raw or '{}').get('avatar','')
        prefix='data:image/jpeg;base64,'
        if not isinstance(photo,str) or not photo.startswith(prefix) or len(photo)>150000:return ''
        data=base64.b64decode(photo[len(prefix):],validate=True)
        if len(data)<4 or not data.startswith(b'\xff\xd8\xff') or not data.endswith(b'\xff\xd9'):return ''
        return photo
    except (ValueError,TypeError,AttributeError):return ''

def message_alerts(s,u,detail=False,avatars=False):
    row=s.one('SELECT settings FROM users WHERE id=?',(u,))
    settings=json.loads(row['settings']) if row else {}
    if not settings.get('messageAlerts',True):return []
    peers=set(settings.get('mutedPeers',[]));rooms=set(settings.get('mutedRooms',[]))
    rows=s.all("""SELECT m.id,m.room,m.sender,m.created,r.kind,r.title,author.name AS sender_name FROM messages m
      JOIN users author ON author.id=m.sender
      JOIN members mb ON mb.room=m.room AND mb.user=?
      JOIN rooms r ON r.id=m.room
      LEFT JOIN message_receipts mr ON mr.message=m.id AND mr.user=?
      LEFT JOIN receipts lr ON lr.room=m.room AND lr.user=?
      WHERE m.sender!=? AND m.created>=? AND mr.read_at IS NULL
      AND (lr.ts IS NULL OR lr.ts<m.created)
      AND NOT EXISTS(SELECT 1 FROM silent_messages sm WHERE sm.message=m.id)
      AND NOT EXISTS(SELECT 1 FROM hidden_messages hm WHERE hm.message=m.id AND hm.user=?)
      AND NOT EXISTS(SELECT 1 FROM blocks b WHERE (b.owner=? AND b.peer=m.sender) OR (b.peer=? AND b.owner=m.sender))
      ORDER BY m.created DESC,m.id DESC LIMIT 500""",(u,u,u,u,now()-300000,u,u,u))
    result={}
    # Legacy clients retain their metadata-only contract and existing mute behavior.
    include_silent=detail and settings.get('silentMessageAlerts',False) is True
    show_details=detail and settings.get('notificationDetails',False) is True
    avatar_budget=192000 if show_details and avatars and settings.get('notificationAvatars',False) is True else 0
    avatar_cache={}
    for m in rows:
        silent=m['room'] in rooms or m['sender'] in peers
        if silent and not include_silent:continue
        room=m['room']
        if room not in result:
            if len(result)>=40:continue
            result[room]={'room':room,'id':m['id'],'created':m['created']}
            if detail:
                result[room].update(count=0,silent=silent)
                if show_details:
                    label=m['title'] if m['kind']=='group' else m['sender_name']
                    # No control characters, arbitrary directions or message bodies.
                    result[room]['label']=''.join(c for c in str(label) if c.isprintable())[:80].strip()
                    if avatar_budget>0 and m['kind']!='group':
                        sender=m['sender']
                        if sender not in avatar_cache and len(avatar_cache)<8:
                            author=s.one('SELECT settings FROM users WHERE id=?',(sender,))
                            avatar_cache[sender]=notification_avatar(author['settings'] if author else '')
                        photo=avatar_cache.get(sender,'')
                        if photo and len(photo)<=avatar_budget:
                            result[room]['avatar']=photo;avatar_budget-=len(photo)
        if detail:result[room]['count']+=1
    return list(result.values())

async def notification_read(request):
    u=auth(request);s=request.app['store'];room=request.match_info['room'];s.member(u,room)
    b=await body(request);mid=b.get('message')
    if not valid_id(mid):raise web.HTTPBadRequest()
    target=s.one('SELECT created,sender FROM messages WHERE id=? AND room=?',(mid,room))
    if not target or target['sender']==u or hidden_for(s,u,mid):raise web.HTTPNotFound()
    rows=s.all("SELECT m.id,m.sender FROM messages m LEFT JOIN message_receipts mr ON mr.message=m.id AND mr.user=? WHERE m.room=? AND m.sender!=? AND (m.created<? OR (m.created=? AND m.id<=?)) AND mr.read_at IS NULL AND NOT EXISTS(SELECT 1 FROM hidden_messages h WHERE h.message=m.id AND h.user=?)",(u,room,u,target['created'],target['created'],mid,u))
    stamp=now()
    with transaction(s.db):
        for m in rows:
            s.db.execute('INSERT OR IGNORE INTO message_receipts VALUES(?,?,?,?)',(m['id'],u,stamp,stamp))
            s.db.execute('UPDATE message_receipts SET read_at=? WHERE message=? AND user=? AND read_at IS NULL',(stamp,m['id'],u))
    for m in rows:
        receipt=s.one('SELECT user,delivered,read_at FROM message_receipts WHERE message=? AND user=?',(m['id'],u))
        if receipt:await s.emit(m['sender'],{'type':'receipt-v2','room':room,'id':m['id'],'receipt':dict(receipt)})
    await s.emit(u,{'type':'message-alert-refresh'})
    return web.json_response({'ok':True,'created':target['created']})

async def message_alert_snapshot(request):
    u=auth(request);return web.json_response({'messages':message_alerts(request.app['store'],u,request.query.get('detail')=='1',request.query.get('avatars')=='1')})

async def events(request):
    u=auth(request);s=request.app['store'];queue=s.events[u];result=[]
    snapshot=request.query.get('ringing')=='1';known=request.query.get('known','')
    if known and not valid_id(known):raise web.HTTPBadRequest()
    # If a previous HTTP response was lost, the current call is replayed immediately.
    current=ringing_for_push(s,u) if snapshot else None
    if not snapshot or (current['callId'] if current else '')==known:
        try:result.append(await asyncio.wait_for(queue.get(),timeout=20 if snapshot else 25))
        except asyncio.TimeoutError:pass
    auth(request)
    while not queue.empty() and len(result)<50:result.append(queue.get_nowait())
    current=ringing_for_push(s,u)
    result=[e for e in result if e.get('type')=='hangup' or e.get('type')=='call' and current and current.get('room')==e.get('room') and (e.get('callId') is None or e.get('callId')==current['callId'])]
    if snapshot:
        payload={'events':result,'ringing':current}
        if request.query.get('messages')=='1':payload['messages']=message_alerts(s,u,request.query.get('detail')=='1',request.query.get('avatars')=='1')
        return web.json_response(payload)
    return web.json_response({'events':result})
async def call_history(request):
    u=auth(request);s=request.app['store'];room=request.match_info.get('room')
    if room:s.member(u,room)
    sql='SELECT c.* FROM calls c JOIN members m ON m.room=c.room WHERE m.user=? AND NOT EXISTS(SELECT 1 FROM hidden_calls h WHERE h.call_id=c.id AND h.user=?)';args=[u,u]
    if room:sql+=' AND c.room=?';args.append(room)
    return web.json_response(s.all(sql+' ORDER BY c.started DESC LIMIT 200',args))
async def acknowledge_call_alert(request):
    # Only the authenticated callee can confirm presentation of a live direct invitation.
    u=auth(request);s=request.app['store'];b=await body(request)
    ident=b.get('callId');status=b.get('status')
    if not valid_id(ident) or status not in ('alerted','silent','displayed'):raise web.HTTPBadRequest()
    call=ringing_call(s,u);active=s.calls.get(u)
    if not call or call['callId']!=ident or not active:raise web.HTTPConflict()
    caller=s.calls.get(active['initiator'])
    if not caller or caller['id']!=ident:raise web.HTTPConflict()
    if call.get('silent'):status='silent'
    old=caller.get('alert_status')
    # Duplicate push/poll/WebView delivery is harmless; a visible-only ack may upgrade.
    if old is None or (old=='displayed' and status!='displayed'):
        caller['alert_status']=status
        await s.emit(active['initiator'],{'type':'call-alert-ack','room':active['room'],'callId':ident,'from':u,'status':status})
    return web.json_response({'ok':True})

async def current_call(request):
    u=auth(request);s=request.app['store'];c=s.calls.get(u)
    if not c:return web.json_response(None)
    return web.json_response({'type':'call','room':c['room'],'from':c['initiator'],'video':c['video'],'incoming':c['initiator']!=u,'callId':c['id'],'ringing':ringing_call(s,u) is not None,**({'alertStatus':c['alert_status']} if c['initiator']==u and c.get('alert_status') else {})})
async def admin_inventory(request):
    auth_admin(request);s=request.app['store']
    if request.match_info['kind']=='users':
        return web.json_response([{**public_user(r,s),'phone':r['phone'],'created':r['created']} for r in s.db.execute('SELECT * FROM users ORDER BY created DESC')])
    rows=s.all('SELECT * FROM rooms ORDER BY created DESC')
    # Reuse one membership query and one audit lookup rather than two queries
    # per room. Preserve the existing authorized inventory response exactly.
    members=defaultdict(list)
    for m in s.db.execute('SELECT m.room AS member_room,u.* FROM members m JOIN users u ON u.id=m.user ORDER BY m.room,m.user'):
        members[m['member_room']].append(public_user(m,s))
    admin=audit_user(s)
    for r in rows:r['members']=members[r['id']];r['audit']=admin
    return web.json_response(rows)
async def admin_messages(request):
    u=auth_admin(request);s=request.app['store'];room=request.match_info['room']
    if not s.one('SELECT 1 FROM rooms WHERE id=?',(room,)):raise web.HTTPNotFound()
    rows=s.all('SELECT * FROM messages WHERE room=? ORDER BY created DESC LIMIT 200',(room,))
    if not rows:return web.json_response([])
    # The inventory is already admin-authorized. Batch only metadata of the
    # selected messages; do not expand recipients or return other envelopes.
    ids=tuple(r['id'] for r in rows);marks=','.join('?' for _ in ids)
    silent={r['message'] for r in s.all(f'SELECT message FROM silent_messages WHERE message IN ({marks})',ids)}
    once={r['message']:r['opened'] for r in s.all(f'SELECT message,opened FROM view_once_uploads WHERE message IN ({marks})',ids)}
    expiry={r['message']:r['due'] for r in s.all(f'SELECT message,due FROM message_expiry WHERE message IN ({marks})',ids)}
    keys={r['message']:json.loads(r['sender_pub']) for r in s.all(f'SELECT message,sender_pub FROM message_keys WHERE message IN ({marks})',ids)}
    revisions={r['message']:r['n'] for r in s.all(f'SELECT message,count(*) n FROM message_revisions WHERE message IN ({marks}) GROUP BY message',ids)}
    receipts=defaultdict(list)
    for r in s.all(f'SELECT message,user,delivered,read_at FROM message_receipts WHERE message IN ({marks}) ORDER BY message,user',ids):
        receipts[r.pop('message')].append(r)
    for r in rows:
        mid=r['id'];r['silent']=mid in silent;r['envelope']=json.loads(r.pop('envelopes')).get(u)
        if mid in once:r.update(view_once=True,view_once_opened=once[mid] is not None)
        if mid in expiry:r['delete_at']=expiry[mid]
        if mid in keys:r['sender_pub']=keys[mid]
        r['history_count']=revisions.get(mid,0);r['receipts_v2']=receipts[mid]
    return web.json_response(rows)
async def admin_upload(request):
    auth_admin(request);s=request.app['store'];r=s.one('SELECT * FROM uploads WHERE id=?',(request.match_info['id'],))
    if not r or not r['complete'] or s.one('SELECT 1 FROM deleted_upload_queue WHERE upload=?',(r['id'],)) or (s.one('SELECT 1 FROM ratchet_pilot_media WHERE upload_id=?',(r['id'],)) or s.one('SELECT 1 FROM ratchet_group_uploads WHERE upload_id=?',(r['id'],))):raise web.HTTPNotFound()
    if private_upload(s,r['id']):raise web.HTTPForbidden(text='Tek görüntülemelik medya normal yönetim indirmesinde açılmaz.')
    return web.FileResponse(s.dir/r['id'],headers={'Content-Type':'application/octet-stream'})
async def admin_delete(request):
    u=auth_admin(request);s=request.app['store'];kind=request.match_info['kind'];ident=request.match_info['id']
    if kind=='messages':
        r=s.one('SELECT room FROM messages WHERE id=?',(ident,))
        if not r:raise web.HTTPNotFound()
        erase_message(s,ident);await s.broadcast(r['room'],{'type':'message','room':r['room'],'id':ident,'deleted':True})
    elif kind=='rooms':
        for f in s.all('SELECT id FROM uploads WHERE room=?',(ident,)):(s.dir/f['id']).unlink(missing_ok=True)
        await s.broadcast(ident,{'type':'rooms'});s.run('DELETE FROM rooms WHERE id=?',(ident,))
    elif kind=='users':
        if ident==u:raise web.HTTPBadRequest(text='Kendi yönetici hesabınızı bu ekrandan silemezsiniz.')
        for f in s.all('SELECT id FROM uploads WHERE owner=?',(ident,)):(s.dir/f['id']).unlink(missing_ok=True)
        s.run('DELETE FROM uploads WHERE owner=?',(ident,));s.run('DELETE FROM calls WHERE caller=? OR callee=?',(ident,ident));s.run('DELETE FROM messages WHERE sender=?',(ident,));s.run('DELETE FROM users WHERE id=?',(ident,))
        for ws in tuple(s.sockets[ident]):await ws.close(code=4001)
    else:raise web.HTTPNotFound()
    return web.json_response({'ok':True})
async def blocks(request):
    u=auth(request);s=request.app['store']
    if request.method=='POST':
        b=await body(request);peer=b['peer']
        if peer==u or not s.one('SELECT 1 FROM users WHERE id=?',(peer,)):raise ValueError()
        s.run('INSERT OR IGNORE INTO blocks VALUES(?,?)',(u,peer))
    return web.json_response([public_user(r,s) for r in s.db.execute('SELECT u.* FROM users u JOIN blocks b ON b.peer=u.id WHERE b.owner=?',(u,))])
async def unblock(request):
    u=auth(request);request.app['store'].run('DELETE FROM blocks WHERE owner=? AND peer=?',(u,request.match_info['peer']))
    return web.json_response({'ok':True})
async def media(request):
    u=auth(request);s=request.app['store'];before=int(request.query.get('before',now()+1));ident=request.query.get('before_id','~')
    rows=s.db.execute('SELECT DISTINCT m.* FROM messages m JOIN members r ON r.room=m.room JOIN message_uploads f ON f.message=m.id WHERE r.user=? AND NOT EXISTS(SELECT 1 FROM hidden_messages h WHERE h.message=m.id AND h.user=?) AND NOT EXISTS(SELECT 1 FROM view_once_uploads v WHERE v.message=m.id) AND (m.created<? OR (m.created=? AND m.id<?)) ORDER BY m.created DESC,m.id DESC LIMIT 100',(u,u,before,before,ident)).fetchall()
    return web.json_response([message_for(r,u,s) for r in rows])
def create_app(data=None,*,push_transport=None,ratchet_pilot=None,ratchet_cutover=None,ratchet_group_pilot=False):
    app=web.Application(middlewares=[boundary],client_max_size=2*1024*1024)
    app['store']=Store(data or os.environ.get('FS_DATA','./private-data'))
    app['origins']=set(os.environ.get('FS_ORIGINS','https://appassets.androidplatform.net').split(','))
    app['tasks']=set()
    project=os.environ.get('FS_FCM_PROJECT')
    if push_transport is None and os.environ.get('FS_FCM_SERVICE_ACCOUNT_JSON') and not project:
        raise ValueError('FS_FCM_PROJECT is required when FCM credentials are set')
    if push_transport is None and project:push_transport=FirebaseTransport(project)
    app['store'].push=PushCalls(app['store'],push_transport,ringing_for_push,lambda store,user:message_alerts(store,user,True))
    app['turn']=TurnCredentials()
    install_account_verify(app, auth, rate)
    app.add_routes([web.post('/api/session',session),web.get('/api/me',me),web.patch('/api/me',me),web.post('/api/logout',logout),web.get('/api/people',people),web.get('/api/contacts',contacts),web.post('/api/contacts',contacts),web.delete('/api/contacts/{peer}',contact_delete),web.get('/api/rooms',rooms),web.post('/api/rooms',rooms),web.get('/api/rooms/{room}/messages',messages),web.post('/api/rooms/{room}/messages',messages),web.patch('/api/messages/{id}',change_message),web.delete('/api/messages/{id}',change_message),web.get('/api/saved',saved),web.post('/api/saved',saved),web.delete('/api/saved/{id}',unsave),web.post('/api/uploads',upload),web.get('/api/uploads/{id}',upload_part),web.put('/api/uploads/{id}',upload_part),web.get('/api/config',config),web.get('/api/socket',socket),web.get('/health',health)])
    app.router.add_route('OPTIONS','/{tail:.*}',lambda r:web.Response(status=204))
    app.router.add_get('/api/events',events)
    app.router.add_post('/api/push/registration',push_registration)
    app.router.add_delete('/api/push/registration',push_registration)
    app.router.add_get('/api/push/ringing',push_ringing)
    app.router.add_get('/api/push/messages',push_messages)
    app.router.add_get('/api/message-alerts',message_alert_snapshot)
    app.router.add_post('/api/rooms/{room}/notification-read',notification_read)
    app.router.add_delete('/api/uploads/{id}',upload_part)
    app.router.add_get('/api/messages/{id}/download/{upload}',download_message_file)
    app.router.add_post('/api/messages/{id}/view-once',open_view_once)
    app.router.add_get('/api/calls',call_history)
    app.router.add_get('/api/calls/current',current_call)
    app.router.add_post('/api/calls/decline',decline_incoming)
    app.router.add_post('/api/calls/alert-ack',acknowledge_call_alert)
    app.router.add_get('/api/rooms/{room}/calls',call_history)
    app.router.add_post('/api/rooms/{room}/read',read_room)
    app.router.add_post('/api/rooms/{room}/receipts',acknowledge_messages)
    app.router.add_post('/api/rooms/{room}/read-delivered',read_delivered_room)
    app.router.add_post('/api/room-history/manage',manage_room_history)
    app.router.add_get('/api/delivery-pending',pending_delivery)
    app.router.add_get('/api/messages/{id}/history',message_history)
    app.router.add_post('/api/rooms/{room}/messages/check',check_messages)
    app.router.add_get('/api/rooms/{room}/scheduled',scheduled_messages)
    app.router.add_post('/api/rooms/{room}/scheduled',scheduled_messages)
    app.router.add_delete('/api/rooms/{room}/scheduled/{id}',scheduled_messages)
    app.router.add_post('/api/rooms/{room}/messages/hide',hide_messages)
    app.router.add_post('/api/rooms/{room}/messages/batch-delete',batch_delete_messages)
    app.router.add_post('/api/rooms/{room}/auto-delete',auto_delete_policy)
    app.router.add_get('/api/admin/inventory/{kind:users|rooms}',admin_inventory)
    app.router.add_get('/api/admin/rooms/{room}/messages',admin_messages)
    app.router.add_get('/api/admin/uploads/{id}',admin_upload)
    app.router.add_delete('/api/admin/{kind:messages|rooms|users}/{id}',admin_delete)
    app.router.add_get('/api/blocks',blocks)
    app.router.add_post('/api/blocks',blocks)
    app.router.add_delete('/api/blocks/{peer}',unblock)
    app.router.add_get('/api/media',media)
    app['ratchet_pilot']=os.environ.get('FS_EXPERIMENTAL_RATCHET')=='1' if ratchet_pilot is None else bool(ratchet_pilot)
    app['ratchet_cutover']=os.environ.get('FS_EXPERIMENTAL_RATCHET_CUTOVER')=='1' if ratchet_cutover is None else bool(ratchet_cutover)
    install_ratchet_pilot(app,auth,body,blocked,rate)
    install_ratchet_cutover(app,auth,body,blocked)
    app['ratchet_group_pilot']=bool(ratchet_group_pilot)
    install_ratchet_group_pilot(app,auth,body,rate)
    install_stories(app,auth=auth,body=body,blocked=blocked,public_user=public_user,public_key_matches=public_key_matches,now=now,rate=rate)
    app.router.add_static('/',ROOT/'web',show_index=False)
    async def close(a):
        for task in a['tasks']:task.cancel()
        await asyncio.gather(*a['tasks'],return_exceptions=True)
        a['store'].db.close()
    async def start(a):
        await expire_messages(a['store'])
        sweep_stories(a['store'],now())
        if a['store'].push.transport:
            task=asyncio.create_task(a['store'].push.worker());a['tasks'].add(task);task.add_done_callback(a['tasks'].discard)
        async def expire_presence():
            last_limit_cleanup=time.monotonic()
            while True:
                await asyncio.sleep(1)
                for user in a['store'].presence.sweep():await a['store'].notify_profile(user)
                clock=time.monotonic()
                if clock-last_limit_cleanup>=60:
                    for key,attempts in tuple(a['store'].limits.items()):
                        if not attempts or attempts[-1]<clock-60:a['store'].limits.pop(key,None)
                    sweep_stories(a['store'],now())
                    last_limit_cleanup=clock
                for source,(_,_,until,_) in tuple(a['store'].typing_leases.items()):
                    if until<=clock:a['store'].typing_leases.pop(source,None)
                await a['store'].group_calls.sweep()
                try:await expire_messages(a['store']);await dispatch_scheduled(a['store'])
                except Exception:
                    import logging
                    logging.getLogger(__name__).exception('Scheduled delivery failed; will retry')
        task=asyncio.create_task(expire_presence());a['tasks'].add(task);task.add_done_callback(a['tasks'].discard)
    app.on_startup.append(start)
    app.on_cleanup.append(close)
    return app
if __name__=='__main__':web.run_app(create_app(),host=os.environ.get('FS_HOST','127.0.0.1'),port=int(os.environ.get('FS_PORT','8787')),access_log=None)
