"""Storage adapter. Database credentials stay on the application server."""
import os
import re
import sqlite3
from pathlib import Path


def maria_sql(sql):
    sql = sql.replace(' COLLATE NOCASE', '')
    sql = sql.replace('INSERT OR IGNORE', 'INSERT IGNORE')
    sql = sql.replace('ON CONFLICT(owner,peer) DO UPDATE SET deleted=0',
                      'ON DUPLICATE KEY UPDATE deleted=0')
    sql = sql.replace('ON CONFLICT(room,user) DO UPDATE SET ts=max(ts,excluded.ts)',
                      'ON DUPLICATE KEY UPDATE ts=GREATEST(ts,VALUES(ts))')
    sql = sql.replace('ON CONFLICT(key) DO UPDATE SET value=excluded.value',
                      'ON DUPLICATE KEY UPDATE value=VALUES(value)')
    sql = re.sub(r'(?<!`)\bkey\b(?!`)', '`key`', sql)
    # Queries are developer-owned constants; question marks never occur in literals.
    return sql.replace('?', '%s')


class MariaConnection:
    def __init__(self):
        import pymysql
        self.driver = pymysql
        options = dict(host=os.environ.get('FS_DB_HOST', 'localhost'),
                       port=int(os.environ.get('FS_DB_PORT', '3306')),
                       user=os.environ['FS_DB_USER'], password=os.environ['FS_DB_PASSWORD'],
                       database=os.environ['FS_DB_NAME'], charset='utf8mb4',
                       cursorclass=pymysql.cursors.DictCursor, autocommit=True,
                       connect_timeout=10, read_timeout=20, write_timeout=20)
        if os.environ.get('FS_DB_TLS_CA'):
            options.update(ssl_ca=os.environ['FS_DB_TLS_CA'], ssl_verify_cert=True,
                           ssl_verify_identity=True)
        self.connection = pymysql.connect(**options)
        try:
            for statement in Path(__file__).with_name('schema.mariadb.sql').read_text().split(';'):
                if statement.strip():
                    self.execute(statement)
            self.commit()
        except Exception:
            self.close()
            raise

    def execute(self, sql, args=()):
        cursor = self.connection.cursor()
        try:
            cursor.execute(maria_sql(sql), args)
            return cursor
        except self.driver.IntegrityError as error:
            self.connection.rollback()
            cursor.close()
            raise sqlite3.IntegrityError('Database constraint violation') from error
        except Exception:
            self.connection.rollback()
            cursor.close()
            raise

    def executemany(self, sql, args):
        cursor = self.connection.cursor()
        try:
            cursor.executemany(maria_sql(sql), args)
            return cursor
        except Exception:
            self.connection.rollback()
            cursor.close()
            raise

    def commit(self):
        self.connection.commit()

    def close(self):
        self.connection.close()


def connect(directory):
    backend = os.environ.get('FS_DB_BACKEND', 'sqlite').lower()
    if backend == 'mariadb':
        return MariaConnection()
    if backend != 'sqlite':
        raise ValueError('FS_DB_BACKEND must be sqlite or mariadb')
    db = sqlite3.connect(Path(directory) / 'fs.sqlite')
    db.row_factory = sqlite3.Row
    db.executescript(Path(__file__).with_name('schema.sql').read_text())
    # Additive, idempotent indexes for the deployed SQLite database. No rows,
    # keys or existing tables are rewritten. Reverse lookups otherwise scan
    # the entire composite-primary-key table as the chat history grows.
    db.executescript('''
        CREATE INDEX IF NOT EXISTS fs_members_user_room ON members(user,room);
        CREATE INDEX IF NOT EXISTS fs_receipts_user_read ON message_receipts(user,read_at,message);
        CREATE INDEX IF NOT EXISTS fs_message_uploads_reverse ON message_uploads(upload,message);
        CREATE INDEX IF NOT EXISTS fs_calls_room_started ON calls(room,started);
        CREATE INDEX IF NOT EXISTS fs_sessions_user_expiry ON sessions(user,expires);
        CREATE INDEX IF NOT EXISTS fs_story_recipients_user ON story_recipients(recipient,story);
    ''')
    return db

# A device change commits its public-key update and session revocation together.
from contextlib import contextmanager
@contextmanager
def transaction(db):
    if isinstance(db, MariaConnection): db.connection.begin()
    else: db.execute('BEGIN IMMEDIATE')
    try:
        yield
        db.commit()
    except Exception:
        if isinstance(db, MariaConnection): db.connection.rollback()
        else: db.rollback()
        raise
