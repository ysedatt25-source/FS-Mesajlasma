"""Validate server-side FCM provisioning without exposing credentials."""
import json, re

PROJECT = re.compile(r'[a-z][a-z0-9-]{4,28}[a-z0-9]\Z')

def validate_project(value):
    if not isinstance(value, str) or not PROJECT.fullmatch(value):
        raise ValueError('FS_FCM_PROJECT must be a valid Firebase project ID')
    return value

def service_account(project, raw):
    validate_project(project)
    if not raw:
        return None  # Local ADC / workload identity remains supported.
    try:
        if not isinstance(raw, str) or len(raw) > 65536:
            raise ValueError()
        obj = json.loads(raw)
        if not isinstance(obj, dict) or obj.get('type') != 'service_account' or obj.get('project_id') != project:
            raise ValueError()
        if not isinstance(obj.get('client_email'), str) or not obj['client_email'].endswith('.iam.gserviceaccount.com'):
            raise ValueError()
        key = obj.get('private_key')
        if not isinstance(key, str) or not key.startswith('-----BEGIN PRIVATE KEY-----\n') or not key.rstrip().endswith('-----END PRIVATE KEY-----'):
            raise ValueError()
        if obj.get('token_uri') != 'https://oauth2.googleapis.com/token':
            raise ValueError()
        return obj
    except (TypeError, ValueError, KeyError):
        raise ValueError('Invalid or mismatched Firebase service account configuration') from None
