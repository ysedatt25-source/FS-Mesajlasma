"""Bounded, ephemeral, foreground WebRTC mesh signaling; no media reaches the API."""
import time
from collections import defaultdict, deque
from itertools import combinations
from emoji_relay import valid_id

FEATURE='group-call-v1'
MAX_PEERS=4
# Longer than the client ICE recovery window (60 seconds).
CALL_DISCONNECT_GRACE=75
class GroupCalls:
    def __init__(self,store,blocked,clock=time.monotonic):
        self.store,self.blocked,self.clock=store,blocked,clock
        self.calls={};self.by_user={};self.capable={};self.rates=defaultdict(deque);self.disconnected={}
    def busy(self,user):return user in self.by_user
    def online(self,user):return any(owner==user for owner in self.capable.values())
    def ringing(self,user):
        c=self.calls.get(self.by_user.get(user));remaining=int(1000*(c['expires']-self.clock())) if c else 0
        if not c or c['peers'].get(user)!='ringing' or remaining<=0:return None
        members={r['user'] for r in self.store.all('SELECT user FROM members WHERE room=?',(c['room'],))}
        if not set(c['peers'])<=members or any(self.blocked(self.store,a,b) for a,b in combinations(c['peers'],2)):return None
        import json
        row=self.store.one('SELECT settings FROM users WHERE id=?',(user,))
        if not row or not json.loads(row['settings']).get('available',True):return None
        return {'type':'call','room':c['room'],'from':c['host'],'video':c['video'],'callId':c['id'],'remainingMs':min(45000,remaining)}
    async def emit(self,user,event):
        if event.get('type')=='group-call-end' and self.store.push:self.store.push.wake_refresh(user)
        if event.get('type') in ('group-call-invite','group-call-end','group-call-state'):
            queue=self.store.events[user]
            if queue.full():queue.get_nowait()
            queue.put_nowait({'type':'group-call-wakeup'})
        for ws,owner in tuple(self.capable.items()):
            if owner!=user:continue
            token=self.store.socket_tokens.get(ws)
            if not token or not self.store.one('SELECT 1 FROM sessions WHERE token=? AND user=? AND expires>?',(token,user,int(time.time()*1000))):continue
            try:await ws.send_json(event)
            except (ConnectionError,RuntimeError):pass
    def event(self,c,kind,**extra):return {'type':'group-call-'+kind,'room':c['room'],'callId':c['id'],'from':c['host'],**extra}
    async def state(self,c):
        if self.calls.get(c['id']) is not c:return
        status=dict(c['peers']);event=self.event(c,'state',video=c['video'],participants=status)
        for u in status:await self.emit(u,event)
    async def connected(self,user,ws):
        self.capable[ws]=user;self.disconnected.pop(user,None)
        c=self.calls.get(self.by_user.get(user))
        if c and user in c['peers']:
            # A missing UI can explicitly accept a rejoin; the browser must never
            # start camera/microphone merely because a snapshot arrives.
            if c['peers'][user]=='ringing':await self.emit(user,self.event(c,'invite',video=c['video']))
            await self.state(c)
        else:await ws.send_json({"type":"group-call-none"})
    def disconnected_socket(self,user,ws):
        self.capable.pop(ws,None);self.rates.pop(ws,None)
        c=self.calls.get(self.by_user.get(user))
        if not self.online(user) and c and c['peers'].get(user)=='joined':self.disconnected[user]=self.clock()+CALL_DISCONNECT_GRACE
    async def end(self,c,reason):
        if self.calls.pop(c['id'],None) is None:return
        peers=list(c['peers'])
        for u in peers:
            if self.by_user.get(u)==c['id']:self.by_user.pop(u,None)
            self.disconnected.pop(u,None)
        for u in peers:await self.emit(u,self.event(c,'end',reason=reason))
    async def leave(self,user,reason='left'):
        c=self.calls.get(self.by_user.get(user))
        if not c:return
        if user==c['host']:await self.end(c,reason);return
        self.by_user.pop(user,None);self.disconnected.pop(user,None);c['peers'].pop(user,None)
        await self.emit(user,self.event(c,'end',reason=reason))
        if len(c['peers'])<2:await self.end(c,'empty')
        else:await self.state(c)
    async def sweep(self):
        n=self.clock()
        for u,t in list(self.disconnected.items()):
            if t<=n:await self.leave(u,'disconnected')
        for c in list(self.calls.values()):
            members={r['user'] for r in self.store.all('SELECT user FROM members WHERE room=?',(c['room'],))}
            if not set(c['peers'])<=members or any(self.blocked(self.store,a,b) for a,b in combinations(c['peers'],2)):
                await self.end(c,'access_changed');continue
            if c['expires']<=n:
                for u,status in list(c['peers'].items()):
                    if status=='ringing':await self.leave(u,'missed')
    async def handle(self,user,ws,b):
        typ=b.get('type','') if isinstance(b,dict) else ''
        if not isinstance(typ,str) or not typ.startswith('group-call-'):return False
        if self.capable.get(ws)!=user:return True
        rate=self.rates[ws];n=self.clock()
        while rate and rate[0]<n-1:rate.popleft()
        if len(rate)>=100:return True
        rate.append(n)
        room,ident=b.get('room'),b.get('callId')
        if not valid_id(room) or not valid_id(ident) or len(ident)>64:return True
        if typ=='group-call-start':
            async def reject(reason):await self.emit(user,{'type':'group-call-end','room':room,'callId':ident,'from':user,'reason':reason})
            record=self.store.one('SELECT kind FROM rooms WHERE id=?',(room,));members={r['user'] for r in self.store.all('SELECT user FROM members WHERE room=?',(room,))}
            if not record or record['kind']!='group' or user not in members or not 3<=len(members)<=MAX_PEERS or type(b.get('video')) is not bool:
                await reject('invalid_group');return True
            if self.busy(user) or user in self.store.calls or ident in self.calls or self.store.one('SELECT 1 FROM calls WHERE id=?',(ident,)):
                await reject('busy');return True
            eligible=[]
            # An opt-in push registration is also a supporting client; legacy clients
            # without a current group websocket or registration remain excluded.
            for peer in sorted(members-{user}):
                if (not self.online(peer) and not (self.store.push and self.store.push.has_registration(peer))) or self.busy(peer) or peer in self.store.calls:continue
                row=self.store.one('SELECT settings FROM users WHERE id=?',(peer,))
                import json
                if not row or not json.loads(row['settings']).get('available',True):continue
                if any(self.blocked(self.store,peer,x) for x in [user,*eligible]):continue
                eligible.append(peer)
            if not eligible:await reject('unavailable');return True
            c={'id':ident,'room':room,'host':user,'video':b['video'],'peers':{user:'joined',**{p:'ringing' for p in eligible}},'expires':n+45}
            self.calls[ident]=c
            for p in c['peers']:self.by_user[p]=ident
            for p in eligible:
                await self.emit(p,self.event(c,'invite',video=c['video']))
                if self.store.push:self.store.push.wake(p)
            await self.state(c);return True
        c=self.calls.get(ident)
        if not c or c['room']!=room or self.by_user.get(user)!=ident:return True
        # Re-evaluate group membership, blocked relationships and actual joined status for every signal.
        members={r['user'] for r in self.store.all('SELECT user FROM members WHERE room=?',(room,))}
        if not set(c['peers'])<=members or any(self.blocked(self.store,a,b) for a,b in combinations(c['peers'],2)):
            await self.end(c,'access_changed');return True
        if typ=='group-call-accept':
            if c['peers'][user]!='ringing' or n>=c['expires']:return True
            c['peers'][user]='joined'
            if self.store.push:self.store.push.wake_refresh(user)
            await self.state(c)
        elif typ=='group-call-leave':await self.leave(user)
        elif typ=='group-call-signal':
            target=b.get('to');kind=b.get('kind')
            if target==user or not valid_id(target) or c['peers'].get(user)!='joined' or c['peers'].get(target)!='joined':return True
            if kind in ('offer','answer'):
                d=b.get('description');
                if not isinstance(d,dict) or d.get('type')!=kind or not isinstance(d.get('sdp'),str) or not 0<len(d['sdp'])<=120000:return True
                extra={'description':{'type':kind,'sdp':d['sdp']}}
            elif kind=='restart-request':
                if user<target:return True
                extra={}
            elif kind=='ice':
                d=b.get('candidate')
                if not isinstance(d,dict) or not isinstance(d.get('candidate'),str) or len(d['candidate'])>4096:return True
                if d.get('sdpMid') is not None and (not isinstance(d['sdpMid'],str) or len(d['sdpMid'])>128):return True
                if d.get('sdpMLineIndex') is not None and (type(d['sdpMLineIndex']) is not int or not 0<=d['sdpMLineIndex']<=128):return True
                if d.get('usernameFragment') is not None and (not isinstance(d['usernameFragment'],str) or len(d['usernameFragment'])>256):return True
                extra={'candidate':{k:d[k] for k in ('candidate','sdpMid','sdpMLineIndex','usernameFragment') if k in d}}
            else:return True
            await self.emit(target,{'type':typ,'room':room,'callId':ident,'from':user,'to':target,'kind':kind,**extra})
        return True
