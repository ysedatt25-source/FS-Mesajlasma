"""Local server-owner provisioning. Never exposes a public promotion endpoint."""
import argparse, os
from database import connect
parser=argparse.ArgumentParser();parser.add_argument('command',choices=['promote']);parser.add_argument('nick');parser.add_argument('--data',default=os.environ.get('FS_DATA','./private-data'));args=parser.parse_args()
db=connect(args.data)
row=db.execute('SELECT id FROM users WHERE nick=? COLLATE NOCASE',(args.nick,)).fetchone()
if not row:parser.error('Önce uygulamadan bu kullanıcı hesabını oluşturun.')
old=db.execute("SELECT value FROM app_config WHERE key='admin'").fetchone()
if old and old['value']!=row['id']:parser.error('Yönetici değişimi mevcut şifreli geçmişin anahtarlarını aktarmayı gerektirir; otomatik değiştirilmedi.')
db.execute("INSERT INTO app_config VALUES('admin',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(row['id'],));db.commit();print('Yönetici hesabı yapılandırıldı. Eski mesajlar geriye dönük açılmaz. Yeni mesajlar yönetici cihazı için de şifrelenir.')
