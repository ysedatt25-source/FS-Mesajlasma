"""Optional FCM call and message wakeups, never chat contents or session credentials.
The provider is off unless explicitly configured; the existing authenticated poll remains available.
"""
import asyncio, hashlib, os, re, time
from fcm_config import validate_project, service_account
from database import transaction
TOKEN=re.compile(r'[A-Za-z0-9:_-]{20,2048}\Z')
BINDING=re.compile(r'[A-Za-z0-9_-]{22,64}\Z')

def valid_registration(token,binding):
    return isinstance(token,str) and bool(TOKEN.fullmatch(token)) and isinstance(binding,str) and bool(BINDING.fullmatch(binding))

def register(store,session,token,binding):
    digest=hashlib.sha256(token.encode()).hexdigest()
    with transaction(store.db):
        store.db.execute('DELETE FROM push_registrations WHERE session_id IN (SELECT token FROM sessions WHERE expires<=?)',(int(time.time()*1000),))
        old=store.one('SELECT session_id FROM push_registrations WHERE registration_hash=?',(digest,))
        if old and old['session_id']!=session:
            # Never allow a registration bound to a different live session to be silently hijacked.
            return False
        store.db.execute('DELETE FROM push_registrations WHERE session_id=?',(session,))
        store.db.execute('INSERT INTO push_registrations(session_id,registration_hash,registration,binding) VALUES(?,?,?,?)',(session,digest,token,binding))
    return True

def remove(store,session):
    store.run('DELETE FROM push_registrations WHERE session_id=?',(session,))

def payload(binding,kind="call-wakeup-v1"):
    if not isinstance(binding,str) or not BINDING.fullmatch(binding):raise ValueError('Invalid binding')
    if kind not in ('call-wakeup-v1','message-wakeup-v1','call-refresh-v1'):raise ValueError('Invalid wakeup')
    return {'kind':kind,'binding':binding}

class FirebaseTransport:
    def __init__(self,project):
        # Imported only when enabled; no private key is written to disk or logged.
        project=validate_project(project)
        account=service_account(project,os.environ.get("FS_FCM_SERVICE_ACCOUNT_JSON"))
        import firebase_admin
        from firebase_admin import credentials,messaging
        self.messaging=messaging
        credential=credentials.Certificate(account) if account else credentials.ApplicationDefault()
        if credential.project_id and credential.project_id!=project:raise ValueError('Firebase credential project mismatch')
        self.app=firebase_admin.initialize_app(credential,{'projectId':project,'httpTimeout':5},name='fs-call-wakeup-v1')
    def __call__(self,token,data,remaining):
        from datetime import timedelta
        m=self.messaging.Message(token=token,data=data,android=self.messaging.AndroidConfig(priority='normal' if data['kind']=='call-refresh-v1' else 'high',ttl=timedelta(milliseconds=min(remaining,15000 if data['kind']=='call-refresh-v1' else 45000 if data['kind']=='call-wakeup-v1' else 300000))))
        try:self.messaging.send(m,app=self.app)
        except self.messaging.UnregisteredError:return False
        return True

class PushCalls:
    def __init__(self,store,transport,ringing,messages=None):
        self.store=store;self.transport=transport;self.ringing=ringing;self.messages=messages;self.queue=asyncio.Queue(maxsize=128)
    def has_registration(self,user):
        return bool(self.transport and self.store.one('SELECT 1 FROM push_registrations p JOIN sessions s ON s.token=p.session_id WHERE s.user=? AND s.expires>?',(user,int(time.time()*1000))))
    def wake(self,user):
        if not self.transport:return
        if self.queue.full():return # Existing authenticated long poll remains authoritative.
        self.queue.put_nowait(user)
    def wake_refresh(self,user):
        # A bounded, best-effort wakeup to reconcile a previously ringing notification.
        if self.queue.full() or not self.has_registration(user):return
        self.queue.put_nowait((user,None,None,time.monotonic()+15))
    def wake_message(self,user,room,mid):
        if not self.transport or not self.messages or self.queue.full():return
        if any(m['room']==room and m['id']==mid for m in self.messages(self.store,user)):
            self.queue.put_nowait((user,room,mid))
    def remaining(self,user,room,mid):
        if room is None:
            current=self.ringing(self.store,user)
            return current['remainingMs'] if current else 0
        current=next((m for m in self.messages(self.store,user) if m['room']==room and m['id']==mid),None) if self.messages else None
        return max(0,min(300000,current['created']+300000-int(time.time()*1000))) if current else 0
    async def deliver(self,user,room=None,mid=None,refresh_until=None):
        def remaining_now():
            return max(0,int((refresh_until-time.monotonic())*1000)) if refresh_until is not None else self.remaining(user,room,mid)
        if not self.transport or remaining_now()<=0:return
        kind='call-refresh-v1' if refresh_until is not None else 'call-wakeup-v1' if room is None else 'message-wakeup-v1'
        rows=self.store.all('SELECT p.session_id,p.registration_hash,p.registration,p.binding FROM push_registrations p JOIN sessions s ON s.token=p.session_id WHERE s.user=? AND s.expires>?',(user,int(time.time()*1000)))
        for row in rows[:8]:
            remaining=remaining_now()
            if remaining<=0:return
            latest=self.store.one('SELECT p.binding FROM push_registrations p JOIN sessions s ON s.token=p.session_id WHERE p.session_id=? AND p.registration_hash=? AND s.user=? AND s.expires>?',(row['session_id'],row['registration_hash'],user,int(time.time()*1000)))
            if not latest or latest['binding']!=row['binding']:continue
            try:ok=await asyncio.to_thread(self.transport,row['registration'],payload(row['binding'],kind),remaining)
            except Exception:continue # Never log provider tokens or payload.
            if ok is False:self.store.run('DELETE FROM push_registrations WHERE session_id=? AND registration_hash=? AND binding=?',(row['session_id'],row['registration_hash'],row['binding']))
    async def worker(self):
        while True:
            user=await self.queue.get()
            try:
                if isinstance(user,tuple):await self.deliver(*user)
                else:await self.deliver(user)
            except Exception:pass # Failure of optional push must not stop the API.
            finally:self.queue.task_done()
