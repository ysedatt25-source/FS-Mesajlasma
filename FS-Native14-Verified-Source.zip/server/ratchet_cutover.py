"""Explicit experimental direct-room cutover. Does not migrate historical ciphertext.
Both authenticated room members must choose the same already established session.
An activated room never falls back to the legacy write path, even if feature flags are disabled.
"""
from aiohttp import web
from database import transaction
from ratchet_pilot import ident, exact, ts

def lock_room(s,room):
    sql='SELECT kind FROM rooms WHERE id=?'+(' FOR UPDATE' if hasattr(s.db,'connection') else '')
    return s.one(sql,(room,))

def active(s,room):
    return s.one('SELECT session_id FROM ratchet_cutover_active WHERE room=?',(room,))

def reject_legacy_write(s,room):
    if active(s,room):
        raise web.HTTPConflict(text='Bu sohbet güvenli kanala geçti. Eski şifreleme ile gönderim ve düzenleme kapalı.')

def status(s,room,user):
    row=active(s,room)
    votes=s.all('SELECT user,session_id FROM ratchet_cutover_votes WHERE room=? AND created>?',(room,ts()-600000))
    rotations=s.all('SELECT user,session_id FROM ratchet_rotation_votes WHERE room=? AND previous=? AND created>?',(room,row['session_id'],ts()-600000)) if row else []
    return {'active':bool(row),'session':row['session_id'] if row else None,
            'rotationOwn':next((v['session_id'] for v in rotations if v['user']==user),None),
            'rotationPeer':next((v['session_id'] for v in rotations if v['user']!=user),None),
            'own':next((v['session_id'] for v in votes if v['user']==user),None),
            'peer':next((v['session_id'] for v in votes if v['user']!=user),None)}

def install(app,auth,body,blocked):
    async def route(r):
        u=auth(r);s=app['store'];room=r.match_info['room'];s.member(u,room)
        b=await body(r) if r.method=='POST' else None
        changed=False
        with transaction(s.db):
            kind=lock_room(s,room)
            members={m['user'] for m in s.all('SELECT user FROM members WHERE room=?',(room,))}
            if not kind or kind['kind']!='direct' or len(members)!=2 or u not in members:raise web.HTTPForbidden()
            peer=next(iter(members-{u}))
            if blocked(s,u,peer):raise web.HTTPForbidden()
            if not (app['ratchet_pilot'] and app['ratchet_cutover']):raise web.HTTPNotFound()
            if r.method=='DELETE':
                if active(s,room):raise web.HTTPConflict(text='Etkin güvenli geçiş geri alınamaz.')
                s.db.execute('DELETE FROM ratchet_cutover_votes WHERE room=? AND user=?',(room,u));changed=True
            if b is not None:
                exact(b,'session consent');sid=ident(b['session'])
                if b['consent'] is not True:raise ValueError()
                existing=active(s,room)
                if existing:
                    if existing['session_id']!=sid:raise web.HTTPConflict(text='Güvenli geçiş zaten etkin.')
                else:
                    established=s.one('SELECT initiator,recipient,reply FROM ratchet_pilot_sessions WHERE id=? AND room=?',(sid,room))
                    if not established or not established['reply'] or {established['initiator'],established['recipient']}!=members:raise web.HTTPConflict(text='Doğrulanmış oturum gerekli.')
                    s.db.execute('DELETE FROM ratchet_cutover_votes WHERE room=? AND user=?',(room,u))
                    s.db.execute('INSERT INTO ratchet_cutover_votes(room,user,session_id,created) VALUES(?,?,?,?)',(room,u,sid,ts()))
                    changed=True
                    other=s.one('SELECT session_id FROM ratchet_cutover_votes WHERE room=? AND user=? AND created>?',(room,peer,ts()-600000))
                    if other and other['session_id']==sid:
                        s.db.execute('INSERT INTO ratchet_cutover_active(room,session_id,created) VALUES(?,?,?)',(room,sid,ts()))
            out=status(s,room,u)
        if changed:await s.broadcast(room,{'type':'rooms'})
        return web.json_response(out)
    async def rotate(r):
        u=auth(r);s=app['store'];room=r.match_info['room'];s.member(u,room)
        b=await body(r);exact(b,'previous session consent');previous=ident(b['previous']);sid=ident(b['session'])
        if b['consent'] is not True or sid==previous:raise ValueError()
        with transaction(s.db):
            kind=lock_room(s,room)
            members={m['user'] for m in s.all('SELECT user FROM members WHERE room=?',(room,))}
            if not kind or kind['kind']!='direct' or len(members)!=2 or u not in members:raise web.HTTPForbidden()
            peer=next(iter(members-{u}))
            if blocked(s,u,peer):raise web.HTTPForbidden()
            if not (app['ratchet_pilot'] and app['ratchet_cutover']):raise web.HTTPNotFound()
            current=active(s,room)
            if not current:raise web.HTTPConflict(text='Etkin oturum yok.')
            if current['session_id']==sid:
                completed=s.one('SELECT previous FROM ratchet_rotations WHERE room=? AND session_id=?',(room,sid))
                if completed and completed['previous']==previous:return web.json_response(status(s,room,u))
            if current['session_id']!=previous:raise web.HTTPConflict(text='Etkin oturum değişti.')
            if s.one('SELECT 1 FROM ratchet_rotations WHERE room=? AND (previous=? OR session_id=?)',(room,sid,sid)):raise web.HTTPConflict(text='Eski oturum tekrar etkinleştirilemez.')
            def keys(x):return {x['initiator']:x['initiator_signing'],x['recipient']:x['responder_signing']}
            old=s.one('SELECT * FROM ratchet_pilot_sessions WHERE room=? AND id=?',(room,previous))
            fresh=s.one('SELECT * FROM ratchet_pilot_sessions WHERE room=? AND id=?',(room,sid))
            if not old or not fresh or not fresh['reply'] or set(keys(fresh))!=members or keys(old)!=keys(fresh) or fresh['created']<old['created']:
                raise web.HTTPConflict(text='Aynı doğrulanmış kimliklerle yeni oturum gerekli.')
            s.db.execute('DELETE FROM ratchet_rotation_votes WHERE room=? AND user=?',(room,u))
            s.db.execute('INSERT INTO ratchet_rotation_votes(room,user,previous,session_id,created) VALUES(?,?,?,?,?)',(room,u,previous,sid,ts()))
            other=s.one('SELECT session_id FROM ratchet_rotation_votes WHERE room=? AND user=? AND previous=? AND created>?',(room,peer,previous,ts()-600000))
            if other and other['session_id']==sid:
                s.db.execute('INSERT INTO ratchet_rotations(room,previous,session_id,created) VALUES(?,?,?,?)',(room,previous,sid,ts()))
                s.db.execute('UPDATE ratchet_cutover_active SET session_id=? WHERE room=? AND session_id=?',(sid,room,previous))
                s.db.execute('DELETE FROM ratchet_rotation_votes WHERE room=?',(room,))
            out=status(s,room,u)
        await s.broadcast(room,{'type':'rooms'})
        return web.json_response(out)
    base='/api/rooms/{room}/ratchet-cutover'
    app.router.add_post(base+'/rotate',rotate);app.router.add_get(base,route);app.router.add_post(base,route);app.router.add_delete(base,route)
