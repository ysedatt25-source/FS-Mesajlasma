"""Disabled-by-default group ciphertext transport. Client verifies signatures and pins.
No membership mutation API, no MLS, no production cutover. A changed roster invalidates
all writes until a new epoch is proposed and all current members approve its key roster.
"""
import base64, hashlib, json, uuid, re
from aiohttp import web
from database import transaction
from ratchet_pilot import b64, exact, ident, ts
from ratchet_cutover import lock_room

def roster_hash(room,epoch,bundles):
    material=['FS group roster v1',room,epoch,[[b['user'],b['dh'],b['signing']] for b in bundles]]
    return base64.b64encode(hashlib.sha256(json.dumps(material,separators=(',',':'),ensure_ascii=False).encode()).digest()).decode()

def install(app,auth,body,rate):
    def access(r):
        if not app['ratchet_group_pilot']:raise web.HTTPNotFound()
        u=auth(r);s=app['store'];room=r.match_info['room'];s.member(u,room);return u,s,room
    def members(s,room,u):
        kind=lock_room(s,room)
        people=sorted(x['user'] for x in s.all('SELECT user FROM members WHERE room=?',(room,)))
        if not kind or kind['kind']!='group' or u not in people or not 2<=len(people)<=100:raise web.HTTPForbidden()
        return people
    def current(s,room):return s.one('SELECT * FROM ratchet_group_current WHERE room=?',(room,))
    def load(s,room,people):
        x=current(s,room)
        if not x or json.loads(x['members_json'])!=people:raise web.HTTPConflict(text='Grup üyeliği değişti; yeni anahtar dönemi gerekli.')
        return x['epoch']
    def snapshot(s,room,epoch,people):
        bundles=[json.loads(x['bundle']) for x in s.all('SELECT bundle FROM ratchet_group_keys WHERE epoch=? ORDER BY user',(epoch,))]
        digest=roster_hash(room,epoch,bundles) if [b['user'] for b in bundles]==people else None
        approved=[x['user'] for x in s.all('SELECT user FROM ratchet_group_votes WHERE epoch=? AND roster=? ORDER BY user',(epoch,digest))] if digest else []
        return {'room':room,'epoch':epoch,'members':people,'bundles':bundles,'roster':digest,'approved':approved,'ready':approved==people}
    async def state(r):
        u,s,room=access(r)
        if r.method=='POST':
            rate(r,'group-epoch:'+u,10);b=await body(r);exact(b,'')
        with transaction(s.db):
            people=members(s,room,u);x=current(s,room)
            if not x or json.loads(x['members_json'])!=people:
                if r.method!='POST':raise web.HTTPConflict(text='Yeni anahtar dönemi gerekli.')
                epoch=uuid.uuid4().hex
                s.db.execute('DELETE FROM ratchet_group_current WHERE room=?',(room,))
                s.db.execute('INSERT INTO ratchet_group_epochs(epoch,room,members_json) VALUES(?,?,?)',(epoch,room,json.dumps(people)))
                s.db.execute('INSERT INTO ratchet_group_current(room,epoch,members_json) VALUES(?,?,?)',(room,epoch,json.dumps(people)))
            else:epoch=x['epoch']
            result=snapshot(s,room,epoch,people)
        return web.json_response(result)
    async def publish(r):
        u,s,room=access(r);rate(r,'group-key:'+u,20);b=await body(r);exact(b,'room epoch user dh signing sig')
        b64(b['dh'],65);b64(b['signing'],65);b64(b['sig'],64)
        with transaction(s.db):
            people=members(s,room,u);epoch=load(s,room,people)
            if b['room']!=room or b['epoch']!=epoch or b['user']!=u:raise web.HTTPConflict(text='Anahtar dönemi veya kullanıcı uyuşmuyor.')
            old=s.one('SELECT bundle FROM ratchet_group_keys WHERE epoch=? AND user=?',(epoch,u))
            if old and json.loads(old['bundle'])!=b:raise web.HTTPConflict(text='Bu dönem için yayımlanan anahtar değiştirilemez.')
            if not old:s.db.execute('INSERT INTO ratchet_group_keys(epoch,user,bundle) VALUES(?,?,?)',(epoch,u,json.dumps(b)))
            result=snapshot(s,room,epoch,people)
        return web.json_response(result)
    async def approve(r):
        u,s,room=access(r);rate(r,'group-vote:'+u,20);b=await body(r);exact(b,'epoch roster');b64(b['roster'],32)
        with transaction(s.db):
            people=members(s,room,u);epoch=load(s,room,people);out=snapshot(s,room,epoch,people)
            if b['epoch']!=epoch or b['roster']!=out['roster']:raise web.HTTPConflict(text='Doğrulanmış güncel üye anahtarları gerekli.')
            if u not in out['approved']:s.db.execute('INSERT INTO ratchet_group_votes(epoch,user,roster) VALUES(?,?,?)',(epoch,u,b['roster']))
            out=snapshot(s,room,epoch,people)
        return web.json_response(out)
    def read_packets(s,epoch,after):
        args=[epoch];where='epoch=?'
        if after is not None:
            anchor=s.one('SELECT created,id FROM ratchet_group_packets WHERE epoch=? AND id=?',(epoch,ident(after)))
            if not anchor:raise web.HTTPConflict(text='Geçersiz geçmiş imleci.')
            where+=' AND (created>? OR (created=? AND id>?))';args.extend([anchor['created'],anchor['created'],anchor['id']])
        rows=s.all('SELECT packet FROM ratchet_group_packets WHERE '+where+' ORDER BY created,id LIMIT 100',tuple(args))
        return [json.loads(x['packet']) for x in rows]
    async def history_epochs(r):
        u,s,room=access(r);rate(r,'group-history:'+u,120)
        with transaction(s.db):
            members(s,room,u)
            after=r.query.get('after','');args=[room,u]
            where='e.room=? AND v.user=?'
            if after:where+=' AND e.epoch>?';args.append(ident(after))
            rows=s.all('SELECT e.epoch,e.members_json FROM ratchet_group_epochs e JOIN ratchet_group_votes v ON e.epoch=v.epoch WHERE '+where+' ORDER BY e.epoch LIMIT 30',tuple(args))
            # The current group membership and historic membership are both required.
            items=[]
            for row in rows:
                people=json.loads(row['members_json'])
                if u not in people:continue
                snap=snapshot(s,room,row['epoch'],people)
                if snap['ready']:items.append({'epoch':row['epoch'],'members':people})
            return web.json_response({'items':items,'next':rows[-1]['epoch'] if len(rows)==30 else None})
    async def history(r):
        u,s,room=access(r);rate(r,'group-history:'+u,120);epoch=ident(r.match_info['epoch'])
        with transaction(s.db):
            members(s,room,u)
            row=s.one('SELECT members_json FROM ratchet_group_epochs WHERE room=? AND epoch=?',(room,epoch))
            if not row or u not in json.loads(row['members_json']):raise web.HTTPNotFound()
            out=snapshot(s,room,epoch,json.loads(row['members_json']))
            if not out['ready']:raise web.HTTPNotFound()
            if r.match_info.get('part')=='messages':return web.json_response(read_packets(s,epoch,r.query.get('after')))
            return web.json_response(out)
    def upload_id(value):
        if not isinstance(value,str) or not re.fullmatch('[a-f0-9]{32}',value):raise ValueError()
        return value
    def ready_epoch(s,room,u):
        people=members(s,room,u);epoch=load(s,room,people)
        if not snapshot(s,room,epoch,people)['ready']:raise web.HTTPConflict(text='Tüm grup üyelerinin anahtar onayı gerekli.')
        return epoch
    async def create_file(r):
        u,s,room=access(r);rate(r,'group-upload:'+u,30);b=await body(r);exact(b,'id size epoch');uid=upload_id(b['id']);size=b['size']
        if type(size) is not int or not 17<=size<=50*1024*1024+16:raise ValueError()
        with transaction(s.db):
            epoch=ready_epoch(s,room,u)
            if b['epoch']!=epoch:raise web.HTTPConflict()
            link=s.one('SELECT * FROM ratchet_group_uploads WHERE upload_id=?',(uid,));f=s.one('SELECT * FROM uploads WHERE id=?',(uid,))
            if s.one('SELECT 1 FROM ratchet_pilot_media WHERE upload_id=?',(uid,)):raise web.HTTPConflict()
            if link or f:
                if not link or not f or link['epoch']!=epoch or link['deleted'] or f['owner']!=u or f['room']!=room or f['size']!=size:raise web.HTTPConflict()
                return web.json_response({'id':uid,'offset':f['received'],'complete':bool(f['complete'])})
            if s.one('SELECT count(*) n FROM uploads f JOIN ratchet_group_uploads g ON g.upload_id=f.id WHERE f.owner=? AND g.message_id IS NULL AND g.deleted=0',(u,))['n']>=8:raise web.HTTPTooManyRequests(text='Bekleyen grup dosyaları sınırı.')
            s.db.execute('INSERT INTO uploads(id,owner,room,size,created) VALUES(?,?,?,?,?)',(uid,u,room,size,ts()))
            s.db.execute('INSERT INTO ratchet_group_uploads(upload_id,epoch) VALUES(?,?)',(uid,epoch))
        return web.json_response({'id':uid,'offset':0,'complete':False},status=201)
    async def file_part(r):
        u,s,room=access(r);uid=upload_id(r.match_info['upload'])
        data=await r.read() if r.method=='PUT' else None
        auth(r) # Revalidate session after streaming the request body.
        if data is not None and not 0<len(data)<=1024*1024:raise ValueError()
        with transaction(s.db):
            members(s,room,u)
            f=s.one('SELECT f.*,g.epoch,g.message_id,g.deleted FROM uploads f JOIN ratchet_group_uploads g ON f.id=g.upload_id WHERE f.id=? AND f.room=?',(uid,room))
            if not f or f['owner']!=u:raise web.HTTPNotFound()
            if f['message_id'] or f['deleted']:raise web.HTTPConflict()
            path=s.dir/uid
            if r.method=='DELETE':
                s.db.execute('DELETE FROM ratchet_group_uploads WHERE upload_id=?',(uid,));s.db.execute('DELETE FROM uploads WHERE id=?',(uid,));path.unlink(missing_ok=True)
                return web.json_response({'ok':True})
            if f['epoch']!=ready_epoch(s,room,u):raise web.HTTPConflict()
            offset=int(r.headers.get('Upload-Offset','-1'))
            if offset!=f['received'] or f['complete'] or offset+len(data)>f['size']:raise web.HTTPConflict()
            with path.open('r+b' if path.exists() else 'wb') as fp:fp.seek(offset);fp.write(data)
            total=offset+len(data);done=total==f['size']
            s.db.execute('UPDATE uploads SET received=?,complete=? WHERE id=?',(total,int(done),uid))
        return web.json_response({'id':uid,'offset':total,'complete':done})
    async def file_read(r):
        u,s,room=access(r);epoch=ident(r.match_info['epoch']);mid=ident(r.match_info['mid']);uid=upload_id(r.match_info['upload'])
        with transaction(s.db):
            members(s,room,u)
            row=s.one('SELECT members_json FROM ratchet_group_epochs WHERE room=? AND epoch=?',(room,epoch))
            if not row or u not in json.loads(row['members_json']):raise web.HTTPNotFound()
            link=s.one('SELECT g.deleted,p.packet FROM ratchet_group_uploads g JOIN ratchet_group_packets p ON p.epoch=g.epoch AND p.id=g.message_id WHERE g.epoch=? AND g.message_id=? AND g.upload_id=?',(epoch,mid,uid))
            if not link:raise web.HTTPNotFound()
            sender=json.loads(link['packet'])['sender'];path=s.dir/uid
            if r.method=='DELETE':
                if sender!=u:raise web.HTTPForbidden()
                s.db.execute('UPDATE ratchet_group_uploads SET deleted=1 WHERE upload_id=?',(uid,));path.unlink(missing_ok=True);s.db.execute('DELETE FROM uploads WHERE id=?',(uid,));return web.json_response({'ok':True})
            if link['deleted']:raise web.HTTPGone()
            f=s.one('SELECT size FROM uploads WHERE id=? AND room=? AND owner=? AND complete=1',(uid,room,sender))
            if not f or not path.is_file() or path.stat().st_size!=f['size']:raise web.HTTPNotFound()
            return web.FileResponse(path,headers={'Content-Type':'application/octet-stream','Content-Disposition':'attachment','Cache-Control':'no-store'})
    async def messages(r):
        u,s,room=access(r)
        upload=None
        if r.method=='POST':
            rate(r,'group-packet:'+u,120);p=await body(r)
            if isinstance(p,dict) and 'packet' in p:
                exact(p,'packet upload');upload=upload_id(p['upload']);p=p['packet']
            exact(p,'room epoch roster sender id ephemeral iv data wraps sig');ident(p['id']);b64(p['ephemeral'],65);b64(p['iv'],12);b64(p['data'],17,16016);b64(p['sig'],64)
        with transaction(s.db):
            people=members(s,room,u);epoch=load(s,room,people);out=snapshot(s,room,epoch,people)
            if not out['ready']:raise web.HTTPConflict(text='Tüm grup üyelerinin anahtar onayı gerekli.')
            if r.method=='GET':
                return web.json_response(read_packets(s,epoch,r.query.get('after')))
            if p['room']!=room or p['epoch']!=epoch or p['roster']!=out['roster'] or p['sender']!=u:raise web.HTTPConflict(text='Geçersiz gönderici veya dönem.')
            if not isinstance(p['wraps'],list) or len(p['wraps'])!=len(people):raise ValueError()
            for expected,w in zip(people,p['wraps']):
                exact(w,'user iv data');b64(w['iv'],12);b64(w['data'],48)
                if w['user']!=expected:raise ValueError()
            encoded=json.dumps(p,sort_keys=True,separators=(',',':'))
            old=s.one('SELECT packet FROM ratchet_group_packets WHERE epoch=? AND id=?',(epoch,p['id']))
            if old:
                linked=s.one('SELECT upload_id FROM ratchet_group_uploads WHERE epoch=? AND message_id=?',(epoch,p['id']))
                if old['packet']!=encoded or (linked['upload_id'] if linked else None)!=upload:raise web.HTTPConflict()
                return web.json_response({'ok':True})
            if upload:
                f=s.one('SELECT f.*,g.epoch,g.message_id,g.deleted FROM uploads f JOIN ratchet_group_uploads g ON f.id=g.upload_id WHERE f.id=?',(upload,))
                if not f or f['epoch']!=epoch or f['room']!=room or f['owner']!=u or not f['complete'] or f['message_id'] or f['deleted']:raise web.HTTPForbidden()
            last=s.one('SELECT MAX(created) AS latest FROM ratchet_group_packets WHERE epoch=?',(epoch,))['latest']
            created=max(ts(),(last or 0)+1)
            s.db.execute('INSERT INTO ratchet_group_packets(epoch,id,packet,created) VALUES(?,?,?,?)',(epoch,p['id'],encoded,created))
            if upload:s.db.execute('UPDATE ratchet_group_uploads SET message_id=? WHERE upload_id=?',(p['id'],upload))
        return web.json_response({'ok':True},status=201)
    base='/api/rooms/{room}/ratchet-group-pilot'
    app.router.add_get(base,state);app.router.add_post(base,state)
    app.router.add_post(base+'/key',publish);app.router.add_post(base+'/approve',approve)
    app.router.add_get(base+'/messages',messages);app.router.add_post(base+'/messages',messages)
    app.router.add_get(base+'/history',history_epochs)
    app.router.add_get(base+'/history/{epoch}',history)
    app.router.add_get(base+'/history/{epoch}/{part:messages}',history)
    app.router.add_post(base+'/files',create_file)
    app.router.add_put(base+'/files/{upload}',file_part)
    app.router.add_delete(base+'/files/{upload}',file_part)
    app.router.add_get(base+'/history/{epoch}/messages/{mid}/media/{upload}',file_read)
    app.router.add_delete(base+'/history/{epoch}/messages/{mid}/media/{upload}',file_read)
