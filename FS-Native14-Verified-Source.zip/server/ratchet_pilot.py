"""Opt-in, two-party experimental ratchet transport. Never processes plaintext."""
import base64, json, re, time
from aiohttp import web
from database import transaction

def ts(): return int(time.time()*1000)
def ident(v):
    if not isinstance(v,str) or not re.fullmatch(r'[A-Za-z0-9_-]{10,64}',v): raise ValueError()
    return v
def b64(v,lo,hi=None):
    hi=lo if hi is None else hi
    if not isinstance(v,str) or len(v)>4*((hi+2)//3): raise ValueError()
    raw=base64.b64decode(v,validate=True)
    if not lo<=len(raw)<=hi or base64.b64encode(raw).decode()!=v: raise ValueError()
    return v
def exact(x,keys):
    if not isinstance(x,dict) or set(x)!=set(keys.split()): raise ValueError()
def offer(o,room,u,peer):
    exact(o,'v room from to nonce dh expires sig')
    if o['v']!=1 or o['room']!=room or o['from']!=u or o['to']!=peer or type(o['expires']) is not int or not ts()<o['expires']<=ts()+125000: raise ValueError()
    b64(o['nonce'],32);b64(o['dh'],65);b64(o['sig'],64)
def reply(r):
    exact(r,'v dh ratchet sig')
    if r['v']!=1: raise ValueError()
    b64(r['dh'],65);b64(r['ratchet'],65);b64(r['sig'],64)
def packet(p):
    exact(p,'v h iv data');exact(p['h'],'dh pn n')
    if p['v']!=1 or any(type(p['h'][k]) is not int or not 0<=p['h'][k]<2147483647 for k in ('pn','n')): raise ValueError()
    b64(p['h']['dh'],65);b64(p['iv'],12);b64(p['data'],16,65552)

def install(app,auth,body,blocked,rate):
    async def access(r):
        if not app['ratchet_pilot']: raise web.HTTPNotFound(text='Deneysel güvenli sohbet etkin değil.')
        u=auth(r);s=app['store'];room=r.match_info['room'];s.member(u,room)
        members=s.all('SELECT user FROM members WHERE room=?',(room,));kind=s.one('SELECT kind FROM rooms WHERE id=?',(room,))
        if not kind or kind['kind']!='direct' or len(members)!=2: raise web.HTTPForbidden(text='Yalnızca birebir sohbet.')
        peer=next(x['user'] for x in members if x['user']!=u)
        if blocked(s,u,peer): raise web.HTTPForbidden()
        return u,s,room,peer
    def row(s,room,sid):
        x=s.one('SELECT * FROM ratchet_pilot_sessions WHERE id=? AND room=?',(sid,room))
        if not x: raise web.HTTPNotFound()
        return dict(x)
    def expose(x):
        return {**x,'offer':json.loads(x['offer']),'reply':json.loads(x['reply']) if x['reply'] else None}
    async def sessions(r):
        u,s,room,peer=await access(r)
        if r.method=='GET':
            args=[room,ts()]; where='room=? AND (reply IS NOT NULL OR expires>?)'
            before=r.query.get('before')
            if before is not None:
                anchor=row(s,room,ident(before));where+=' AND (created<? OR (created=? AND id<?))';args.extend([anchor['created'],anchor['created'],anchor['id']])
            return web.json_response([expose(x) for x in s.all('SELECT * FROM ratchet_pilot_sessions WHERE '+where+' ORDER BY created DESC,id DESC LIMIT 30',tuple(args))])
        b=await body(r);rate(r,'ratchet-offer:'+u,12);exact(b,'id offer signing');sid=ident(b['id']);offer(b['offer'],room,u,peer);b64(b['signing'],65)
        if sid!=b['offer']['nonce'].replace('+','-').replace('/','_').rstrip('='): raise ValueError()
        with transaction(s.db):
            from ratchet_cutover import lock_room
            lock_room(s,room)
            if s.one('SELECT count(*) n FROM ratchet_pilot_sessions WHERE room=? AND reply IS NULL AND expires>?',(room,ts()))['n']>=30: raise web.HTTPConflict(text='Bekleyen teklif sınırı.')
            s.db.execute('DELETE FROM ratchet_pilot_sessions WHERE room=? AND reply IS NULL AND expires<=?',(room,ts()))
            if s.one('SELECT 1 FROM ratchet_pilot_sessions WHERE id=?',(sid,)): raise web.HTTPConflict()
            s.db.execute('INSERT INTO ratchet_pilot_sessions VALUES(?,?,?,?,?,?,?,?,?,?)',(sid,room,u,peer,json.dumps(b['offer']),b['signing'],None,None,b['offer']['expires'],ts()))
        return web.json_response(expose(row(s,room,sid)),status=201)
    def prekey(b,room,owner,peer):
        exact(b,'v room owner peer id dh signing expires sig')
        if b['v']!=1 or b['room']!=room or b['owner']!=owner or b['peer']!=peer or not re.fullmatch(r'[a-f0-9]{32}',ident(b['id'])) or type(b['expires']) is not int or not ts()<b['expires']<=ts()+7*86400000+60000: raise ValueError()
        b64(b['dh'],65);b64(b['signing'],65);b64(b['sig'],64)
    async def prekeys(r):
        u,s,room,peer=await access(r)
        if r.method=='GET':
            x=s.one('SELECT bundle FROM ratchet_prekeys WHERE room=? AND owner=? AND used_by IS NULL AND expires>? ORDER BY expires DESC LIMIT 1',(room,peer,ts()))
            return web.json_response(json.loads(x['bundle']) if x else None)
        b=await body(r);rate(r,'prekey:'+u,12);prekey(b,room,u,peer)
        with transaction(s.db):
            from ratchet_cutover import lock_room
            lock_room(s,room)
            old=s.one('SELECT bundle FROM ratchet_prekeys WHERE id=?',(b['id'],))
            if old:
                if json.loads(old['bundle'])!=b: raise web.HTTPConflict()
                return web.json_response({'ok':True})
            s.db.execute('DELETE FROM ratchet_prekeys WHERE room=? AND owner=? AND expires<=?',(room,u,ts()))
            if s.one('SELECT count(*) n FROM ratchet_prekeys WHERE room=? AND owner=? AND used_by IS NULL',(room,u))['n']>=30: raise web.HTTPConflict(text='Ön anahtar sınırı.')
            s.db.execute('INSERT INTO ratchet_prekeys VALUES(?,?,?,?,?,NULL)',(b['id'],room,u,json.dumps(b),b['expires']))
        return web.json_response({'ok':True},status=201)
    async def own_prekeys(r):
        u,s,room,peer=await access(r)
        rows=s.all('SELECT id,expires,used_by FROM ratchet_prekeys WHERE room=? AND owner=? AND used_by IS NULL AND expires>? ORDER BY expires DESC',(room,u,ts()))
        return web.json_response([dict(x) for x in rows])
    async def offline(r):
        u,s,room,peer=await access(r);o=await body(r);rate(r,'offline:'+u,12)
        exact(o,'v id from to dh signing bundle sig');sid=ident(o['id']);b=o['bundle']
        if o['v']!=2 or o['from']!=u or o['to']!=peer or not re.fullmatch(r'[a-f0-9]{32}',sid): raise ValueError()
        b64(o['dh'],65);b64(o['signing'],65);b64(o['sig'],64)
        with transaction(s.db):
            existing=s.one('SELECT * FROM ratchet_pilot_sessions WHERE id=? AND room=?',(sid,room))
            if existing:
                if existing['initiator']!=u or json.loads(existing['offer'])!=o: raise web.HTTPConflict()
                return web.json_response(expose(existing))
            prekey(b,room,peer,u)
            key=s.one('SELECT * FROM ratchet_prekeys WHERE id=? AND room=? AND owner=?',(b['id'],room,peer))
            if not key or json.loads(key['bundle'])!=b: raise web.HTTPConflict(text='Ön anahtar mevcut değil.')
            cur=s.db.execute('UPDATE ratchet_prekeys SET used_by=? WHERE id=? AND room=? AND owner=? AND used_by IS NULL AND expires>?',(sid,b['id'],room,peer,ts()))
            if cur.rowcount!=1: raise web.HTTPConflict(text='Ön anahtar kullanıldı.')
            s.db.execute('INSERT INTO ratchet_pilot_sessions VALUES(?,?,?,?,?,?,?,?,?,?)',(sid,room,u,peer,json.dumps(o),o['signing'],json.dumps({'v':2}),b['signing'],b['expires'],ts()))
        return web.json_response(expose(row(s,room,sid)),status=201)
    async def session_detail(r):
        u,s,room,peer=await access(r);return web.json_response(expose(row(s,room,ident(r.match_info['sid']))))
    async def respond(r):
        u,s,room,peer=await access(r);sid=ident(r.match_info['sid']);x=row(s,room,sid)
        if x['recipient']!=u: raise web.HTTPForbidden()
        b=await body(r);rate(r,'ratchet-reply:'+u,20);exact(b,'reply signing');reply(b['reply']);b64(b['signing'],65)
        if x['reply']:
            if json.loads(x['reply'])==b['reply'] and x['responder_signing']==b['signing']: return web.json_response(expose(x))
            raise web.HTTPConflict()
        if x['expires']<=ts(): raise web.HTTPConflict(text='Teklif süresi doldu.')
        cur=s.run('UPDATE ratchet_pilot_sessions SET reply=?,responder_signing=? WHERE id=? AND room=? AND reply IS NULL AND expires>?',(json.dumps(b['reply']),b['signing'],sid,room,ts()))
        if cur.rowcount!=1: raise web.HTTPConflict()
        return web.json_response(expose(row(s,room,sid)))
    async def messages(r):
        u,s,room,peer=await access(r);sid=ident(r.match_info['sid']);x=row(s,room,sid)
        if not x['reply']: raise web.HTTPConflict(text='Oturum henüz hazır değil.')
        if r.method=='GET':
            # Pilot cap bounds bandwidth and missed-message recovery. No plaintext or admin envelope.
            rows=s.all('SELECT m.id,m.sender,m.packet,m.created,f.upload_id,f.deleted AS media_deleted FROM ratchet_pilot_messages m LEFT JOIN ratchet_pilot_media f ON f.session_id=m.session_id AND f.message_id=m.id WHERE m.session_id=? ORDER BY m.created,m.id',(sid,))
            return web.json_response([{**x,'packet':json.loads(x['packet'])} for x in rows])
        b=await body(r);rate(r,'ratchet-send:'+u,120);exact(b,'id packet upload' if 'upload' in b else 'id packet');mid=ident(b['id']);upload=ident(b['upload']) if 'upload' in b else None;packet(b['packet']);encoded=json.dumps(b['packet'],sort_keys=True,separators=(',',':'))
        with transaction(s.db):
            from ratchet_cutover import lock_room, active
            lock_room(s,room)
            old=s.one('SELECT sender,packet FROM ratchet_pilot_messages WHERE session_id=? AND id=?',(sid,mid))
            if old:
                linked=s.one('SELECT upload_id FROM ratchet_pilot_media WHERE session_id=? AND message_id=?',(sid,mid))
                if old['sender']!=u or old['packet']!=encoded or (linked['upload_id'] if linked else None)!=upload: raise web.HTTPConflict(text='Mesaj kimliği çakıştı.')
                return web.json_response({'id':mid,'ok':True})
            selected=active(s,room)
            if selected and selected['session_id']!=sid:raise web.HTTPConflict(text='Bu oturum etkin değil; yeni oturumu doğrulayın.')
            if s.one('SELECT count(*) n FROM ratchet_pilot_messages WHERE session_id=?',(sid,))['n']>=100: raise web.HTTPConflict(text='Deneysel oturum mesaj sınırı.')
            if upload:
                f=s.one('SELECT owner,room,complete FROM uploads WHERE id=?',(upload,))
                if not f or f['owner']!=u or f['room']!=room or not f['complete']: raise web.HTTPForbidden(text='Dosya bu mesaja ait değil.')
                if s.one('SELECT 1 FROM ratchet_pilot_media WHERE upload_id=?',(upload,)) or s.one('SELECT 1 FROM ratchet_group_uploads WHERE upload_id=?',(upload,)) or s.one('SELECT 1 FROM message_uploads WHERE upload=?',(upload,)): raise web.HTTPConflict(text='Dosya başka bir mesaja bağlı.')
            s.db.execute('INSERT INTO ratchet_pilot_messages VALUES(?,?,?,?,?)',(sid,mid,u,encoded,ts()))
            if upload:s.db.execute('INSERT INTO ratchet_pilot_media(session_id,message_id,upload_id) VALUES(?,?,?)',(sid,mid,upload))
        return web.json_response({'id':mid,'ok':True},status=201)
    async def media(r):
        u,s,room,peer=await access(r);sid=ident(r.match_info['sid']);row(s,room,sid);mid=ident(r.match_info['mid']);upload=ident(r.match_info['upload'])
        f=s.one('SELECT m.sender,f.deleted FROM ratchet_pilot_media f JOIN ratchet_pilot_messages m ON m.session_id=f.session_id AND m.id=f.message_id WHERE f.session_id=? AND f.message_id=? AND f.upload_id=?',(sid,mid,upload))
        if not f:raise web.HTTPNotFound()
        path=s.dir/upload
        if r.method=='DELETE':
            if f['sender']!=u:raise web.HTTPForbidden()
            # Deny new reads before unlinking. Repeat DELETE can finish interrupted cleanup.
            s.run('UPDATE ratchet_pilot_media SET deleted=1 WHERE session_id=? AND message_id=?',(sid,mid))
            path.unlink(missing_ok=True)
            s.run('DELETE FROM uploads WHERE id=? AND owner=? AND room=?',(upload,u,room))
            return web.json_response({'ok':True})
        if f['deleted']:raise web.HTTPGone()
        item=s.one('SELECT size FROM uploads WHERE id=? AND owner=? AND room=? AND complete=1',(upload,f['sender'],room))
        if not item or not path.is_file() or path.stat().st_size!=item['size']:raise web.HTTPNotFound()
        return web.FileResponse(path,headers={'Content-Type':'application/octet-stream','Content-Disposition':'attachment','Cache-Control':'no-store'})
    base='/api/rooms/{room}/ratchet-pilot'
    app.router.add_get(base,sessions);app.router.add_post(base,sessions)
    app.router.add_get(base+'/prekeys',prekeys);app.router.add_post(base+'/prekeys',prekeys)
    app.router.add_get(base+'/prekeys/own',own_prekeys)
    app.router.add_post(base+'/offline',offline)
    app.router.add_get(base+'/{sid}',session_detail)
    app.router.add_post(base+'/{sid}/reply',respond)
    app.router.add_get(base+'/{sid}/messages',messages);app.router.add_post(base+'/{sid}/messages',messages)

    app.router.add_get(base+'/{sid}/messages/{mid}/media/{upload}',media)
    app.router.add_delete(base+'/{sid}/messages/{mid}/media/{upload}',media)
