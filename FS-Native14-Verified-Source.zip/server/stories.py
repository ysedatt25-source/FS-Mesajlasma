"""Expiring encrypted stories; only explicitly authorized recipient envelopes are served."""
import asyncio, base64, json, re
from aiohttp import web
from database import transaction

MAX_MEDIA = 8 * 1024 * 1024
TTL = 24 * 60 * 60 * 1000
DURATIONS = (6, 12, 24, 48)
HOUR = 60 * 60 * 1000
PENDING_TTL = 10 * 60 * 1000
MAX_AUDIENCE = 100
MAX_ACTIVE = 5


def sweep(s, now):
    s.run('DELETE FROM stories WHERE expires<=? OR (content IS NULL AND created<=?)', (now, now-PENDING_TTL))


def install(app, *, auth, body, blocked, public_user, public_key_matches, now, rate):
    def allowed(s, owner, recipient):
        return owner == recipient or (not blocked(s, owner, recipient) and bool(s.one('SELECT 1 FROM contacts WHERE owner=? AND peer=? AND deleted=0', (owner, recipient))))

    def access(request, owner_only=False, pending=False):
        u=auth(request);s=request.app['store'];ident=request.match_info['id']
        row=s.one('SELECT id,owner,sender_pub,created,expires,size,content IS NOT NULL AS ready FROM stories WHERE id=? AND expires>?', (ident,now()))
        if not row or (not row['ready'] and (not pending or row['created']<=now()-PENDING_TTL)) or (owner_only and row['owner']!=u) or not allowed(s,row['owner'],u):raise web.HTTPNotFound()
        recipient=s.one('SELECT envelope,recipient_pub,viewed FROM story_recipients WHERE story=? AND recipient=?',(ident,u))
        if not recipient:raise web.HTTPNotFound()
        return s,u,row,recipient

    async def audience(request):
        u=auth(request);s=request.app['store'];rows=s.all('SELECT u.* FROM contacts c JOIN users u ON u.id=c.peer WHERE c.owner=? AND c.deleted=0 ORDER BY u.id LIMIT 101',(u,))
        return web.json_response([{**public_user(r,s),'close_friend':bool(s.one('SELECT 1 FROM story_close_friends WHERE owner=? AND peer=?',(u,r['id'])))} for r in rows if allowed(s,u,r['id'])])

    async def close_friends(request):
        u=auth(request);s=request.app['store'];rate(request,'story-close-friends:'+u,30);b=await body(request);peers=b.get('peers')
        if not isinstance(peers,list) or len(peers)>MAX_AUDIENCE or any(not isinstance(peer,str) or peer==u for peer in peers) or len(set(peers))!=len(peers):raise ValueError()
        if any(not allowed(s,u,peer) for peer in peers):raise web.HTTPForbidden(text='Yakın arkadaş listesinde yalnızca uygun kişiler olabilir.')
        with transaction(s.db):
            s.db.execute('DELETE FROM story_close_friends WHERE owner=?',(u,))
            s.db.executemany('INSERT INTO story_close_friends(owner,peer) VALUES(?,?)',[(u,p) for p in peers])
        return web.json_response({'peers':peers})

    async def collection(request):
        u=auth(request);s=request.app['store'];t=now()
        if request.method=='GET':
            rows=s.all('SELECT st.id,st.owner,st.sender_pub,st.created,st.expires,st.size,sr.viewed FROM stories st JOIN story_recipients sr ON sr.story=st.id WHERE sr.recipient=? AND st.expires>? AND st.content IS NOT NULL ORDER BY st.created DESC,st.id DESC LIMIT 200',(u,t))
            return web.json_response([{**{k:r[k] for k in ('id','created','expires','size','viewed')},'owner':public_user(s.one('SELECT * FROM users WHERE id=?',(r['owner'],)),s),'liked':bool(s.one('SELECT 1 FROM story_likes WHERE story=? AND recipient=?',(r['id'],u))),'muted':bool(s.one('SELECT 1 FROM story_mutes WHERE viewer=? AND author=?',(u,r['owner'])))} for r in rows if allowed(s,r['owner'],u)])
        rate(request,'story-create:'+u,12);b=await body(request);ident=b.get('id');size=b.get('size');packets=b.get('envelopes');keys=b.get('recipient_pubs')
        if not isinstance(ident,str) or not re.fullmatch(r'[a-f0-9]{32}',ident) or type(size) is not int or not 17<=size<=MAX_MEDIA+16 or not isinstance(packets,dict) or not isinstance(keys,dict) or set(keys)!=set(packets) or u not in keys or not 2<=len(keys)<=MAX_AUDIENCE+1:raise ValueError()
        hours=b.get('duration_hours',24)
        if type(hours) is not int or hours not in DURATIONS:raise ValueError()
        for recipient,packet in packets.items():
            if not isinstance(packet,dict) or set(packet)!={'iv','data'} or not isinstance(packet['iv'],str) or not isinstance(packet['data'],str) or len(packet['data'])>2048 or len(base64.b64decode(packet['iv'],validate=True))!=12 or len(base64.b64decode(packet['data'],validate=True))<17:raise ValueError()
            row=s.one('SELECT pub FROM users WHERE id=?',(recipient,))
            if not row or not allowed(s,u,recipient):raise web.HTTPForbidden(text='Hikâye alıcısına izin verilmiyor.')
            if not isinstance(keys[recipient],dict) or not public_key_matches(keys[recipient],json.loads(row['pub'])):raise web.HTTPConflict(text='Cihaz anahtarı değişti. Alıcıları yenileyin.')
        sweep(s,t)
        with transaction(s.db):
            if s.one('SELECT count(*) n FROM stories WHERE owner=?',(u,))['n']>=MAX_ACTIVE:raise web.HTTPTooManyRequests(text='En fazla 5 etkin hikâye paylaşabilirsiniz.')
            if s.one('SELECT 1 FROM stories WHERE id=?',(ident,)):raise web.HTTPConflict()
            s.db.execute('INSERT INTO stories(id,owner,sender_pub,created,expires,size) VALUES(?,?,?,?,?,?)',(ident,u,json.dumps(keys[u]),t,t+hours*HOUR,size))
            s.db.executemany('INSERT INTO story_recipients(story,recipient,envelope,recipient_pub) VALUES(?,?,?,?)',[(ident,r,json.dumps(packets[r]),json.dumps(keys[r])) for r in packets])
        return web.json_response({'id':ident,'duration_hours':hours},status=201)

    async def media(request):
        s,u,row,recipient=access(request,owner_only=request.method=='PUT',pending=request.method=='PUT')
        if request.method=='GET':
            content=s.one('SELECT content FROM stories WHERE id=?',(row['id'],))['content']
            return web.Response(body=bytes(content),content_type='application/octet-stream')
        if row['ready']:raise web.HTTPConflict()
        if request.content_length!=row['size']:raise web.HTTPBadRequest(text='Dosya boyutu eşleşmedi.')
        try:
            content=await asyncio.wait_for(request.content.readexactly(row['size']),timeout=45)
        except (asyncio.TimeoutError,asyncio.IncompleteReadError):raise web.HTTPBadRequest(text='Yükleme tamamlanamadı.')
        s,u,row,recipient=access(request,owner_only=True,pending=True)
        if row['ready']:raise web.HTTPConflict()
        with transaction(s.db):
            recipients=s.all('SELECT recipient,recipient_pub FROM story_recipients WHERE story=?',(row['id'],))
            for r in recipients:
                peer=s.one('SELECT pub FROM users WHERE id=?',(r['recipient'],))
                if not peer or not allowed(s,u,r['recipient']) or not public_key_matches(json.loads(r['recipient_pub']),json.loads(peer['pub'])):raise web.HTTPConflict(text='Alıcı veya cihaz anahtarı değişti.')
            s.db.execute('UPDATE stories SET content=?,expires=? WHERE id=? AND content IS NULL',(content,now()+row['expires']-row['created'],row['id']))
        for r in recipients:await s.emit(r['recipient'],{'type':'stories-changed-v1'})
        return web.json_response({'ok':True})

    async def detail(request):
        s,u,row,recipient=access(request,owner_only=request.method=='DELETE',pending=request.method=='DELETE')
        if request.method=='DELETE':
            recipients=s.all('SELECT recipient FROM story_recipients WHERE story=?',(row['id'],));s.run('DELETE FROM stories WHERE id=?',(row['id'],))
            for r in recipients:await s.emit(r['recipient'],{'type':'stories-changed-v1'})
            return web.json_response({'ok':True})
        return web.json_response({'id':row['id'],'owner':row['owner'],'sender_pub':json.loads(row['sender_pub']),'envelope':json.loads(recipient['envelope']),'size':row['size'],'expires':row['expires']})

    async def caption_edit(request):
        # Replace only recipient-encrypted metadata; do not change media, expiry or audience.
        s,u,row,recipient=access(request,owner_only=True)
        if request.method=='POST':
            rate(request,'story-caption:'+u,20);b=await body(request)
            s,u,row,recipient=access(request,owner_only=True)
        current=s.all('SELECT recipient,recipient_pub FROM story_recipients WHERE story=?',(row['id'],))
        keys={r['recipient']:json.loads(r['recipient_pub']) for r in current}
        for peer,key in keys.items():
            user=s.one('SELECT pub FROM users WHERE id=?',(peer,))
            if not user or not allowed(s,u,peer) or not public_key_matches(key,json.loads(user['pub'])):raise web.HTTPConflict(text='Alıcı veya cihaz anahtarı değişti. Erişim listesini kontrol edin.')
        expected=json.loads(recipient['envelope'])
        if request.method=='GET':
            return web.json_response({'id':row['id'],'owner':u,'sender_pub':json.loads(row['sender_pub']),'size':row['size'],'envelope':expected,'recipient_pubs':keys})
        packets=b.get('envelopes')
        if b.get('expected')!=expected or not isinstance(packets,dict) or set(packets)!=set(keys):raise web.HTTPConflict(text='Hikâye veya erişim listesi değişti. Yeniden açın.')
        for packet in packets.values():
            if not isinstance(packet,dict) or set(packet)!={'iv','data'} or not isinstance(packet['iv'],str) or not isinstance(packet['data'],str) or len(packet['data'])>2048 or len(base64.b64decode(packet['iv'],validate=True))!=12 or len(base64.b64decode(packet['data'],validate=True))<17:raise ValueError()
        with transaction(s.db):
            for peer,packet in packets.items():
                s.db.execute('UPDATE story_recipients SET envelope=? WHERE story=? AND recipient=?',(json.dumps(packet),row['id'],peer))
        for peer in keys:await s.emit(peer,{'type':'stories-changed-v1'})
        return web.json_response({'ok':True})

    async def view(request):
        s,u,row,_=access(request)
        if u!=row['owner']:s.run('UPDATE story_recipients SET viewed=? WHERE story=? AND recipient=? AND viewed IS NULL',(now(),row['id'],u))
        return web.json_response({'ok':True})

    async def viewers(request):
        s,u,row,_=access(request,owner_only=True)
        rows=s.all('SELECT recipient,viewed FROM story_recipients WHERE story=? AND recipient!=? AND viewed IS NOT NULL ORDER BY viewed DESC',(row['id'],u))
        return web.json_response([{'user':public_user(s.one('SELECT * FROM users WHERE id=?',(r['recipient'],)),s),'viewed':r['viewed'],'liked':bool(s.one('SELECT 1 FROM story_likes WHERE story=? AND recipient=?',(row['id'],r['recipient'])))} for r in rows])

    async def like(request):
        s,u,row,_=access(request);rate(request,'story-like:'+u,60);b=await body(request);s,u,row,_=access(request);liked=b.get('liked')
        if u==row['owner'] or type(liked) is not bool:raise ValueError()
        if liked and not s.one('SELECT 1 FROM story_recipients WHERE story=? AND recipient=? AND viewed IS NOT NULL',(row['id'],u)):raise web.HTTPConflict(text='Önce hikâyeyi görüntüleyin.')
        with transaction(s.db):
            s.db.execute('DELETE FROM story_likes WHERE story=? AND recipient=?',(row['id'],u))
            if liked:s.db.execute('INSERT INTO story_likes(story,recipient) VALUES(?,?)',(row['id'],u))
        return web.json_response({'liked':liked})

    async def mute(request):
        s,u,row,_=access(request);rate(request,'story-mute:'+u,30);b=await body(request);s,u,row,_=access(request);muted=b.get('muted');author=row['owner']
        if author==u or type(muted) is not bool:raise ValueError()
        with transaction(s.db):
            s.db.execute('DELETE FROM story_mutes WHERE viewer=? AND author=?',(u,author))
            if muted:s.db.execute('INSERT INTO story_mutes(viewer,author) VALUES(?,?)',(u,author))
        return web.json_response({'muted':muted})

    async def recipients(request):
        s,u,row,_=access(request,owner_only=True)
        if request.method=='POST':
            rate(request,'story-revoke:'+u,30);b=await body(request);s,u,row,_=access(request,owner_only=True)
        else:b=None
        current=[r['recipient'] for r in s.all('SELECT recipient FROM story_recipients WHERE story=? AND recipient!=?',(row['id'],u))]
        if request.method=='GET':
            return web.json_response([public_user(s.one('SELECT * FROM users WHERE id=?',(r,)),s) for r in current])
        remove=b.get('remove')
        if not isinstance(remove,list) or not remove or len(remove)>MAX_AUDIENCE or any(not isinstance(r,str) or r not in current for r in remove) or len(set(remove))!=len(remove):raise ValueError()
        with transaction(s.db):
            for r in remove:s.db.execute('DELETE FROM story_recipients WHERE story=? AND recipient=?',(row['id'],r))
        for r in remove:await s.emit(r,{'type':'stories-changed-v1'})
        return web.json_response({'ok':True})

    app.add_routes([web.get('/api/stories/audience',audience),web.post('/api/stories/close-friends',close_friends),web.get('/api/stories',collection),web.post('/api/stories',collection),web.get('/api/stories/{id}',detail),web.delete('/api/stories/{id}',detail),web.get('/api/stories/{id}/media',media),web.put('/api/stories/{id}/media',media),web.get('/api/stories/{id}/caption',caption_edit),web.post('/api/stories/{id}/caption',caption_edit),web.post('/api/stories/{id}/view',view),web.get('/api/stories/{id}/viewers',viewers),web.post('/api/stories/{id}/like',like),web.post('/api/stories/{id}/mute',mute),web.get('/api/stories/{id}/recipients',recipients),web.post('/api/stories/{id}/recipients',recipients)])
