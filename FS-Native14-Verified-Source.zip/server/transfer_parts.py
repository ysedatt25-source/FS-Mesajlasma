"""Durable ciphertext chunk writes. DB offset is committed only after disk flush."""
import os

class MissingPrefix(Exception):
    pass

def check_prefix(path, offset, complete=False):
    length=path.stat().st_size if path.is_file() else 0
    if length<offset or (complete and length!=offset):
        raise MissingPrefix('Stored file does not match the committed offset')

def write_chunk(path, offset, data):
    check_prefix(path,offset)
    created=not path.exists()
    with path.open('r+b' if not created else 'wb') as f:
        f.seek(offset)
        if f.write(data)!=len(data):
            raise OSError('Short file write')
        end=offset+len(data)
        # If a process died after writing but before committing the DB offset,
        # discard the uncommitted suffix rather than appending it twice.
        f.truncate(end)
        f.flush()
        os.fsync(f.fileno())
    if created and os.name=='posix':
        fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    return end
