"""Server-only TURN credential minting. Long-lived tokens never reach clients."""
import asyncio, os, re, time
from aiohttp import ClientSession, ClientTimeout, web

class TurnCredentials:
    def __init__(self):
        self.cache = {}
        self.lock = asyncio.Lock()

    async def fetch(self, key, token):
        url = f'https://rtc.live.cloudflare.com/v1/turn/keys/{key}/credentials/generate-ice-servers'
        async with ClientSession(timeout=ClientTimeout(total=12), trust_env=True) as session:
            async with session.post(url, headers={'Authorization': 'Bearer '+token}, json={'ttl':86400}) as response:
                if response.status != 201:
                    raise ValueError('TURN provider unavailable')
                body = await response.json()
        servers = body.get('iceServers')
        if not isinstance(servers,list) or not any(isinstance(s,dict) and s.get('username') and s.get('credential') and any(str(u).startswith(('turn:','turns:')) for u in ([s.get('urls')] if isinstance(s.get('urls'),str) else s.get('urls',[]))) for s in servers):
            raise ValueError('Invalid TURN credentials')
        return servers

    async def fetch_turnix(self, token):
        headers={'Authorization':'Bearer '+token}
        async with ClientSession(timeout=ClientTimeout(total=12), trust_env=True) as session:
            # Never enable relaying on a paid/overage-enabled subscription.
            async with session.get('https://turnix.io/api/v1/usage/current',headers=headers) as response:
                if response.status != 200: raise ValueError('TURN plan unavailable')
                usage=await response.json()
            self.validate_free_plan(usage)
            async with session.post('https://turnix.io/api/v1/credentials/ice',headers=headers,json={'ttl':3600}) as response:
                if response.status == 429: raise web.HTTPServiceUnavailable(text='Ücretsiz arama aktarım kotası doldu. Ücretli kullanıma geçilmedi.')
                if response.status != 200: raise ValueError('TURN provider unavailable')
                body=await response.json()
        servers=body.get('iceServers')
        if not isinstance(servers,list) or not any(isinstance(s,dict) and s.get('username') and s.get('credential') and any(str(u).startswith(('turn:','turns:')) for u in ([s.get('urls')] if isinstance(s.get('urls'),str) else s.get('urls',[]))) for s in servers):
            raise ValueError('Invalid TURN credentials')
        return servers

    @staticmethod
    def validate_free_plan(usage):
        if usage.get('current_plan','').upper() != 'FREE' or usage.get('is_overage_available') is not False:
            raise web.HTTPServiceUnavailable(text='Arama aktarımı yalnız ücretsiz ve aşım ücreti kapalı planda kullanılabilir.')
        used=usage.get('current_period_usage_gb');limit=usage.get('limit_before_avarage_gb')
        if not isinstance(used,(int,float)) or not isinstance(limit,(int,float)) or limit<=0 or used>=limit:
            raise web.HTTPServiceUnavailable(text='Ücretsiz arama aktarım kotası doldu veya doğrulanamadı. Ücretli kullanıma geçilmedi.')

    async def get(self,user):
        turnix_token=os.environ.get('TURNIX_API_TOKEN','')
        key=os.environ.get('FS_CF_TURN_KEY_ID',''); token=os.environ.get('FS_CF_TURN_API_TOKEN','')
        if turnix_token:
            # Credentials are issued per connection; quota and no-overage state are rechecked.
            try: return await self.fetch_turnix(turnix_token)
            except web.HTTPServiceUnavailable: raise
            except Exception:
                raise web.HTTPServiceUnavailable(text='Arama aktarım sunucusuna ulaşılamadı.') from None
        if not key and not token: return None
        if not re.fullmatch(r'[A-Za-z0-9_-]{8,128}',key) or not token:
            raise web.HTTPServiceUnavailable(text='Arama aktarım sunucusunun yapılandırması eksik.')
        async with self.lock:
            cached=self.cache.get(user)
            if cached and cached[0] > time.monotonic() and cached[1] == (key,token): return cached[2]
            try: servers=await self.fetch(key,token)
            except Exception:
                raise web.HTTPServiceUnavailable(text='Arama aktarım sunucusuna ulaşılamadı.') from None
            if len(self.cache)>=512: self.cache.pop(next(iter(self.cache)))
            self.cache[user]=(time.monotonic()+1800,(key,token),servers)
            return servers
