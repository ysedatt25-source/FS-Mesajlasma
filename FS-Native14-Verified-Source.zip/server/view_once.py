"""A single-use, direct-message ciphertext grant. Consumption precedes delivery."""

def private_upload(store, upload):
    return store.one('SELECT * FROM view_once_uploads WHERE upload=?',(upload,))

def private_message(store, message):
    return store.one('SELECT * FROM view_once_uploads WHERE message=?',(message,))

def claim(store, upload, message, recipient, timestamp):
    result=store.run('UPDATE view_once_uploads SET opened=? WHERE upload=? AND message=? AND recipient=? AND opened IS NULL',(timestamp,upload,message,recipient))
    return result.rowcount==1
