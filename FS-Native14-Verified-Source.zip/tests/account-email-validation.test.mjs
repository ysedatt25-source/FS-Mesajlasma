import test from 'node:test';
import assert from 'node:assert/strict';
import {accountIssues} from '../web/feedback.js';
const valid={name:'Test',nick:'test_user',phone:'05421234567',email:'test@example.com',invite:'0032',privacy:'on',password:'123456',passwordConfirm:'123456'};
test('valid registration',()=>assert.deepEqual(accountIssues(valid,true),[]));
test('email required and malformed rejected',()=>{for(const email of ['', 'bad','a@b'])assert(accountIssues({...valid,email},true).some(x=>x.field==='email'));});
test('password confirmation',()=>assert(accountIssues({...valid,passwordConfirm:'wrong'},true).some(x=>x.field==='passwordConfirm')));
test('legacy login unchanged',()=>assert.deepEqual(accountIssues({login:'alice',password:'123456'},false),[]));
