import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {createRefreshBatch} from '../web/refresh-batch.js';
import {createAccessGate} from '../web/access-gate.js';
const src=fs.readFileSync(new URL('../web/app.js',import.meta.url),'utf8');
const take=(a,b)=>src.slice(src.indexOf(a),src.indexOf(b,src.indexOf(a)));
const guard=take('function assertAccess()','const state =');
const keyCode=take('async function keyFor(peer)','async function envelopes(');
const decodeCode=take('async function openMessagePayload(','const ratchetMaintenance=');
const sendCode=take('async function send(payload','const quickReactions');
const refreshCode=take('let roomRefreshQueue','function shell(');
function delayed(){let release;const promise=new Promise(r=>release=r);return {promise,release};}
async function context(inject={}){
 const access=createAccessGate(async()=>true);await access.submit('123456',true);
 const state={user:{id:'me'},token:'session',room:{id:'r'},rooms:[{id:'r',members:[{id:'me'},{id:'peer',pub:{}}]}],identity:{pair:{privateKey:{}}},keys:new Map(),cache:new Map(),messages:[],reply:null,page:'home'};
 const c={createRefreshBatch,apiRoot:'https://test.invalid',access,state,isLocked:()=>access.locked,DOMException,crypto:{randomUUID:()=> 'test-message'},navigator:{onLine:true},localState:{outbox:[]},validatePayload:p=>p,keyFor:async()=>({}),persistLocal:()=>Promise.resolve(),...inject};vm.createContext(c);vm.runInContext(guard,c);return c;
}
async function relock(c){c.access.lock();c.state.keys.clear();c.state.cache.clear();await c.access.submit('123456',true);}
test('pending key derivation cannot repopulate cache after a new unlock',async()=>{const d=delayed(),c=await context({peerKey:()=>d.promise});vm.runInContext(keyCode,c);const pending=c.keyFor({id:'peer',pub:{}});await relock(c);d.release({fakeKey:true});await assert.rejects(pending,{name:'AbortError'});assert.equal(c.state.keys.size,0);});
test('pending decrypt cannot repopulate plaintext cache after re-unlock',async()=>{const d=delayed(),c=await context({open:()=>d.promise});vm.runInContext(decodeCode,c);const pending=c.decode({id:'m',room:'r',sender:'peer',envelope:{}});await relock(c);d.release({type:'text',text:'secret'});await assert.rejects(pending,{name:'AbortError'});assert.equal(c.state.cache.size,0);});
test('message encryption initiated before lock cannot send using a later unlocked session',async()=>{const d=delayed();let posts=0;const c=await context({envelopes:()=>d.promise,api:async()=>{posts++;return {id:'m'}}});vm.runInContext(sendCode,c);const pending=c.send({type:'text',text:'old session'});await relock(c);d.release({peer:{}});await assert.rejects(pending,{name:'AbortError'});assert.equal(posts,0);assert.equal(c.state.cache.size,0);});
test('response from earlier session cannot update rooms after a new unlock',async()=>{const d=delayed(),c=await context({api:()=>d.promise,decode:async x=>x});vm.runInContext(refreshCode,c);const pending=c.refreshRoomsNow();await relock(c);c.state.rooms=[{id:'fresh'}];d.release([{id:'stale'}]);await assert.rejects(pending,{name:'AbortError'});assert.equal(c.state.rooms[0].id,'fresh');});
test('queued room refresh is discarded when its originating session changes',async()=>{let calls=0;const c=await context({api:async()=>{calls++;return []}});vm.runInContext(refreshCode,c);const pending=c.refreshRooms();c.access.lock();await pending;assert.equal(calls,0);});
