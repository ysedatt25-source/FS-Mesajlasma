import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
const src=readFileSync(new URL('../web/app.js',import.meta.url),'utf8');
const slice=(a,b)=>src.slice(src.indexOf(a),src.indexOf(b,src.indexOf(a)));
const tick=()=>new Promise(resolve=>setImmediate(resolve));
function deferred(){let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return {promise,resolve,reject};}
function harness(kind){
 const old={id:'old',room:'r',created:10},next={id:'next',room:'r',created:1,payload:{type:'file'}};
 const state={page:kind==='history'?'chat':'media',room:{id:'r'},routeVersion:1,token:'t',user:{id:'u'},messages:[old],media:[],hasOlder:true};
 const access={epoch:1,valid(e){return this.epoch===e&&!locked}};let locked=false;
 const query={oninput(){events.draw++}},button={disabled:false},gallery={isConnected:true},status={},more={disabled:false};
 const elements={'#chat-query':query,'#gallery':gallery,'#media-status':status,'#media-more':more};let currentButton=button;
 const modal={open:true,contains:b=>b===currentButton,querySelector:()=>currentButton};
 const request=deferred(),decoded=deferred(),events={api:0,decode:0,render:0,draw:0};
 const context=vm.createContext({state,access,isLocked:()=>locked,apiRoot:'https://test.invalid',modal,$:k=>elements[k],api:()=>{events.api++;return request.promise},decode:()=>{events.decode++;return decoded.promise},upsertMessages:(a,b)=>[...a,...b],renderMessages:()=>events.render++,renderGallery:()=>events.render++,mediaEpoch:1,mediaLoading:false,mediaHasMore:true,mediaCursor:'',mediaRoomScope:null});
 vm.runInContext(kind==='history'?slice('async function searchHistory(){','\nfunction restoreAudio()'):slice('async function loadMediaPage(){','\nfunction filteredMedia()'),context);
 return {state,access,context,events,request,decoded,next,old,query,button,more,elements,modal,lock(){locked=true;access.epoch++},replaceDialog(){currentButton={disabled:false};elements['#chat-query']={oninput(){throw Error('stale dialog redraw')}}},start(){return kind==='history'?context.searchHistory():context.loadMediaPage()}};
}
test('history search commits only to current dialog and room',async()=>{const h=harness('history'),p=h.start();h.request.resolve([h.next]);await tick();h.decoded.resolve(h.next);await p;assert.equal(h.state.messages.length,2);assert.equal(h.events.render,1);assert.equal(h.events.draw,1);assert.equal(h.button.disabled,false);});
test('history route changes while decrypting do not insert old chat messages',async()=>{const h=harness('history'),p=h.start();h.request.resolve([h.next]);await tick();h.state.room={id:'other'};h.state.routeVersion++;h.state.messages=[];h.decoded.resolve(h.next);await p;assert.equal(h.state.messages.length,0);assert.equal(h.events.render,0);});
test('reopened same-room search never updates the replacement dialog',async()=>{const h=harness('history'),p=h.start();h.request.resolve([h.next]);await tick();h.replaceDialog();h.decoded.resolve(h.next);await p;assert.equal(h.state.messages.length,1);assert.equal(h.events.draw,0);});
test('PIN lock before history response prevents decryption and ignores obsolete errors',async()=>{const h=harness('history'),p=h.start();h.lock();h.request.resolve([h.next]);await p;assert.equal(h.events.decode,0);assert.equal(h.events.render,0);});
test('foreign-room history response rejected before decrypting',async()=>{const h=harness('history'),p=h.start();h.request.resolve([{...h.next,room:'foreign'}]);await assert.rejects(p,/eşleşmiyor/);assert.equal(h.events.decode,0);assert.equal(h.button.disabled,false);});
test('current media request updates current gallery and cursor',async()=>{const h=harness('media'),p=h.start();h.request.resolve([h.next]);await tick();h.decoded.resolve(h.next);await p;assert.equal(h.state.media.length,1);assert.equal(h.events.render,1);assert.equal(h.more.disabled,false);assert.match(h.context.mediaCursor,/before_id=next/);});
test('PIN lock before media response prevents decryption',async()=>{const h=harness('media'),p=h.start();h.lock();h.request.resolve([h.next]);await p;assert.equal(h.events.decode,0);assert.equal(h.events.render,0);});
test('old media response cannot replace reopened gallery or unlock its busy flag',async()=>{const h=harness('media'),p=h.start();h.request.resolve([h.next]);await tick();h.context.mediaEpoch++;h.elements['#gallery']={isConnected:true};h.elements['#media-more']={disabled:true};h.decoded.resolve(h.next);await p;assert.equal(h.state.media.length,0);assert.equal(h.events.render,0);assert.equal(h.context.mediaLoading,true);assert.equal(h.elements['#media-more'].disabled,true);});
test('obsolete media errors cannot change a replacement gallery',async()=>{const h=harness('media'),p=h.start();h.context.mediaEpoch++;h.elements['#media-status']={textContent:'new'};h.request.reject(Error('old'));await p;assert.equal(h.elements['#media-status'].textContent,'new');});

test('peer media never decrypts other room rows',async()=>{const h=harness('media');h.context.mediaRoomScope='r';const p=h.start();h.request.resolve([{...h.next,id:'foreign',room:'other'},h.next]);await tick();assert.equal(h.events.decode,1);h.decoded.resolve(h.next);await p;assert.equal(h.state.media.length,1);assert.equal(h.state.media[0].room,'r');});
