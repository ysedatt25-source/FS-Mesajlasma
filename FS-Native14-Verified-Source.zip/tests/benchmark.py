"""Local API + WebSocket latency only; not a physical-phone benchmark."""
import asyncio, base64, json, statistics, sys, tempfile, time
from pathlib import Path
from aiohttp.test_utils import TestClient,TestServer
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from app import create_app
async def main():
 with tempfile.TemporaryDirectory() as d:
  client=TestClient(TestServer(create_app(d)));await client.start_server()
  try:
   users=[]
   for i in range(2):
    response=await client.post('/api/session',json={'register':True,'privacy_accepted':True,'name':'Benchmark','nick':'benchmark'+str(i),'phone':'+90500000000'+str(i),'password':'benchmark-private-password','invite':'0032','pub':{'kty':'EC','crv':'P-256','x':'benchmark-x','y':'benchmark-y'}});users.append(await response.json())
   headers={'Authorization':'Bearer '+users[0]['token']}
   response=await client.post('/api/rooms',headers=headers,json={'members':[users[1]['user']['id']]});room=(await response.json())['id']
   ws=await client.ws_connect('/api/socket');await ws.send_json({'token':users[1]['token']});await ws.receive_json()
   envelope={'iv':base64.b64encode(b'123456789012').decode(),'data':base64.b64encode(b'ciphertext'*20).decode()};envelopes={u['user']['id']:envelope for u in users};samples=[]
   for i in range(100):
    begin=time.perf_counter();response=await client.post('/api/rooms/'+room+'/messages',headers=headers,json={'id':'benchmark_message_'+str(i),'envelopes':envelopes});await response.read();assert response.status==201
    event=await ws.receive_json(timeout=2);assert event['id']=='benchmark_message_'+str(i);samples.append((time.perf_counter()-begin)*1000)
   result={'scope':'Local loopback HTTP persistence + peer WebSocket event; simulated ciphertext, no phone, no WAN, no WhatsApp comparison','samples':len(samples),'p50_ms':round(statistics.median(samples),3),'p95_ms':round(sorted(samples)[94],3),'max_ms':round(max(samples),3)}
   output=Path(__file__).resolve().parents[1]/'build/test-evidence';output.mkdir(parents=True,exist_ok=True);(output/'benchmark.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));await ws.close()
  finally:await client.close()
if __name__=='__main__':asyncio.run(main())
