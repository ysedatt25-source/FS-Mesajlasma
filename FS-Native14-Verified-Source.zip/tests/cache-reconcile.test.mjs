import test from 'node:test';
import assert from 'node:assert/strict';
import {missingCachedMessages} from '../web/message-state.js';
const m=(id,props={})=>({id,room:'room',...props});
test('offline deletion reconciles old acknowledged messages without removing valid history',async()=>{
 const old=[m('old_message_111'),m('old_message_222'),m('new_message_333'),m('pending_444',{pending:true}),m('call_record_55',{callRecord:true}),m('other_room_66',{room:'other'})];
 const lost=await missingCachedMessages(old,[m('new_message_333')],'room',async ids=>{assert.deepEqual(ids,['old_message_111','old_message_222']);return {existing:['old_message_222']}});
 assert.deepEqual(lost,['old_message_111']);
});
test('batch size is bounded and large caches are checked in order',async()=>{
 const old=Array.from({length:401},(_,i)=>m('message_id_'+i));let lengths=[];
 const lost=await missingCachedMessages(old,[],'room',async ids=>{lengths.push(ids.length);return {existing:ids}});assert.deepEqual(lengths,[200,200,1]);assert.deepEqual(lost,[]);
});
test('server error or foreign IDs cannot be treated as deletion',async()=>{
 for(const response of [{},{existing:['foreign_id_111']}])await assert.rejects(missingCachedMessages([m('message_id_111')],[],'room',async()=>response));
});
test('lock or conversation change invalidates an outstanding check',async()=>{
 let live=true;const lost=await missingCachedMessages([m('message_id_111')],[],'room',async()=>{live=false;return {existing:[]}},()=>live);assert.deepEqual(lost,[]);
});
