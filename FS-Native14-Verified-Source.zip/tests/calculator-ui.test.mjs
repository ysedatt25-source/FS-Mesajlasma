import test from 'node:test';
import assert from 'node:assert/strict';
import {Window} from 'happy-dom';
import {mountCalculator,formatCalculation} from '../web/calculator-ui.js';
const window=new Window({url:'https://appassets.androidplatform.net/calculator-window.html'});
globalThis.document=window.document;globalThis.localStorage=window.localStorage;
// The emulator cannot generate browser-trusted events. Exercise the handler's
// trusted-input branch using an explicit unit-test fixture, never an override
// of the application or of Event.isTrusted. The Chromium suite independently
// tests genuine pointer input and rejection of synthetic DOM events.
function fixture(options={}){
 const root=document.createElement('div');document.body.replaceChildren(root);
 const view=mountCalculator(root,options);
 return {root,view,click:k=>{const target=root.querySelector(`[data-calc="${k}"]`);assert(target,k);return root.querySelector('.android-calculator').onclick({target,isTrusted:true})},synthetic:k=>root.querySelector(`[data-calc="${k}"]`).click()};
}
async function keys(f,seq){for(const k of seq)await f.click(k)}
const display=f=>f.root.querySelector('.display').textContent;
test('Turkish grouped result and decimal separator',()=>{assert.equal(formatCalculation(2025),'2.025');assert.equal(formatCalculation(12345.75),'12.345,75');assert.equal(formatCalculation(-2025),'-2.025')});
test('Reference live preview changes into grouped answer after equals',async()=>{const f=fixture();await keys(f,['4','5','×','4','5']);assert.equal(f.root.querySelector('#calc-preview').textContent,'2.025');assert.equal(display(f),'45×45');await f.click('=');assert.equal(display(f),'2.025');assert.equal(f.root.querySelector('#calc-expression').textContent,'45×45')});
test('Scientific grid matches reference, degree/radian and inverse calculate',async()=>{const f=fixture();f.root.querySelector('#calc-science').click();assert.deepEqual([...f.root.querySelectorAll('[data-calc]')].slice(0,15).map(x=>x.dataset.calc),['sin','cos','tan','rad','deg','log','ln','(',')','inv','!','AC','%','⌫','÷']);assert.equal(f.root.querySelectorAll('[data-calc]').length,35);await keys(f,['sin','3','0',')','=']);assert.equal(display(f),'0,5');await keys(f,['AC','inv','sin','0',',','5',')','=']);assert.equal(display(f),'30');await keys(f,['AC','rad','inv','sin','π','÷','2',')','=']);assert.equal(display(f),'1')});
test('Floating calculator cannot unlock chat; fullscreen/minimize/close pass state',async()=>{let checks=0;const actions=[];const f=fixture({floating:true,checkPin:async()=>{checks++;return true},onUnlock:()=>assert.fail('overlay opened chat'),windowAction:(...a)=>actions.push(a)});await keys(f,[...'123456','=']);assert.equal(checks,0);assert.equal(display(f),'123.456');for(const [index,action] of ['fullscreen','minimize','close'].entries()){f.root.querySelector('#calc-menu').click();const buttons=[...f.root.querySelectorAll('.calc-popup .row')];assert.deepEqual(buttons.map(b=>b.textContent),['Tam ekran','Küçült','Kapat']);buttons[index].click();assert.equal(actions[index][0],action);assert.equal(JSON.parse(actions[index][1]).input,'123456')}});
test('Calculator transfers arithmetic but never transfers unsubmitted numeric PIN candidates; rejects injected content',async()=>{const a=fixture();await keys(a,['4','5']);assert.equal(display(a),'45');assert.equal(JSON.parse(a.view.snapshot()).input,'');await keys(a,['+','2']);const state=a.view.snapshot();const b=fixture();b.view.restore(state);assert.equal(display(b),'45+2');b.view.restore({input:'<img src=x onerror=alert(1)>'});assert.equal(b.root.querySelector('img'),null);assert.equal(display(b),'45+2');await b.click('=');assert.equal(display(b),'47')});
test('Synthetic DOM key events cannot enter a PIN or invoke its verifier',async()=>{let checks=0,unlocks=0;const f=fixture({checkPin:async()=>{checks++;return true},onUnlock:async()=>{unlocks++}});for(const k of '123456=')f.synthetic(k);assert.equal(display(f),'');assert.equal(checks,0);await keys(f,[...'123456']);f.synthetic('=');assert.equal(checks,0);assert.equal(unlocks,0);await f.click('=');assert.equal(checks,1);assert.equal(unlocks,1)});
