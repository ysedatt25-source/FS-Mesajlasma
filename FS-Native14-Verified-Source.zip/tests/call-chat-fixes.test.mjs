import test from 'node:test';
import assert from 'node:assert/strict';
import {pipPosition,urlParts,mapUrls,effectiveStatus,applyAlertReceipt} from '../web/call-chat-fixes.js';
test('PIP remains in all corners after keyboard viewport shrinks',()=>{for(const h of [480,160,80,0])for(const x of [-1,0,.5,1,2])for(const y of [-1,0,.5,1,2]){const b={left:4,top:90,width:352,height:h};const size={width:Math.min(96,b.width),height:Math.min(128,h)};const p=pipPosition(b,size,{x,y});assert(p.left>=b.left&&p.left+size.width<=b.left+b.width);assert(p.top>=b.top&&p.top+size.height<=b.top+b.height)}});
test('links preserve original text and recognize https/http/www',()=>{const text='Bak https://example.org/a?q=1&b=2, www.example.com. (http://example.net/a(b)).';const parts=urlParts(text);assert.equal(parts.map(x=>x.text).join(''),text);assert.deepEqual(parts.filter(x=>x.url).map(x=>x.url),['https://example.org/a?q=1&b=2','https://www.example.com/','http://example.net/a(b)']);});
test('unsafe schemes and credential URLs not clickable',()=>{assert.equal(urlParts('javascript:alert(1) data:text/html,a https://user:pw@example.com').filter(x=>x.url).length,0);});
test('map coordinates validated and embed pinned',()=>{for(const x of [[91,1],[0,181],[NaN,0],['40',1]])assert.equal(mapUrls(...x),null);const links=mapUrls(41.01,28.97);assert.equal(new URL(links.embed).searchParams.get('marker'),'41.01,28.97');assert.equal(new URL(links.external).searchParams.get('mlat'),'41.01');});
test('background/disconnected override preferred status',()=>{for(const x of ['online','offline','busy']){assert.equal(effectiveStatus(false,true,x),'offline');assert.equal(effectiveStatus(true,false,x),'offline');assert.equal(effectiveStatus(true,true,x),x);}});
import {callControlState} from '../web/call-chat-fixes.js';
test('controls auto-hide after ten seconds, stay hidden across redraw, only tap restores',()=>{let c=callControlState({},100);assert.equal(c.controlsHidden,false);c=callControlState(c,10100);assert.equal(c.controlsHidden,true);c=callControlState(c,30000);assert.equal(c.controlsHidden,true);c=callControlState(c,30001,true);assert.equal(c.controlsHidden,false);c=callControlState(c,30010,true);assert.equal(c.controlsHidden,true);assert.equal(callControlState(c,50000).controlsHidden,true);});
import {callEventMatches} from '../web/call-chat-fixes.js';
test('stale call events never match a new call in the same room',()=>{const c={room:{id:'room'},callId:'new'};assert(!callEventMatches(c,{room:'room',callId:'old'}));assert(!callEventMatches(c,{room:'room'}));assert(callEventMatches(c,{room:'room',callId:'new'}));assert(!callEventMatches(c,{room:'other',callId:'new'}));assert(!callEventMatches(null,{}));});
test('old server call events still work without negotiated call ID',()=>{assert(callEventMatches({room:{id:'room'},callId:null},{room:'room',type:'accepted'}));});
import {currentCallAction} from '../web/call-chat-fixes.js';
test('foreground reconciliation opens only an unaccepted incoming invitation',()=>{
 assert.equal(currentCallAction(null,{incoming:true,ringing:true}),'open');
 assert.equal(currentCallAction(null,{incoming:true,ringing:false}),'none');
 assert.equal(currentCallAction(null,{incoming:false,ringing:true}),'none');
 assert.equal(currentCallAction(null,{incoming:true}),'open'); // old server
});
test('foreground reconciliation dismisses an expired or replaced ringing invitation only',()=>{
 const call={incoming:true,room:{id:'room'},callId:'a'};
 assert.equal(currentCallAction(call,null),'close');
 assert.equal(currentCallAction(call,{room:'room',callId:'a',incoming:true,ringing:false}),'close');
 assert.equal(currentCallAction(call,{room:'room',callId:'b',incoming:true,ringing:true}),'close');
 assert.equal(currentCallAction(call,{room:'room',callId:'a',incoming:true,ringing:true}),'none');
 assert.equal(currentCallAction({...call,accepting:true},null),'none');
 assert.equal(currentCallAction({...call,incoming:false},null),'none');
});

test('call presentation is confirmed only by receipt and cannot regress or overwrite an accepted call',()=>{const c={offerer:true,phase:'Aranıyor…'};assert.equal(applyAlertReceipt(c,'unknown'),false);assert.equal(c.phase,'Aranıyor…');assert(applyAlertReceipt(c,'displayed'));assert.match(c.phase,/ses doğrulanmadı/);assert(applyAlertReceipt(c,'alerted'));assert.match(c.phase,/Çalıyor/);assert.equal(applyAlertReceipt(c,'displayed'),false);c.alertAccepted=true;c.phase='Bağlanıyor…';assert.equal(applyAlertReceipt(c,'silent'),false);assert.equal(c.phase,'Bağlanıyor…');assert.equal(applyAlertReceipt({incoming:true},'alerted'),false);});
