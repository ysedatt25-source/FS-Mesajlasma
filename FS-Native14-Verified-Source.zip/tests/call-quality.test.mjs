import test from 'node:test';
import assert from 'node:assert/strict';
import {videoCaptureConstraints,readCallStats,createCallQuality,preferVideoDetail} from '../web/call-quality.js';
const stats=(bps=8000000,extra=[])=>new Map([
 ['old',{id:'old',type:'candidate-pair',state:'succeeded',nominated:true,availableOutgoingBitrate:10000,currentRoundTripTime:10}],
 ['active',{id:'active',type:'candidate-pair',state:'succeeded',nominated:true,availableOutgoingBitrate:bps,currentRoundTripTime:.08}],
 ['transport',{id:'transport',type:'transport',selectedCandidatePairId:'active'}],...extra.map(r=>[r.id,r])]);
function fixture(){let params={encodings:[{maxBitrate:9999999,scaleResolutionDownBy:1}],transactionId:'txn'},calls=[],audioCalls=0;const sender={track:{kind:'video',enabled:true},getParameters:()=>structuredClone(params),async setParameters(p){calls.push(p.degradationPreference);params=structuredClone(p)}};const audio={track:{kind:'audio'},getParameters:()=>{audioCalls++;return {}},setParameters(){audioCalls++}};let current=stats();const pc={connectionState:'connected',getStats:async()=>current,getSenders:()=>[sender,audio]};return {pc,sender,calls,params:()=>params,audioCalls:()=>audioCalls,set:s=>current=s}};
test('high detail camera ideals have no mandatory minimum or fixed maximum; audio unchanged',()=>{const c=videoCaptureConstraints();assert.equal(c.width.ideal,3840);assert.equal(c.height.ideal,2160);assert.equal(c.frameRate.ideal,30);for(const x of [c.width,c.height,c.frameRate])assert.deepEqual(Object.keys(x),['ideal']);let v={kind:'video',contentHint:''},a={kind:'audio',contentHint:''};preferVideoDetail(v);preferVideoDetail(a);assert.equal(v.contentHint,'detail');assert.equal(a.contentHint,'');});
test('actual selected transport only, not an old nominated pair',()=>{const m=readCallStats(stats());assert.equal(m.bandwidth,8000000);assert.equal(m.rtt,.08);assert.equal(readCallStats(new Map()).bandwidth,null);});
test('loss uses interval deltas, ignores counter resets, received dimensions are actual stats',()=>{const r=(received,lost)=>({id:'incoming',type:'inbound-rtp',kind:'video',packetsReceived:received,packetsLost:lost,framesDecoded:70,frameWidth:1920,frameHeight:1080});const a=readCallStats(stats(8000000,[r(900,100)]));assert.equal(a.receiveLoss,null);const b=readCallStats(stats(8000000,[r(990,110)]),a.next);assert.equal(b.receiveLoss,.1);assert.deepEqual(b.remoteSize,{width:1920,height:1080});assert.equal(readCallStats(stats(8000000,[r(2,1)]),b.next).receiveLoss,null);});
test('default detail, hysteresis on severe link conditions and full recovery; bitrate encodings and audio untouched',async()=>{const f=fixture(),q=createCallQuality();assert.equal((await q.sample(f.pc)).mode,'maintain-resolution');f.set(stats(400000));assert.equal((await q.sample(f.pc)).mode,'maintain-resolution');assert.equal((await q.sample(f.pc)).mode,'balanced');f.set(stats());for(let i=0;i<2;i++)assert.equal((await q.sample(f.pc)).mode,'balanced');assert.equal((await q.sample(f.pc)).mode,'maintain-resolution');assert.deepEqual(f.calls,['maintain-resolution','balanced','maintain-resolution']);assert.deepEqual(f.params().encodings,[{maxBitrate:9999999,scaleResolutionDownBy:1}]);assert.equal(f.audioCalls(),0);});
test('one weak sample, unknown stats and stale audio loss cannot change video detail mode',async()=>{const f=fixture(),q=createCallQuality();f.set(stats(400000));await q.sample(f.pc);f.set(new Map());await q.sample(f.pc);f.set(stats(8000000,[{id:'ra',type:'remote-inbound-rtp',kind:'audio',fractionLost:.9}]));assert.equal((await q.sample(f.pc)).mode,'maintain-resolution');assert.deepEqual(f.calls,['maintain-resolution']);});
test('disabled video and audio sender untouched; newly enabled video gets policy',async()=>{const f=fixture(),q=createCallQuality();f.sender.track.enabled=false;await q.sample(f.pc);assert.equal(f.calls.length,0);f.sender.track.enabled=true;await q.sample(f.pc);assert.equal(f.calls.length,1);});
test('no parallel sample and no changes when the call has already ended',async()=>{const f=fixture(),q=createCallQuality();let resolve;f.pc.getStats=()=>new Promise(r=>resolve=r);let active=true;const flight=q.sample(f.pc,()=>active);assert.equal(await q.sample(f.pc),null);active=false;resolve(stats());assert.equal(await flight,null);assert.equal(f.calls.length,0);});
test('unsupported degradation hint does not break call and does not hammer sender',async()=>{const f=fixture(),q=createCallQuality();let n=0;f.sender.setParameters=async()=>{n++;throw new DOMException('unsupported','NotSupportedError')};assert.equal((await q.sample(f.pc)).label,'Bağlantı kuruldu');await q.sample(f.pc);assert.equal(n,1);});
test('transient negotiation errors retry without breaking the call',async()=>{const f=fixture(),q=createCallQuality();const set=f.sender.setParameters;let n=0;f.sender.setParameters=async(p)=>{if(n++===0)throw new DOMException('not negotiated','InvalidStateError');return set(p)};await q.sample(f.pc);await q.sample(f.pc);assert.equal(n,2);assert.deepEqual(f.calls,['maintain-resolution']);});
const encoder=(reason='none',fps=30,capture=30,active=true)=>[
 {id:'cam',type:'media-source',kind:'video',framesPerSecond:capture},
 {id:'video-out',type:'outbound-rtp',kind:'video',active,mediaSourceId:'cam',transportId:'transport',qualityLimitationReason:reason,framesPerSecond:fps}];
test('CPU pressure selects balanced even on a fast network and blocks premature recovery',async()=>{
 const f=fixture(),q=createCallQuality();f.set(stats(8000000,encoder('cpu',24)));
 assert.equal((await q.sample(f.pc)).mode,'maintain-resolution');assert.equal((await q.sample(f.pc)).mode,'balanced');
 for(let i=0;i<4;i++)assert.equal((await q.sample(f.pc)).mode,'balanced');
 f.set(stats(8000000,encoder()));for(let i=0;i<2;i++)assert.equal((await q.sample(f.pc)).mode,'balanced');
 assert.equal((await q.sample(f.pc)).mode,'maintain-resolution');assert.equal(f.audioCalls(),0);
});
test('sustained encoder FPS collapse selects motion priority and restores detail after recovery',async()=>{
 const f=fixture(),q=createCallQuality();f.set(stats(8000000,encoder('cpu',8)));
 assert.equal((await q.sample(f.pc)).mode,'maintain-resolution');assert.equal((await q.sample(f.pc)).mode,'balanced');assert.equal((await q.sample(f.pc)).mode,'maintain-framerate');
 f.set(stats(8000000,encoder('bandwidth',20)));for(let i=0;i<4;i++)assert.equal((await q.sample(f.pc)).mode,'maintain-framerate');
 f.set(stats(8000000,encoder()));await q.sample(f.pc);await q.sample(f.pc);assert.equal((await q.sample(f.pc)).mode,'maintain-resolution');
 assert.deepEqual(f.calls,['maintain-resolution','balanced','maintain-framerate','maintain-resolution']);
 assert.deepEqual(f.params().encodings,[{maxBitrate:9999999,scaleResolutionDownBy:1}]);
});
test('slow camera, missing metrics and inactive encoding do not count as frame collapse',()=>{
 for(const rows of [encoder('bandwidth',5,8),encoder('none',4,30),encoder('cpu',0,30,false),encoder('cpu',undefined,0)])assert.equal(readCallStats(stats(8000000,rows)).framePressure,false);
 assert.equal(readCallStats(stats(8000000,encoder('cpu',0,30,false))).cpuLimited,false);
});
test('video uses its own selected transport, not an unrelated audio transport',()=>{
 const rows=[{id:'video-pair',type:'candidate-pair',state:'succeeded',availableOutgoingBitrate:2200000,currentRoundTripTime:.1},{id:'video-transport',type:'transport',selectedCandidatePairId:'video-pair'},{id:'v',type:'outbound-rtp',kind:'video',transportId:'video-transport'}];
 assert.equal(readCallStats(stats(10000,rows)).bandwidth,2200000);
 assert.equal(readCallStats(stats(10000,rows.slice(2))).bandwidth,null);
});
test('disabled camera and disconnected calls reset sample streaks',async()=>{
 const f=fixture(),q=createCallQuality();f.set(stats(400000));await q.sample(f.pc);f.sender.track.enabled=false;await q.sample(f.pc);f.sender.track.enabled=true;
 assert.equal((await q.sample(f.pc)).mode,'maintain-resolution');f.pc.connectionState='disconnected';await q.sample(f.pc);f.pc.connectionState='connected';assert.equal((await q.sample(f.pc)).mode,'maintain-resolution');assert.equal((await q.sample(f.pc)).mode,'balanced');
});
test('quality hint remains private to controller and no visual quality label is emitted',async()=>{
 const f=fixture(),q=createCallQuality();f.set(stats(300000));await q.sample(f.pc);const r=await q.sample(f.pc);assert.equal(r.weak,true);assert.equal(r.label,'Bağlantı kuruldu');
});
test('high RTT with actual video loss is handled even if bitrate estimate is high',async()=>{
 const f=fixture(),q=createCallQuality();const s=stats(8000000,[{id:'remote-v',type:'remote-inbound-rtp',kind:'video',fractionLost:.06}]);s.get('active').currentRoundTripTime=.9;f.set(s);await q.sample(f.pc);assert.equal((await q.sample(f.pc)).mode,'balanced');
});
test('measured transmitted and received frame size, FPS and actual byte rate',()=>{const base=[{id:'out',type:'outbound-rtp',kind:'video',frameWidth:1920,frameHeight:1080,framesPerSecond:28,bytesSent:1000,timestamp:1000},{id:'in',type:'inbound-rtp',kind:'video',framesDecoded:60,frameWidth:1280,frameHeight:720,framesPerSecond:24}];const first=readCallStats(new Map(base.map(x=>[x.id,x])));assert.equal(first.sendBitrate,null);base[0]={...base[0],bytesSent:251000,timestamp:2000};const second=readCallStats(new Map(base.map(x=>[x.id,x])),first.next);assert.deepEqual(second.localSize,{width:1920,height:1080});assert.deepEqual(second.remoteSize,{width:1280,height:720});assert.equal(second.outgoingFps,28);assert.equal(second.receiveFps,24);assert.equal(second.sendBitrate,2000000);base[0]={...base[0],bytesSent:20,timestamp:3000};assert.equal(readCallStats(new Map(base.map(x=>[x.id,x])),second.next).sendBitrate,null);});
