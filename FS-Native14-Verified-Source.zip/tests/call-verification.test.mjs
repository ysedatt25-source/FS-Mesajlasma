import test from 'node:test';
import assert from 'node:assert/strict';
import {callVerificationSnapshot,sameCallVerification,verificationDigest,verifyCallTransport} from '../web/call-verification.js';
const ID='a'.repeat(32);
const snapshot=(p,id=ID)=>callVerificationSnapshot(p,id);
const line=x=>'a=fingerprint:sha-256 '+Array(32).fill(x).join(':')+'\r\n';
const peer=(a='AA',b='BB')=>({connectionState:'connected',signalingState:'stable',currentLocalDescription:{sdp:line(a)},currentRemoteDescription:{sdp:line(b)}});
test('opposite ends of a call derive the same fingerprint hash',async()=>{const a=snapshot(peer()),b=snapshot(peer('BB','AA'));assert.deepEqual(await verificationDigest(a),await verificationDigest(b));});
test('different peer certificate changes the fingerprint hash',async()=>{assert.notDeepEqual(await verificationDigest(snapshot(peer())),await verificationDigest(snapshot(peer('AA','CC'))));});
test('disconnected, connecting and closed connections never expose a code',()=>{for(const connectionState of ['new','connecting','disconnected','failed','closed'])assert.equal(snapshot({...peer(),connectionState}),null);});
test('pending renegotiation and missing SDP cannot be verified',()=>{assert.equal(snapshot({...peer(),signalingState:'have-local-offer'}),null);assert.equal(snapshot({...peer(),currentRemoteDescription:null}),null);});
test('repeated identical fingerprints are accepted but different certificates fail closed',()=>{const p=peer();p.currentLocalDescription.sdp+=line('AA');assert.ok(snapshot(p));p.currentLocalDescription.sdp+=line('CC');assert.equal(snapshot(p),null);});
test('malformed and non SHA-256 fingerprints never produce a code',()=>{const p=peer();p.currentLocalDescription.sdp='a=fingerprint:sha-256 AA:BB\n';assert.equal(snapshot(p),null);p.currentLocalDescription.sdp=line('AA').replace('sha-256','sha-1');assert.equal(snapshot(p),null);});
test('a stale verification snapshot is invalid after SDP or connection change',()=>{const p=peer(),a=snapshot(p);assert.ok(sameCallVerification(a,snapshot(p)));p.currentLocalDescription.sdp+='a=ice-ufrag:new\n';assert.ok(!sameCallVerification(a,snapshot(p)));p.connectionState='disconnected';assert.ok(!sameCallVerification(a,snapshot(p)));});
test('current negotiated descriptions take precedence over pending descriptions',()=>{const p=peer();p.localDescription={sdp:line('CC')};assert.equal(snapshot(p).material,snapshot(peer()).material);});

function transportStats(a='AA',b='BB',state='connected') {return new Map([['t',{type:'transport',dtlsState:state,localCertificateId:'l',remoteCertificateId:'r'}],['l',{type:'certificate',fingerprintAlgorithm:'sha-256',fingerprint:Array(32).fill(a).join(':')}],['r',{type:'certificate',fingerprintAlgorithm:'sha-256',fingerprint:Array(32).fill(b).join(':')}]])}
test('same certificates in another call produce a different digest',async()=>assert.notDeepEqual(await verificationDigest(snapshot(peer())),await verificationDigest(snapshot(peer(),'b'.repeat(32)))));
test('missing call id, self certificate, and disconnected ICE fail closed',()=>{assert.equal(callVerificationSnapshot(peer(),null),null);assert.equal(snapshot(peer('AA','AA')),null);assert.equal(snapshot({...peer(),iceConnectionState:'disconnected'}),null)});
test('replacement connection with identical SDP cannot reuse proof',()=>assert.equal(sameCallVerification(snapshot(peer()),snapshot(peer())),false));
test('negotiated DTLS certificates match SDP',async()=>{const p=peer();p.getStats=async()=>transportStats();assert.equal(await verifyCallTransport(snapshot(p)),true)});
test('mismatched remote or local certificate, incomplete transport and missing statistics fail closed',async()=>{const p=peer();for(const stats of [transportStats('AA','CC'),transportStats('CC','BB'),transportStats('AA','BB','connecting'),new Map()]){p.getStats=async()=>stats;assert.equal(await verifyCallTransport(snapshot(p)),false)}p.getStats=async()=>{throw Error('unavailable')};assert.equal(await verifyCallTransport(snapshot(p)),false)});
test('additional transport with a different certificate fails closed',async()=>{const p=peer(),stats=transportStats();stats.set('t2',{...stats.get('t'),remoteCertificateId:'l'});p.getStats=async()=>stats;assert.equal(await verifyCallTransport(snapshot(p)),false)});
test('disconnect while stats promise pending prevents verification',async()=>{const p=peer();let resolve;p.getStats=()=>new Promise(r=>resolve=r);const pending=verifyCallTransport(snapshot(p));p.connectionState='disconnected';resolve(transportStats());assert.equal(await pending,false)});
