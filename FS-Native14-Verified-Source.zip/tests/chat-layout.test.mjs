import {test} from 'node:test';
import assert from 'node:assert/strict';
import {chatMessageJoined} from '../web/chat-layout.js';
const start=new Date(2026,10,25,12).getTime();
const msg=(sender='a',created=start,extra={})=>({sender,created,payload:{type:'text',text:'Merhaba'},...extra});
const a=msg();
test('adjacent text from same sender groups within two minutes',()=>{assert.equal(chatMessageJoined(a,msg('a',start+120000)),true)});
test('sender changes break groups',()=>assert.equal(chatMessageJoined(a,msg('b')),false));
test('large gap and reverse order break groups',()=>{assert.equal(chatMessageJoined(a,msg('a',start+120001)),false);assert.equal(chatMessageJoined(a,msg('a',start-1)),false)});
test('local midnight breaks group',()=>assert.equal(chatMessageJoined(msg('a',new Date(2026,10,25,23,59,59).getTime()),msg('a',new Date(2026,10,26,0,0,0).getTime())),false));
test('unread divider breaks group',()=>assert.equal(chatMessageJoined(a,msg(),{unreadBoundary:true}),false));
test('call, album, file and emoji remain independent',()=>{for(const b of [msg('a',start,{callRecord:true}),msg('a',start,{album:[]}),msg('a',start,{payload:{type:'file'}}),msg('a',start,{payload:{type:'text',text:'❤️'}})])assert.equal(chatMessageJoined(a,b,{singleEmoji:t=>t==='❤️'}),false)});
test('missing message and invalid timestamp do not group',()=>{assert.equal(chatMessageJoined(null,a),false);assert.equal(chatMessageJoined(a,msg('a',NaN)),false)});

test('reply, special effect and different rooms split groups',()=>{for(const b of [msg('a',start,{reply:'prior'}),msg('a',start,{payload:{type:'text',text:'Hello',effect:'heart'}}),msg('a',start,{room:'other'})])assert.equal(chatMessageJoined({...a,room:'room'},b),false);});
