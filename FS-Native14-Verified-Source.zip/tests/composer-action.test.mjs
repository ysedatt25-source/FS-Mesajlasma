import assert from 'node:assert/strict';
import test from 'node:test';
import {composerMode,createMicGesture} from '../web/composer-action.js';
const e={isPrimary:true,button:0,pointerId:1};
function setup(){let mode='mic',t=0,task=null,start=0,stop=0,cancel=0;const g=createMicGesture({mode:()=>mode,start:()=>{start++;mode='recording'},finish:()=>{stop++;mode='mic'},cancel:()=>{cancel++;mode='mic'},now:()=>t,schedule:f=>(task=f,1),unschedule:()=>task=null});return {g,mode:m=>{mode=m;g.changed()},time:x=>{t=x},fire:()=>{const f=task;task=null;f?.()},counts:()=>[start,stop,cancel]};}
test('blank, spaces and empty reply use microphone',()=>{assert.equal(composerMode({text:'  \n'}),'mic');assert.equal(composerMode({}),'mic')});
test('typed text and single emoji send instantly',()=>{for(const text of ['a','😘','👩‍❤️‍👨'])assert.equal(composerMode({text}),'send')});
test('file, gallery and recording select send',()=>{assert.equal(composerMode({files:1}),'send');assert.equal(composerMode({recording:true}),'send')});
test('busy and active recording prevent conflicting send',()=>{assert.equal(composerMode({active:true,text:'x'}),'recording');assert.equal(composerMode({busy:true,files:2}),'busy')});
test('a tap on empty microphone never starts a recording',()=>{const s=setup();assert(s.g.down(e));s.g.up(e);s.fire();assert(!s.g.click());assert.deepEqual(s.counts(),[0,0,0])});
test('deliberate hold then release starts and stops once',()=>{const s=setup();s.g.down(e);s.fire();s.g.up(e);s.g.up(e);assert(!s.g.click());assert.deepEqual(s.counts(),[1,1,0])});
test('rapid double click after sending cannot start microphone',()=>{const s=setup();s.mode('send');assert(!s.g.down(e));assert(s.g.click());s.mode('mic');s.time(100);s.g.down(e);s.fire();s.g.up(e);assert(!s.g.click());assert.deepEqual(s.counts(),[0,0,0])});
test('typing while pointer held cancels microphone, does not send accidentally',()=>{const s=setup();s.g.down(e);s.mode('send');s.fire();s.g.up(e);assert(!s.g.click());assert.deepEqual(s.counts(),[0,0,0])});
test('after send cooldown a deliberate long press is allowed',()=>{const s=setup();s.mode('send');s.g.click();s.mode('mic');s.time(400);s.g.down(e);s.fire();assert.deepEqual(s.counts(),[1,0,0])});
test('pointer cancel and room reset cancel capture',()=>{const s=setup();s.g.down(e);s.fire();s.g.abort(e);assert.deepEqual(s.counts(),[1,0,1]);s.g.down(e);s.g.reset();s.fire();assert.deepEqual(s.counts(),[1,0,1])});
test('nonprimary pointer cannot start a recording',()=>{const s=setup();assert(!s.g.down({...e,isPrimary:false}));s.fire();assert.deepEqual(s.counts(),[0,0,0])});
