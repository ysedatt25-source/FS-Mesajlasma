import test from 'node:test';
import assert from 'node:assert/strict';
import {serverRoot, fetchServer, verifyServer} from '../web/connection.js';
import {uploadChunks, transferRetryable, transferDeadline} from '../web/transfer-resilience.js';
test('Android asset origin cannot be used as an API server', async () => {
  assert.throws(()=>serverRoot('https://appassets.androidplatform.net'), /sunucusu/);
  let requests=0;
  await assert.rejects(fetchServer('', '/api/session', {}, async()=>requests++), /sunucusu/);
  assert.equal(requests,0);
});
test('server paths survive normalization and /api is not doubled',()=>{
  assert.equal(serverRoot('https://fs.example/chat/api/'),'https://fs.example/chat');
  assert.equal(serverRoot('http://127.0.0.1:8787/'),'http://127.0.0.1:8787');
  for(const u of ['https://appassets.androidplatform.net', 'http://fs.example','https://u:p@fs.example','https://fs.example/?token=secret']) assert.throws(()=>serverRoot(u));
});
test('static sites and 404 health pages fail verification', async()=>{
  for(const response of [new Response('Not found',{status:404}),Response.json({ok:true}),Response.json({ok:false,service:'fs-mesajlasma'})])
    await assert.rejects(verifyServer('https://fs.example',async()=>response), /API sunucusu/);
  assert.equal(await verifyauro(), 'https://fs.example');
  async function verifyauro(){return verifyServer('https://fs.example',async()=>Response.json({ok:true,service:'fs-mesajlasma'}));}
});
test('network failures are explained without submitting to an asset URL',async()=>{
  await assert.rejects(fetchServer('https://fs.example','/health',{},async()=>{throw TypeError('Failed to fetch')}),/bağlanılamadı/);
});

test('missing Android API never sends a registration request', async()=>{
 let requests=0;
 await assert.rejects(fetchServer('', '/api/session', {method:'POST'}, async()=>{requests++}), /sunucusu henüz/);
 assert.equal(requests,0);
});

// Integration of the real connection wrapper and chunk reconciler, not a fake
// error code passed directly to uploadChunks. The first PUT commits before its
// response is lost, then the second file must be transmitted exactly once.
test('two files continue after lost committed PUT through fetchServer', async()=>{
 const received=new Map(), writes=[], heads=[];let lost=false;
 const fetcher=async(url,opts)=>{
  const id=new URL(url).pathname.split('/').at(-1), data=received.get(id)||Buffer.alloc(0);
  if(opts.method==='HEAD'){heads.push(id);return new Response(null,{headers:{'Upload-Offset':String(data.length)}});}
  assert.equal(opts.method,'PUT');assert.equal(Number(opts.headers['Upload-Offset']),data.length);
  const next=Buffer.concat([data,Buffer.from(opts.body)]);received.set(id,next);writes.push(id);
  if(!lost){lost=true;throw new TypeError('injected lost response after commit');}
  return Response.json({offset:next.length});
 };
 for(const [id,bytes] of [['first',Buffer.from('one bytes')],['second',Buffer.from('two bytes')]]){
  const path='/api/uploads/'+id;
  await uploadChunks({size:bytes.length,
   readOffset:async()=>Number((await fetchServer('https://fs.example',path,{method:'HEAD'},fetcher)).headers.get('Upload-Offset')),
   write:async(a,b)=>(await (await fetchServer('https://fs.example',path,{method:'PUT',headers:{'Upload-Offset':String(a)},body:bytes.subarray(a,b)},fetcher)).json()).offset});
  assert.deepEqual(received.get(id),bytes);
 }
 assert.equal(lost,true);assert.deepEqual(writes,['first','second']);assert.deepEqual(heads,['first','first','second']);
});
test('network rejection retains retry code, HTTP permission response is not rewritten',async()=>{
 await assert.rejects(fetchServer('https://fs.example','/api/uploads/x',{},async()=>{throw new TypeError('lost response')}),e=>e.code==='NETWORK'&&transferRetryable(e)&&/bağlanılamadı/.test(e.message));
 const denied=await fetchServer('https://fs.example','/api/uploads/x',{},async()=>new Response(null,{status:403}));assert.equal(denied.status,403);
});
test('pre-aborted transfer does not reach the server',async()=>{
 const c=new AbortController();c.abort();let calls=0;
 await assert.rejects(fetchServer('https://fs.example','/api/uploads/x',{signal:c.signal},async()=>{calls++;return new Response()}),e=>e.name==='AbortError'&&!transferRetryable(e));assert.equal(calls,0);
});
test('caller cancellation reaches the underlying fetch and stays nonretryable',async()=>{
 const c=new AbortController();let actual;
 const p=fetchServer('https://fs.example','/api/uploads/x',{signal:c.signal},async(url,opts)=>{actual=opts.signal;return new Promise((resolve,reject)=>actual.addEventListener('abort',()=>reject(new DOMException('aborted','AbortError')),{once:true}));});
 c.abort();assert.equal(actual.aborted,true);await assert.rejects(p,e=>e.name==='AbortError'&&!transferRetryable(e));
});
test('late fetch success after caller cancellation cannot be used',async()=>{
 const c=new AbortController();let finish;const p=fetchServer('https://fs.example','/api/uploads/x',{signal:c.signal},()=>new Promise(r=>finish=r));c.abort();finish(Response.json({offset:10}));await assert.rejects(p,{name:'AbortError'});
});
test('transfer deadline aborts underlying fetch and is retryable as a timeout',async()=>{
 let actual;await assert.rejects(transferDeadline(signal=>fetchServer('https://fs.example','/api/uploads/x',{signal},(url,opts)=>{actual=opts.signal;return new Promise((r,j)=>actual.addEventListener('abort',()=>j(new DOMException('aborted','AbortError')),{once:true}));}),{ms:5}),e=>e.code==='TRANSFER_TIMEOUT'&&transferRetryable(e));assert.equal(actual.aborted,true);
});

test('socket authentication watchdog closes only the current unconfirmed connection',async()=>{const {readFileSync}=await import('node:fs');const {runInNewContext}=await import('node:vm');const src=readFileSync(new URL('../web/app.js',import.meta.url),'utf8');const code=src.slice(src.indexOf('function watchSocketHandshake'),src.indexOf('function clearReconnect'));const watch=runInNewContext(code+';watchSocketHandshake');let fn,closed=0,cancelled=0,active=true;const ws={close(code){assert.equal(code,4000);closed++}};const options={schedule(f,ms){assert.equal(ms,20000);fn=f;return 1;},cancel(){cancelled++;fn=null;}};let stop=watch(ws,()=>active,options);stop();assert.equal(cancelled,1);assert.equal(fn,null);stop=watch(ws,()=>active,options);active=false;fn();assert.equal(closed,0);active=true;watch(ws,()=>active,options);fn();assert.equal(closed,1);});
