import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {characterAssetPath,buildEmojiIndex,mergeEmojiCatalog,emojiAsset} from '../web/emoji-effects.js';
const read=n=>JSON.parse(fs.readFileSync(new URL('../web/'+n+'.json',import.meta.url)));
const index=buildEmojiIndex(mergeEmojiCatalog(read('emojis'),read('emoji-extension')));
for(const glyph of ['😂','😘','😊','😉','😡','😢','😍','😴','😮','🐱','🐶','🕯️','❤️','🔥','🦋','👋','⭐','🌸']) test('authored route '+glyph,()=>{const p=characterAssetPath(emojiAsset(index,glyph));assert.match(p,/^emoji-character\//);assert.ok(fs.existsSync(new URL('../web/'+p,import.meta.url)));});

for(const glyph of ['😁','😛','🤔','😎','🐝','👍','😱','💔','🐟','👏','🎈','😔','😭','🚀','🎵','😏','🙏','🌈']) test('new authored route '+glyph,()=>{const p=characterAssetPath(emojiAsset(index,glyph));assert.match(p,/^emoji-character\//);assert.ok(fs.existsSync(new URL('../web/'+p,import.meta.url)));});

test('all catalog entries use only verified artwork or exact static Unicode',()=>{for(const row of mergeEmojiCatalog(read('emojis'),read('emoji-extension'))){const path=characterAssetPath(row.file);if(path!==null){assert.match(path,/^emoji-character\//);assert.ok(fs.existsSync(new URL('../web/'+path,import.meta.url)));}}});

test('picker uses static glyphs instead of concurrent animated decoders',()=>{const source=fs.readFileSync(new URL('../web/app.js',import.meta.url),'utf8');const line=source.split('\n').find(x=>x.includes('const markup=items.slice(append?previousVisible:0,visible)'));assert.ok(line);assert.match(line,/emoji-picker-glyph/);assert.doesNotMatch(line,/<img|characterAssetPath/);});
