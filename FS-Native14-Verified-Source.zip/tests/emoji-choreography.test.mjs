import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {effectPlan,particlePlan,mergeEmojiCatalog} from '../web/emoji-effects.js';
const read=name=>JSON.parse(fs.readFileSync(new URL('../web/'+name,import.meta.url),'utf8'));
test('semantic effects select different trajectories instead of one universal movement',()=>{
 const examples=[['❤️','heart'],['😭','fall'],['🎉','confetti'],['🦋','flutter'],['🔥','flame'],['🎵','float'],['⚡','flash'],['🚀','launch'],['💔','split'],['🌹','bloom'],['🌊','wave'],['🇹🇷','flag'],['👩🏽‍⚕️','orbit'],['1️⃣','pulse'],['😉','flash'],['🚗','dash']];
 for(const [e,m] of examples)assert.equal(effectPlan(e).motion,m,e);
});
test('exact color, complexion, flags, family and compound glyphs are preserved in effect particles',()=>{
 for(const e of ['🩵','💙','👍🏿','👍🏻','🇹🇷','🇩🇪','👨‍👩‍👧‍👦','1️⃣','👩🏽‍⚕️','🏳️‍🌈'])assert.ok(effectPlan(e).symbols.includes(e),e);
 assert.ok(!effectPlan('🩵').symbols.includes('❤'));
 assert.ok(!effectPlan('👍🏿').symbols.includes('👍🏻'));
});
test('choreography deterministically matches sender and recipient, varies by exact Unicode',()=>{
 const a=effectPlan('❤️'),b=effectPlan('❤');assert.equal(a.seed,b.seed);assert.equal(a.motion,b.motion);
 const c=effectPlan('💙');assert.notEqual(a.seed,c.seed);
 assert.notDeepEqual(particlePlan(a.kind,1,12,a.seed,a.motion),particlePlan(c.kind,1,12,c.seed,c.motion));
 assert.deepEqual(effectPlan('👨‍👩‍👧‍👦'),effectPlan('👨‍👩‍👧‍👦'));
});
test('all 3757 catalog emoji resolve to safe bounded choreography',()=>{
 const items=mergeEmojiCatalog(read('emojis.json'),read('emoji-extension.json'));assert.equal(items.length,3757);
 const motions=new Set(),seeds=new Set();for(const {emoji} of items){const p=effectPlan(emoji);assert.ok(p,emoji);motions.add(p.motion);seeds.add(p.seed);assert.ok(p.symbols.length>0&&p.symbols.length<=3);if(emoji!=='🦋')assert.ok(!p.symbols.includes('🦋'));
 for(let i=0;i<12;i++){const v=particlePlan(p.kind,i,12,p.seed,p.motion);for(const n of Object.values(v))assert.ok(Number.isFinite(n));assert.ok(Math.abs(v.x)<=240&&Math.abs(v.y)<=240);assert.ok(v.duration+v.delay<2200);}}
 assert.ok(motions.size>=20);assert.ok(seeds.size>=3750);
});
test('confetti arcs upward then down, hearts and flames rise, tears fall, broken hearts split',()=>{
 for(let i=0;i<12;i++){assert.ok(particlePlan('celebrate',i).my<0&&particlePlan('celebrate',i).y>0);assert.ok(particlePlan('love',i).y<0);assert.ok(particlePlan('fire',i).y<0);assert.ok(particlePlan('rain',i).y>0);assert.ok(particlePlan('broken',i).x*(i%2?1:-1)>0);}
});

test('kiss and tongue scenes retain exact glyph and distinct particle paths',()=>{for(const emoji of ['💋','😘','😛','😜','🤪']){const plan=effectPlan(emoji);assert.ok(plan.symbols.includes(emoji));assert.ok(['kiss','tongue'].includes(plan.kind));}const a=effectPlan('💋'),b=effectPlan('😛');assert.notDeepEqual(particlePlan(a.kind,5,12,a.seed,a.motion),particlePlan(b.kind,5,12,b.seed,b.motion));});
