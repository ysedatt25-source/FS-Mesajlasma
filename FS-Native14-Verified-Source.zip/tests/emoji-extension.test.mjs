import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {isSingleEmoji,emojiKey,mergeEmojiCatalog,buildEmojiIndex,emojiAsset,emojiFilePath,characterAssetPath} from '../web/emoji-effects.js';
const read=p=>fs.readFileSync(new URL('../web/'+p,import.meta.url));
const legacy=JSON.parse(read('emojis.json')),extended=JSON.parse(read('emoji-extension.json')),merged=mergeEmojiCatalog(legacy,extended),index=buildEmojiIndex(merged),source=read('app.js').toString();
test('Native12 legacy manifest bytes, ordering and call verification remain frozen',()=>{
 assert.equal(createHash('sha256').update(read('emojis.json')).digest('hex'),'245d5917149d3ee8043ebf72079c1662da8dcc8e743c347f2243c6f3954ff70d');
 assert.deepEqual(merged.slice(0,legacy.length),legacy);
 assert.match(source,/legacyVerificationEmojis\[\(\(digest\[i \* 2\] << 8\) \| digest\[i \* 2 \+ 1\]\) % legacyVerificationEmojis.length\]/);
 for(const row of legacy)assert.equal(emojiAsset(index,row.emoji),row.file);
});
test('2876 newly bundled Unicode 16 RGI entries are exact, unique and disjoint',()=>{
 assert.equal(extended.length,2876);assert.equal(index.size,3757);
 const keys=new Set(legacy.map(x=>emojiKey(x.emoji)));
 for(const row of extended){assert.match(row.emoji,/^\p{RGI_Emoji}$/v);assert.ok(isSingleEmoji(row.emoji));assert.ok(!keys.has(emojiKey(row.emoji)));keys.add(emojiKey(row.emoji));
 assert.equal(row.file,'e-'+[...emojiKey(row.emoji)].map(c=>c.codePointAt(0).toString(16)).join('_')+'.webp');assert.equal(emojiFilePath(emojiAsset(index,row.emoji)),'emoji-extra/'+row.file);const path=characterAssetPath(row.file);if(path){assert.equal(path,'emoji-character/'+row.file);assert.ok(fs.existsSync(new URL('../web/'+path,import.meta.url)));}else{assert.equal(path,null);}}
});
test('flags, family, mixed tones, wheelchair, keycaps, standalone tones and qualification map exactly',()=>{
 for(const value of ['🇹🇷','🇯🇵','👩‍❤️‍💋‍👩','🧑🏽‍🦽','🫱🏿‍🫲🏻','1️⃣','🏳️‍🌈','🏿']){
 assert.ok(emojiAsset(index,value),value);assert.equal(emojiAsset(index,value),emojiAsset(index,emojiKey(value)));}
 assert.notEqual(emojiAsset(index,'🇹🇷'),emojiAsset(index,'🇯🇵'));assert.notEqual(emojiAsset(index,'👍🏽'),emojiAsset(index,'👍🏿'));
 for(const bad of ['normal metin','😀😀','🇹','😀 hello'])assert.equal(emojiAsset(index,bad),null);
});
test('optional catalog failure never replaces original assets; unsafe and duplicate rows rejected',()=>{
 assert.deepEqual(mergeEmojiCatalog(legacy,null),legacy);
 assert.deepEqual(mergeEmojiCatalog(legacy,[null,{emoji:'a',file:'e-1.webp'},{emoji:'😂',file:'../evil.webp'},{emoji:legacy[0].emoji,file:'e-1.webp'}]),legacy);
 assert.equal(emojiFilePath('../x.webp'),null);assert.equal(emojiFilePath('https://example.com/e.webp'),null);assert.equal(emojiFilePath('1f602.webp'),'emoji/1f602.webp');
});
test('picker pages remain bounded, new picker glyphs static, reduced motion fallback retains exact text',()=>{
 assert.match(source,/items\.slice\(append\?previousVisible:0,visible\)/);assert.match(source,/emoji-picker-glyph/);assert.match(source,/const animatedPath=asset&&!window\.matchMedia/);assert.match(source,/class="emoji-fallback">\$\{escape\(p.text\)\}/);assert.match(source,/fetch\("emoji-extension.json"\).*?catch\(\(\)=>\[\]\)/);
});
