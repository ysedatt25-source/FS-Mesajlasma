import test from 'node:test';
import assert from 'node:assert/strict';
import {replayArtwork} from '../web/emoji-effects.js';
test('successful replay reuses artwork',async()=>{let n=0;const fetcher=async()=>({ok:true,blob:async()=>new Blob([String(++n)])});const a=await replayArtwork('a',fetcher);assert.equal(await replayArtwork('a',fetcher),a);assert.equal(n,1);});
test('failed responses are not cached',async()=>{let n=0;const fetcher=async()=>({ok:++n>1,blob:async()=>new Blob(['ok'])});await assert.rejects(replayArtwork('b',fetcher));await replayArtwork('b',fetcher);assert.equal(n,2);});
test('cache evicts old artwork',async()=>{let n=0;const fetcher=async()=>({ok:true,blob:async()=>new Blob([String(++n)])});for(let i=0;i<9;i++)await replayArtwork('evict'+i,fetcher);await replayArtwork('evict0',fetcher);assert.equal(n,10);});
test('oversized artwork is not retained',async()=>{let n=0;const fetcher=async()=>({ok:true,blob:async()=>{n++;return new Blob([new Uint8Array(524289)]);}});await replayArtwork('large',fetcher);await replayArtwork('large',fetcher);assert.equal(n,2);});
test('aborted artwork is not retained',async()=>{let n=0;const fetcher=async()=>({ok:true,blob:async()=>new Blob([String(++n)])});const c=new AbortController();c.abort();await replayArtwork('abort',fetcher,c.signal);await replayArtwork('abort',fetcher);assert.equal(n,2);});
