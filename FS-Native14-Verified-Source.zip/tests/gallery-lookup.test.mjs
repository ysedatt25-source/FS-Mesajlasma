import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {createRecordLookup} from '../web/app-performance.js';
const src=fs.readFileSync(new URL('../web/app.js',import.meta.url),'utf8');
const fn=name=>src.match(new RegExp('^function '+name+'\\(.*$', 'm'))[0];
function setup(){let checks=0;const hidden=new Set();const state={media:Array.from({length:10000},(_,i)=>({id:String(i),created:1,payload:{type:'file',name:'Foto '+i,mime:'image/jpeg'}})),mediaFilter:'Fotoğraflar'};const c={state,lookupRecord:createRecordLookup(),isViewOnce:m=>!!m.once,hiddenMessage:m=>{checks++;return hidden.has(m.id)},localDay:()=> 'today'};vm.createContext(c);vm.runInContext(['photoCandidates','visiblePhoto','currentPhoto','matchesMediaFilter','filteredMedia'].map(fn).join('\n'),c);return {c,state,hidden,checks:()=>checks};}
test('gallery viewer checks only selected record on repeated access',()=>{const {c,checks}=setup();for(let i=0;i<100;i++)assert.equal(c.currentPhoto('9999','media').id,'9999');assert.equal(checks(),200);});
test('live filters and hidden state still prevent access',()=>{const {c,state,hidden}=setup();assert.ok(c.currentPhoto('1','media'));state.mediaQuery='Foto 2';assert.equal(c.currentPhoto('1','media'),undefined);state.mediaQuery='';hidden.add('1');assert.equal(c.currentPhoto('1','media'),undefined);hidden.clear();state.mediaFilter='Bağlantılar';assert.equal(c.currentPhoto('1','media'),undefined);state.mediaFilter='Fotoğraflar';state.mediaDate='yesterday';assert.equal(c.currentPhoto('1','media'),undefined);state.mediaDate='today';state.media[1].once=true;assert.equal(c.currentPhoto('1','media'),undefined);});
