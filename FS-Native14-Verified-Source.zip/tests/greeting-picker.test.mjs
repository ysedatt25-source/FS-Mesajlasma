import test from 'node:test';import assert from 'node:assert/strict';
import {createGreetingPicker,GREETINGS} from '../web/greeting-picker.js';
import {buildEmojiIndex} from '../web/emoji-effects.js';
test('stable within route and different on next route',()=>{const pick=createGreetingPicker(()=>0),index=new Map();const a=pick(1,index);assert.equal(pick(1,index),a);assert.notEqual(pick(2,index),a);});
test('prefers available animated assets',()=>{const pick=createGreetingPicker(()=>0),index=buildEmojiIndex([{emoji:'🤗',file:'1f917.webp'}]);assert.equal(pick(1,index),'🤗');assert.equal(pick(2,index),'🤗');});
test('fallback always uses supported greeting',()=>{const pick=createGreetingPicker(()=>.9999);assert.ok(GREETINGS.includes(pick(1,new Map())));assert.ok(GREETINGS.includes(pick(2,new Map())));});
