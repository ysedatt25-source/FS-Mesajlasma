import test from 'node:test';
import assert from 'node:assert/strict';
import {openHistorical} from '../web/history-keys.js';
import {peerKey,seal,inspectRecovery,b64} from '../web/crypto.js';
async function key(){const pair=await crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},false,['deriveKey']);return {pair,pub:await crypto.subtle.exportKey('jwk',pair.publicKey)};}
const [old,active,peer]=await Promise.all([key(),key(),key()]);
const payload={type:'text',text:'Old message'};
const packet=await seal(await peerKey(peer.pair.privateKey,old.pub),payload,'room-a');
const opts={keys:[active,old],senderPub:peer.pub,packet,room:'room-a'};
test('historical incoming payload authenticates with correct old private key',async()=>assert.deepEqual(await openHistorical(opts),payload));
test('wrong or missing private key fails closed',async()=>{await assert.rejects(openHistorical({...opts,keys:[active]}));await assert.rejects(openHistorical({...opts,keys:[]}));});
test('own messages use recorded historical sender key or legacy self key',async()=>{const e=await seal(await peerKey(old.pair.privateKey,old.pub),payload,'room-a');assert.deepEqual(await openHistorical({...opts,senderPub:old.pub,packet:e}),payload);assert.deepEqual(await openHistorical({...opts,ownLegacy:true,packet:e}),payload);});
test('different room and modified ciphertext fail authentication',async()=>{await assert.rejects(openHistorical({...opts,room:'room-b'}));await assert.rejects(openHistorical({...opts,packet:{...packet,data:(packet.data[0]==='A'?'B':'A')+packet.data.slice(1)}}));});
test('invalid decrypted payload remains rejected',async()=>{const e=await seal(await peerKey(peer.pair.privateKey,old.pub),{type:'html',text:'bad'},'room-a');await assert.rejects(openHistorical({...opts,packet:e}));});
test('session cancellation before and during key search fails closed',async()=>{await assert.rejects(openHistorical({...opts,valid:()=>false}),{name:'AbortError'});let n=0;await assert.rejects(openHistorical({...opts,valid:()=>++n<3}),{name:'AbortError'});});
test('historical file metadata and encrypted revision retain exact original values',async()=>{const f={type:'file',name:'old.jpg',mime:'image/jpeg',size:123,key:'example',iv:'example',upload:'abcdefghijkl'};const e=await seal(await peerKey(peer.pair.privateKey,old.pub),f,'room-a');assert.deepEqual(await openHistorical({...opts,packet:e}),f);});
test('historical candidate list is bounded and cannot accidentally try unlimited keys',async()=>{await assert.rejects(openHistorical({...opts,keys:[...Array(8).fill(active),old]}));});
