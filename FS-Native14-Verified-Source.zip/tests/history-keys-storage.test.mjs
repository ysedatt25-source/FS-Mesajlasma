import test from 'node:test';
import {IDBFactory} from 'fake-indexeddb';
test('account-bound history recovery persistence, isolation, and session preservation',async()=>{
 globalThis.indexedDB=new IDBFactory();

const {identity,vault,prepareRecovery,createRecoveryExport,peerKey,seal,sameIdentity}=await import('../web/crypto.js');
const {addHistoryKey,historyKeys,openHistorical}=await import('../web/history-keys.js');
const assert=(ok,msg)=>{if(!ok)throw Error(msg);};let tests=[];
const rejects=async(fn)=>{try{await fn();return false}catch{return true}};
const root='https://server-a.invalid',account='synthetic-a',pass='account-password',recovery='long independent recovery passphrase';
const old=await identity();await prepareRecovery(pass);const legacy=await vault('recovery');
const backup=await createRecoveryExport(legacy,pass,recovery,account,old.pub);
const peer=await crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveKey']);const peerPub=await crypto.subtle.exportKey('jwk',peer.publicKey);
const incoming=await seal(await peerKey(peer.privateKey,old.pub),{type:'text',text:'old incoming'},'room-a');
const outgoing=await seal(await peerKey(old.pair.privateKey,old.pub),{type:'text',text:'old outgoing'},'room-a');
await vault('identity',null);const active=await identity();await vault('session',{token:'current-session',user:{id:account,pub:active.pub}});
const args={root,account,packet:backup,password:recovery,activePub:active.pub};
const read=()=>historyKeys(root,account);
assert(await rejects(()=>addHistoryKey({...args,password:'bad'})),'wrong password accepted');assert((await read()).length===0,'wrong password wrote key');tests.push('wrong password rejected');
assert(await rejects(()=>addHistoryKey({...args,account:'other'})),'wrong account accepted');assert(await rejects(()=>addHistoryKey({...args,packet:legacy,password:pass})),'unbound legacy accepted');tests.push('wrong account and unbound backup rejected');
assert(await rejects(()=>addHistoryKey({...args,valid:()=>false})),'cancelled import accepted');tests.push('cancelled operation rejected');
assert((await addHistoryKey(args)).added,'not added');assert((await read()).length===1,'key missing');assert((await read())[0].pair.privateKey.extractable===false,'extractable key');tests.push('encrypted backup adds nonextractable key');
assert(!(await addHistoryKey(args)).added&&(await read()).length===1,'duplicate key');tests.push('duplicates do not overwrite');
assert((await historyKeys(root,'other')).length===0&&(await historyKeys('https://server-b.invalid',account)).length===0,'scope leak');tests.push('account and server isolated');

const keys=await read();const opts={keys,senderPub:peerPub,packet:incoming,room:'room-a'};
assert((await openHistorical(opts)).text==='old incoming','incoming failed');tests.push('old incoming decrypted');
assert((await openHistorical({...opts,senderPub:old.pub,packet:outgoing})).text==='old outgoing','outgoing failed');assert((await openHistorical({...opts,ownLegacy:true,packet:outgoing})).text==='old outgoing','legacy self failed');tests.push('old own messages decrypted');
assert(await rejects(()=>openHistorical({...opts,room:'wrong'})),'wrong room accepted');assert(await rejects(()=>openHistorical({...opts,packet:{...incoming,data:(incoming.data[0]==='A'?'B':'A')+incoming.data.slice(1)}})),'tampered accepted');tests.push('wrong room and tampered ciphertext rejected');
assert(await rejects(()=>openHistorical({...opts,valid:()=>false})),'locked session accepted');tests.push('locked session rejected');
assert(sameIdentity((await identity()).pub,active.pub)&&(await vault('session')).token==='current-session','active state changed');tests.push('active identity and session preserved');
if(tests.length!==11)throw Error('Incomplete tests'); for(const t of tests)console.log('PASS',t);
});
