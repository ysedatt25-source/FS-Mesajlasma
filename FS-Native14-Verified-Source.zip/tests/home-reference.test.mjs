import test from 'node:test';
import assert from 'node:assert/strict';
import {roomUnreadState,chatList} from '../web/chat-tools.js';
const latest={id:'m',sender:'peer',created:20,payload:{type:'text',text:'Merhaba'}};
test('confirmed delivered unread survives an own last message, including large counts',()=>{
 const room={id:'r',unread_delivered_count:13333,last:{...latest,sender:'self'},created:1};
 assert.deepEqual(roomUnreadState(room,{},'self'),{count:13333,pending:false});
 assert.deepEqual(chatList([room],{},'Okunmamış','','self'),[room]);
});
test('old server and not yet delivered use dot instead of invented count',()=>{
 for(const raw of [undefined,0,-1,1.2,'3',Infinity])assert.deepEqual(roomUnreadState({id:'r',last:latest,unread_delivered_count:raw},{},'self'),{count:0,pending:true});
});
test('known read, local hidden, own, reactions and locked messages do not produce fallback dot',()=>{
 for(const last of [{...latest,receipts_v2:[{user:'self',read_at:21}]},{...latest,sender:'self'},...['reaction','vote','locked'].map(type=>({...latest,payload:{type}}))])assert.deepEqual(roomUnreadState({id:'r',last},{},'self'),{count:0,pending:false});
 for(const prefs of [{read:{r:20}},{hiddenMessages:{r:['m']}}])assert.deepEqual(roomUnreadState({id:'r',last:latest},prefs,'self'),{count:0,pending:false});
});

test('personally removed room is absent until server reports revival',()=>{const room={id:'r',created:1,hidden_from_home:true};for(const filter of ['Tümü','Arşiv','Okunmamış'])assert.deepEqual(chatList([room],{archived:['r']},filter,'','self'),[]);assert.deepEqual(chatList([{...room,hidden_from_home:false}],{},'Tümü','','self').map(r=>r.id),['r']);});
