import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {incomingCallDetails,incomingCallMarkup} from '../web/incoming-call-screen.js';
const avatar=(u,large)=>`<span class="avatar large">${u?.id==='a'?'A':'?'}</span>`;
const direct=(video=false)=>({incoming:true,video,peer:{id:'a',name:'Ayşe Demir'},room:{id:'r'},callId:'c'});
const group=(video=false)=>({incoming:true,group:true,video,host:'a',room:{id:'r',title:'Arkadaşlar',members:[{id:'b',name:'Başka kişi'},{id:'a',name:'Ayşe Demir'}]},callId:'c'});
for (const [label,make] of [['direct',direct],['group',group]])for(const video of [false,true])test(`${label} ${video?'video':'audio'} renders caller, type and safe actions without branding or media preview`,()=>{
 const c=make(video),d=incomingCallDetails(c),html=incomingCallMarkup(c,avatar);
 assert.equal(d.name,'Ayşe Demir');assert.equal(d.caller.id,'a');assert.ok(html.includes(d.type));assert.ok(html.includes('Ayşe Demir'));
 assert.equal(html.includes('Arkadaşlar'),label==='group');assert.equal((html.match(/data-action="(?:accept-call|reject-call|reply-call)"/g)||[]).length,3);
 assert.doesNotMatch(html,/whatsapp|mektup|fs mesajlaşma|<video|<audio|verification|call-voice/i);
 assert.match(html,/aria-labelledby="incoming-caller"/);assert.match(html,/role="status"/);
});
test('untrusted names escaped, blank caller/group fallback',()=>{let c=group();c.room.title='<svg onload="bad()">';c.room.members[1].name='<img src=x onerror=bad()>';const html=incomingCallMarkup(c,avatar);assert.doesNotMatch(html,/<img src=x|<svg onload/);assert.match(html,/&lt;img/);assert.match(html,/&lt;svg/);c.host='missing';c.room.title=' ';assert.equal(incomingCallDetails(c).name,'Arayan kişi');assert.equal(incomingCallDetails(c).group,'Grup görüşmesi');});
test('accepting state disables repeat accept and reply while keeping reject available',()=>{const html=incomingCallMarkup({...direct(true),accepting:true},avatar);assert.match(html,/data-action="accept-call"[^>]*disabled/);assert.match(html,/data-action="reply-call" disabled/);assert.doesNotMatch(html,/data-action="reject-call"[^>]*disabled/);assert.match(html,/Bağlanıyor/);});
const appSource=readFileSync(new URL('../web/app.js',import.meta.url),'utf8');
// Execute the actual relevant application handler cases using fake media/signalling dependencies.
const section=appSource.slice(appSource.indexOf('    case "accept-call":'),appSource.indexOf('    case "end-call":'));
const createHandler=new Function('d',`const {state,callRingtones,window,showCall,setupGroupMedia,setupPeer,endCall,signal}=d;return async a=>{switch(a){${section}}};`);
function fixture(c=direct()){
 const events=[];const state={call:c};let resolve,reject;
 const pending=new Promise((a,b)=>{resolve=a;reject=b;});
 const d={state,callRingtones:{stop:()=>events.push('ring-stop')},window:{FSNative:{dismissCallRingtone:()=>events.push('native-stop')}},showCall:()=>events.push(state.call?.incoming?'incoming':'active'),setupGroupMedia:()=>{events.push('group-media');return pending;},setupPeer:()=>{events.push('media');return pending;},endCall:async()=>{events.push('end');state.call=null;},signal:b=>events.push(b.type)};
 return {d,state,events,resolve,reject,action:createHandler(d)};
}
test('accept starts media only once, renders connecting then active after signalling',async()=>{const f=fixture();let pending=f.action('accept-call');assert.deepEqual(f.events,['ring-stop','native-stop','incoming','media']);await f.action('accept-call');f.resolve();await pending;assert.deepEqual(f.events,['ring-stop','native-stop','incoming','media','accepted','active']);assert.equal(f.state.call.incoming,false);await f.action('reject-call');assert.equal(f.events.at(-1),'active');});
test('group accept uses group media and correct signal',async()=>{const f=fixture(group(true));const p=f.action('accept-call');f.resolve();await p;assert.ok(f.events.includes('group-media'));assert.ok(f.events.includes('group-call-accept'));});
test('reject while accepting prevents stale acceptance and does not open active view',async()=>{const f=fixture();const p=f.action('accept-call');await f.action('reject-call');f.resolve();await p;assert.equal(f.state.call,null);assert.ok(f.events.includes('call-rejected'));assert.ok(!f.events.includes('accepted'));assert.ok(!f.events.includes('active'));});
test('stale media failure cannot end a newer call',async()=>{const f=fixture();const p=f.action('accept-call');await f.action('reject-call');const replacement=group();f.state.call=replacement;f.reject(Error('old failed'));await p;assert.equal(f.state.call,replacement);assert.equal(f.events.filter(x=>x==='end').length,1);});
test('signal failure after capture releases call instead of leaving ringing state',async()=>{const f=fixture();f.d.signal=()=>{throw Error('offline')};const p=createHandler(f.d)('accept-call');f.resolve();await assert.rejects(p,/offline/);assert.equal(f.state.call,null);});
test('reject signal failure still closes local call; no action when call absent',async()=>{const f=fixture();f.d.signal=()=>{throw Error('offline')};const action=createHandler(f.d);await assert.rejects(action('reject-call'),/offline/);assert.equal(f.state.call,null);await action('reject-call');});
test('incoming path precedes active group and direct media rendering',()=>{const start=appSource.indexOf('function showCall()'),stop=appSource.indexOf('async function endCall(',start),code=appSource.slice(start,stop);assert.ok(code.indexOf('if(c.incoming)')<code.indexOf('if(c.group)'));assert.match(code,/if\(c\.incoming\)\{[\s\S]*?app\.innerHTML=incomingCallMarkup\(c,avatar\);\s*return;\s*\}/);});
