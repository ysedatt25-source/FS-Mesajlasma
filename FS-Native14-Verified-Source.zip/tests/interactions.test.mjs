import test from 'node:test';import assert from 'node:assert/strict';import {Window} from 'happy-dom';import {isSingleEmoji,animateEmoji,clearEmojiEffect,effectPlan} from '../web/emoji-effects.js';import {VoiceRecorder,voiceExtension} from '../web/voice-recorder.js';
function fixture({pending=false,denied=false}={}){let time=0,stops=0,resolve;const ready=[],errors=[],status=[];const track={stop:()=>stops++};const stream={getTracks:()=>[track],getAudioTracks:()=>[track]};class Recorder{static isTypeSupported(t){return t==='audio/mp4'}constructor(s,o){this.mimeType=o?.mimeType;this.state='inactive'}start(){this.state='recording'}pause(){this.state='paused'}resume(){this.state='recording'}stop(){this.state='inactive';queueMicrotask(()=>{this.ondataavailable?.({data:new Blob(['audio'])});this.onstop?.()})}}const mediaDevices={getUserMedia:()=>denied?Promise.reject(Object.assign(Error(),{name:'NotAllowedError'})):pending?new Promise(r=>resolve=r):Promise.resolve(stream)};const controller=new VoiceRecorder({mediaDevices,Recorder,onReady:r=>ready.push(r),onError:e=>errors.push(e.message),onStatus:s=>status.push(s.phase),now:()=>time,AudioContext:null});return {controller,ready,errors,status,release:()=>resolve(stream),advance:n=>time=n,stops:()=>stops}}
const flush=()=>new Promise(r=>setTimeout(r,0));
test('Emoji identity includes hearts, butterfly, flags, skin tone, keycaps and ZWJ',()=>{for(const e of ['😂','💜','❤️','🦋','🇹🇷','👍🏽','1️⃣','👨‍👩‍👧‍👦'])assert.equal(isSingleEmoji(e),true,e);for(const x of ['abc','hello 😂','😂😂','1',''])assert.equal(isSingleEmoji(x),false,x)});
test('Character artwork replays locally, replaces pending replay, and respects reduced motion',async()=>{
 const w=new Window(),host=w.document.createElement('div');host.className='fs-chat';
 host.innerHTML='<article><img class="animated-emoji" alt="😂" src="emoji-character/e-1f602.webp"></article>';w.document.body.append(host);
 const target=host.querySelector('article'),jobs=[],paths=[];let finish;
 const fetchAsset=path=>{paths.push(path);return new Promise(resolve=>{finish=resolve})};
 try{
  assert.equal(animateEmoji(target,'😂',{schedule:f=>jobs.push(f),fetchAsset}),true);
  await Promise.resolve();assert.deepEqual(paths,['emoji-character/e-1f602.webp']);
  assert.equal(host.querySelector('.emoji-interactive-layer'),null);
  assert.equal(animateEmoji(target,'😘',{schedule:f=>jobs.push(f),fetchAsset:async()=>({ok:true,blob:async()=>new Blob(['kiss'])}),assetPath:'e-1f618.webp'}),true);
  finish({ok:true,blob:async()=>new Blob(['stale'])});await flush();
  assert.equal(host.querySelectorAll('.emoji-interactive-layer').length,1);
  assert.equal(host.querySelectorAll('.emoji-particle').length,0);
  assert.ok(host.querySelector('.emoji-replay').src.startsWith('blob:'));
  jobs[0]();assert.equal(host.querySelectorAll('.emoji-interactive-layer').length,1);
  jobs[1]();assert.equal(host.querySelector('.emoji-interactive-layer'),null);
  assert.equal(animateEmoji(target,'😂',{reducedMotion:true}),false);
  target.querySelector('img').src='emoji-extra/e-1f1f9_1f1f7.webp';
  assert.equal(animateEmoji(target,'🇹🇷',{fetchAsset}),false,'unverified generic artwork must never replay');
 }finally{clearEmojiEffect();await w.happyDOM.abort()}
});
test('Microphone release while permission pending stops the late stream and creates no recording',async()=>{const f=fixture({pending:true});const p=f.controller.start();f.controller.stop();f.release();await p;assert.equal(f.stops(),1);assert.equal(f.ready.length,0);assert.equal(f.controller.session,null)});
test('Repeated pointer release preserves a completed recording, reports MIME and cleans microphone',async()=>{const f=fixture();await f.controller.start();f.advance(1100);f.controller.stop();f.controller.stop();await flush();assert.equal(f.ready.length,1);assert.equal(f.ready[0].duration,1100);assert.equal(f.ready[0].mime,'audio/mp4');assert.equal(voiceExtension(f.ready[0].mime),'m4a');assert.ok(f.stops()>0);assert.deepEqual(f.status,['permission','recording','stopping','idle'])});
test('Cancellation/navigation cannot publish an old recording into another chat',async()=>{const f=fixture();await f.controller.start();f.advance(1000);f.controller.cancel();await flush();assert.equal(f.ready.length,0);assert.equal(f.controller.session,null);assert.ok(f.stops()>0)});
test('Denied microphone and very short clips produce actionable errors and no pending file',async()=>{const f=fixture({denied:true});await f.controller.start();assert.match(f.errors[0],/Mikrofon izni/);assert.equal(f.controller.session,null);const g=fixture();await g.controller.start();g.advance(100);g.controller.stop();await flush();assert.match(g.errors[0],/çok kısa/);assert.equal(g.ready.length,0)});

test('Paused voice recording excludes paused time, resumes the same clip and can finish paused',async()=>{const f=fixture();await f.controller.start();f.advance(1000);f.controller.pause();assert.equal(f.controller.session.recorder.state,'paused');f.advance(9000);f.controller.resume();f.advance(10000);f.controller.pause();f.advance(12000);f.controller.stop();await flush();assert.equal(f.ready[0].duration,2000);assert(f.status.includes('paused'));assert.equal(f.ready.length,1)});
