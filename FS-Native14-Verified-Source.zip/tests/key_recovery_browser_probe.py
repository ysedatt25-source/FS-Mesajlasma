"""Real Chromium WebCrypto + IndexedDB checks, no live network, no production data."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
 pg=b.new_page()
 pg.route('https://recovery-qa.invalid/**',lambda route:route.fulfill(status=200,content_type='text/html',body='<!doctype html><html><body></body></html>'))
 pg.goto('https://recovery-qa.invalid/')
 js='\n'.join(line.replace('export ','') for line in (root/'crypto.js').read_text().splitlines() if not line.startswith('export { calculate }'))
 pg.evaluate('()=>{'+js+'''\nwindow.recoveryQA=async()=>{
 const original=await identity();await prepareRecovery('account-password');const packet=await createRecoveryExport(await vault('recovery'),'account-password','durable recovery password','account-a',original.pub);
 const reject=async p=>{try{await p;return false}catch{return true}};
 const wrong=await reject(inspectRecovery(packet,'incorrect password'));
 const candidate=await inspectRecovery(packet,'durable recovery password');
 const peer=await crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveKey']);const peerPub=await crypto.subtle.exportKey('jwk',peer.publicKey);
 const message=await seal(await peerKey(peer.privateKey,original.pub),{text:'old ciphertext'},'room');
 await vault('identity',null);const fresh=await identity();
 const staged=(await identity()).pub.x===fresh.pub.x&&fresh.pub.x!==original.pub.x;
 const other=await reject(commitRecovery(candidate,{token:'test',user:{id:'wrong',pub:candidate.pub}}));
 const cancelled=await reject(commitRecovery(candidate,{token:'test',user:{id:'account-a',pub:candidate.pub}},()=>false));
 const unchanged=(await identity()).pub.x===fresh.pub.x;
 await commitRecovery(candidate,{token:'test',user:{id:'account-a',pub:candidate.pub}});
 const recovered=await identity(),result=await open(await peerKey(recovered.pair.privateKey,peerPub),message,'room');
 return {wrong,staged,other,cancelled,unchanged,restored:recovered.pub.x===original.pub.x&&result.text==='old ciphertext',nonextractable:!recovered.pair.privateKey.extractable,session:(await vault('session')).user.id==='account-a'};
 };}''')
 result=pg.evaluate('recoveryQA()');assert result['wrong'];print('PASS real WebCrypto rejects wrong recovery password')
 assert result['staged'] and result['other'] and result['cancelled'] and result['unchanged'];print('PASS real IndexedDB never changes identity before matching successful login')
 assert result['restored'] and result['nonextractable'] and result['session'];print('PASS real IndexedDB restores session and nonextractable private key that decrypts earlier ciphertext')
 b.close()
