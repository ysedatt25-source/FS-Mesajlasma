import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {readFile} from 'node:fs/promises';
const [base,cryptoPath,interactionPath]=process.argv.slice(2);
const {peerKey,seal,open}=await import(pathToFileURL(cryptoPath));
const {matchesInteraction}=await import(pathToFileURL(interactionPath));
async function req(path,{token,method='GET',body}={}){
 const r=await fetch(base+path,{method,headers:{...(token?{Authorization:'Bearer '+token}:{}),...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined});
 const v=await r.json();assert.ok(r.ok,JSON.stringify(v));return v;
}
async function account(nick,phone){
 const pair=await crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveKey']);
 const pub=await crypto.subtle.exportKey('jwk',pair.publicKey);
 const data=await req('/api/session',{method:'POST',body:{register:true,privacy_accepted:true,nick,name:nick,phone,password:'test-password-only',invite:'0032',pub}});
 return {...data,pair,pub};
}
function socket(account){
 const ws=new WebSocket(base.replace(/^http/,'ws')+'/api/socket');const queue=[];let wake;
 ws.addEventListener('message',e=>{queue.push(JSON.parse(e.data));wake?.();});
 const opened=new Promise((resolve,reject)=>{ws.addEventListener('open',()=>{ws.send(JSON.stringify({token:account.token}));resolve()},{once:true});ws.addEventListener('error',reject,{once:true});});
 async function next(timeout=2000){await opened;if(!queue.length)await new Promise((resolve,reject)=>{const t=setTimeout(()=>{wake=null;reject(Error('timeout'));},timeout);wake=()=>{clearTimeout(t);wake=null;resolve();};});return queue.shift();}
 return {ws,next,queue,send:x=>ws.send(JSON.stringify(x))};
}
const a=await account('cryptoa','+905004444401'),b=await account('cryptob','+905004444402'),c=await account('cryptoc','+905004444403');
const room=(await req('/api/rooms',{token:a.token,method:'POST',body:{members:[b.user.id]}})).id;
const ab=await peerKey(a.pair.privateKey,b.pub),ba=await peerKey(b.pair.privateKey,a.pub),aa=await peerKey(a.pair.privateKey,a.pub);
const wrong=await peerKey(c.pair.privateKey,a.pub);
const tests=['😘','😜','❤️']; const sockets=[];
try{
 const sa=socket(a),sb=socket(b),sc=socket(c);sockets.push(sa,sb,sc);
 for (const s of sockets) assert.ok((await s.next()).features.includes('emoji-interaction-v1'));
 for(const [i,emoji] of tests.entries()){
  const id='encrypted_emoji_'+i,payload={type:'text',text:emoji};
  await req('/api/rooms/'+room+'/messages',{token:a.token,method:'POST',body:{id,envelopes:{[a.user.id]:await seal(aa,payload,room),[b.user.id]:await seal(ab,payload,room)}}});
  assert.equal((await sa.next()).type,'message');assert.equal((await sb.next()).type,'message');
  const messages=await req('/api/rooms/'+room+'/messages',{token:b.token});const record=messages.find(x=>x.id===id);assert.deepEqual(await open(ba,record.envelope,room),payload);
  const event={type:'emoji-interaction-v1',id:'interaction_'+i,target:id,emoji};const envelope=await seal(ab,event,room);
  sa.send({type:event.type,id:event.id,target:id,room,envelopes:{[b.user.id]:envelope,[c.user.id]:envelope}});
  const received=await sb.next();assert.equal(received.from,a.user.id);assert.equal(received.target,id);assert.ok(!('emoji' in received));
  const decrypted=await open(ba,received.envelope,room);assert.deepEqual(decrypted,event);assert.ok(matchesInteraction(decrypted,{id,room,payload},room));
  await assert.rejects(open(wrong,received.envelope,room));await assert.rejects(open(ba,received.envelope,'wrong-room'));
  sa.send({type:event.type,id:event.id,target:id,room,envelopes:{[b.user.id]:envelope}});
  await assert.rejects(sb.next(150),/timeout/);await assert.rejects(sc.next(150),/timeout/);
  console.log('PASS encrypted emoji, room binding, outsider rejection, replay:',emoji);
 }
 assert.equal((await req('/api/rooms/'+room+'/messages',{token:b.token})).length,3);
 console.log('PASS: interaction events are not persisted as extra messages');
}finally{for(const s of sockets)s.ws.close();}
