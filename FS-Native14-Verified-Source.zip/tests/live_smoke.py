"""Explicit live synthetic integration probe. Never targets an implicit URL."""
import asyncio,os,json,time,base64,secrets
import aiohttp
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
BASE=os.environ['FS_LIVE_TEST_URL'];assert BASE.startswith('https://')
ORIGIN='https://appassets.androidplatform.net'
def b64(b):return base64.b64encode(b).decode()
def seal(key,payload,aad):
 iv=secrets.token_bytes(12);return dict(iv=b64(iv),data=b64(AESGCM(key).encrypt(iv,json.dumps(payload).encode(),aad.encode())))
async def main():
 stamp=secrets.token_hex(4);report=[]
 async with aiohttp.ClientSession(trust_env=True,timeout=aiohttp.ClientTimeout(total=30)) as c:
  async def api(path,body=None,token=None,method=None):
   async with c.request(method or ('POST' if body else 'GET'),BASE+'/api'+path,json=body,headers={'Origin':ORIGIN,**({'Authorization':'Bearer '+token} if token else {})}) as r:
    data=await r.json();assert r.status<300,(path,r.status,data);assert r.headers.get('Access-Control-Allow-Origin')==ORIGIN;return data
  async def user(n):
   k=ec.generate_private_key(ec.SECP256R1());p=k.public_key().public_numbers();pub={'kty':'EC','crv':'P-256','x':base64.urlsafe_b64encode(p.x.to_bytes(32,'big')).decode().rstrip('='),'y':base64.urlsafe_b64encode(p.y.to_bytes(32,'big')).decode().rstrip('=')}
   nick='fsqa_'+stamp+n;password=secrets.token_hex(6)
   a=await api('/session',dict(register=True,privacy_accepted=True,name='FS QA temporary '+n,nick=nick,phone='+999'+str(int(time.time()*1000))[-9:]+n,password=password,invite='0032',pub=pub))
   await api('/session',dict(login=nick,password=password,pub=pub));return a,k,pub,nick
  a,ak,ap,an=await user('1');b,bk,bp,bn=await user('2');at=a['token'];bt=b['token'];report.append('HTTPS registration/login and Android CORS')
  people=await api('/people?q='+bn,token=at);assert people[0]['id']==b['user']['id'] and 'phone' not in people[0]
  room=(await api('/rooms',dict(members=[b['user']['id']]),at))['id'];report.append('Username search and private room creation')
  async with c.ws_connect(BASE+'/api/socket',origin=ORIGIN) as wa,c.ws_connect(BASE+'/api/socket',origin=ORIGIN) as wb:
   await wa.send_json(dict(token=at));await wb.send_json(dict(token=bt));assert (await wa.receive_json())['type']=='connected';assert (await wb.receive_json())['type']=='connected'
   async def event(ws,kind):
    for i in range(20):
     e=await ws.receive_json(timeout=10)
     if e.get('type')==kind:return e
    raise AssertionError(kind)
   key=ak.exchange(ec.ECDH(),bk.public_key());payload=dict(type='text',text='FS live QA '+stamp);env={a['user']['id']:seal(ak.exchange(ec.ECDH(),ak.public_key()),payload,room),b['user']['id']:seal(key,payload,room)}
   m=await api('/rooms/'+room+'/messages',dict(envelopes=env),at);await event(wb,'message');rows=await api('/rooms/'+room+'/messages',token=bt);e=rows[0]['envelope'];decoded=AESGCM(bk.exchange(ec.ECDH(),ak.public_key())).decrypt(base64.b64decode(e['iv']),base64.b64decode(e['data']),room.encode());assert json.loads(decoded)==payload;report.append('WSS realtime message and independent AES-GCM decryption')
   raw=b'FS synthetic encrypted upload';filekey=secrets.token_bytes(32);iv=secrets.token_bytes(12);cipher=AESGCM(filekey).encrypt(iv,raw,None);u=await api('/uploads',dict(room=room,size=len(cipher)),at)
   async with c.put(BASE+'/api/uploads/'+u['id'],data=cipher,headers={'Authorization':'Bearer '+at,'Upload-Offset':'0'}) as r:assert r.status==200
   async with c.get(BASE+'/api/uploads/'+u['id'],headers={'Authorization':'Bearer '+bt}) as r:assert r.status==200;assert AESGCM(filekey).decrypt(iv,await r.read(),None)==raw
   await api('/uploads/'+u['id'],token=at,method='DELETE');await api('/messages/'+m['id'],token=at,method='DELETE');report.append('Encrypted upload/download; test message and file deleted')
   await wa.send_json(dict(type='call',room=room));await event(wb,'call');await wb.send_json(dict(type='accepted',room=room));await event(wa,'accepted');await wa.send_json(dict(type='hangup',room=room));await event(wb,'hangup');report.append('Call invite/accept/hangup signaling; media not tested')
  print(json.dumps(dict(passed=len(report),reports=report,testUsers=[an,bn],scope='Synthetic accounts retained. No physical device or TURN media test.'),indent=2))
asyncio.run(main())
