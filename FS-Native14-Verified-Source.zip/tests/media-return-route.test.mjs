import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
const source=readFileSync(new URL('../web/app.js',import.meta.url),'utf8');
const media=source.slice(source.indexOf('let mediaCursor='),source.indexOf('async function loadMediaPage()'));
const start=source.indexOf('    case "back":');
const back=source.slice(start,source.indexOf('    case "auth-toggle":',start));
function fixture(page){
 const state={page,mediaFilter:'Tümü',mediaDate:'',mediaQuery:''};
 const el={}; const context=vm.createContext({state,isLocked:()=>false,rememberChat(){},shell(){},$(){return el},loadMediaPage:async()=>{},home(){state.page='home'},profile(){state.page='profile'}});
 vm.runInContext(media+'\nfunction goBack(){switch("back"){'+back+'}}',context);
 return {state,open:()=>vm.runInContext('mediaPage()',context),back:()=>vm.runInContext('goBack()',context)};
}
for(const route of ['home','profile'])test('Media returns to its actual entry screen: '+route,async()=>{const f=fixture(route);await f.open();assert.equal(f.state.page,'media');await f.open();f.back();assert.equal(f.state.page,route);});
test('Peer media cannot switch to global on refresh; back restores actual peer',async()=>{
 const peer={id:'peer'},state={page:'peer',room:{id:'r',kind:'direct',members:[{id:'self'},peer]},user:{id:'self'},mediaFilter:'Tümü',mediaDate:'',mediaQuery:''};
 const el={};const context=vm.createContext({state,isLocked:()=>false,rememberChat(){},shell(){},$(){return el},loadMediaPage:async()=>{},home(){state.page='home'},profile(p){assert.equal(p,peer);state.page='peer'}});
 vm.runInContext(media+'\nfunction goBack(){switch("back"){'+back+'}}',context);
 await vm.runInContext('mediaPage("other")',context);assert.equal(state.page,'peer');
 state.mediaFilter="Videolar";state.mediaQuery="başka";state.mediaDate="2026-11-01";
 await vm.runInContext('mediaPage("r")',context);assert.equal(state.page,'media');assert.deepEqual([state.mediaFilter,state.mediaQuery,state.mediaDate],["Tümü","",""]);assert.equal(vm.runInContext('mediaRoomScope',context),'r');
 state.mediaFilter='Dosyalar';await vm.runInContext('mediaPage()',context);assert.equal(state.mediaFilter,'Dosyalar');assert.equal(vm.runInContext('mediaRoomScope',context),'r');vm.runInContext('goBack()',context);assert.equal(state.page,'peer');
});
