package com.fs.mesajlasma;
public final class AudioRoutePolicyTest {
 static int checks;
 static void eq(String wanted,String pref,boolean video,boolean bt,boolean wired,boolean ear,boolean sp){checks++;String got=AudioRoutePolicy.target(pref,video,bt,wired,ear,sp);if(!wanted.equals(got))throw new AssertionError(wanted+" != "+got);}
 public static void main(String[] args){
  eq("earpiece","auto",false,false,false,true,true);
  eq("speaker","auto",true,false,false,true,true);
  eq("bluetooth","auto",false,true,false,true,true);
  eq("bluetooth","auto",true,true,false,true,true);
  eq("bluetooth","auto",true,true,true,true,true);
  eq("speaker","speaker",false,true,true,true,true);
  eq("earpiece","earpiece",true,true,false,true,true);
  eq("bluetooth","bluetooth",true,true,true,true,true);
  eq("earpiece","bluetooth",true,false,false,true,true);
  eq("bluetooth","bluetooth",true,true,false,true,true);
  eq("earpiece","wired",true,true,false,true,true);
  eq("wired","wired",false,true,true,true,true);
  eq("speaker","earpiece",false,false,false,false,true);
  eq("speaker","auto",false,false,false,false,true);
  eq("unknown","auto",false,false,false,false,false);
  eq("wired","bluetooth",false,false,true,false,true);
  for(String r:new String[]{"auto","speaker","earpiece","bluetooth","wired"}){checks++;if(!AudioRoutePolicy.valid(r))throw new AssertionError(r);}
  for(String r:new String[]{null,"","other","unknown"}){checks++;if(AudioRoutePolicy.valid(r))throw new AssertionError(r);}
  System.out.println("PASS "+checks+" audio route policy checks");
 }
}
