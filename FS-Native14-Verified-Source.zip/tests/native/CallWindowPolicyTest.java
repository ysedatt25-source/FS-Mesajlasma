package com.fs.mesajlasma;
public final class CallWindowPolicyTest {
 static int checks;static void check(boolean x){checks++;if(!x)throw new AssertionError("check "+checks);}
 public static void main(String[] args){
  check(CallWindowPolicy.valid("abc","abc",40000,1000,100000,61000));
  check(!CallWindowPolicy.valid("old","new",40000,1000,100000,61000));
  check(!CallWindowPolicy.valid("bad/id","bad/id",40000,1000,100000,61000));
  check(!CallWindowPolicy.valid(null,"abc",40000,1000,100000,61000));
  check(!CallWindowPolicy.valid("abc","abc",1000,1000,100000,61000));
  check(!CallWindowPolicy.valid("abc","abc",40000,1000,61000,61000));
  check(!CallWindowPolicy.valid("abc","abc",50000,1000,100000,61000));
  check(!CallWindowPolicy.valid("abc","abc",40000,1000,120000,61000));
  check(!CallWindowPolicy.validId(""));check(!CallWindowPolicy.validId(new String(new char[129]).replace('\0','a')));
  check(CallWindowPolicy.validId("a_B-9"));System.out.println("PASS "+checks+" call-window lifetime and identity checks");
 }
}
