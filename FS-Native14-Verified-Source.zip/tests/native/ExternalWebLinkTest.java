package com.fs.mesajlasma;
public class ExternalWebLinkTest {
 public static void main(String[] args){String good="https://example.org/a%20b?q=1&x=2#p";if(!good.equals(ExternalWebLink.validate(good)))throw new AssertionError("exact URL");System.out.println("PASS exact path query fragment");for(String bad:new String[]{"javascript:alert(1)","file:///etc/passwd","intent://example.org","https://a:b@example.org/","https://appassets.androidplatform.net/index.html","https://example.org/\nfoo","not a link"}){if(ExternalWebLink.validate(bad)!=null)throw new AssertionError(bad);System.out.println("PASS rejected "+bad.replace("\n","\\n"));}if(!"http://example.org/a".equals(ExternalWebLink.validate("http://example.org/a")))throw new AssertionError("http");System.out.println("PASS http URL");}
}
