package com.fs.mesajlasma;

public class IncomingCallNoticeTest {
 private static void check(boolean condition,String description){if(!condition)throw new AssertionError(description);System.out.println("PASS "+description);}
 public static void main(String[] args){
  IncomingCallNotice state=new IncomingCallNotice();
  check(state.observe("call_a",45000)==IncomingCallNotice.Action.POST,"new incoming call requests notification");
  check(state.observe("call_a",43000)==IncomingCallNotice.Action.POST,"unposted notification can be retried after permission grant");
  state.posted("call_a");
  check(state.observe("call_a",25000)==IncomingCallNotice.Action.KEEP,"heartbeat never re-rings posted call");
  check(!state.matches("old_id")&&state.matches("call_a"),"stale legacy hangup cannot dismiss a new call");
  check(state.observe("call_b",30000)==IncomingCallNotice.Action.POST,"new call replaces previous call");
  state.posted("call_b");state.posted("call_a");
  check(state.observe("call_b",2000)==IncomingCallNotice.Action.KEEP,"stale acknowledgement cannot modify new call state");
  check(state.observe("call_b",0)==IncomingCallNotice.Action.CLEAR&&state.known().isEmpty(),"expired invitation clears notification and known ID");
  check(state.observe("invalid/id",1000)==IncomingCallNotice.Action.CLEAR,"invalid identifiers rejected");
  check(IncomingCallNotice.duration(99000)==45000&&IncomingCallNotice.duration(-1)==0,"notification lifetime capped to 45 seconds");
  check(IncomingCallNotice.nextRetry(1000)==2000&&IncomingCallNotice.nextRetry(8000)==8000,"network retry is bounded");
  state.observe("call_c",1000);state.posted("call_c");state.reset();
  check(state.observe("call_c",1000)==IncomingCallNotice.Action.POST,"account change resets notification state");
 }
}
