package com.fs.mesajlasma;
public class MessageAlertPolicyTest {
 static int count;
 static void check(boolean ok){if(!ok)throw new AssertionError("test "+(count+1));count++;}
 public static void main(String[] args){String a="message_alert_001",b="message_alert_002";
 check(MessageAlertPolicy.validId(a));check(!MessageAlertPolicy.validId(null));check(!MessageAlertPolicy.validId("../invalid"));check(!MessageAlertPolicy.validId("short"));
 check(MessageAlertPolicy.fresh(a,2,"",0));check(!MessageAlertPolicy.fresh(a,2,a,2));check(!MessageAlertPolicy.fresh(a,1,b,2));check(MessageAlertPolicy.fresh(b,2,a,2));check(!MessageAlertPolicy.fresh(a,2,b,2));check(!MessageAlertPolicy.fresh(a,0,"",0));
 check(MessageAlertPolicy.suppress(true,a,a));check(!MessageAlertPolicy.suppress(false,a,a));check(!MessageAlertPolicy.suppress(true,b,a));check(!MessageAlertPolicy.suppress(true,"",a));
 check(MessageAlertPolicy.count(0)==1);check(MessageAlertPolicy.count(900)==500);check(MessageAlertPolicy.count(3)==3);
 check(MessageAlertPolicy.label("Alice",false).equals("Yeni mesaj"));check(MessageAlertPolicy.label("Alice",true).equals("Alice"));check(MessageAlertPolicy.label("A\n\u202eB",true).equals("AB"));check(MessageAlertPolicy.label(" ",true).equals("Yeni mesaj"));check(MessageAlertPolicy.label(null,true).equals("Yeni mesaj"));check(MessageAlertPolicy.label("a".repeat(90),true).length()==80);check(MessageAlertPolicy.description(2).startsWith("2 yeni mesaj"));
 check(!MessageAlertPolicy.avatarCandidate(null));check(!MessageAlertPolicy.avatarCandidate("https://example.com/a.jpg"));check(!MessageAlertPolicy.avatarCandidate(MessageAlertPolicy.AVATAR_PREFIX+"a".repeat(150000)));check(MessageAlertPolicy.avatarCandidate(MessageAlertPolicy.AVATAR_PREFIX+"/9j/2Q=="));
 check(MessageAlertPolicy.jpegHeader(new byte[]{-1,-40,-1,-1,-39}));check(!MessageAlertPolicy.jpegHeader(new byte[]{-1,-40,-1,0}));check(!MessageAlertPolicy.jpegHeader(null));
 check(MessageAlertPolicy.avatarSample(512,512)==2);check(MessageAlertPolicy.avatarSample(4096,4096)==0);check(MessageAlertPolicy.avatarSample(-1,50)==0);check(MessageAlertPolicy.avatarSample(4096,100)==16);check(MessageAlertPolicy.avatarSample(64,64)==1);
 check(MessageAlertPolicy.avatarFingerprint("invalid").isEmpty());check(!MessageAlertPolicy.avatarFingerprint(MessageAlertPolicy.AVATAR_PREFIX+"aa").equals(MessageAlertPolicy.avatarFingerprint(MessageAlertPolicy.AVATAR_PREFIX+"bb")));
 System.out.println(count+"/"+count+" message policy checks passed");}
}
