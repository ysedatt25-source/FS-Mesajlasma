package com.fs.mesajlasma;
public final class ProjectionSessionTest {
 static void ok(boolean x){if(!x)throw new AssertionError();}
 public static void main(String[] args){ProjectionSession s=new ProjectionSession();String a="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",b="bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
 ok(!s.begin("bad",0));ok(s.begin(a,0));ok(!s.begin(b,0));ok(s.waiting(a));ok(s.poll(a,0,1).equals("waiting"));ok(s.poll(b,0,1).equals("ended"));ok(!s.activate(b,2));ok(s.activate(a,2));ok(s.poll(a,0,3).equals("active"));s.publish(b,"wrong");ok(s.poll(a,0,4).equals("active"));s.publish(a,"jpeg");ok(s.poll(a,0,5).equals("frame|1|jpeg"));ok(s.poll(a,1,6).equals("active"));ok(!s.cancel(b));ok(s.cancel(a));ok(s.poll(a,0,7).equals("ended"));ok(!s.activate(a,8));ok(s.begin(b,9));ok(!s.waiting(a));s.publish(a,"late");ok(s.activate(b,10));ok(s.poll(b,0,11).equals("active"));ok(!s.alive(b,10012));ok(s.poll(b,0,10012).equals("ended"));ok(s.begin(a,10013));s.cancelAll();ok(!s.activate(a,10014));System.out.println("PASS: 24 projection consent, isolation, cleanup and expiry checks");}
}
