import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {characterAssetPath} from '../web/emoji-effects.js';
const read=n=>JSON.parse(fs.readFileSync(new URL('../'+n,import.meta.url),'utf8'));
test('all 881 frozen Noto Unicode entries resolve to their exact authored bytes',()=>{
 const catalog=read('licenses/noto-animation-catalog.json'),legacy=read('web/emojis.json');
 assert.equal(catalog.length,881);assert.equal(new Set(catalog.map(x=>x.file)).size,881);
 assert.deepEqual(catalog.map(({emoji,file})=>({emoji,file})),legacy);
 for(const row of catalog){
  assert.equal(characterAssetPath(row.file),'emoji/'+row.file);
  const bytes=fs.readFileSync(new URL('../web/emoji/'+row.file,import.meta.url));
  assert.equal(createHash('sha256').update(bytes).digest('hex'),row.sha256);
  assert(row.frames>1);assert.match(row.source,/^https:\/\/fonts\.gstatic\.com\/s\/e\/notoemoji\/latest\/[a-f0-9_]+\/512\.webp$/);
 }
});
test('unverified paths and generic deformation never enter the authored catalog',()=>{
 for(const path of ['../1f602.webp','https://example.com/1f602.webp','emoji/1f602.webp','e-1f1f9_1f1f7.webp','unknown.webp'])assert.equal(characterAssetPath(path),null);
});
