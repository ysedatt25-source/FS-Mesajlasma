import test from 'node:test';
import assert from 'node:assert/strict';
import {photoBounds,photoZoom} from '../web/photo-gestures.js';
test('fit is uncropped and no pan at original zoom',()=>assert.deepEqual(photoBounds({scale:1,x:900,y:-900},300,600,1200,600),{scale:1,x:0,y:0}));
test('pan is clamped at actual image edges, not the letterbox',()=>assert.deepEqual(photoBounds({scale:3,x:999,y:-999},300,600,1200,600),{scale:3,x:300,y:0}));
test('portrait image permits vertical pan only when necessary',()=>assert.deepEqual(photoBounds({scale:2,x:999,y:999},600,300,600,1200),{scale:2,x:0,y:150}));
test('invalid values reset and scale is bounded',()=>{assert.deepEqual(photoBounds({scale:Infinity,x:NaN,y:Infinity},300,300,0,0),{scale:1,x:0,y:0});assert.equal(photoBounds({scale:99,x:0,y:0},300,300,300,300).scale,5);});
test('zoom maintains finger anchor',()=>assert.deepEqual(photoZoom({scale:1,x:0,y:0},2,{x:30,y:-20}),{scale:2,x:-30,y:20}));
test('pinch midpoint can move while scaling',()=>assert.deepEqual(photoZoom({scale:2,x:10,y:20},4,{x:20,y:40},{x:25,y:50}),{scale:4,x:5,y:10}));
