import {test} from 'node:test';
import assert from 'node:assert/strict';
import {pipGeometry,pipRatio} from '../web/call-chat-fixes.js';
test('all sizes, positions and viewport shapes fit without changing aspect ratio',()=>{
 for(const [width,height] of [[390,640],[640,180],[20,150],[300,0],[0,0],[300,30]])for(const preferred of [72,128,180,240])for(const x of [0,.5,1])for(const y of [0,.5,1]){
  const b={left:4,top:50,width,height},g=pipGeometry(b,preferred,{x,y});
  assert(g.left>=b.left&&g.top>=b.top&&g.left+g.width<=b.left+width+1e-6&&g.top+g.height<=b.top+height+1e-6);assert.equal(g.width,g.height*.75);
 }
});
test('keyboard temporarily shrinks video, preferred size returns unchanged',()=>{
 const ratio={x:.7,y:.8};const small=pipGeometry({left:0,top:100,width:390,height:45},180,ratio);assert.equal(small.height,45);
 assert.equal(pipGeometry({left:0,top:100,width:390,height:500},180,ratio).height,180);
});
test('dragging to edge clamps ratios and preserves position on collapsed axes',()=>{
 const b={left:4,top:10,width:120,height:200};assert.deepEqual(pipRatio(b,{width:90,height:100},-900,900),{x:0,y:1});
 assert.deepEqual(pipRatio(b,{width:120,height:200},-900,900,{x:.2,y:.8}),{x:.2,y:.8});
});
