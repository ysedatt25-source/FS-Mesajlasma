import test from 'node:test';
import assert from 'node:assert/strict';

import {accountIssues,showNotice} from '../web/feedback.js';
const valid={name:'Test',nick:'test_user',phone:'0542 123 45 67',invite:'0032',privacy:'on',password:'123456',passwordConfirm:'123456',email:'test@example.com'};
test('Registration lists missing fields together and accepts the six-character password',()=>{
 assert.deepEqual(accountIssues(valid,true),[]);
 assert.deepEqual(new Set(accountIssues({},true).map(x=>x.field)),new Set(['name','nick','phone','invite','privacy','password','email']));
});
test('Account validation rejects malformed nick, phone, invitation and short password',()=>{
 for(const [field,value] of [['nick','a!'],['phone','12'],['invite','0000'],['password','12345'],['privacy','']])assert(accountIssues({...valid,[field]:value},true).some(x=>x.field===field),field);
 assert.deepEqual(accountIssues({...valid,phone:'+90 (542) 123 45 67'},true),[]);
});
test('Login validates its own required fields without requiring registration fields',()=>{
 assert.deepEqual(accountIssues({login:'test_user',password:'123456'},false),[]);
 assert.equal(accountIssues({login:' ',password:'123456'},false)[0].field,'login');
});
