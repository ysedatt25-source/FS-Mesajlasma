import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
import {effectiveStatus} from '../web/call-chat-fixes.js';
const source=fs.readFileSync(new URL('../web/app.js',import.meta.url),'utf8');
const start=source.indexOf('let presenceAuthenticated=false');const end=source.indexOf("document.addEventListener('visibilitychange'",start);assert.ok(start>=0&&end>start);const code=source.slice(start,end);
function setup(fetch){const state={token:'synthetic-session',user:{id:'a'},locked:false,page:'chat'};const ctx={state,document:{hidden:false},navigator:{onLine:true},localStorage:{getItem:()=>null},apiRoot:'https://synthetic.invalid',fetch,notice:()=>{},effectiveStatus,queueMicrotask};vm.runInNewContext(code+'\npresenceAuthenticated=true;',ctx);return ctx;}
test('expiry-aware server receives actual repeated heartbeat',async()=>{const events=[],ctx=setup(async(u,o)=>{events.push(JSON.parse(o.body).status);return {ok:true}});await ctx.syncPresence();await ctx.syncPresence();await ctx.syncPresence(true);assert.deepEqual(events,['online','online']);});
test('queued pagehide preserves explicit leaving flag',async()=>{const events=[];let release;const ctx=setup(async(u,o)=>{events.push(JSON.parse(o.body).status);if(events.length===1)await new Promise(r=>release=r);return {ok:true}});const pending=ctx.syncPresence();await ctx.syncPresence(true,true);release();await pending;await new Promise(r=>setImmediate(r));assert.deepEqual(events,['online','offline']);});
test('v2 publishes ordered lifecycle and heartbeat frames, not HTTP',async()=>{
 const events=[];const ctx=setup(async()=>{throw Error('unexpected HTTP')});ctx.state.presenceSocket=true;ctx.state.socket={readyState:1,send:v=>events.push(JSON.parse(v))};
 await ctx.syncPresence();await ctx.syncPresence();await ctx.syncPresence(true);ctx.document.hidden=true;await ctx.syncPresence();ctx.document.hidden=false;await ctx.syncPresence();
 assert.deepEqual(events.map(e=>e.foreground),[true,true,false,true]);assert.equal(ctx.state.user.status,'online');assert.ok(events.every(e=>e.type==='presence-socket-v2'));
});
test('native pause overrides visible WebView and does not change preference',async()=>{
 const events=[];const ctx=setup(async()=>{throw Error('unexpected HTTP')});let nativeVisible=true;ctx.window={FSNative:{isForeground:()=>nativeVisible}};ctx.state.presenceSocket=true;ctx.state.socket={readyState:1,send:v=>events.push(JSON.parse(v))};ctx.localStorage.getItem=()=> 'busy';await ctx.syncPresence();nativeVisible=false;await ctx.syncPresence(true);assert.equal(ctx.state.user.status,'offline');nativeVisible=true;await ctx.syncPresence(true);assert.equal(ctx.state.user.status,'busy');assert.deepEqual(events.map(e=>[e.foreground,e.preference]),[[true,'busy'],[false,'busy'],[true,'busy']]);
});
