import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {createAccessGate} from '../web/access-gate.js';
const source=fs.readFileSync(new URL('../web/app.js',import.meta.url),'utf8');
const take=(a,b)=>source.slice(source.indexOf(a),source.indexOf(b,source.indexOf(a)));
const code=take('async function profilePhoto()','function importKeyDialog()');
const image={type:'image/png',size:123};
const jpeg='data:image/jpeg;base64,AAAA';
async function fixture(opts={}){
 const access=createAccessGate(async()=>true);await access.submit('123456',true);
 const controls=[{},{}],trace=[];
 const fileInput={dataset:{},files:[],isConnected:true,parentElement:{querySelectorAll:()=>controls},click(){trace.push('picker')}};
 const state={page:'profile',user:{id:'owner'},token:'authenticated'};
 const c={state,access,isLocked:()=>access.locked,$:s=>s==='#profile-photo-file'?fileInput:null,createImageBitmap:async()=>({width:640,height:480,close:()=>trace.push('close bitmap')}),document:{createElement:()=>({getContext:()=>({drawImage:(...args)=>trace.push(['crop',...args.slice(1)])}),toDataURL:()=>jpeg})},patchSettings:async p=>trace.push(['save',p.avatar]),profile:()=>trace.push('render'),notice:(...args)=>trace.push(['notice',...args]),...opts};
 vm.createContext(c);vm.runInContext(code,c);
 const select=async f=>{fileInput.files=f?[f]:[];await fileInput.onchange()};return {c,access,state,fileInput,controls,trace,select};
}
test('owner profile renders a separate accessible change icon and single image picker; peer does not',()=>{const code=take('function profile(peer = state.user)','function settings()');const ctx={state:{user:{id:'owner'},settings:{}},isLocked:()=>false,discardVoice(){},shell:(title,body)=>ctx.html=body,escape:s=>s,avatar:()=>'<span class="avatar"></span>',icon:()=>'<svg></svg>',row:()=>''};vm.createContext(ctx);vm.runInContext(code,ctx);ctx.profile({id:'owner'});assert.match(ctx.html,/class="profile-photo-change"[^>]*aria-label="Profil resmini değiştir"/);assert.match(ctx.html,/id="profile-photo-file" type="file" accept="image\/jpeg,image\/png,image\/webp" hidden/);assert(ctx.html.indexOf('profile-avatar-button')<ctx.html.indexOf('profile-photo-change'));ctx.profile({id:'peer'});assert(!ctx.html.includes('profile-photo-change'));assert(!ctx.html.includes('profile-photo-file'));});
test('selecting a photo crops, saves, refreshes and releases bitmap',async()=>{const f=await fixture();await f.c.profilePhoto();await f.select(image);assert.deepEqual(f.trace.map(x=>Array.isArray(x)?x[0]:x),['picker','crop','save','render','notice','close bitmap']);assert.deepEqual(f.trace[1].slice(1),[80,0,480,480,0,0,512,512]);assert.equal(f.trace[2][1],jpeg);assert(!f.controls.some(x=>x.disabled));});
test('cancel selection makes no changes and allows choosing again',async()=>{const f=await fixture();await f.c.profilePhoto();await f.select();await f.c.profilePhoto();assert.deepEqual(f.trace,['picker','picker']);});
test('empty, oversized and non-image files are rejected before decoding',async()=>{const f=await fixture({createImageBitmap:()=>{throw Error('unexpected decode')}});await f.c.profilePhoto();for(const file of [{...image,size:0},{...image,size:10*1048576+1},{...image,type:'image/svg+xml'}]){await f.select(file);assert.equal(f.trace.at(-1)[3],'error');assert.match(f.trace.at(-1)[1],/10 MB/)}assert(!f.trace.some(x=>x[0]==='save'));});
test('locked or peer profile cannot open picker',async()=>{const f=await fixture();f.state.page='peer';await f.c.profilePhoto();f.state.page='profile';f.access.lock();await f.c.profilePhoto();assert.equal(f.trace.length,0);});
test('late image decode after relock cannot save or render',async()=>{let release;const f=await fixture({createImageBitmap:()=>new Promise(r=>release=r)});await f.c.profilePhoto();const pending=f.select(image);f.access.lock();await f.access.submit('123456',true);let closed=false;release({width:1,height:1,close(){closed=true}});await pending;assert(closed);assert.deepEqual(f.trace,['picker']);});
test('detached picker result cannot change a different screen or account',async()=>{const f=await fixture();await f.c.profilePhoto();f.fileInput.isConnected=false;await f.select(image);assert.deepEqual(f.trace,['picker']);});
test('duplicate picker and change events blocked while processing',async()=>{let release;const f=await fixture({createImageBitmap:()=>new Promise(r=>release=r)});await f.c.profilePhoto();const pending=f.select(image);assert(f.controls.every(x=>x.disabled));await f.c.profilePhoto();await f.select(image);release({width:1,height:1,close(){}});await pending;assert.equal(f.trace.filter(x=>x==='picker').length,1);assert.equal(f.trace.filter(x=>x[0]==='save').length,1);});
test('save failure reports error and enables retry',async()=>{const f=await fixture({patchSettings:async()=>{throw Error('server unavailable')}});await f.c.profilePhoto();await f.select(image);assert.equal(f.trace.find(x=>x[0]==='notice')[1],'server unavailable');assert(!f.trace.includes('render'));assert(!f.controls.some(x=>x.disabled));});
test('late save response cannot navigate back to a profile or display obsolete toast',async()=>{let release;const f=await fixture({patchSettings:()=>new Promise(r=>release=r)});await f.c.profilePhoto();const pending=f.select(image);await new Promise(r=>setImmediate(r));f.state.page='chat';release();await pending;assert(!f.trace.includes('render'));assert(!f.trace.some(x=>x[0]==='notice'));});
