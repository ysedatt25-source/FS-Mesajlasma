import assert from 'node:assert/strict';
import {RatchetPilotClient} from '../web/ratchet-pilot.js';
import {generateStorageKey} from '../web/ratchet-storage.js';
import {signingIdentity} from '../web/ratchet-handshake.js';
const f=JSON.parse(process.env.FS_PILOT_FIXTURE);
function memory(){const m=new Map(),p=new Map(),k=(s,i)=>JSON.stringify([s,i]);return {read:async i=>structuredClone(m.get(i)),compareAndSwap:async(i,rev,r)=>{if((m.get(i)?.revision??0)!==rev)return false;m.set(i,structuredClone(r));return true;},putPrekey:async(s,i,v)=>{p.set(k(s,i),structuredClone(v));},getPrekey:async(s,i)=>structuredClone(p.get(k(s,i))),bindPrekey:async(s,i,sid)=>{let v=p.get(k(s,i));if(!v||v.bound&&v.bound!==sid)return false;v.bound=sid;return true;},deletePrekey:async(s,i)=>p.delete(k(s,i))};}
const request=token=>async(path,opts={})=>{const r=await fetch(f.url+'api'+path,{method:opts.method||'GET',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:opts.body?JSON.stringify(opts.body):undefined});const d=await r.json();if(!r.ok)throw Error(r.status+' '+d.error);return d;};
const argsA={api:request(f.a.token),room:f.room,user:f.a.user.id,peer:f.b.user.id,store:memory(),key:await generateStorageKey(),identity:await signingIdentity()};
const argsB={api:request(f.b.token),room:f.room,user:f.b.user.id,peer:f.a.user.id,store:memory(),key:await generateStorageKey(),identity:await signingIdentity()};
let a=new RatchetPilotClient(argsA),b=new RatchetPilotClient(argsB);const pa=await a.ownFingerprint(),pb=await b.ownFingerprint();
const {createAutoRotation}=await import('../web/ratchet-auto-rotation.js');
const first=argsA.user<argsB.user?{client:a,args:argsA,pin:pb}:{client:b,args:argsB,pin:pa};const second=first.client===a?{client:b,args:argsB,pin:pa}:{client:a,args:argsA,pin:pb};
await second.client.maintainPrekeys();let row=await first.client.startOffline(first.pin);await second.client.acceptOffline(row,second.pin);await first.client.send(row,'verified old message');await second.client.sync(row);
const policy='/rooms/'+f.room+'/ratchet-cutover';const vote={method:'POST',body:{session:row.id,consent:true}};await first.args.api(policy,vote);assert((await second.args.api(policy,vote)).active);
const rotate1=createAutoRotation({...first.args,client:first.client,valid:()=>true,threshold:2});const rotate2=createAutoRotation({...second.args,client:second.client,valid:()=>true,threshold:2});
assert.equal(await rotate1.run(),null);rotate1.enable('A'.repeat(43)+'=');await assert.rejects(rotate1.run(),/kimliği değişti/);rotate1.enable(first.pin);rotate2.enable(second.pin);
assert.equal((await rotate1.run()).rotationOwn,null);await first.client.send(row,'threshold message');assert.equal((await rotate2.run()).session,row.id);
const waiting=await rotate1.run();assert.equal(waiting.session,row.id);assert(waiting.rotationOwn);assert.equal((await rotate1.run()).rotationOwn,waiting.rotationOwn);const changed=await rotate2.run();assert.equal(changed.session,waiting.rotationOwn);const fresh=await first.client.session(changed.session);await first.client.send(fresh,'automatic new message');assert.equal((await second.client.sync(fresh))[0].text,'automatic new message');assert.equal((await second.client.sync(row)).length,2);rotate1.disable();assert.equal(await rotate1.run(),null);console.log('PASS: explicit dual opt-in, wrong pin rejected, deterministic foreground rotation, old history preserved, new session sends successfully');
