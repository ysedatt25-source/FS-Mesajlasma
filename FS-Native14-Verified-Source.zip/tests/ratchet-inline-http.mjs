import assert from 'node:assert/strict';
import {RatchetPilotClient} from '../web/ratchet-pilot.js';
import {generateStorageKey} from '../web/ratchet-storage.js';
import {signingIdentity} from '../web/ratchet-handshake.js';
const f=JSON.parse(process.env.FS_PILOT_FIXTURE);
function memory(){const m=new Map(),p=new Map(),k=(s,i)=>JSON.stringify([s,i]);return {read:async i=>structuredClone(m.get(i)),compareAndSwap:async(i,rev,r)=>{if((m.get(i)?.revision??0)!==rev)return false;m.set(i,structuredClone(r));return true;},putPrekey:async(s,i,v)=>{p.set(k(s,i),structuredClone(v));},getPrekey:async(s,i)=>structuredClone(p.get(k(s,i))),bindPrekey:async(s,i,sid)=>{let v=p.get(k(s,i));if(!v||v.bound&&v.bound!==sid)return false;v.bound=sid;return true;},deletePrekey:async(s,i)=>p.delete(k(s,i))};}
const request=token=>async(path,opts={})=>{const r=await fetch(f.url+'api'+path,{method:opts.method||'GET',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:opts.body?JSON.stringify(opts.body):undefined});const d=await r.json();if(!r.ok)throw Error(r.status+' '+d.error);return d;};
const argsA={api:request(f.a.token),room:f.room,user:f.a.user.id,peer:f.b.user.id,store:memory(),key:await generateStorageKey(),identity:await signingIdentity()};
const argsB={api:request(f.b.token),room:f.room,user:f.b.user.id,peer:f.a.user.id,store:memory(),key:await generateStorageKey(),identity:await signingIdentity()};
let a=new RatchetPilotClient(argsA),b=new RatchetPilotClient(argsB);const pa=await a.ownFingerprint(),pb=await b.ownFingerprint();
const {createInlineTransport}=await import('../web/ratchet-inline.js');
const staged=[];await b.stagePrekeyReserve({count:()=>0,stage:bundle=>{staged.push(bundle);return true;}});assert.equal(staged.length,2);await argsB.api('/rooms/'+f.room+'/ratchet-pilot/prekeys',{method:'POST',body:staged[0]});
const row=await a.startOffline(pb);await b.acceptOffline(row,pa);await a.send(row,'initial');await b.sync(row);
const policy='/rooms/'+f.room+'/ratchet-cutover',vote={method:'POST',body:{session:row.id,consent:true}};await argsA.api(policy,vote);assert((await argsB.api(policy,vote)).active);
let lost=false;const lostApi=async(path,opts)=>{const result=await argsA.api(path,opts);if(!lost&&opts?.method==='POST'&&path.endsWith('/messages')){lost=true;throw Error('lost HTTP response');}return result;};a.close();a=new RatchetPilotClient({...argsA,api:lostApi});
const ta=createInlineTransport({api:argsA.api,client:a,room:f.room,valid:()=>true}),tb=createInlineTransport({api:argsB.api,client:b,room:f.room,valid:()=>true});
await assert.rejects(ta.send('inline secret'),/lost HTTP response/);await ta.send('inline secret');let received=await tb.sync();assert.equal(received.filter(x=>x.text==='inline secret').length,1);await tb.send('inline answer');assert.equal((await ta.sync()).at(-1).text,'inline answer');ta.close();tb.close();console.log('PASS: staged public prekey, real offline agreement, inline bidirectional text and lost response idempotency');
