import test from 'node:test';import assert from 'node:assert/strict';
import {signingIdentity,fingerprint} from '../web/ratchet-handshake.js';
import {makePrekey,initiateOffline,receiveOffline} from '../web/ratchet-offline.js';
async function setup(){const a=await signingIdentity(),b=await signingIdentity(),pinA=await fingerprint(a.publicKey),pinB=await fingerprint(b.publicKey);const local=await makePrekey({room:'room',user:'bob',peer:'alice',identity:b});const start=(bundle=local.bundle,pin=pinB)=>initiateOffline({bundle,room:'room',user:'alice',peer:'bob',identity:a,pin});const receive=(offer,opts={})=>receiveOffline({offer,room:'room',user:'bob',peer:'alice',identity:b,pin:pinA,local,claim:async()=>true,...opts});return {local,start,receive};}
test('modified signed prekey fails',async()=>{const x=await setup();await assert.rejects(x.start({...x.local.bundle,expires:x.local.bundle.expires-1000}),/imzası/);});
test('prekey room binding rejects cross-room use',async()=>{const x=await setup();await assert.rejects(x.start({...x.local.bundle,room:'different'}),/Geçersiz ön anahtar/);});
test('modified signed offer rejected before claiming key',async()=>{const x=await setup(),{offer}=await x.start();let claims=0;await assert.rejects(x.receive({...offer,id:'a'.repeat(32)},{claim:async()=>{claims++;return true;}}),/imzası/);assert.equal(claims,0);});
test('a prekey bound to another session cannot be used',async()=>{const x=await setup(),{offer}=await x.start();await assert.rejects(x.receive(offer,{claim:async()=>false}),/zaten kullanıldı/);});
test('recipient needs the original private prekey',async()=>{const x=await setup(),{offer}=await x.start();await assert.rejects(x.receive(offer,{local:null}),/bulunamadı/);});
