import assert from 'node:assert/strict';
import {RatchetPilotClient} from '../web/ratchet-pilot.js';
import {generateStorageKey} from '../web/ratchet-storage.js';
import {signingIdentity} from '../web/ratchet-handshake.js';
const f=JSON.parse(process.env.FS_PILOT_FIXTURE);
function memory(){const m=new Map(),nonces=new Set();return {read:async id=>structuredClone(m.get(id)),compareAndSwap:async(id,rev,r)=>{if((m.get(id)?.revision??0)!==rev)return false;m.set(id,structuredClone(r));return true;},claimNonce:async(s,n)=>{if(nonces.has(s+n))return false;nonces.add(s+n);return true;}};}
let failNext=false;const request=token=>async(path,opts={})=>{const r=await fetch(f.url+'api'+path,{method:opts.method||'GET',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:opts.body?JSON.stringify(opts.body):undefined});const d=await r.json();if(!r.ok)throw Error(r.status+' '+d.error);if(failNext&&opts.method==='POST'&&path.endsWith('/messages')){failNext=false;throw Error('simulated response loss');}return d;};
const argsA={api:request(f.a.token),room:f.room,user:f.a.user.id,peer:f.b.user.id,store:memory(),key:await generateStorageKey(),identity:await signingIdentity()};
const argsB={api:request(f.b.token),room:f.room,user:f.b.user.id,peer:f.a.user.id,store:memory(),key:await generateStorageKey(),identity:await signingIdentity()};
let a=new RatchetPilotClient(argsA),b=new RatchetPilotClient(argsB);const pinA=await a.ownFingerprint(),pinB=await b.ownFingerprint();
let row=await a.start();assert.equal((await b.list())[0].id,row.id);await assert.rejects(b.accept(row,'wrong'),/eşleşmedi/);row=await b.accept(row,pinA);await a.finish(row,pinB);
await a.send(row,'pilot-private-first');assert.equal((await b.sync(row))[0].text,'pilot-private-first');await b.send(row,'pilot-private-reply');assert.deepEqual((await a.sync(row)).map(x=>x.text),['pilot-private-first','pilot-private-reply']);
failNext=true;await assert.rejects(a.send(row,'pilot-private-retry'),/simulated response loss/);a.close();a=new RatchetPilotClient(argsA);assert.equal((await a.sync(row)).at(-1).text,'pilot-private-retry');b.close();b=new RatchetPilotClient(argsB);assert.equal((await b.sync(row)).at(-1).text,'pilot-private-retry');assert.equal((await b.sync(row)).length,3);console.log('PASS: signed handshake, independent pin, real HTTP bidirectional ciphertext, durable retry, restore, duplicate handling');
