import test from 'node:test';
import assert from 'node:assert/strict';
import {mergeMessagePage,upsertMessage} from '../web/message-state.js';
import {calculate} from '../web/calculator.js';
const m=(id,created,pending=false)=>({id,created,pending,room:'r'});
test('HTTP acknowledgement and repeated realtime pages display one message per ID',()=>{
 let rows=[m('one',10,true)];
 rows=upsertMessage(rows,[m('one',11)]);
 for(let i=0;i<5;i++)rows=mergeMessagePage(rows,[m('one',11)],'r');
 assert.equal(rows.length,1);assert.equal(rows[0].pending,false);
});
test('Refresh preserves queued messages and older pagination, removes deleted current messages',()=>{
 const rows=mergeMessagePage([m('old',1),m('deleted',5),m('queued',8,true)],[m('first',3),m('last',7)],'r');
 assert.deepEqual(rows.map(x=>x.id),['old','first','last','queued']);
 assert.deepEqual(mergeMessagePage([m('deleted',5),m('queued',8,true)],[],'r').map(x=>x.id),['queued']);
});
test('Calculator handles precedence, contextual percentages and scientific functions',()=>{
 for(const [input,result] of [['2+3×4',14],['100+20%',120],['200-10%',180],['200×10%',20],['-2^2',-4],['2^3^2',512],['sin(30)',0.5],['√(81)',9],['5!',120],['log(100)',2]])assert.equal(calculate(input),result,input);
 assert.ok(Math.abs(calculate('sin(pi/2)',{radians:true})-1)<1e-10);
});
test('Calculator rejects invalid math and executable input',()=>{
 for(const input of ['1/0','tan(90)','sqrt(-1)','alert(1)','2+','171!','(2+3'])assert.throws(()=>calculate(input),undefined,input);
});
