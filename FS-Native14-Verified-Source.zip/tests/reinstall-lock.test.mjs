import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {createAccessGate} from '../web/access-gate.js';
const src=fs.readFileSync(new URL('../web/app.js',import.meta.url),'utf8');
const take=(a,b)=>src.slice(src.indexOf(a),src.indexOf(b,src.indexOf(a)));
const auth=take('function authPage(register)','function welcome()');
const del=()=>{let release;return {promise:new Promise(r=>release=r),release};};
async function fixture(inject={}){
 const access=createAccessGate(async p=>p==='123456');await access.submit('123456',true);
 const trace=[],submit={disabled:false};const field=()=>({autocomplete:'',addEventListener(){}});
 const form={isConnected:true,dataset:{},elements:{namedItem:field},querySelector:s=>s==='button.primary'?submit:{textContent:''}};
 const state={page:'lock',token:null,user:null,identity:{}};
 const app={innerHTML:''};
 const c={access,app,state,isLocked:()=>access.locked,$:()=>form,field:(n,l)=>`<input name="${n}" aria-label="${l}">`,DOMException,FormData:class{*[Symbol.iterator](){yield ['login','0500 111 11 11'];yield ['password','account-password'];}},accountIssues:()=>[],formIssues(){},verifyServer:async()=>{},apiRoot:'test',identity:async()=>({pub:{key:'new'}}),api:async(path,opts)=>{trace.push(['request',opts.body]);return {token:'valid-token',user:{id:'existing'},settings:{},deviceChanged:true}},prepareRecovery:async()=>{},vault:async(k,v)=>trace.push(['persist',k,v]),initLocal:async()=>{},nativeSession:()=>trace.push(['native']),refreshRooms:async()=>{},connect:()=>trace.push(['connect']),home:()=>trace.push(['home']),welcome:()=>trace.push(['welcome']),notice:()=>{},...inject};
 vm.createContext(c);vm.runInContext(auth,c);c.authPage(false);
 return {c,access,trace,form,submit:()=>form.onsubmit({preventDefault(){},target:form})};
}
test('existing account uses login request, not registration, then persists session before home',async()=>{const f=await fixture();assert.match(f.c.app.innerHTML,/Tekrar üye olmana gerek yok/);await f.submit();assert.equal(f.trace[0][1].register,false);assert.equal(f.trace[0][1].login,'05001111111');assert.equal(f.c.state.user.id,'existing');assert.deepEqual(f.trace.map(x=>x[0]),['request','persist','native','connect','home','welcome']);});
test('auth route never renders while calculator is locked',async()=>{const f=await fixture();f.access.lock();f.c.app.innerHTML='calculator';f.c.authPage(false);assert.equal(f.c.app.innerHTML,'calculator');});
test('old sign-in cannot submit after PIN lock during server verification',async()=>{const d=del(),f=await fixture({verifyServer:()=>d.promise});const task=f.submit();f.access.lock();await f.access.submit('123456',true);d.release();await task;assert.equal(f.trace.length,0);assert.equal(f.c.state.token,null);});
test('late successful login cannot persist or show account after relock',async()=>{const d=del(),f=await fixture({api:()=>d.promise});const task=f.submit();await new Promise(r=>setImmediate(r));f.access.lock();await f.access.submit('123456',true);d.release({token:'old',user:{id:'old'},settings:{}});await task;assert.equal(f.trace.length,0);assert.equal(f.c.state.token,null);});
test('PIN verifier cannot overlap across lock generations',async()=>{const d=del();let checks=0;const a=createAccessGate(()=>{checks++;return d.promise});const pending=a.submit('123456',true);a.lock();assert.equal(await a.submit('123456',true),false);assert.equal(checks,1);d.release(true);assert.equal(await pending,false);assert.equal(a.locked,true);assert.equal(await a.submit('123456',true),true);});
test('no protected actions while account is not authenticated',async()=>{const a=take('async function actions(a, el)','document.addEventListener("click", async');const c={isLocked:()=>false,state:{page:'auth',token:null,user:null},home(){throw Error('bypassed')},openRoom(){throw Error('bypassed')}};vm.createContext(c);vm.runInContext(a,c);await c.actions('home',{});await c.actions('open-room',{dataset:{id:'r'}});await c.actions('admin',{});});
for(const failure of ['once','inline','emoji']) test('failed '+failure+' lock cleanup still removes previous content and renders calculator',async()=>{
 const access=createAccessGate(async()=>true);await access.submit('123456',true);
 const app={style:{},inert:false,textContent:'PRIVATE CONVERSATION',replaceChildren(){this.textContent='';}};
 const modal={style:{},open:true,close(){this.open=false;},replaceChildren(){}};
 const state={page:'chat',socket:{close(){}},adminRooms:[{}],adminMessages:[{}]};
 const c={app,modal,state,access,console:{warn(){}},closeOnceViewer(){assert.equal(access.locked,true);assert.equal(app.style.visibility,'hidden');if(failure==='once')throw Error('simulated media cleanup failure')},closeInlineRatchet(){assert.equal(app.style.visibility,'hidden');if(failure==='inline')throw Error('simulated ratchet cleanup failure')},window:{},resetDelivery(){},closeAlbumViewer(){},clearProfileViewer(){},callRingtones:{stop(){}},clearEmojiEffect(){throw Error('simulated cleanup failure')},mountCalculator(root){root.textContent='CALCULATOR';return {};},presenceAuthenticated:true};
 vm.createContext(c);vm.runInContext('let adminSequence=0;'+take('function clearAdminState(){','function adminGuard(page)')+take('let calculatorView;','window.addEventListener(\'fs-calculator-restore\''),c);c.showLock();assert.equal(state.adminRooms.length,0);assert.equal(state.adminMessages.length,0);
 assert.equal(access.locked,true);assert.equal(state.page,'lock');assert.equal(app.textContent,'CALCULATOR');assert.equal(modal.open,false);assert.equal(app.inert,false);assert.equal(app.style.visibility,'');
});
