"""Run real WebCrypto clients against a disposable local aiohttp API."""
import asyncio, os, sys, tempfile, shutil
from pathlib import Path
from aiohttp import web
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'server'))
from app import create_app
async def main():
    with tempfile.TemporaryDirectory(prefix='fs-crypto-') as tmp:
        app=create_app(tmp);runner=web.AppRunner(app);await runner.setup();site=web.TCPSite(runner,'127.0.0.1',0);await site.start()
        port=site._server.sockets[0].getsockname()[1]
        try:
            cmd=['node',str(root/'tests/live-emoji-crypto.mjs'),f'http://127.0.0.1:{port}',str(root/'web/crypto.js'),str(root/'web/realtime-emoji.js')]
            proc=await asyncio.create_subprocess_exec(*cmd,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
            try:out,_=await asyncio.wait_for(proc.communicate(),20)
            except asyncio.TimeoutError:proc.kill();await proc.wait();raise
            print(out.decode(),end='');assert proc.returncode==0,proc.returncode
        finally:await runner.cleanup()
if __name__=='__main__':asyncio.run(main())
