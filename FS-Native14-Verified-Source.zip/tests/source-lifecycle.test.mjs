import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
import {encodePhotoPreview} from '../web/photo-preview.js';
import {prepareMedia} from '../web/media-preparation.js';
import {decryptFile} from '../web/crypto.js';
const src=readFileSync(new URL('../web/app.js',import.meta.url),'utf8');
const slice=(a,b)=>src.slice(src.indexOf(a),src.indexOf(b,src.indexOf(a)));
const tick=()=>new Promise(resolve=>setImmediate(resolve));
test('late worker failures cannot terminate a new attachment; fallback preserves original bytes',async()=>{
 const original=globalThis.Worker,workers=[];
 class FakeWorker{constructor(){workers.push(this)}postMessage(data){this.request=data}terminate(){this.terminated=true}}
 globalThis.Worker=FakeWorker;
 try{
  const file=new Blob(['original attachment'],{type:'text/plain'});
  const a=prepareMedia(file,async()=>undefined);await tick();const old=workers[0];assert.ok(old.request);old.onerror();
  const result=await a;assert.equal(await (await decryptFile(result.encrypted.data,{...result.encrypted,mime:file.type})).text(),'original attachment');assert.ok(old.terminated);
  const b=prepareMedia(file,async()=>{throw Error('unexpected fallback')});await tick();const next=workers[1];assert.ok(next.request);
  old.onerror();old.onmessageerror();old.onmessage({data:{id:next.request.id,error:'old worker'}});assert.equal(next.terminated,undefined);
  next.onmessage({data:{id:next.request.id,result:{verified:true}}});assert.deepEqual(await b,{verified:true});
  const c=prepareMedia(file,async()=>undefined);await tick();next.onmessageerror();assert.ok((await c).encrypted);assert.ok(next.terminated);
 }finally{globalThis.Worker=original;}
});
test('fallback bitmap released even if canvas fails',async()=>{
 let closed=0;const context={encodePhotoPreview,createImageBitmap:async()=>({width:10,height:10,close(){closed++}}),document:{createElement:()=>({getContext:()=>null})}};
 vm.createContext(context);vm.runInContext(slice('async function thumbnail(file)','const thumbnailUrls'),context);
 assert.equal(await context.thumbnail({type:'image/png'}),undefined);assert.equal(closed,1);
});
test('obsolete thumbnail observers cannot start decryption in a new route or account',async()=>{
 let calls=0;const obs=[];const state={token:'a',page:'chat',routeVersion:1,messages:[],media:[]};const img={dataset:{thumb:'m'},isConnected:true,removeAttribute(){delete this.dataset.thumb}};
 class Observer{constructor(fn){this.fn=fn;obs.push(this)}observe(){}unobserve(){}disconnect(){this.disconnected=true}}
 const context={state,document:{querySelectorAll:()=>[img]},isLocked:()=>false,access:{epoch:1,valid:e=>e===1},IntersectionObserver:Observer,lookupRecord:()=>({id:'m',payload:{thumbnail:{data:'x'}}}),isViewOnce:()=>false,hiddenMessage:()=>false,deletedInSession:new Set(),unb64:()=>new Uint8Array(),decryptFile:async()=>{calls++;return {}},thumbnailUrls:{load:async(id,make)=>{await make();return 'blob:test'},has:()=>true}};
 vm.createContext(context);vm.runInContext(slice('let thumbnailObserver=null;','function keyedMessages('),context);
 context.loadThumbnails();const old=obs[0];context.loadThumbnails();assert.ok(old.disconnected);old.fn([{isIntersecting:true,target:img}]);await tick();assert.equal(calls,0);
 state.routeVersion++;obs[1].fn([{isIntersecting:true,target:img}]);await tick();assert.equal(calls,0);
 context.loadThumbnails();obs[2].fn([{isIntersecting:true,target:img}]);await tick();assert.equal(calls,1);assert.equal(img.src,'blob:test');
 context.stopThumbnailObservation();assert.ok(obs[2].disconnected);
});
test('safe-chat modal close has one guarded refresh listener',()=>{
 const code=slice('let inlineRatchet=null;','function updateCutoverComposer()');let refreshes=0,handler;const modal={open:false,addEventListener(type,fn){assert.equal(type,'close');handler=fn}};let locked=false;
 vm.runInNewContext(code,{modal,queueMicrotask,isLocked:()=>locked,updateCutoverComposer(){refreshes++}});handler();return tick().then(async()=>{assert.equal(refreshes,1);modal.open=true;handler();await tick();assert.equal(refreshes,1);modal.open=false;locked=true;handler();await tick();assert.equal(refreshes,1);assert.equal((src.match(/modal\.addEventListener\("close",\(\)=>queueMicrotask\([^\n]*updateCutoverComposer/g)||[]).length,1);});
});
