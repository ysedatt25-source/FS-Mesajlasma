import test from 'node:test';
import assert from 'node:assert/strict';
import {fetchServer} from '../web/connection.js';
import {albumMembers} from '../web/album-download.js';
import {estimateRecordBytes,BoundedCache} from '../web/resource-budget.js';
import {VoiceRecorder} from '../web/voice-recorder.js';
test('late cancelled fetch releases unread response body',async()=>{
 const controller=new AbortController();let finish,cancelled=0;
 const p=fetchServer('https://example.invalid','/media',{signal:controller.signal},()=>new Promise(r=>finish=r));
 const check=assert.rejects(p,{name:'AbortError'});controller.abort();
 finish(new Response(new ReadableStream({cancel(){cancelled++}})));
 await check;assert.equal(cancelled,1);
});
test('album rejects missing or invalid MIME rather than throwing',()=>{
 const photo={id:'a',payload:{type:'file',mime:'image/png'}};
 for(const mime of [undefined,null,42,'text/plain'])assert.deepEqual(albumMembers([{id:'a',albumIds:['a','b']}],'a',[photo,{id:'b',payload:{type:'file',mime}}],()=>true),[]);
});
test('binary records obey byte budget without enumerating millions of indices',()=>{
 const bytes=new Uint8Array(1024*1024), view=new DataView(new ArrayBuffer(1024*1024));
 assert.ok(estimateRecordBytes({bytes},2*1024*1024)>=bytes.byteLength);
 assert.ok(estimateRecordBytes({view},2*1024*1024)>=view.byteLength);
 const cache=new BoundedCache({count:5,bytes:1000,weight:estimateRecordBytes});cache.set('large',{bytes:new ArrayBuffer(2048)});assert.equal(cache.size,0);
});
test('voice analyser failure does not leave microphone running',async()=>{
 let stopped=0,errors=[];const track={stop(){stopped++}};
 const stream={getTracks:()=>[track],getAudioTracks:()=>[track]};
 class Recorder{state='inactive';start(){this.state='recording'}stop(){this.state='inactive'}}
 class AudioContext{createMediaStreamSource(){return {connect(){},disconnect(){}}}createAnalyser(){return {fftSize:256,getByteTimeDomainData(){throw Error('audio device gone')}}}close(){return Promise.resolve()}}
 const rec=new VoiceRecorder({mediaDevices:{getUserMedia:async()=>stream},Recorder,AudioContext,onError:e=>errors.push(e)});
 const previous=globalThis.setInterval;let tick;globalThis.setInterval=fn=>{tick=fn;return 0};
 try{await rec.start();assert.doesNotThrow(()=>tick());assert.equal(rec.session,null);assert.equal(stopped,1);assert.equal(errors.length,1);}finally{globalThis.setInterval=previous;rec.cancel()}
});
