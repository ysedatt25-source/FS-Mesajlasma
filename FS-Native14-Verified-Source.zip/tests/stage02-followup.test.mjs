import test from 'node:test';
import assert from 'node:assert/strict';
import {receiptStatus} from '../web/message-details.js';
import {chatMessageJoined} from '../web/chat-layout.js';
const r=(user,read_at=null)=>({user,delivered:10,read_at});
const photo=(receipts_v2=[],extra={})=>({receipts_v2,...extra});
test('album cannot show blue ticks when only first photo is read',()=>{
 const first=photo([r('b',20)]), second=photo([r('b')]);
 assert.equal(receiptStatus({...first,album:[first,second]},['b']).read,false);
 assert.equal(receiptStatus({...first,album:[first,second]},['b']).mark,'✓');
 assert.equal(receiptStatus({...first,album:[first,second]},['b']).state,'delivered');
});
test('album waits for every photo to be delivered',()=>{
 const first=photo([r('b',20)]),second=photo();
 assert.equal(receiptStatus({...first,album:[first,second]},['b']).mark,'✓');
});
test('album pending and queued states take precedence',()=>{
 const first=photo([r('b',20)]);
 assert.equal(receiptStatus({...first,album:[first,photo([],{pending:true})]},['b']).mark,'◷');
 assert.equal(receiptStatus({...first,album:[first,photo([],{pending:true,queued:true})]},['b']).mark,'Kuyrukta');
});
test('group album read requires all peers on all items',()=>{
 const first=photo([r('b',20),r('c',20)]),second=photo([r('b',20),r('c',20)]);
 assert.equal(receiptStatus({...first,album:[first,second]},['b','c']).read,true);
 assert.equal(receiptStatus({...first,album:[first,second]},['b','c','d']).mark,'✓');
});
test('locked/invalid payload does not join visible text bubble',()=>{
 const m={sender:'a',room:'r',created:Date.now(),payload:{type:'text',text:'a'}};
 assert.equal(chatMessageJoined(m,{...m,payload:{type:'text',text:null}}),false);
});
