import test from 'node:test';
import assert from 'node:assert/strict';
import {MESSAGE_EFFECTS,effectFields,messageEffect,validEffectVariant,createEffectHistory} from '../web/message-effects.js';
import {validatePayload} from '../web/payload.js';
test('six explicit choices retain three legacy wire values',()=>{
 assert.equal(MESSAGE_EFFECTS.length,6);
 for(const e of MESSAGE_EFFECTS){const fields=effectFields(e.id);assert.ok(['heart','sparkle','celebrate'].includes(fields.effect));assert.equal(messageEffect(fields.effect,fields.effectVariant).id,e.id);assert.equal(validatePayload({type:'text',text:'Test',...fields}).text,'Test');}
 assert.deepEqual(effectFields('unknown'),{});assert.deepEqual(effectFields(''),{});assert.equal(messageEffect('heart','fire').id,'heart');
});
test('untrusted effect variant is strictly paired with its legacy effect',()=>{
 for(const p of [{effect:'heart',effectVariant:'fire'},{effect:'heart',effectVariant:'heart'},{effectVariant:'fire'},{effect:'sparkle',effectVariant:'<img>'}])assert.throws(()=>validatePayload({type:'text',text:'Test',...p}));
 assert.ok(validEffectVariant('celebrate','fireworks'));
});
test('automatic effect history suppresses duplicate deliveries, bounded and resettable',()=>{
 const h=createEffectHistory(2);assert.ok(h.accept('a'));assert.equal(h.accept('a'),false);assert.ok(h.accept('b'));assert.ok(h.accept('c'));assert.ok(h.accept('a'));assert.equal(h.accept('a'),false);h.clear();assert.ok(h.accept('a'));
});
