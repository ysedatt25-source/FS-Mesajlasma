import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import * as effects from '../web/emoji-effects.js';
import {reactionValue,sameReaction} from '../web/message-interactions.js';
const src=fs.readFileSync(new URL('../web/app.js',import.meta.url),'utf8');
test('emoji category is exclusive and ignores presentation selector',()=>{
 for(const [glyph,category] of [['❤️','Kalpler'],['☀️','Diğer'],['✈️','Diğer'],['🐱','Hayvanlar'],['😄','Yüzler'],['🥰','Yüzler'],['💔','Kalpler']]) assert.equal(effects.emojiCategory(glyph),category,glyph);
});
test('emoji search retains normalized Turkish and exact emoji matching',()=>{
 assert.ok(effects.emojiMatches('❤️','kalp'));assert.ok(effects.emojiMatches('❤️','❤'));assert.ok(effects.emojiMatches('🐱','hayvan'));assert.ok(effects.emojiMatches('🦋','KELEBEK'));assert.ok(!effects.emojiMatches('☀️','kalp'));assert.ok(!effects.emojiMatches('❤️','__proto__'));assert.ok(!effects.emojiMatches('❤️','\uFE0F'));
});
test('catalog categories partition all 3757 entries',()=>{
 const read=n=>JSON.parse(fs.readFileSync(new URL('../web/'+n,import.meta.url),'utf8'));
 const rows=effects.mergeEmojiCatalog(read('emojis.json'),read('emoji-extension.json'));assert.equal(rows.length,3757);
 for(const {emoji} of rows)assert.ok(['Kalpler','Yüzler','Hayvanlar','Diğer'].includes(effects.emojiCategory(emoji)),emoji);
});
test('remove-only action never re-adds a stale reaction',async()=>{
 const fn=src.slice(src.indexOf('async function reactToMessage('),src.indexOf('function openReactionPicker('));const events=[];const reactions=new Map([['u','🔥']]);const ctx={state:{page:'chat',room:{id:'r'},user:{id:'u'},routeVersion:1},isLocked:()=>false,eligibleMessage:()=>({}),isSingleEmoji:effects.isSingleEmoji,reactionFlight:new Set(),messageIndex:{reactions:new Map([['m',reactions]])},reactionValue,sameReaction,send:async p=>events.push(p.text),window:{matchMedia:()=>({matches:true})}};
 vm.runInNewContext(fn,ctx);await ctx.reactToMessage('m','❤️',{removeOnly:true});assert.deepEqual(events,[]);await ctx.reactToMessage('m','🔥',{removeOnly:true});assert.deepEqual(events,['']);await ctx.reactToMessage('m','❤️');assert.deepEqual(events,['','❤️']);
});
test('picker fallback is scoped to emoji thumbnails',()=>{
 assert.match(src,/image\?\.classList\?\.contains\('emoji-picker-image'\)/);assert.match(src,/class="emoji-picker-glyph"/);assert.match(src,/data-remove-only="true"/);
});
