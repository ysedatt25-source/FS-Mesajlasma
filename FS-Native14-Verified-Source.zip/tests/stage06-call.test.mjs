import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createCallQuality} from '../web/call-quality.js';
const source=readFileSync(new URL('../web/app.js',import.meta.url),'utf8');
const attach=source.slice(source.indexOf('function attachVideo()'),source.indexOf('function callElapsedLabel('));
function fixture({page='call',local=true,remoteTag='VIDEO',swapped=false,extras,stream={id:'local'},remote={id:'remote'}}={}){
 const nodes=new Map(), mk=(id,tagName='VIDEO')=>({id,tagName,muted:false,paused:false,srcObject:null,style:{},remove(){nodes.delete(this.id)},play(){return Promise.resolve()}});
 if(page==='call'){nodes.set('remote-video',mk('remote-video',remoteTag));if(local)nodes.set('local-video',mk('local-video'));}else if(local)nodes.set('call-mini',mk('call-mini'));
 const state={page,call:{stream,remote,swapped,extras}},app={append(el){nodes.set(el.id,el)}},document={createElement:()=>mk('','AUDIO')};
 const run=new Function('state','$','app','document','isLocked',attach+'\nattachVideo();');
 return {state,nodes,run:()=>run(state,s=>nodes.get(s.slice(1)),app,document,()=>false)};
}
test('remote audio remains audible if swapped preview disappears',()=>{const f=fixture({local:false,swapped:true});f.run();const r=f.nodes.get('remote-video');assert.equal(r.srcObject,f.state.call.remote);assert.equal(r.muted,false);assert.equal(f.state.call.swapped,false);});
test('local camera is never attached to the remote audio-only element after a swap',()=>{const f=fixture({remoteTag:'AUDIO',swapped:true});f.run();assert.equal(f.nodes.get('remote-video').srcObject,f.state.call.remote);assert.equal(f.nodes.get('local-video').muted,true);});
test('cleared stream detaches stale media rather than replaying it',()=>{const f=fixture();f.run();f.state.call.remote=null;f.run();assert.equal(f.nodes.get('remote-video').srcObject,null);});
test('chat video and background audio have exactly one audible remote owner',()=>{const f=fixture({page:'chat',extras:{remote:'off',mode:'camera'}});f.run();assert.equal(f.nodes.get('call-mini').muted,true);assert.equal(f.nodes.get('fs-background-call').srcObject,f.state.call.remote);f.state.call.extras.remote='camera';f.run();assert.equal(f.nodes.has('fs-background-call'),false);assert.equal(f.nodes.get('call-mini').muted,false);assert.equal(f.nodes.get('call-mini').srcObject,f.state.call.remote);});
test('media mode change preserves an existing ten-second deadline',()=>{const code=source.slice(source.indexOf('function refreshCallExtras(c)'),source.indexOf('function showCallExtras()'));const c={video:false,controlsHidden:false,controlsUntil:12345,extras:{mode:'camera',remote:'off'},nativeCamera:true};new Function('state','isLocked','window','$','attachVideo','showCall',code+'\nrefreshCallExtras(state.call);')({call:c,page:'home'},()=>false,{},()=>null,()=>{},()=>{});assert.equal(c.controlsUntil,12345);});
test('stats collected across a connection-state change cannot be used as current video measurements',async()=>{let resolve;const pc={connectionState:'connecting',getStats:()=>new Promise(r=>resolve=r),getSenders:()=>[]};const q=createCallQuality(),p=q.sample(pc);pc.connectionState='connected';resolve(new Map());assert.equal(await p,null);});
