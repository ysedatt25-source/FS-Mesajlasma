// Test-only request barrier. No production imports or global state.
export function holdExactMessagePost({fetcher,url,match}) {
 let id=null,released=false,resolve;
 const gate=new Promise(r=>resolve=r),observed=[];
 return {get id(){return id},observed,
   async fetch(input,opts){
     if(String(input)===url&&opts?.method==='POST'){
       const candidate=JSON.parse(opts.body).id;
       const valid=typeof candidate==='string'&&/^[A-Za-z0-9_-]{10,64}$/.test(candidate)&&match(candidate);
       observed.push({matched:!!valid});
       if(valid&&!id&&!released){id=candidate;await gate;}
     }
     return fetcher(input,opts);
   },release(){released=true;resolve();}
 };
}

// Match the exact message-scoped Range endpoint as well as the older upload
// endpoint. A failure test must prove its fault was actually injected.
export function failExactDownload({fetcher,origin,messageId,uploadId,status=503}) {
 const legacy='/api/uploads/'+encodeURIComponent(uploadId);
 const scoped='/api/messages/'+encodeURIComponent(messageId)+'/download/'+encodeURIComponent(uploadId);
 const hits=[];
 return {hits,async fetch(input,opts){
  const url=new URL(typeof input==='string'||input instanceof URL?input:input.url,origin);
  if(url.origin===origin&&(url.pathname===legacy||url.pathname===scoped)){
   hits.push({path:url.pathname,range:opts?.headers?.Range||null});
   return Response.json({error:'injected download failure'},{status});
  }
  return fetcher(input,opts);
 }};
}
