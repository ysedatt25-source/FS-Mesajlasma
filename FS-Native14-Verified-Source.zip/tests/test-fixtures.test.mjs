import test from 'node:test';
import assert from 'node:assert/strict';
import {holdExactMessagePost,failExactDownload} from './test-fixtures.mjs';
const url='http://127.0.0.1:8788/api/rooms/test/messages';
const post=id=>({method:'POST',body:JSON.stringify({id})});
test('an earlier poll or unrelated POST cannot consume the emoji barrier',async()=>{
 const sent=[];const h=holdExactMessagePost({url,match:id=>id==='emoji_message_1',fetcher:async(u,o)=>{sent.push(JSON.parse(o.body).id);return 'OK'}});
 assert.equal(await h.fetch(url,post('poll_message_1')),'OK');assert.equal(h.id,null);
 const pending=h.fetch(url,post('emoji_message_1'));assert.equal(h.id,'emoji_message_1');
 assert.deepEqual(sent,['poll_message_1']);await h.fetch(url,post('other_message_1'));
 assert.deepEqual(sent,['poll_message_1','other_message_1']);h.release();assert.equal(await pending,'OK');assert.deepEqual(sent,['poll_message_1','other_message_1','emoji_message_1']);
});
test('release is safe on failure and never holds a later message',async()=>{
 const h=holdExactMessagePost({url,match:()=>true,fetcher:async()=>42});h.release();h.release();assert.equal(await h.fetch(url,post('emoji_message_2')),42);assert.equal(h.id,null);
});

test('download failure fixture intercepts both legacy and durable range endpoints only for selected file',async()=>{
 const origin='http://127.0.0.1:8788',messageId='message_test',uploadId='upload_test',forwarded=[];
 const f=failExactDownload({origin,messageId,uploadId,fetcher:async(u)=>{forwarded.push(String(u));return new Response(null,{status:200});}});
 for(const path of ['/api/uploads/upload_test','/api/messages/message_test/download/upload_test'])assert.equal((await f.fetch(origin+path,{headers:{Range:'bytes=0-9'}})).status,503);
 for(const path of ['/api/uploads/upload_test2','/api/messages/other/download/upload_test','/api/messages/message_test/download/other','https://foreign.invalid/api/uploads/upload_test'])assert.equal((await f.fetch(path)).status,200);
 assert.equal(f.hits.length,2);assert.equal(f.hits[1].range,'bytes=0-9');assert.equal(forwarded.length,4);
});
