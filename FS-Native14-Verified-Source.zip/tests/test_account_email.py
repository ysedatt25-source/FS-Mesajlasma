from test_server import APITest, PUB

class AccountEmailTest(APITest):
 async def test_email_registration(self):
  data=dict(register=True,privacy_accepted=True,name='New',nick='new_user',phone='+905004444444',password='test-password-123',invite='0032',pub=PUB,email='bad')
  self.assertEqual((await self.client.post('/api/session',json=data)).status,400)
  data['email']=' New@Example.com '
  r=await self.client.post('/api/session',json=data);self.assertEqual(r.status,200,await r.text());user=(await r.json())['user'];self.assertNotIn('email',user)
  row=self.app['store'].one('SELECT * FROM account_emails WHERE user_id=?',(user['id'],));self.assertEqual(row['email'],'new@example.com');self.assertEqual(row['verified'],0)
  self.assertEqual((await self.client.post('/api/session',json=data)).status,409)
  r=await self.client.post('/api/session',json=dict(login='new_user',password=data['password'],pub=PUB));self.assertEqual(r.status,200)
