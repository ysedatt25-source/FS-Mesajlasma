from test_server import APITest
class VerifyTest(APITest):
 async def test_verify_existing_account(self):
  sent=[];self.app['email_sender']=lambda address,code:sent.append((address,code))
  h=self.h(self.a);start='/api/account/email/start';finish='/api/account/email/finish'
  self.assertEqual((await self.client.post(start,json={'email':'a@example.com'})).status,401)
  self.assertEqual((await self.client.post(start,headers=h,json={'email':'a@example.com'})).status,401)
  self.assertEqual((await self.client.post(start,headers=h,json={'email':'a@example.com','password':'wrong-password'})).status,401)
  self.assertEqual((await self.client.post(start,headers=h,json={'email':'a@example.com','password':'test-password-123'})).status,200)
  code=sent[0][1]
  self.assertEqual((await self.client.post(finish,headers=self.h(self.b),json={'code':code})).status,400)
  self.assertEqual((await self.client.post(finish,headers=h,json={'code':code})).status,200)
  self.assertEqual((await self.client.post(finish,headers=h,json={'code':code})).status,400)
  row=self.app['store'].one('SELECT * FROM account_emails WHERE user_id=?',(self.a['user']['id'],))
  self.assertEqual((row['email'],row['verified']),('a@example.com',1))
 async def test_invalid_email_never_reaches_database_or_sender(self):
  sent=[]; self.app['email_sender']=lambda *args:sent.append(args)
  for email in ['bad\ud800@example.com','bad\x00@example.com','bad\x7f@example.com']:
   body={'email':email,'phone':'+905001111111','password':'test-password-123','code':'x'*32}
   for path in ['/api/account/email/start','/api/account/recovery/start','/api/account/recovery/finish']:
    r=await self.client.post(path,headers=self.h(self.a),json=body)
    self.assertEqual(r.status,400,await r.text())
  self.assertEqual(sent,[])
