"""Isolated real Chromium checks of the production emoji picker and optimizations."""
from pathlib import Path
import os, base64
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]; src=(root/'web/app.js').read_text()
picker=src[src.index('function emojiPicker(panel=null) {'):src.index('const liveLocations = new Map()')]
# Load the actual production helpers from a data URL; no external server or mock search.
helpers='data:text/javascript;base64,'+base64.b64encode((root/'web/emoji-effects.js').read_bytes()).decode()
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page()
 page.set_content('<dialog id="modal"></dialog>')
 page.evaluate('''async helpers=>{const {emojiMatches,emojiCategory}=await import(helpers);const $=s=>document.querySelector(s),state={reactionTarget:null,user:{id:'me'}},messageIndex={reactions:new Map()},escape=s=>String(s),sameReaction=(a,b)=>a===b,emojiFilePath=f=>'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22/%3E',emojiItems=Array.from({length:180},(_,i)=>({emoji:'😀'+i,file:'asset'+i+'.webp'}));function dialog(t,h){const m=$('#modal');m.innerHTML=h;m.showModal();}'''+picker+''';emojiPicker();window.first=$('#emoji-list').firstElementChild;window.firstImg=first.firstElementChild;}''',helpers)
 assert page.locator('#emoji-list button').count()==72
 page.locator('#emoji-more').click();assert page.locator('#emoji-list button').count()==144
 assert page.evaluate('first === document.querySelector("#emoji-list").firstElementChild && firstImg === first.firstElementChild');print('PASS first 72 animated image nodes retained when more is pressed')
 page.locator('#emoji-more').click();assert page.locator('#emoji-list button').count()==180 and not page.locator('#emoji-more').is_visible();print('PASS last page and no duplicate emoji')
 page.locator('#emoji-search').fill('179');assert page.locator('#emoji-list button').count()==1 and page.locator('#emoji-list button').get_attribute('data-emoji')=='😀179';print('PASS search resets visible items')
 page.locator('#emoji-search').fill('absent');assert page.locator('#emoji-list .hint').count()==1;print('PASS empty search')
 page.locator('#emoji-search').fill('');page.emulate_media(reduced_motion='reduce');page.locator('#emoji-more').click();assert page.locator('#emoji-list .emoji-picker-glyph').count()==144 and page.locator('#emoji-list img').count()==0;print('PASS motion preference change rebuilds existing entries')
 page.locator('[data-category="Hayvanlar"]').click();assert page.locator('#emoji-list .hint').count()==1;page.locator('[data-category="Tümü"]').click();assert page.locator('#emoji-list button').count()==72;print('PASS category switch resets page')
 b.close()
