"""Ensure opening a normal dialog cannot retain the fullscreen story player's layout."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
src=(root/'app.js').read_text(); dialog=src[src.index('function dialog(title, content)'):src.index('function field(',src.index('function dialog(title, content)'))]
with sync_playwright() as p:
    b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    page=b.new_page(viewport={'width':390,'height':844})
    page.set_content('<div id="app"><section class="screen fs-premium fs-home"><button id="focus">Arama</button></section></div><dialog id="modal" class="story-fullscreen"><div class="story-view">Hikâye</div></dialog>')
    page.add_style_tag(path=str(root/'style.css'))
    page.evaluate('''()=>{const modal=document.querySelector('#modal'),$=s=>document.querySelector(s),state={};const assertAccess=()=>{},closeOnceViewer=()=>{},closeAlbumViewer=()=>{},clearProfileViewer=()=>{},clearMessageMenu=()=>{},closeComposerEmoji=()=>{},escape=s=>s,button=()=>'<button>Kapat</button>';let closes=0;const storyController={closeViewer(){closes++;modal.classList.remove('story-fullscreen');modal.querySelector('.story-view')?.remove();}};'''+dialog+'''\nmodal.showModal();window.openNormal=()=>{dialog('Normal','<div class="home-search-filters"><button aria-pressed="true">Seçili</button></div>');return {closes,full:modal.classList.contains('story-fullscreen'),height:modal.getBoundingClientRect().height};};}''')
    v=page.evaluate('openNormal()');assert v['closes']==1 and not v['full'] and v['height']<844,v
    print('PASS opening normal dialog removes fullscreen story state synchronously')
    for light,fill in [(False,'rgb(41, 122, 185)'),(True,'rgb(22, 116, 180)')]:
        page.evaluate('(v)=>document.body.classList.toggle("light",v)',light)
        assert page.locator('.home-search-filters button').evaluate('(e)=>getComputedStyle(e).backgroundColor')==fill
    page.evaluate('document.querySelector("#modal").close()');page.locator('#focus').focus()
    assert page.locator('#focus').evaluate('(e)=>getComputedStyle(e).outlineColor')=='rgb(22, 129, 196)'
    print('PASS search selection and keyboard focus use active theme')
    b.close()
