"""Isolated browser component test. Uses synthetic PIN verifier, not the native app or database."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
calc=(root/'calculator.js').read_text().replace('export ', '')
ui=(root/'calculator-ui.js').read_text().split('\n',1)[1].replace('export ', '')
gate=(root/'access-gate.js').read_text().replace('export ', '')
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
    page=browser.new_page(viewport={'width':390,'height':844},has_touch=True)
    page.set_content('<div id="app"></div>')
    page.add_style_tag(content=(root/'style.css').read_text())
    page.evaluate('''() => { '''+calc+'\n'+ui+'\n'+gate+'''
       const access=createAccessGate(async pin=>pin==='123456');
       const root=document.querySelector('#app');
       window.locked=()=>access.locked;
       window.reset=()=>{access.lock();mountCalculator(root,{checkPin:(pin,eq)=>access.submit(pin,eq),onUnlock:()=>root.textContent='TEST-UNLOCK'});};
       window.reset();
    }''')
    def key(k):page.locator(f'[data-calc="{k}"]').click()
    def digits(s):
        for k in s:key(k)
    digits('123456'); assert page.evaluate('locked()');print('PASS Correct PIN digits alone do not unlock')
    page.evaluate('reset()');key('=');assert page.evaluate('locked()');print('PASS Reset clears unsubmitted PIN')
    digits('123455');key('=');assert page.evaluate('locked()');print('PASS Wrong PIN does not unlock')
    key('AC');key('2');key('+');key('3');key('=');assert page.locator('.display').inner_text()=='5';assert page.evaluate('locked()');print('PASS Arithmetic does not unlock')
    key('AC');digits('123456');page.evaluate('document.querySelector(\'[data-calc="="]\').click()');assert page.evaluate('locked()');print('PASS Synthetic equals ignored')
    key('=');page.get_by_text('TEST-UNLOCK',exact=True).wait_for();assert not page.evaluate('locked()');print('PASS Trusted equals with correct PIN unlocks')
    page.evaluate('reset()');assert page.evaluate('locked()');print('PASS Relock revokes access')
    browser.close()
