import asyncio, unittest
import test_server

class CallAlertAck(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=test_server.APITest.asyncSetUp
    asyncTearDown=test_server.APITest.asyncTearDown
    h=test_server.APITest.h
    register=test_server.APITest.register
    async def open_call(self, ident, video=False):
        a=await self.client.ws_connect('/api/socket');self.addAsyncCleanup(a.close)
        await a.send_json({'token':self.a['token'],'callIds':True});features=(await a.receive_json(timeout=2))['features'];self.assertIn('call-alert-ack-v1',features)
        await a.send_json({'type':'call','room':self.room,'callId':ident,'video':video});self.assertEqual((await a.receive_json(timeout=2))['type'],'call');return a
    async def ack(self,user,ident,status='alerted'):
        return await self.client.post('/api/calls/alert-ack',headers=self.h(user),json={'callId':ident,'status':status})
    async def test_authenticated_callee_only_and_dedup(self):
        ident='ack_direct_audio_001';a=await self.open_call(ident)
        self.assertEqual((await self.client.post('/api/calls/alert-ack',json={'callId':ident,'status':'alerted'})).status,401)
        for user,call,status,expected in [(self.a,ident,'alerted',409),(self.c,ident,'alerted',409),(self.b,'wrong_call_123','alerted',409),(self.b,ident,'bogus',400)]:
            self.assertEqual((await self.ack(user,call,status)).status,expected)
        current=await (await self.client.get('/api/calls/current',headers=self.h(self.a))).json();self.assertNotIn('alertStatus',current)
        self.assertEqual((await self.ack(self.b,ident,'displayed')).status,200);ev=await a.receive_json(timeout=2);self.assertEqual((ev['type'],ev['callId'],ev['status']),('call-alert-ack',ident,'displayed'))
        self.assertEqual((await self.ack(self.b,ident)).status,200);self.assertEqual((await a.receive_json(timeout=2))['status'],'alerted')
        self.assertEqual((await self.ack(self.b,ident)).status,200);self.assertEqual((await self.ack(self.b,ident,'displayed')).status,200)
        with self.assertRaises(asyncio.TimeoutError):await a.receive_json(timeout=.15)
        current=await (await self.client.get('/api/calls/current',headers=self.h(self.a))).json();self.assertEqual(current['alertStatus'],'alerted')
        await a.send_json({'type':'hangup','room':self.room,'callId':ident});self.assertEqual((await a.receive_json(timeout=2))['type'],'hangup');self.assertEqual((await self.ack(self.b,ident)).status,409)
    async def test_video_muted_and_expired(self):
        await self.client.patch('/api/me',headers=self.h(self.b),json={'mutedPeers':[self.a['user']['id']]})
        ident='ack_direct_video_001';a=await self.open_call(ident,True)
        self.assertEqual((await self.ack(self.b,ident)).status,200);self.assertEqual((await a.receive_json(timeout=2))['status'],'silent')
        store=self.app['store'];store.calls[self.b['user']['id']]['started']-=46000
        self.assertEqual((await self.ack(self.b,ident)).status,409)
    async def test_accepted_call_rejects_late_receipt(self):
        ident='ack_accepted_001';a=await self.open_call(ident)
        b=await self.client.ws_connect('/api/socket');self.addAsyncCleanup(b.close);await b.send_json({'token':self.b['token'],'callIds':True});await b.receive_json(timeout=2)
        await b.send_json({'type':'accepted','room':self.room,'callId':ident});self.assertEqual((await a.receive_json(timeout=2))['type'],'accepted');self.assertEqual((await self.ack(self.b,ident)).status,409)
