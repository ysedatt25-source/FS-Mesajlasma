"""Chromium offline audio filters and DSP; not physical capture or remote RTP."""
import json, os, pathlib
from playwright.sync_api import sync_playwright
root=pathlib.Path(__file__).resolve().parents[1]
dsp=(root/'web/voice-transform-dsp.js').read_text().replace('export ','')
voice=(root/'web/call-voice.js').read_text().split('export function createVoiceFilters(context,mode){',1)[1].split('\nconst stop=',1)[0]
with sync_playwright() as p:
    b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM','/usr/bin/chromium'),args=['--no-sandbox'])
    try:
        pg=b.new_page();pg.set_content('<html></html>')
        results=pg.evaluate('''async()=>{'''+dsp+'\nfunction createVoiceFilters(context,mode){'+voice+'''
        const rate=48000, results=[];
        for(const mode of ['female','male']){
          const ctx=new OfflineAudioContext(1,rate,rate), f=createVoiceFilters(ctx,mode);
          const freq=new Float32Array([20,300,1000,4000]), mag=new Float32Array(4),phase=new Float32Array(4);
          f.highpass.getFrequencyResponse(freq,mag,phase);
          if(mag[0]>.12||mag[1]<.93||mag[2]<.98)throw Error('Unexpected rumble filter '+Array.from(mag));
          const input=ctx.createBuffer(1,rate,rate),samples=input.getChannelData(0);
          for(let i=0;i<rate;i++)samples[i]=.95*Math.sin(2*Math.PI*440*i/rate);
          const source=ctx.createBufferSource();source.buffer=input;
          source.connect(f.highpass).connect(f.shelf).connect(f.warmth).connect(f.limiter).connect(ctx.destination);source.start();
          const out=(await ctx.startRendering()).getChannelData(0);
          let peak=0,sum=0;for(let i=rate/4;i<rate;i++){if(!Number.isFinite(out[i]))throw Error('Nonfinite audio');peak=Math.max(peak,Math.abs(out[i]));sum+=out[i]*out[i];}
          const rms=Math.sqrt(sum/(rate*.75));if(!(rms>.05&&peak<.90))throw Error('Unexpected processed levels '+peak+' '+rms);
          results.push({mode,rumble_20hz_db:20*Math.log10(mag[0]),speech_1000hz_db:20*Math.log10(mag[2]),steady_peak:peak,rms});
        }return results;
        }''')
        print(json.dumps(results,indent=2))
    finally:b.close()
