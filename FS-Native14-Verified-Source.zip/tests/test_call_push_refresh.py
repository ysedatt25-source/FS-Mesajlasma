import asyncio,time,unittest
import test_server
class CallPushRefresh(unittest.IsolatedAsyncioTestCase):
 asyncSetUp=test_server.APITest.asyncSetUp
 asyncTearDown=test_server.APITest.asyncTearDown
 h=test_server.APITest.h
 register=test_server.APITest.register
 async def test_terminal_call_refresh_is_bounded_and_authenticated(self):
  s=self.app['store'];sent=[];s.push.transport=lambda t,d,ttl:sent.append((t,d,ttl)) or True
  uid=self.b['user']['id'];token='FCM_call_refresh_registration_012345';binding='call_refresh_binding_0123456789'
  self.assertEqual((await self.client.post('/api/push/registration',headers=self.h(self.b),json={'registration':token,'binding':binding})).status,200)
  a=await self.client.ws_connect('/api/socket');self.addAsyncCleanup(a.close);await a.send_json({'token':self.a['token'],'callIds':True});await a.receive_json(timeout=2)
  await a.send_json({'type':'call','room':self.room,'callId':'refresh_call_123','video':False});await a.receive_json(timeout=2)
  self.assertEqual(await asyncio.wait_for(s.push.queue.get(),2),uid);await s.push.deliver(uid)
  await a.send_json({'type':'hangup','room':self.room,'callId':'refresh_call_123'});await a.receive_json(timeout=2)
  item=await asyncio.wait_for(s.push.queue.get(),2);self.assertEqual(item[:3],(uid,None,None));await s.push.deliver(*item)
  self.assertEqual([x[1] for x in sent],[{'kind':'call-wakeup-v1','binding':binding},{'kind':'call-refresh-v1','binding':binding}]);self.assertTrue(0<sent[1][2]<=15000)
  h={**self.h(self.b),'X-FS-Push-Binding':binding};self.assertIsNone((await(await self.client.get('/api/push/ringing',headers=h)).json())['ringing'])
  await s.push.deliver(uid,None,None,time.monotonic()-1);self.assertEqual(len(sent),2)
  await self.client.post('/api/logout',headers=self.h(self.b));await s.push.deliver(uid,None,None,time.monotonic()+10);self.assertEqual(len(sent),2)
if __name__=='__main__':unittest.main()
