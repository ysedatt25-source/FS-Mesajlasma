"""Native Chromium sender API test, synthetic video source; not a phone/network benchmark."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import os
root=Path(__file__).resolve().parents[1]
src=(root/'web/call-quality.js').read_text().replace('export function','function')
with sync_playwright() as p:
    b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
    pg=b.new_page()
    pg.set_content('<canvas width="640" height="360"></canvas>')
    r=pg.evaluate('''async()=>{'''+src+'''
      const canvas=document.querySelector('canvas');canvas.getContext('2d').fillRect(0,0,640,360);
      const stream=canvas.captureStream(30),track=stream.getVideoTracks()[0];preferVideoDetail(track);
      const pc=new RTCPeerConnection();const sender=pc.addTrack(track,stream);
      try{
        await pc.setLocalDescription(await pc.createOffer());
        const before=sender.getParameters();const q=createCallQuality();
        const res=await q.sample(pc);const after=sender.getParameters();
        const simulated=(reason,fps)=>new Map([
          ['p',{id:'p',type:'candidate-pair',state:'succeeded',nominated:true,availableOutgoingBitrate:8000000,currentRoundTripTime:.08}],
          ['t',{id:'t',type:'transport',selectedCandidatePairId:'p'}],
          ['cam',{id:'cam',type:'media-source',kind:'video',framesPerSecond:30}],
          ['v',{id:'v',type:'outbound-rtp',kind:'video',mediaSourceId:'cam',transportId:'t',qualityLimitationReason:reason,framesPerSecond:fps}]
        ]);
        let measurements=simulated('cpu',8);
        // Inject controlled metrics, but apply every policy to the real browser sender.
        const controlled={connectionState:'connected',getStats:async()=>measurements,getSenders:()=>[sender]};
        const policy=createCallQuality(),modes=[];
        for(let i=0;i<3;i++){await policy.sample(controlled);modes.push(sender.getParameters().degradationPreference);}
        measurements=simulated('none',30);
        for(let i=0;i<3;i++)await policy.sample(controlled);
        modes.push(sender.getParameters().degradationPreference);
        return {mode:res.mode,hint:track.contentHint,applied:after.degradationPreference,before:before.encodings,after:after.encodings,modes,final:sender.getParameters().encodings};
      }finally{pc.close();track.stop()}
    }''')
    assert r['hint']=='detail' and r['mode']=='maintain-resolution', r
    assert r['applied']=='maintain-resolution',r
    assert r['before']==r['after']==r['final'],r
    assert r['modes']==['maintain-resolution','balanced','maintain-framerate','maintain-resolution'],r
    print('PASS real Chromium RTCRtpSender accepts detail preference without bitrate or resolution cap:',r)
    b.close()
