"""Real browser ICE restart; local synthetic peers, not a phone/network-switch benchmark."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import os
root=Path(__file__).resolve().parents[1]
src=(root/'web/call-recovery.js').read_text().replace('export ','')
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
    page=browser.new_page()
    page.set_content('<canvas width="320" height="240"></canvas>')
    result=page.evaluate('''async()=>{'''+src+'''
      const a=new RTCPeerConnection(),b=new RTCPeerConnection(),canvas=document.querySelector('canvas');
      const context=canvas.getContext('2d'),stream=canvas.captureStream(15),track=stream.getVideoTracks()[0];
      const paint=setInterval(()=>{context.fillStyle=`rgb(${Math.floor(Math.random()*255)},0,0)`;context.fillRect(0,0,320,240)},70);
      const qa=[],qb=[];a.onicecandidate=e=>{if(e.candidate)acceptIce(b,qb,e.candidate).catch(()=>{})};b.onicecandidate=e=>{if(e.candidate)acceptIce(a,qa,e.candidate).catch(()=>{})};
      const sender=a.addTrack(track,stream);let received; b.ontrack=e=>{received=e.track};
      const wait=async (label,pred)=>{for(let i=0;i<100;i++){if(pred())return;await new Promise(r=>setTimeout(r,100))}throw Error(label+' timeout: '+JSON.stringify([a,b].map(pc=>({connection:pc.connectionState,ice:pc.iceConnectionState,gathering:pc.iceGatheringState,signaling:pc.signalingState,candidates:(pc.localDescription?.sdp.match(/^a=candidate:/gm)||[]).length}))))};
      async function offer(d){await b.setRemoteDescription(d);await drainIce(b,qb);await b.setLocalDescription(await b.createAnswer());await a.setRemoteDescription(b.localDescription);await drainIce(a,qa)}
      try{await a.setLocalDescription(await a.createOffer());await offer(a.localDescription);await wait('initial connection',()=>a.connectionState==='connected'&&b.connectionState==='connected'&&!!received);
       const original=a.localDescription,remote=received;let now=0,sent=[];
       const recovery=createIceRecovery({pc:a,offerer:true,valid:()=>true,clock:()=>now,send:(type,payload)=>sent.push([type,payload])});
       recovery.request();await recovery.tick();now=3000;await recovery.tick();
       if(sent.length!==1||sent[0][0]!=='offer')throw Error('restart missing');
       if(!isRestartOffer(original,sent[0][1].description))throw Error('ICE credentials unchanged');
       await offer(sent[0][1].description);recovery.answered();await wait('ICE restart',()=>a.connectionState==='connected'&&b.connectionState==='connected');
       return {sameSender:sender===a.getSenders()[0],sameTrack:sender.track===track,sameRemote:received===remote,states:[a.connectionState,b.connectionState]};
      }finally{clearInterval(paint);a.close();b.close();track.stop();}
    }''')
    assert result=={'sameSender':True,'sameTrack':True,'sameRemote':True,'states':['connected','connected']},result
    print('PASS local real WebRTC restart, same sender and tracks:',result)
    browser.close()
