"""Exercise the actual banner and resume helpers in isolated Chromium DOM."""
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
s=(root/'web/app.js').read_text(); helpers=s[s.index('function syncCallReturnBanner(){'):s.index('function shell(')]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']); page=b.new_page()
 page.set_content('<div id="app"></div>');page.evaluate('''()=>{const $=s=>document.querySelector(s),app=$('#app');let locked=false;const state={page:'home',token:'t',user:{},call:{video:true}};const isLocked=()=>locked;let attached=0,bound=0;function attachVideo(){attached++}function bindChatPip(){bound++}function syncChatViewport(){}\n'''+helpers+'''\nwindow.test=(route,lock,active,token=true)=>{state.page=route;locked=lock;state.call=active?{video:true}:null;state.token=token?'t':null;app.innerHTML='<section class="screen '+(route==='chat'?'fs-chat':'')+'"><input value="draft"></section>';restoreCallSurface();restoreCallSurface();return {count:app.querySelectorAll('.call-banner').length,mini:!!$('#call-mini'),draft:app.querySelector('input').value,attached,bound}};window.repair=()=>{app.querySelector('.call-banner').remove();restoreCallSurface();return app.querySelectorAll('.call-banner').length};window.end=()=>{state.call=null;syncCallReturnBanner();return app.querySelectorAll('.call-banner').length};}''')
 for route in ['home','chat','settings','profile','gallery','admin','search']:
  r=page.evaluate('(r)=>test(r,false,true)',route);assert r['count']==1 and r['draft']=='draft' and r['mini']==(route=='chat'),r
 print('PASS Seven eligible routes, idempotence, draft preservation and chat mini')
 for route in ['call','lock','setup','auth']:
  assert page.evaluate('(r)=>test(r,false,true)',route)['count']==0
 assert page.evaluate("test('home',true,true)")['count']==0
 assert page.evaluate("test('home',false,true,false)")['count']==0
 print('PASS Call, PIN, setup, auth and missing-token exclusions')
 page.evaluate("test('chat',false,true)");assert page.evaluate('repair()')==1;assert page.evaluate('end()')==0
 print('PASS Resume repairs missing banner; ended call removes banner')
 b.close()
