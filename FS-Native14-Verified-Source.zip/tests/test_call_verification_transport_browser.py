"""Compare actual negotiated DTLS certificate stats on two local Chromium peers."""
from pathlib import Path
import hashlib, os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
src=(root/'call-verification.js').read_text().replace('export ','').replace('subtle=globalThis.crypto.subtle','subtle={digest:async(_,bytes)=>Uint8Array.from(await window.fixtureDigest(new TextDecoder().decode(bytes))).buffer}')
with sync_playwright() as p:
    b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--disable-features=WebRtcHideLocalIpsWithMdns'])
    page=b.new_page();page.expose_function('fixtureDigest',lambda m:list(hashlib.sha256(m.encode()).digest()))
    page.set_content('<canvas width="32" height="32"></canvas>')
    result=page.evaluate('''async()=>{'''+src+'''
      const a=new RTCPeerConnection(),b=new RTCPeerConnection(),id='b'.repeat(32),stream=document.querySelector('canvas').captureStream(5),qa=[],qb=[];
      a.addTrack(stream.getVideoTracks()[0],stream);a.createDataChannel('test');
      const add=async(pc,q,c)=>{if(!c)return;if(pc.remoteDescription)await pc.addIceCandidate(c);else q.push(c)};
      a.onicecandidate=e=>add(b,qb,e.candidate).catch(()=>{});b.onicecandidate=e=>add(a,qa,e.candidate).catch(()=>{});
      const wait=async(fn)=>{for(let i=0;i<120;i++){if(await fn())return;await new Promise(r=>setTimeout(r,100))}throw Error('Local DTLS connection or certificate statistics unavailable')};
      try{await a.setLocalDescription(await a.createOffer());await b.setRemoteDescription(a.localDescription);for(const c of qb.splice(0))await b.addIceCandidate(c);await b.setLocalDescription(await b.createAnswer());await a.setRemoteDescription(b.localDescription);for(const c of qa.splice(0))await a.addIceCandidate(c);
      await wait(()=>a.connectionState==='connected'&&b.connectionState==='connected');
      let x,y;await wait(async()=>{x=callVerificationSnapshot(a,id);y=callVerificationSnapshot(b,id);return await verifyCallTransport(x)&&await verifyCallTransport(y)});
      const digestA=await verificationDigest(x),digestB=await verificationDigest(y);const equal=digestA.every((v,i)=>v===digestB[i]);
      a.close();return {equal,closedRejected:!await verifyCallTransport(x)};
      }finally{a.close();b.close();for(const t of stream.getTracks())t.stop()}
    }''')
    assert result=={'equal':True,'closedRejected':True},result
    print('PASS actual local peer DTLS certificates, matching code, and closed connection rejection')
    b.close()
