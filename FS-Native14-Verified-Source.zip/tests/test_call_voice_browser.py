"""Real Chromium WebAudio + WebRTC loopback; synthetic tone, not human voice quality."""
import functools, http.server, json, os, pathlib, threading
from playwright.sync_api import sync_playwright
root=pathlib.Path(__file__).resolve().parents[1]/'web'
class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*args): pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root)))
threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM','/usr/bin/chromium'),args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
    page=browser.new_page();page.on('console',lambda msg: print(msg.text,flush=True) if msg.type=='error' else None);page.goto(f'http://127.0.0.1:{server.server_port}/calculator-window.html')
    result=page.evaluate('''async()=>{
      const {createOutgoingVoice}=await import('/call-voice.js');const result=[];
      const wait=ms=>new Promise(r=>setTimeout(r,ms));
      const until=async(fn,label,ms=10000)=>{const end=performance.now()+ms;while(performance.now()<end){if(await fn())return;await wait(50)}throw Error('Timeout: '+label)};
      const gather=pc=>until(()=>pc.iceGatheringState==='complete','ICE gathering');
      const audioStats=async(pc,type)=>[...(await pc.getStats()).values()].filter(s=>s.type===type&&(s.kind==='audio'||s.mediaType==='audio')).map(s=>({packetsReceived:s.packetsReceived,bytesReceived:s.bytesReceived,packetsSent:s.packetsSent,bytesSent:s.bytesSent,totalAudioEnergy:s.totalAudioEnergy,audioLevel:s.audioLevel}));
      for(const mode of ['normal','female','male']){
       const ctx=new AudioContext({sampleRate:48000});await ctx.resume();
       const osc=ctx.createOscillator(),gain=ctx.createGain(),dest=ctx.createMediaStreamDestination();osc.frequency.value=200;gain.gain.value=.25;osc.connect(gain).connect(dest);osc.start();
       // Keep the synthetic source graph pulled even before the peer connects.
       const keep=ctx.createGain();keep.gain.value=.00001;gain.connect(keep).connect(ctx.destination);
       const raw=dest.stream;let voice;const a=new RTCPeerConnection(),b=new RTCPeerConnection();let element,receiver,source,analyser,silent;
       try{
        voice=await createOutgoingVoice(raw,mode);
        let stream;b.ontrack=e=>{stream=e.streams[0]||new MediaStream([e.track])};
        const sender=a.addTrack(voice.stream.getAudioTracks()[0],voice.stream);
        // Wait for the complete offer/answer candidate set rather than losing
        // late candidates from an asynchronously populated array.
        await a.setLocalDescription(await a.createOffer());await gather(a);
        await b.setRemoteDescription(a.localDescription);
        await b.setLocalDescription(await b.createAnswer());await gather(b);
        await a.setRemoteDescription(b.localDescription);
        await until(()=>stream&&a.connectionState==='connected'&&b.connectionState==='connected','both peers connected');
        element=document.createElement('audio');element.autoplay=true;element.volume=0;element.srcObject=stream;document.body.append(element);let playing=false,playError;element.play().then(()=>playing=true,e=>playError=e);await until(()=>{if(playError)throw playError;return playing},'remote audio playback',5000);
        // Explicitly pull the remote graph; a disconnected analyser may yield
        // only -Infinity even while RTP packets are arriving in headless CI.
        receiver=new AudioContext({sampleRate:48000});await receiver.resume();
        analyser=receiver.createAnalyser();analyser.fftSize=16384;analyser.smoothingTimeConstant=0;
        source=receiver.createMediaStreamSource(stream);silent=receiver.createGain();silent.gain.value=.00001;source.connect(analyser).connect(silent).connect(receiver.destination);
        const data=new Float32Array(analyser.frequencyBinCount);let peak=0,db=-Infinity;
        for(let i=0;i<100;i++){await wait(100);analyser.getFloatFrequencyData(data);let best=-Infinity,k=0;for(let j=20;j<130;j++){if(data[j]>best){best=data[j];k=j;}}peak=k*receiver.sampleRate/analyser.fftSize;db=best;if(db>-65&&i>10)break;}
        const inbound=await audioStats(b,'inbound-rtp');const outbound=await audioStats(a,'outbound-rtp');
        const diagnostic=JSON.stringify({mode,connection:[a.connectionState,b.connectionState],ice:[a.iceConnectionState,b.iceConnectionState],contexts:[ctx.state,receiver.state],tracks:stream.getAudioTracks().map(t=>({muted:t.muted,enabled:t.enabled,state:t.readyState})),inbound,outbound,peak,db:String(db)});
        if(!inbound.some(s=>s.packetsReceived>0&&s.bytesReceived>0))throw Error('No received RTP audio '+diagnostic);
        if(!(db>-65))throw Error('No received audio '+diagnostic);const target={normal:200,female:267,male:159}[mode];if(Math.abs(peak-target)>20)throw Error('Wrong pitch '+diagnostic);
        if(a.connectionState!=='connected'||b.connectionState!=='connected')throw Error('Peer disconnected '+diagnostic);
        if((sender.track===raw.getAudioTracks()[0])!==(mode==='normal'))throw Error('Wrong outgoing track');
        result.push({mode,received_hz:Math.round(peak*10)/10,peak_db:Math.round(db),connection:a.connectionState,raw_bypass:mode==='normal',inbound});
       }catch(error){console.error('voice-loopback',mode,error.message,JSON.stringify({outbound:await audioStats(a,'outbound-rtp'),inbound:await audioStats(b,'inbound-rtp')}));throw error;}
       finally{if(element){element.pause();element.srcObject=null;element.remove()}source?.disconnect();analyser?.disconnect();silent?.disconnect();if(receiver)await receiver.close();a.close();b.close();voice?.close();raw.getTracks().forEach(t=>t.stop());osc.stop();await ctx.close();}
      }return result;
    }''')
    browser.close();print(json.dumps(result,indent=2))
finally: server.shutdown()
