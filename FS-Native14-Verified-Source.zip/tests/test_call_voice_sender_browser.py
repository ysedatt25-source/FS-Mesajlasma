"""Real Chromium DSP and sender configuration without secure-origin navigation.
Does not validate AudioWorklet execution, remote RTP or Android hardware."""
import os,json,pathlib
from playwright.sync_api import sync_playwright
root=pathlib.Path(__file__).resolve().parents[1]
dsp=(root/'web/voice-transform-dsp.js').read_text().replace('export ','')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM','/usr/bin/chromium'),args=['--no-sandbox','--autoplay-policy=no-user-gesture-required'])
 pg=b.new_page();pg.set_content('<html></html>')
 result=pg.evaluate('''async()=>{'''+dsp+'''
 const ctx=new AudioContext({sampleRate:48000});await ctx.resume();const r=[];
 for(const mode of ['normal','female','male']){
 const n=48000*2,buf=ctx.createBuffer(1,n,48000),out=buf.getChannelData(0),pitch=new StreamingPitch(48000,VOICE_PROFILES[mode].ratio);
 for(let i=0;i<n;i+=128){const len=Math.min(128,n-i),x=Float32Array.from({length:len},(_,j)=>.4*Math.sin(2*Math.PI*200*(i+j)/48000));pitch.process(x,out.subarray(i,i+len));}
 let peak=0,best=0;for(let f=100;f<350;f++){let re=0,im=0;for(let i=0;i<24000;i++){const a=2*Math.PI*f*i/48000;re+=out[48000+i]*Math.cos(a);im+=out[48000+i]*Math.sin(a);}if(re*re+im*im>best){best=re*re+im*im;peak=f;}}
 const dest=ctx.createMediaStreamDestination(),source=ctx.createBufferSource();source.buffer=buf;source.loop=true;source.connect(dest);source.start();const pc=new RTCPeerConnection();
 try{const track=dest.stream.getAudioTracks()[0],sender=pc.addTrack(track,dest.stream);await pc.setLocalDescription(await pc.createOffer());if(sender.track!==track||!pc.localDescription.sdp.includes('m=audio'))throw Error('Sender not connected');if(Math.abs(peak-200*VOICE_PROFILES[mode].ratio)>18)throw Error('Unexpected pitch');r.push({mode,frequency_hz:peak,rtc_offer_audio:true});}finally{pc.close();source.stop();dest.stream.getTracks().forEach(t=>t.stop());}
 }await ctx.close();return r;}
 ''');print(json.dumps(result,indent=2));b.close()
