"""Isolated production chat template, message renderer and grouping helper in Chromium."""
from pathlib import Path
import os,re
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]; web=root/'web'; app=(web/'app.js').read_text()
markup=next(line.strip() for line in app.splitlines() if 'app.innerHTML = `<section class="screen chat-wall fs-premium fs-chat"' in line)
render=app[app.index('function renderMessage(m) {'):app.index('async function send(payload,')]
layout=(web/'chat-layout.js').read_text().replace('export function','function')+"\n"+(web/'message-details.js').read_text().replace('export function','function')
layout+='\n'+(web/'message-effects.js').read_text().replace('export ','')+"\n"+app[app.index("function keyedMessages(target, markup)"):app.index("const audioUrls = new MediaUrlCache")]
layout+='\n'+(web/'call-chat-fixes.js').read_text().replace('export ','')+'\n'+app[app.index('function linkText('):app.index('function openExternal(')]
options=next(line.strip() for line in app.splitlines() if line.strip().startswith("case 'chat-options':"))
icons=(web/'icons.js').read_text().replace('export const icon','const icon')
layout+='\n'+next(line for line in app.splitlines() if line.startswith('function peerPresenceLabel('))
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page();page.set_content('<meta name="viewport" content="width=device-width,initial-scale=1"><div id="app"></div><dialog id="modal"></dialog>');page.add_style_tag(content=(web/'style.css').read_text())
 page.evaluate('''()=>{'''+icons+layout+'''
 const app=document.querySelector('#app'),room={kind:'direct',members:[{id:'a'},{id:'b'}]},peer={status:'online'},state={room,user:{id:'a'},settings:{available:true,blur:true},selected:new Set(),call:null,page:'chat'};
 const escape=s=>String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
 const name=()=> 'Çok uzun kişi adı örnek örnek örnek';const avatar=()=>'<span class="avatar">FS</span>';
 const button=(action,ico,label,extra='')=>`<button class="icon" data-action="${action}" aria-label="${label}" ${extra}>${icon(ico)}</button>`;
 '''+markup+'''
 const localStateForMenu={preferences:{pinned:[],archived:[]}};state.room.id='r';
 window.openChatOptions=()=>{const localState=localStateForMenu,autoDeleteLabel=()=> '1 gün';function dialog(title,html){const modal=document.querySelector('#modal');modal.innerHTML='<button class="dialog-close" data-action="close-dialog">×</button><h2>'+title+'</h2>'+html;modal.showModal()};switch('chat-options'){'''+options+'''}};
 const isSingleEmoji=t=>t==='❤️',emojiAsset=()=>null,emojiIndex={},emojiFilePath=()=>null,formattedMessageText=t=>escape(t),preview=p=>p.text||p.name||'',audioUrls=new Map(),localState={playback:{}},voiceDurationHint=()=>0,isViewOnce=m=>!!m.payload.viewOnce,onceStatus=()=> 'Bir kez açılabilir',quoteSnapshot=()=>null,validQuote=()=>true,senderName=()=> 'Gönderen adı çok uzun olabilir',sameReaction=(a,b)=>a===b,time=()=> '12:45',messageIndex={byId:new Map(),reactions:new Map(),votes:new Map()};
 '''+render+'''
 const start=Date.now(),msg=(id,sender,payload,extra={})=>({id,sender,payload,created:start,...extra});
 const texts=[msg('m1','b',{type:'text',text:'Merhaba, iyi günler.'}),msg('m2','b',{type:'text',text:'Birlikte gelen mesaj. '+ 'çokuzun'.repeat(22)}),msg('m3','a',{type:'text',text:'Teşekkür ederim.'}),msg('m4','a',{type:'text',text:'❤️'}),msg('m5','b',{type:'file',mime:'audio/mp4',name:'ses.m4a',size:1200}),msg('m6','a',{type:'file',mime:'application/pdf',name:'uzun-dosya-adi-'.repeat(14)+'.pdf',size:1024}),msg('m7','b',{type:'file',mime:'video/mp4',name:'video.mp4',size:1000,viewOnce:true}),msg('m8','b',{type:'text',text:'Alıntı mesajı'},{reply:'m2'})];
 texts.forEach(m=>messageIndex.byId.set(m.id,m));
 const list=document.querySelector('#messages');
 list.innerHTML='<div class="message-row"><div class="day">25.11.2026</div></div>'+Array.from({length:3},(_,r)=>texts.map((m,i)=>{const before=chatMessageJoined(texts[i-1],m,{singleEmoji:isSingleEmoji}),after=chatMessageJoined(m,texts[i+1],{singleEmoji:isSingleEmoji});return `<div class="message-row"><div class="tg-message-line" data-bubble-group="${before?(after?'middle':'end'):(after?'start':'single')}">${renderMessage({...m,id:m.id+'-'+r})}</div></div>`}).join('')).join('');
 window.testMediaCards=()=>{room.kind='direct';list.classList.remove('selection-active');const file=(id,mime)=>msg(id,'b',{type:'file',mime,name:'uzun-dosya-'.repeat(30)+'.jpg',size:1048576});const album=Array.from({length:6},(_,i)=>file('photo'+i,'image/jpeg'));list.innerHTML=[file('doc','application/pdf'),file('vid','video/mp4'),file('img','image/jpeg'),{...album[0],album}].map(m=>'<div class="message-row">'+renderMessage(m)+'</div>').join('');};
 window.keyedMessages=keyedMessages;window.testStage02=()=>{room.kind="group";list.classList.remove("selection-active");list.innerHTML=["start","middle","end","single"].map((g,i)=>`<div class="message-row" data-row-id="test${i}"><div class="tg-message-line" data-bubble-group="${g}">${renderMessage(msg("test"+i,i===3?"a":"b",{type:"text",text:"Test message"},{bubbleGroup:g,pending:i===3}))}</div></div>`).join("");window.playNew=()=>animateComposerSend(list,"test3",{x:100,y:400});};
 window.testReceiptStates=()=>{room.kind='direct';list.innerHTML=[{}, {receipts_v2:[{user:'b',delivered:20}]}, {receipts_v2:[{user:'b',delivered:20,read_at:25}]}].map((m,i)=>renderMessage(msg('receipt'+i,'a',{type:'text',text:'Durum'},m))).join('');};
 window.selectMode=()=>{list.classList.add('selection-active');for(const line of list.querySelectorAll('.tg-message-line'))line.insertAdjacentHTML('afterbegin','<button class="selection-dot" aria-label="Mesajı seç">✓</button>')};
 }''')
 page.wait_for_timeout(180)
 for theme in ('dark','light'):
  page.evaluate('(theme)=>document.body.classList.toggle("light",theme==="light")',theme)
  for w,h in [(280,560),(320,640),(390,844),(390,300),(844,390),(540,720)]:
   page.set_viewport_size({'width':w,'height':h});page.wait_for_timeout(60)
   result=page.evaluate('''()=>{const a=document.querySelector('#app'),l=document.querySelector('#messages'),c=document.querySelector('#compose'),h=document.querySelector('.chat-head'),ar=a.getBoundingClientRect(),cr=c.getBoundingClientRect(),hr=h.getBoundingClientRect(),lr=l.getBoundingClientRect();const within=e=>{const r=e.getBoundingClientRect();return r.left>=ar.left-1&&r.right<=ar.right+1};const children=[...document.querySelectorAll('.message,.voice-message,.voice-message button,.file-button,.once-media,.reply-quote,.chat-head>button,.composer button,#message-text')];return {shell:cr.bottom<=ar.bottom+1&&hr.bottom<=lr.top+1&&lr.bottom<=cr.top+1,scroll:l.clientHeight>50&&l.scrollHeight>l.clientHeight,within:children.every(within),bubbleWidth:[...l.querySelectorAll('.message:not(.emoji)')].every(e=>e.scrollWidth<=e.clientWidth+2),composerWidth:c.scrollWidth<=c.clientWidth+1&&document.querySelector('#message-text').getBoundingClientRect().width>=40,emoji:getComputedStyle(l.querySelector('.emoji')).backgroundColor==='rgba(0, 0, 0, 0)',group: getComputedStyle(l.querySelector('[data-bubble-group=start]').parentElement).paddingBottom==='2px'&&getComputedStyle(l.querySelector('[data-bubble-group=end] .message')).borderTopLeftRadius==='5px'}}''')
   assert all(result.values()),(theme,w,h,result)
   print(f'PASS {theme} {w}x{h} chat geometry, media, group, emoji and scroll')
 page.set_viewport_size({'width':390,'height':844});assert page.locator('.fs-text-bubble>time').first.evaluate('e=>getComputedStyle(e).display')=='inline-block';assert page.locator('.fs-chat-text').count()>0;print('PASS compact text and inline message time')
 page.set_viewport_size({'width':280,'height':560});page.evaluate('selectMode()');
 assert page.evaluate('''()=>{const a=document.querySelector('#app').getBoundingClientRect();return [...document.querySelectorAll('.selection-dot,.message')].every(e=>{const r=e.getBoundingClientRect();return r.left>=a.left-1&&r.right<=a.right+1})}''')
 print('PASS selection geometry 280px')
 page.emulate_media(reduced_motion='reduce');assert page.locator('.chat-head').evaluate('e=>getComputedStyle(e).animationName')=='none';print('PASS reduced motion')
 page.emulate_media(reduced_motion='no-preference');page.set_viewport_size({'width':390,'height':844});page.evaluate('testStage02()');
 assert page.locator('.fs-bubble-sender').count()==1;print('PASS group sender only at group start')
 assert page.locator('.receipt-mark[data-receipt=pending]').count()==1;print('PASS semantic receipt marker')
 assert page.evaluate('''()=>{let a=document.querySelector('[data-bubble-group=start]'),b=document.querySelector('[data-bubble-group=end]');return getComputedStyle(a,'::before').content==='none'&&getComputedStyle(b,'::before').content!=='none'}''');print('PASS tail only on final bubble')
 assert page.evaluate('playNew()') is True;assert page.evaluate('playNew()') is False;print('PASS one-shot actual bubble animation')
 page.evaluate('testStage02()');assert page.evaluate("""()=>{const list=document.querySelector('#messages'),row=list.querySelector('[data-row-id=test3]'),line=row.firstElementChild;for(const el of list.children){el.dataset.key=el.dataset.rowId;el._fsMarkup=el.outerHTML;}const fresh=row.cloneNode(true);fresh.querySelector('.receipt-mark').textContent='✓';if(!playNew())return false;const animation=line.getAnimations()[0];keyedMessages(list,[...list.children].map(e=>e===row?fresh.outerHTML:e.outerHTML).join(''));return list.querySelector('[data-row-id=test3]').firstElementChild===line&&line.getAnimations().includes(animation)&&line.querySelector('.receipt-mark').textContent==='✓';}""") is True;print('PASS receipt acknowledgement preserves running send animation')
 page.evaluate('testStage02()');page.emulate_media(reduced_motion='reduce');assert page.evaluate('playNew()') is False;print('PASS animation respects reduced motion')
 page.evaluate('testReceiptStates()');assert page.locator('.receipt-mark').all_text_contents()==['✓','✓','✓✓'];assert page.locator('.receipt-mark').evaluate_all('(rows)=>rows.map(r=>r.dataset.receipt)')==['accepted','delivered','read'];assert page.locator('.receipt-mark[data-receipt=delivered]').get_attribute('title').startswith('Teslim edildi');print('PASS Telegram-style receipt counts preserve distinct delivery state')
 page.set_viewport_size({'width':390,'height':844});page.emulate_media(reduced_motion='no-preference');page.evaluate("document.body.classList.add('light');testStage02()");page.wait_for_timeout(220)
 assert page.locator('.chat-head [data-action="chat-options"]').count()==1
 assert page.locator('.chat-head [data-action="audio-call"]').count()==1 and page.locator('.chat-head [data-action="video-call"]').count()==1
 assert page.locator('.chat-head [data-action="available"]').count()==1
 assert not page.locator('.chat-return-tools').is_visible();page.evaluate("document.querySelector('#return-reply').hidden=false");assert page.locator('.chat-return-tools').is_visible();page.evaluate("document.querySelector('#return-reply').hidden=true")
 assert page.locator('.chat-peer-name').evaluate('e=>getComputedStyle(e).textOverflow')=='ellipsis'
 print('PASS header actions, name overflow and conditional return-to-reply strip')
 for theme,colors in [('light',('rgb(255, 255, 255)','rgb(226, 255, 199)')),('dark',('rgb(33, 46, 61)','rgb(43, 82, 120)'))]:
  page.evaluate('(theme)=>document.body.classList.toggle("light",theme==="light")',theme)
  assert page.locator('.fs-text-bubble:not(.mine)').first.evaluate('e=>getComputedStyle(e).backgroundColor')==colors[0]
  assert page.locator('.fs-text-bubble.mine').first.evaluate('e=>getComputedStyle(e).backgroundColor')==colors[1]
  assert page.locator('#messages').evaluate('e=>getComputedStyle(e).backgroundImage.startsWith("url(")')
  print('PASS '+theme+' incoming/outgoing colors and original local wallpaper')
 page.evaluate("document.querySelector('#messages').insertAdjacentHTML('afterbegin','<div class=message-row><div class=day>27 Kasım 2026</div><div class=unread-divider>Okunmamış mesajlar</div></div>')")
 assert page.locator('.day').evaluate('e=>getComputedStyle(e).borderRadius')=='14px'
 for theme,color in [('light','rgb(104, 133, 108)'),('dark','rgb(53, 76, 96)')]:
  page.evaluate('(t)=>document.body.classList.toggle("light",t==="light")',theme);assert page.locator('.day').evaluate('e=>getComputedStyle(e).backgroundColor')==color
 assert page.locator('.chat-head [data-action="chat-options"] svg path').evaluate('e=>getComputedStyle(e).strokeWidth')=='3.3px'
 assert page.locator('.unread-divider').evaluate('e=>getComputedStyle(e).borderRadius')=='0px'
 print('PASS date and unread separator styles')
 for w,h in [(280,560),(390,844),(844,390),(390,300)]:
  page.set_viewport_size({'width':w,'height':h});page.evaluate('openChatOptions()');page.wait_for_timeout(50)
  assert page.locator('#modal').is_visible()
  for action in ['chat-search','outbox','scheduled-list','pin-chat','archive-chat','mute-room','history-clear']:
   assert page.locator('#modal [data-action="'+action+'"]').count()==1
  box=page.locator('#modal').bounding_box();assert box['x']>=0 and box['y']>=0 and box['x']+box['width']<=w+1 and box['y']+box['height']<=h+1,box
  page.evaluate("document.querySelector('#modal').close()")
  print(f'PASS overflow menu preserves existing action entries and fits {w}x{h}')
 page.evaluate('testMediaCards()');assert page.locator('.fs-video-preview').count()==1;assert page.locator('.fs-file-label strong').count()==1;assert page.locator('.fs-photo-frame .blurred').count()==1;assert page.locator('.album button').count()==4;assert page.locator('.album-count').inner_text()=='6';assert page.locator('.album [data-action="view-album"]').count()==4
 for w,h in [(280,560),(390,844),(800,360)]:
  page.set_viewport_size({'width':w,'height':h});assert page.evaluate("[...document.querySelectorAll('.message,.file-button,.fs-video-preview,.fs-photo-preview,.album')].every(e=>e.scrollWidth<=e.clientWidth+2)"),(w,h)
 print('PASS file/video/photo cards and 2x2 album total, 3 viewport widths')
 b.close()
