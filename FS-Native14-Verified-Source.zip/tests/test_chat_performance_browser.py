"""Isolated production unread badge and real Chromium frame batching."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]; web=root/'web'
app=(web/'app.js').read_text(); badge=app[app.index('function updateLatestButton(){'):app.index('function jumpToLatest(){')]
helpers=(web/'chat-performance.js').read_text().replace('export function','function')
batch=(web/'refresh-batch.js').read_text().replace('export function','function')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage']); page=b.new_page()
 page.set_content('<div id="messages" style="height:200px;overflow:auto"><div style="height:3000px"></div></div><button id="new-messages"><span id="new-messages-count"></span></button>')
 result=page.evaluate('''async()=>{'''+helpers+batch+badge+'''
 const $=s=>document.querySelector(s),isLocked=()=>false,nearLatest=t=>t.scrollHeight-t.scrollTop-t.clientHeight<=32;
 const state={page:'chat',room:{id:'room'},user:{id:'self'},messages:Array.from({length:10000},(_,i)=>({id:String(i),created:i+1,sender:'peer',payload:{type:'text'}}))};
 const localState={preferences:{read:{room:0},hiddenMessages:{room:[]}}};let deletedRevision=0,inspections=0;const deleted=new Set(),hiddenMessage=m=>{inspections++;return deleted.has(m.id)||localState.preferences.hiddenMessages.room.includes(m.id)},countUnread=createUnreadCounter();
 const list=$('#messages'),button=$('#new-messages'),label=$('#new-messages-count');
 for(let i=0;i<120;i++){list.scrollTop=i;localState.preferences.read.room=i;updateLatestButton();}
 const first=inspections===10000&&label.textContent==='99+'&&button.getAttribute('aria-label')==='9881 yeni mesaj; en yeni mesaja git';
 localState.preferences.hiddenMessages.room=['9999'];updateLatestButton();const hide=button.getAttribute('aria-label')==='9880 yeni mesaj; en yeni mesaja git';
 deleted.add('9998');deletedRevision++;updateLatestButton();const del=button.getAttribute('aria-label')==='9879 yeni mesaj; en yeni mesaja git';
 list.scrollTop=list.scrollHeight;updateLatestButton();const bottom=button.hidden&&label.hidden;
 let calls=0,last=-1;const frame=frameBatch(v=>{calls++;last=v});for(let i=0;i<120;i++)frame(i);await new Promise(requestAnimationFrame);const raf=calls===1&&last===119;
 return {first,hide,del,bottom,raf};}''')
 assert all(result.values()),result
 for name in result: print('PASS',name)
 b.close()
