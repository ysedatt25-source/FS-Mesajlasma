"""Chromium isolated chat DOM + actual viewport functions; simulated keyboard, not Android IME."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
source=(root/'app.js').read_text()
viewport=source[source.index('let viewportFrame=0, previousChatHeight=0,'):source.index('function bindChatPip()')]
helpers=(root/'call-chat-fixes.js').read_text().split('export function urlParts')[0].replace('export ','')
markup='''<div id="app"><section class="screen chat-wall fs-premium fs-chat"><button class="call-banner">Aramaya geri dön</button><header class="chat-head"><button class="icon">←</button><button><span class="avatar">A</span></button><h1>Test kişisi<small>Çevrimiçi</small></h1><button class="icon">☎</button><button class="icon">▣</button></header><nav class="chat-tools"><button>Sohbette ara</button></nav><div id="pinned-message" hidden></div><div id="selection"></div><main class="scroll messages" id="messages"></main><div id="reply"></div><div id="upload-progress"></div><div id="voice-status" hidden></div><form class="composer"><div class="box"><textarea id="message-text" rows="1"></textarea></div><button class="icon send">➤</button></form><video id="call-mini" class="chat-pip"></video></section></div>'''
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
    page=browser.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
    page.set_content('<meta name="viewport" content="width=device-width,initial-scale=1,interactive-widget=resizes-content">'+markup)
    page.add_style_tag(content=(root/'style.css').read_text())
    page.evaluate('''()=>{'''+helpers+'''\nconst $=s=>document.querySelector(s),app=$('#app'),state={page:'chat',call:{chatPipRatio:{x:1,y:1}}};let virtualMessages=null;const nearLatest=t=>Math.max(0,t.scrollHeight-t.scrollTop-t.clientHeight)<=32;function updateLatestButton(){}
    $('#messages').innerHTML=Array.from({length:70},(_,i)=>'<div class="message-row"><div class="message">Mesaj '+i+'</div></div>').join('');
    '''+viewport+'''
    window.sync=syncChatViewport;window.setVisual=(height,offsetTop)=>{Object.defineProperty(window,'visualViewport',{configurable:true,value:{height,offsetTop}});syncChatViewport()};window.exitChat=()=>{state.page='home';app.innerHTML='<section class="screen">Home</section>';syncChatViewport()};syncChatViewport();
    }''')
    def geometry():
        return page.evaluate('''()=>{const r=s=>{const a=document.querySelector(s).getBoundingClientRect();return {top:a.top,bottom:a.bottom,height:a.height,left:a.left,right:a.right}};return {head:r('.chat-head'),app:r('#app'),messages:r('#messages'),composer:r('.composer'),pip:r('#call-mini'),scroll:document.querySelector('#messages').scrollTop,position:getComputedStyle(document.querySelector('#app')).position}}''')
    def verify(h,top):
        g=geometry(); assert g['position']=='fixed',g
        assert abs(g['app']['top']-top)<1 and abs(g['app']['height']-h)<1,g
        assert g['head']['top']>=top and g['head']['bottom']<=g['messages']['top']+.5,g
        assert g['messages']['height']>0 and g['composer']['bottom']<=top+h+.5,g
        assert g['pip']['top']>=g['messages']['top'] and g['pip']['bottom']<=g['messages']['bottom']+.5,g
        return g
    verify(844,0); print('PASS Full-height header, composer, and video visible')
    page.locator('#message-text').focus();page.set_viewport_size({'width':390,'height':384});page.evaluate('sync()');verify(384,0);print('PASS Resized-layout keyboard keeps header and composer visible')
    page.set_viewport_size({'width':390,'height':844});page.evaluate('setVisual(330,160)');verify(330,160);print('PASS Panned visual viewport with nonzero offset keeps entire chat visible')
    page.evaluate("document.querySelector('#messages').scrollTop=200");before=geometry();page.evaluate("document.querySelector('#messages').scrollTop=650");after=verify(330,160);assert after['scroll']>before['scroll'] and before['head']==after['head'];print('PASS Messages scroll independently; header remains stationary')
    page.evaluate("document.querySelector('#messages').scrollTop=500");page.evaluate('setVisual(300,100)');assert geometry()['scroll']==500;print('PASS Reading position survives keyboard resize')
    page.evaluate("const a=document.querySelector('#messages');a.scrollTop=a.scrollHeight");page.evaluate('setVisual(290,120)');assert page.evaluate("(()=>{const a=document.querySelector('#messages');return a.scrollHeight-a.scrollTop-a.clientHeight<2})()");print('PASS Latest message stays at bottom during keyboard resize')
    page.evaluate('''()=>{document.querySelector('#reply').innerHTML='<div class="reply-banner tg-reply"><button class="reply-quote"><strong>Test kişisine yanıt</strong><span>Örnek mesaj</span></button><button class="icon">×</button></div>';document.querySelector('textarea').style.height='120px';sync()}''');verify(290,120);print('PASS Reply bar and multiline composer fit with keyboard and video')
    page.evaluate('''()=>{const b=document.querySelector('#pinned-message');b.hidden=false;b.innerHTML='<button class="fs-pin-jump"><span><strong>Sabitlenen mesaj</strong><small>'+('uzun mesaj '.repeat(80))+'</small></span></button><button class="icon">×</button>';sync()}''');verify(290,120);assert page.locator('#pinned-message').is_visible();assert page.locator('#pinned-message').evaluate('el=>el.scrollWidth<=el.clientWidth');print('PASS Pinned bar remains bounded with keyboard and long text')
    page.evaluate('setVisual(250,120)');verify(250,120);assert not page.locator('#pinned-message').is_visible();print('PASS Tiny keyboard viewport prioritizes conversation and composer')
    page.evaluate('setVisual(844,0)');verify(844,0);print('PASS Closing keyboard restores full height')
    page.evaluate('exitChat()');assert page.evaluate("getComputedStyle(document.querySelector('#app')).position")=='relative';assert page.evaluate("document.querySelector('#app').style.getPropertyValue('--chat-viewport-height')")=='';print('PASS Leaving chat restores ordinary screen layout')
    browser.close()
