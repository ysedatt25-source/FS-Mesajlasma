import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from ci_source_identity import verify, required_suites


class IdentityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.ci = self.root / 'build/ci'
        self.results = self.ci / 'test-logs/results.json'
        self.results.parent.mkdir(parents=True)
        self.manifest = self.root / 'FS-FINAL-SHA256.txt'
        self.source = self.root / 'web/app.js'
        self.source.parent.mkdir()
        self.source.write_text('source 1')
        self.manifest.write_text(hashlib.sha256(self.source.read_bytes()).hexdigest() + '  web/app.js\n')
        self.results.write_text(json.dumps({name: 0 for name in required_suites(self.root)}))
        self.apk = self.ci / 'FS-Mesajlasma-34.32-native14-push-unsigned.apk'
        self.apk.write_bytes(b'APK fixture')
        self.metadata = self.ci.parent / 'push-metadata/build-info.json'
        self.metadata.parent.mkdir()
        self.metadata.write_text('{}')

    def step(self, mode):
        verify(self.root, self.ci, mode)

    def test_complete_flow(self):
        for mode in ('record-tests', 'check-tests', 'record-build', 'check-build'):
            self.step(mode)

    def test_source_change_rejected(self):
        self.step('record-tests')
        self.manifest.write_text('source 2')
        with self.assertRaises(ValueError): self.step('check-tests')

    def test_failed_or_missing_results_rejected(self):
        for value in ({}, {'node': 0}, dict(dom=0, ui=1, node=0, **{'java-syntax': 0}), dict(dom=False, ui=0, node=0, **{'java-syntax': 0})):
            self.results.write_text(json.dumps(value))
            with self.assertRaises(ValueError): self.step('record-tests')

    def test_apk_change_rejected(self):
        self.step('record-tests'); self.step('record-build')
        self.apk.write_bytes(b'different APK')
        with self.assertRaises(ValueError): self.step('check-build')

    def test_metadata_change_rejected(self):
        self.step('record-tests'); self.step('record-build')
        self.metadata.write_text('{"other":true}')
        with self.assertRaises(ValueError): self.step('check-build')

    def test_changed_results_rejected(self):
        self.step('record-tests')
        self.results.write_text(self.results.read_text() + '\n')
        with self.assertRaises(ValueError): self.step('check-tests')

    def test_missing_attestation_rejected(self):
        with self.assertRaises(FileNotFoundError): self.step('check-tests')

    def test_missing_individual_suite_rejected(self):
        tests = self.root / 'tests'
        tests.mkdir()
        (tests / 'test_new.py').touch()
        with self.assertRaises(ValueError): self.step('record-tests')

    def test_modified_runtime_bytes_rejected(self):
        self.step('record-tests')
        self.source.write_text('changed without changing manifest')
        with self.assertRaises(ValueError): self.step('check-tests')

    def test_untracked_runtime_file_rejected(self):
        (self.source.parent / 'unexpected.js').touch()
        with self.assertRaises(ValueError): self.step('record-tests')

    def test_untracked_test_or_build_tool_rejected(self):
        for folder in ('tests', 'tools', 'deploy', 'server-integration'):
            path = self.root / folder / 'unexpected.py'
            path.parent.mkdir(exist_ok=True)
            path.touch()
            with self.assertRaises(ValueError): self.step('record-tests')
            path.unlink()

    def test_untracked_gradle_and_npm_inputs_rejected(self):
        for name in ('android/settings.gradle', 'android/app/build.gradle', 'android/gradle.properties', 'android/app/libs/extra.jar', 'package-lock.json', '.npmrc', '.circleci/config.yml'):
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text('unexpected')
            with self.subTest(name=name), self.assertRaisesRegex(ValueError, 'Untracked'):
                self.step('record-tests')
            path.unlink()

    def test_generated_gradle_output_allowed(self):
        self.step('record-tests')
        for name in ('android/app/build/generated/BuildConfig.java', 'android/.gradle/cache.bin'):
            path = self.root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text('generated')
        self.step('check-tests')

    def test_manifest_symlink_rejected(self):
        target = self.root / 'other.js'
        target.write_bytes(self.source.read_bytes())
        self.source.unlink()
        self.source.symlink_to(target)
        with self.assertRaisesRegex(ValueError, 'Source digest mismatch'):
            self.step('record-tests')
