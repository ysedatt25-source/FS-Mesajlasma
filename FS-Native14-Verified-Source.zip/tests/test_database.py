import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from database import maria_sql

class DatabaseSQLTest(unittest.TestCase):
    def test_parameter_binding_and_case_insensitive_nick(self):
        self.assertEqual(maria_sql('SELECT * FROM users WHERE nick=? COLLATE NOCASE'),
                         'SELECT * FROM users WHERE nick=%s')
    def test_contacts_upsert(self):
        sql=maria_sql('INSERT INTO contacts VALUES(?,?,0) ON CONFLICT(owner,peer) DO UPDATE SET deleted=0')
        self.assertIn('ON DUPLICATE KEY UPDATE deleted=0',sql)
        self.assertEqual(sql.count('%s'),2)
    def test_receipts_never_regress(self):
        sql=maria_sql('INSERT INTO receipts VALUES(?,?,?) ON CONFLICT(room,user) DO UPDATE SET ts=max(ts,excluded.ts)')
        self.assertIn('ts=GREATEST(ts,VALUES(ts))',sql)
    def test_admin_upsert_and_reserved_identifier(self):
        sql=maria_sql("INSERT INTO app_config VALUES('admin',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value")
        self.assertIn('ON DUPLICATE KEY UPDATE value=VALUES(value)',sql)
        self.assertIn('c.`key`',maria_sql("SELECT * FROM app_config c WHERE c.key='admin'"))
    def test_ignore_duplicates(self):
        self.assertEqual(maria_sql('INSERT OR IGNORE INTO saved VALUES(?,?)'),
                         'INSERT IGNORE INTO saved VALUES(%s,%s)')
    def test_schema_keeps_message_ciphertext_and_binary_identifiers(self):
        schema=Path(__file__).resolve().parents[1].joinpath('server/schema.mariadb.sql').read_text()
        self.assertIn('envelopes LONGTEXT',schema)
        self.assertIn('COLLATE=utf8mb4_bin',schema)
        self.assertIn('nick VARCHAR(64) COLLATE utf8mb4_unicode_ci',schema)
        self.assertNotIn('PRAGMA',schema)
