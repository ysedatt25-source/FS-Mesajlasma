import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from device_performance import pss_kib,gfx_counts,frame_times,frame_delta,battery,metrics

class DevicePerformanceTest(unittest.TestCase):
 def test_pss_variants(self):
  self.assertEqual(pss_kib(' TOTAL PSS: 123,456 TOTAL RSS: 234567'),123456)
  self.assertEqual(pss_kib(' TOTAL    789 123 456'),789);self.assertEqual(pss_kib('TOTAL PSS: 100\nTOTAL PSS: 200'),300);self.assertIsNone(pss_kib('no data'))
 def test_gfx_delta(self):
  a=gfx_counts('Total frames rendered: 100\nJanky frames: 5 (5%)');b=gfx_counts('Total frames rendered: 200\nJanky frames: 15 (7.5%)')
  self.assertEqual(frame_delta(a,b),{'frames':100,'janky':10,'jank_percent':10.0});self.assertIsNone(frame_delta(b,a));self.assertIsNone(frame_delta(a,a));self.assertIsNone(frame_delta(a,gfx_counts('')))
 def test_frames_ignore_invalid_and_duplicate(self):
  text='---PROFILEDATA---\nFlags,IntendedVsync,FrameCompleted\n0,1000000,11000000\n0,1000000,11000000\n1,2000000,10000000\n0,9000,8000\n0,0,5000\n0,4000,9223372036854775807\n---PROFILEDATA---'
  self.assertEqual(frame_times(text),{(1000000,11000000):10.0});self.assertEqual(frame_times('0,1,2'),{})
 def test_battery_unknown(self):
  result=battery('level: 90\nCharge counter: 4000000\nstatus: 3\ntemperature: 300');self.assertEqual(result['level_percent'],90);self.assertEqual(result['charge_counter_uAh'],4000000);self.assertIsNone(battery('')['charge_counter_uAh'])
 def test_metrics(self):
  self.assertEqual(metrics([1,None,3,5]),{'samples':3,'median':3,'p95':5,'max':5});self.assertEqual(metrics([])['samples'],0)
