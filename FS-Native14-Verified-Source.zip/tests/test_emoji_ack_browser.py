"""Regression for optimistic-to-acknowledged UI event ordering.
Uses the unchanged production eligibility, click handler, emoji dispatch, keyed
row patcher and animation implementation. State/network fixtures are explicit;
this does not replace tests/dom.test.mjs or a physical-device test.
"""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
app=(root/'app.js').read_text()
effects=(root/'emoji-effects.js').read_text().replace('export ','')
def section(a,b):
    x=app.index(a);return app[x:app.index(b,x)]
code='\n'.join([
    effects,
    (root/'message-interactions.js').read_text().replace('import {isViewOnce} from "./view-once.js";','').replace('export ',''),
    (root/'app-performance.js').read_text().replace('export ','')+'\nconst lookupRecord=createRecordLookup();',
    section('function eligibleMessage(', 'function validQuote('),
    section('function bindSelection()', 'function selectionBar()'),
    section('function emojiEffect(', 'async function sendEmojiInteraction('),
    section('function keyedMessages(', 'const audioUrls'),
])
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
    page=browser.new_page(viewport={'width':390,'height':844}, reduced_motion='no-preference')
    page.set_content('<section class="fs-chat" style="width:380px;height:700px"><main id="messages"></main></section>')
    page.evaluate('()=>{'+code+'''
        const $=s=>document.querySelector(s);
        const state={page:'chat',room:{id:'r'},routeVersion:1,user:{id:'me'},selected:new Set(),messages:[{id:'exact-message',pending:true,payload:{type:'text',text:'😘'}}]};
        let locked=false,hidden=false,relayed=0;
        const isLocked=()=>locked,hiddenMessage=()=>hidden;
        const sendEmojiInteraction=async()=>{relayed++};
        const renderMessages=()=>{};
        
        const reactToMessage=async()=>{throw Error("unexpected reaction")};
        const messageMenu=()=>{throw Error("unexpected menu")};
        const beginReply=()=>{throw Error("unexpected reply")};
        const notice=()=>{};
        const draw=()=>keyedMessages($('#messages'),`<div data-key="exact-message"><article class="message emoji mine" data-message="exact-message" data-emoji="😘"><span class="emoji-fallback">😘</span><time>12:00 · ${state.messages[0].pending?'◷':'✓'}</time></article></div>`);
        bindSelection();draw();window.oldEmoji=$('.emoji-fallback');
        window.ack=()=>{state.messages=[{...state.messages[0],pending:false}];draw()};
        window.relayCount=()=>relayed;
        window.setLocked=()=>{locked=true;clearEmojiEffect()};
        window.hideMessage=()=>{locked=false;hidden=true;clearEmojiEffect()};
        window.selectMessage=()=>{hidden=false;state.selected.add('other');clearEmojiEffect()};
        window.resetEffect=()=>clearEmojiEffect();
    }''')
    emoji=page.locator('.emoji-fallback');layer=page.locator('.emoji-interactive-layer')
    emoji.click();assert layer.count()==0 and page.evaluate('relayCount()')==0
    print('PASS pending emoji cannot animate or relay')
    page.evaluate('ack()');assert page.evaluate('!oldEmoji.isConnected')
    page.evaluate('oldEmoji.click()');assert layer.count()==0
    print('PASS old optimistic DOM node detached after acknowledgement')
    emoji.click();page.wait_for_timeout(330);assert layer.count()==1 and layer.get_attribute('data-effect')=='kiss' and page.evaluate('relayCount()')==1
    print('PASS exact acknowledged message animates and invokes relay')
    emoji.click();page.wait_for_timeout(330);assert layer.count()==1 and layer.get_attribute('data-effect')=='kiss'
    print('PASS repeated tap replaces effect instead of stacking')
    page.evaluate('setLocked()');emoji.click();assert layer.count()==0 and page.evaluate('relayCount()')==2
    print('PASS locked account rejects emoji interaction')
    page.evaluate('hideMessage()');emoji.click();assert layer.count()==0 and page.evaluate('relayCount()')==2
    print('PASS hidden message rejects emoji interaction')
    page.evaluate('selectMessage()');emoji.click();assert layer.count()==0 and page.evaluate('relayCount()')==2
    print('PASS selection mode does not relay emoji')
    browser.close()
