"""Real Chromium runs the actual effect renderer/CSS, not a reimplementation."""
import base64, json, os
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]/'web'
code=(ROOT/'emoji-effects.js').read_text().replace('export ','')
css=(ROOT/'style.css').read_text()
manifest={x['emoji']:x['file'] for x in json.loads((ROOT/'emoji-extension.json').read_text())}
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
 page=b.new_page(viewport={'width':360,'height':640},reduced_motion='no-preference')
 page.set_content('<main class="fs-chat" style="position:relative;width:350px;height:600px"><article class="message emoji" style="margin:150px 0 0 130px"><span class="emoji-fallback">❤️</span></article><button id="click-test" style="position:absolute;left:15px;top:50px">OK</button></main>')
 page.add_style_tag(content=css)
 page.evaluate('()=>{'+code+'''\nconst target=document.querySelector('article');window.fx=(e,opts={})=>animateEmoji(target,e,{fetchAsset:null,...opts});window.stopFx=clearEmojiEffect;window.plan=effectPlan;window.anchor=()=>target.getBoundingClientRect().toJSON();window.hit=0;document.querySelector('#click-test').onclick=()=>window.hit++;}''')
 before=page.evaluate('anchor()')
 expected={'❤️':('heart','emoji-rise'),'😭':('fall','emoji-fall'),'🎉':('confetti','emoji-arc'),'🦋':('flutter','emoji-sway'),'⭐':('glow','emoji-bloom'),'⚡':('flash','emoji-flash'),'💔':('split','emoji-split'),'👨‍👩‍👧‍👦':('orbit','emoji-orbit'),'💋':('kiss','fs-emoji-kiss'),'😛':('wiggle','fs-emoji-tongue')}
 for e,(motion,animation) in expected.items():
  assert page.evaluate('e=>fx(e)',e)
  layer=page.locator('.emoji-interactive-layer');assert layer.count()==1
  assert layer.get_attribute('data-motion')==motion
  particle=layer.locator('.emoji-particle').first
  assert particle.evaluate('el=>getComputedStyle(el).animationName')==animation
  page.wait_for_timeout(110)
  t1=particle.evaluate('el=>getComputedStyle(el).transform');page.wait_for_timeout(150);t2=particle.evaluate('el=>getComputedStyle(el).transform');assert t1!=t2,(e,t1,t2)
  assert page.evaluate('anchor()')==before
 print('PASS ten semantic animation families run different CSS paths with no message layout shift')
 assert page.locator('.emoji-particle').count()==12
 page.locator('#click-test').click();assert page.evaluate('hit')==1
 print('PASS effect layer is bounded and cannot intercept ordinary chat controls')
 page.evaluate('fx("👍🏿")');layer=page.locator('.emoji-interactive-layer');assert layer.get_attribute('data-glyph')=='👍🏿';assert '👍🏿' in layer.locator('.emoji-particle').all_text_contents();assert layer.evaluate('el=>getComputedStyle(el,"::before").content')=='"👍🏿"'
 print('PASS original exact Unicode glyph is replayed even without a bundled asset')
 # Actual animated local WebP loading via a fixture response (no network access).
 file=manifest['🇹🇷'];uri='data:image/webp;base64,'+base64.b64encode((ROOT/'emoji-extra'/file).read_bytes()).decode()
 page.evaluate('([file,uri])=>fx("🇹🇷",{assetPath:file,fetchAsset:async()=>fetch(uri)})',[file,uri]);page.wait_for_function('document.querySelector(".emoji-interactive-layer")?.dataset.replay==="asset"');assert page.locator('.emoji-replay').evaluate('i=>i.naturalWidth')==80
 print('PASS exact local animated WebP replay replaces the fallback after successful decode')
 page.evaluate('([file,uri])=>{window.abortSeen=false;fx("🇹🇷",{assetPath:file,fetchAsset:(path,{signal})=>new Promise(resolve=>{signal.addEventListener("abort",()=>window.abortSeen=true);window.finishOld=async()=>resolve(await fetch(uri))})})}',[file,uri]);page.wait_for_function('typeof finishOld==="function"');page.evaluate('fx("💙")');assert page.evaluate('abortSeen');page.evaluate('finishOld()');page.wait_for_timeout(120);assert page.locator('.emoji-interactive-layer').get_attribute('data-glyph')=='💙';assert page.locator('.emoji-replay').count()==0
 print('PASS replaced effect cancels old asset request and cannot attach stale replay')
 page.evaluate('stopFx()');assert page.locator('.emoji-interactive-layer').count()==0
 page.evaluate('fx("🎉")');page.wait_for_timeout(2300);assert page.locator('.emoji-interactive-layer').count()==0
 print('PASS explicit cleanup and automatic expiration remove entire effect')
 page.emulate_media(reduced_motion='reduce');assert not page.evaluate('fx("❤️",{reducedMotion:true})');assert page.locator('.emoji-interactive-layer').count()==0
 print('PASS motion reduction suppresses effect before layer creation')
 b.close()
