"""Chromium decodes real authored artwork; generic transforms stay disabled."""
import base64, os
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]/'web'
code=(ROOT/'emoji-effects.js').read_text().replace('export ','')
uri='data:image/webp;base64,'+base64.b64encode((ROOT/'emoji/1f602.webp').read_bytes()).decode()
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':360,'height':640},reduced_motion='no-preference')
 page.set_content('<main class="fs-chat" style="position:relative;width:350px;height:600px"><article class="message emoji" style="margin:150px 0 0 130px"><img class="animated-emoji" src="emoji/1f602.webp" alt="😂"></article><button id="click-test">OK</button></main>')
 page.add_style_tag(content=(ROOT/'style.css').read_text())
 page.evaluate('([code,uri])=>{eval(code+";window.animate=animateEmoji;window.stopFx=clearEmojiEffect;");window.artwork=uri;window.fx=()=>animate(document.querySelector("article"),"😂",{fetchAsset:async()=>fetch(artwork)});window.hit=0;document.querySelector("#click-test").onclick=()=>window.hit++;}',[code,uri])
 before=page.locator('article').bounding_box();assert page.evaluate('fx()')
 page.wait_for_function('document.querySelector(".emoji-replay")?.naturalWidth===160')
 layer=page.locator('.emoji-interactive-layer');assert layer.count()==1
 assert page.locator('.emoji-particle').count()==0
 assert 'character-replay' in layer.get_attribute('class')
 assert page.locator('article').bounding_box()==before
 page.locator('#click-test').click();assert page.evaluate('hit')==1
 print('PASS real authored WebP decodes without particles, layout shift or intercepted controls')
 assert page.evaluate('fx()');page.wait_for_function('document.querySelector(".emoji-replay")?.naturalWidth===160');assert layer.count()==1
 page.evaluate('stopFx()');assert layer.count()==0
 page.evaluate('fx()');page.wait_for_timeout(2300);assert layer.count()==0
 print('PASS repeat replay never stacks and explicit/automatic cleanup removes it')
 page.evaluate('''()=>{window.abortSeen=false;window.animate(document.querySelector('article'),'😂',{fetchAsset:(_, {signal})=>new Promise(resolve=>{signal.addEventListener('abort',()=>abortSeen=true);window.finishOld=async()=>resolve(await fetch(artwork))})});}''')
 page.wait_for_function('typeof finishOld==="function"');page.evaluate('stopFx();finishOld()');page.wait_for_timeout(100);assert page.evaluate('abortSeen');assert layer.count()==0
 print('PASS cleanup cancels pending artwork and suppresses stale completion')
 assert not page.evaluate("animate(document.querySelector('article'),'🇹🇷',{assetPath:'e-1f1f9_1f1f7.webp'})")
 page.emulate_media(reduced_motion='reduce');assert not page.evaluate("animate(document.querySelector('article'),'😂',{reducedMotion:true})");assert layer.count()==0
 print('PASS unverified flag deformation and reduced-motion replay are suppressed')
 b.close()
