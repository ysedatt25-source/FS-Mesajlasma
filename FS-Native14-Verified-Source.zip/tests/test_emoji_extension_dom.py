"""Actual Chromium image decoder/animation and production message renderer."""
import base64, json, os
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]/'web'
app=(ROOT/'app.js').read_text();effects=(ROOT/'emoji-effects.js').read_text().replace('export ','')
# Sample actual bundled animations (five classes). Chromium decodes actual local files via data URL.
manifest={x['emoji']:x['file'] for x in json.loads((ROOT/'emoji-extension.json').read_text())}
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
 page=b.new_page(viewport={'width':360,'height':640},reduced_motion='no-preference');page.set_content('<main id="samples" style="display:flex;gap:5px;background:white;flex-wrap:wrap"></main>')
 samples=['🇹🇷','🧑🏽‍🦽','👩‍❤️‍💋‍👩','1️⃣','🏿'];uris=['data:image/webp;base64,'+base64.b64encode((ROOT/'emoji-extra'/manifest[e]).read_bytes()).decode() for e in samples]
 page.evaluate('urls=>{for(const src of urls){const i=document.createElement("img");i.src=src;i.width=i.height=80;document.querySelector("#samples").append(i)}}',uris)
 assert page.evaluate('async()=>{await Promise.all([...document.images].map(i=>i.decode()));return [...document.images].every(i=>i.naturalWidth===80&&i.naturalHeight===80)}')
 print('PASS real Chromium decodes exact flags, mixed complexion profession, couple, keycap and standalone skin tone')
 shots=[]
 for _ in range(5):
  shots.append(page.locator('#samples').screenshot(animations='allow'));page.wait_for_timeout(137)
 assert len(set(shots))>=3,'actual WebP frames must change in Chromium'
 print('PASS real displayed WebP frames change over time without moving message container')
 # Exercise actual picker and message renderer via component functions, production paths unchanged.
 picker=app[app.index('function emojiPicker(panel=null)'):app.index('const liveLocations = new Map();')]
 page.set_content('<dialog id="modal"></dialog>');page.evaluate('([code,rows])=>{'+'''const state={};const $=s=>document.querySelector(s);const escape=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;');const dialog=(title,html)=>{const d=$('#modal');d.innerHTML=html;d.showModal()};const emojiItems=rows;eval(code+'\\nwindow.openPicker=emojiPicker;');openPicker()}''',[effects+'\n'+(ROOT/'message-interactions.js').read_text().replace('import {isViewOnce} from "./view-once.js";','').replace('export ','')+'\n'+picker,json.loads((ROOT/'emoji-extension.json').read_text())])
 assert page.locator('#emoji-list button').count()==72
 page.locator('#emoji-search').fill('🇹🇷');assert page.locator('#emoji-list button').count()==1;assert page.locator('#emoji-list button .emoji-picker-glyph').inner_text()=='🇹🇷';assert page.locator('#emoji-list img').count()==0
 page.locator('#emoji-search').fill('__proto__');assert page.locator('#emoji-list button').count()==0
 page.locator('#emoji-search').fill('kalp');assert page.locator('#emoji-list button').count()>0;print('PASS Turkish keyword search and unsafe object keys handled')
 print('PASS actual picker paging and exact flag search keep extended preview static')
 # Generic extension animations must stay excluded by the production path selector.
 page.evaluate('()=>{'+effects+';window.chooseAnimation=characterAssetPath;}')
 assert page.evaluate('chooseAnimation("e-1f1f9_1f1f7.webp")') is None
 assert page.evaluate('chooseAnimation("1f602.webp")')=='emoji/1f602.webp'
 assert page.evaluate('chooseAnimation("../1f602.webp")') is None
 print('PASS verified Noto paths are selected and generic flag deformation is excluded')
 b.close()
