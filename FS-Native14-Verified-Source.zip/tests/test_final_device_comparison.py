import copy, hashlib, tempfile, unittest, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from compare_device_performance import compare
from release_gate import validate, CHECKS, digest, certificate_matches, EXPECTED_CERT

class ComparisonTests(unittest.TestCase):
    def setUp(self):
        self.a={'package':'com.fs.mesajlasma','version':'34.32','device_id_sha256':'fixture','scenario':'chat-scroll','requested_seconds':120,'duration_seconds':121,'interval_seconds':5,'same_main_process':True,'pss_kib':{'samples':24,'median':200,'p95':300},'frame_duration_ms_sampled':{'samples':500,'median':12,'p95':20},'gfx_counter_delta':{'frames':500,'jank_percent':4}}
        self.b=copy.deepcopy(self.a);self.b.update(package='org.telegram.messenger',version='fixture');self.b['pss_kib']['median']=250
    def test_same_device_and_metrics(self):
        out=compare(self.a,self.b);self.assertTrue(out['same_device']);self.assertEqual(out['metrics'][0]['fs_vs_telegram_percent'],-20)
    def test_mismatched_conditions_are_rejected(self):
        for k,v in [('device_id_sha256','other'),('scenario','call'),('requested_seconds',90),('interval_seconds',8),('same_main_process',False),('duration_seconds',20)]:
            with self.subTest(k=k),self.assertRaises(ValueError):compare(self.a,{**self.b,k:v})
    def test_insufficient_frames_not_success(self):
        self.b['frame_duration_ms_sampled']['samples']=1;self.b['gfx_counter_delta']['frames']=0
        out=compare(self.a,self.b);self.assertIsNone(out['metrics'][2]['fs']);self.assertIsNone(out['metrics'][4]['telegram'])
    def test_zero_reference_no_fake_percent(self):
        self.b['gfx_counter_delta']['jank_percent']=0
        self.assertIsNone(compare(self.a,self.b)['metrics'][4]['fs_vs_telegram_percent'])

class GateTests(unittest.TestCase):
    def test_only_expected_v2_certificate_accepted(self):
        v2='Verified using v2 scheme (APK Signature Scheme v2): true\n'
        cert='Signer #1 certificate SHA-256 digest: '+EXPECTED_CERT+'\n'
        self.assertTrue(certificate_matches(v2+cert));self.assertFalse(certificate_matches(cert));self.assertFalse(certificate_matches(v2+cert.replace(EXPECTED_CERT,'0'*64)));self.assertFalse(certificate_matches(v2+cert+cert.replace('#1','#2')))

    def test_evidence_cannot_be_reused_after_source_or_apk_change(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);source=root/'app.js';source.write_text('old');apk=root/'candidate.apk';apk.write_bytes(b'fixture');manifest=root/'FS-FINAL-SHA256.txt';manifest.write_text(digest(source)+'  app.js\n')
            evidence={k:True for k in CHECKS}
            self.assertIn('source_manifest_sha256_mismatch',validate(root,apk,evidence))
            evidence.update(source_manifest_sha256=digest(manifest),signed_apk_sha256=digest(apk));self.assertEqual(validate(root,apk,evidence),[])
            source.write_text('new');apk.write_bytes(b'other');errors=validate(root,apk,evidence)
            self.assertIn('source_integrity:app.js',errors);self.assertIn('signed_apk_sha256_mismatch',errors)
    def test_missing_physical_evidence_fails(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);errors=validate(root,root/'missing.apk',{})
            self.assertTrue(set(CHECKS).issubset(errors));self.assertIn('signed_apk_missing',errors)
