"""Exercise production keyed reconciliation with real Chromium DOM nodes."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import os
source=(Path(__file__).resolve().parents[1]/'web/app.js').read_text()
avatar=source[source.index('const avatar ='):source.index('const empty =')]
source=source[source.index('function reconcileHomeRows('):source.index('let homeListSequence =')]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM','/usr/bin/chromium'),args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page();page.set_content('<main id="list" style="height:400px;overflow:auto"></main>')
 result=page.evaluate('''async()=>{'''+source+'''
 const list=document.querySelector('#list'),parts=Array.from({length:500},(_,i)=>({key:'room:'+i,html:`<button style="display:block;height:40px" data-id="${i}">room ${i}</button>`}));
 reconcileHomeRows(list,parts);const original=[...list.children];original[20].focus({preventScroll:true});list.scrollTop=600;
 const observer=new MutationObserver(()=>{});observer.observe(list,{childList:true});
 for(let i=0;i<20;i++)reconcileHomeRows(list,parts);
 const stable=observer.takeRecords().length===0&&original.every((n,i)=>n===list.children[i]);
 const scroll=list.scrollTop===600,focus=document.activeElement===original[20];
 const changed=parts.map((r,i)=>i===20?{...r,html:'<button data-id="20" style="display:block;height:40px">new</button>'}:r);
 reconcileHomeRows(list,changed);const updated=list.children[20]!==original[20]&&list.children[20].textContent==='new'&&document.activeElement===list.children[20]&&original.filter((n,i)=>i!==20&&n===list.children[i]).length===499;
 const reordered=[changed[499],...changed.slice(0,499)];reconcileHomeRows(list,reordered);const moved=list.firstElementChild===original[499]&&list.children[1]===original[0];
 reconcileHomeRows(list,reordered.filter(r=>r.key!=='room:0'));const removed=!original[0].isConnected&&list.children.length===499;
 reconcileHomeRows(list,[{key:'empty',html:'<div>empty</div>'}]);const cleared=list.children.length===1&&list.textContent==='empty'&&original.every(n=>!n.isConnected);
 observer.disconnect();return {stable,scroll,focus,updated,moved,removed,cleared};}''')
 lazy=page.evaluate('''()=>{const escape=s=>String(s);'''+avatar+'''const p={avatar:'data:image/png;base64,AAAA'};const template=document.createElement('template');template.innerHTML=avatar(p,false,true);const img=template.content.querySelector('img');const deferred=img.loading==='lazy'&&img.decoding==='async';template.innerHTML=avatar(p,true);return deferred&&template.content.querySelector('img').loading!=='lazy';}''')
 result['lazy_only_when_requested']=lazy
 assert all(result.values()),result
 for k in result: print('PASS',k)
 b.close()
