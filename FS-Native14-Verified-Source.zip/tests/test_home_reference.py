"""Check authenticated, exact delivered unread counts and isolation on the real API."""
import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from test_server import APITest as Fixture
class HomeReferenceTest(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=Fixture.asyncSetUp
    asyncTearDown=Fixture.asyncTearDown
    h=Fixture.h
    register=Fixture.register
    env=Fixture.env
    async def send(self,mid,user):
        r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(user),json={'id':mid,'envelopes':self.env()});self.assertEqual(r.status,201,await r.text())
    async def receipt(self,delivered=[],read=[]):
        r=await self.client.post('/api/rooms/'+self.room+'/receipts',headers=self.h(self.b),json={'delivered':delivered,'read':read});self.assertEqual(r.status,200,await r.text())
    async def count(self,user):
        r=await self.client.get('/api/rooms',headers=self.h(user));self.assertEqual(r.status,200,await r.text());rows=await r.json();return [x['unread_delivered_count'] for x in rows if x['id']==self.room]
    async def test_count_and_read(self):
        self.assertEqual(await self.count(self.b),[0]);await self.send('home_ref_msg_001',self.a);await self.send('home_ref_msg_002',self.a)
        self.assertEqual(await self.count(self.b),[0]);await self.receipt(['home_ref_msg_001','home_ref_msg_002']);self.assertEqual(await self.count(self.b),[2]);self.assertEqual(await self.count(self.a),[0]);self.assertEqual(await self.count(self.c),[])
        await self.receipt(read=['home_ref_msg_001']);await self.send('home_ref_msg_003',self.b);self.assertEqual(await self.count(self.b),[1]);await self.receipt(read=['home_ref_msg_002']);self.assertEqual(await self.count(self.b),[0])
    async def test_hidden_and_deleted(self):
        await self.send('home_ref_msg_004',self.a);await self.send('home_ref_msg_005',self.a);await self.receipt(['home_ref_msg_004','home_ref_msg_005']);self.assertEqual(await self.count(self.b),[2]);self.app['store'].run('INSERT INTO hidden_messages VALUES(?,?)',(self.b['user']['id'],'home_ref_msg_004'));self.assertEqual(await self.count(self.b),[1]);r=await self.client.delete('/api/messages/home_ref_msg_005',headers=self.h(self.a));self.assertEqual(r.status,200,await r.text());self.assertEqual(await self.count(self.b),[0]);self.assertEqual((await self.client.get('/api/rooms')).status,401)
    async def test_explicit_mark_delivered_only(self):
        await self.send('home_ref_msg_011',self.a);await self.send('home_ref_msg_012',self.a);await self.send('home_ref_msg_013',self.b)
        await self.receipt(['home_ref_msg_011']);path='/api/rooms/'+self.room+'/read-delivered'
        for user,status in [(self.c,403),(None,401)]:
            r=await self.client.post(path,headers=self.h(user) if user else {},json={});self.assertEqual(r.status,status)
        r=await self.client.post(path,headers=self.h(self.b),json={});self.assertEqual(r.status,200);self.assertEqual((await r.json())['count'],1);self.assertEqual(await self.count(self.b),[0])
        store=self.app['store'];uid=self.b['user']['id'];self.assertIsNotNone(store.one('SELECT read_at FROM message_receipts WHERE message=? AND user=?',('home_ref_msg_011',uid))['read_at']);self.assertIsNone(store.one('SELECT read_at FROM message_receipts WHERE message=? AND user=?',('home_ref_msg_012',uid)));self.assertIsNone(store.one('SELECT read_at FROM message_receipts WHERE message=? AND user=?',('home_ref_msg_013',uid)))
        r=await self.client.post(path,headers=self.h(self.b),json={});self.assertEqual((await r.json())['count'],0)
    async def manage(self,user,op,rooms):
        return await self.client.post('/api/room-history/manage',headers=self.h(user) if user else {},json={'operation':op,'rooms':rooms})
    async def get_rooms(self,user):
        r=await self.client.get('/api/rooms',headers=self.h(user));self.assertEqual(r.status,200);return await r.json()
    async def get_messages(self,user,room=None):
        return await self.client.get('/api/rooms/'+(room or self.room)+'/messages',headers=self.h(user))
    async def test_clear_all_personally_and_keep_future_messages(self):
        # More than one history page, including records the client never loaded.
        store=self.app['store'];a=self.a['user']['id'];b=self.b['user']['id']
        import json
        from app import now
        for i in range(105):store.run('INSERT INTO messages(id,room,sender,envelopes,created) VALUES(?,?,?,?,?)',(f'clear_history_{i:04}',self.room,a,json.dumps(self.env()),now()-10000+i))
        store.run('INSERT INTO saved VALUES(?,?)',(b,'clear_history_0001'))
        store.run('INSERT INTO calls(id,room,caller,callee,video,started,status) VALUES(?,?,?,?,?,?,?)',('clear_call_0001',self.room,a,b,0,now()-1000,'ended'))
        r=await self.manage(self.b,'clear',[self.room]);self.assertEqual(r.status,200,await r.text());revision=(await r.json())['rooms'][0]['history_revision']
        self.assertEqual(await (await self.get_messages(self.b)).json(),[]);self.assertEqual(len(await(await self.get_messages(self.a)).json()),80)
        self.assertEqual(store.one('SELECT count(*) n FROM messages WHERE room=?',(self.room,))['n'],105)
        self.assertEqual(store.one('SELECT count(*) n FROM hidden_messages WHERE user=?',(b,))['n'],105)
        self.assertEqual(await(await self.client.get('/api/calls',headers=self.h(self.b))).json(),[])
        self.assertEqual(len(await(await self.client.get('/api/calls',headers=self.h(self.a))).json()),1)
        self.assertEqual(await(await self.client.get('/api/saved',headers=self.h(self.b))).json(),[])
        rows=await self.get_rooms(self.b);self.assertEqual(rows[0]['history_revision'],revision);self.assertFalse(rows[0]['hidden_from_home']);self.assertIsNone(rows[0]['last'])
        await self.send('clear_history_new',self.a);self.assertEqual([m['id'] for m in await(await self.get_messages(self.b)).json()],['clear_history_new'])
    async def test_shared_clear_all_pages_keeps_call_history_and_new_messages(self):
        import json
        from app import now
        store=self.app['store'];a=self.a['user']['id'];b=self.b['user']['id']
        for i in range(105):store.run('INSERT INTO messages(id,room,sender,envelopes,created) VALUES(?,?,?,?,?)',(f'shared_clear_{i:04}',self.room,a if i%2 else b,json.dumps(self.env()),now()-10000+i))
        store.run('INSERT INTO saved VALUES(?,?)',(b,'shared_clear_0001'))
        store.run('INSERT INTO calls(id,room,caller,callee,video,started,status) VALUES(?,?,?,?,?,?,?)',('shared_call_0001',self.room,a,b,0,now()-1000,'ended'))
        request={'operation':'clear','rooms':[self.room],'scope':'everyone'};path='/api/room-history/manage'
        self.assertEqual((await self.client.post(path,headers=self.h(self.c),json=request)).status,403)
        r=await self.client.post(path,headers=self.h(self.b),json=request);self.assertEqual(r.status,200,await r.text());revision=(await r.json())['rooms'][0]['history_revision']
        for user in (self.a,self.b):
            self.assertEqual(await(await self.get_messages(user)).json(),[])
            self.assertEqual((await self.get_rooms(user))[0]['history_revision'],revision)
            self.assertEqual(len(await(await self.client.get('/api/calls',headers=self.h(user))).json()),1)
        self.assertEqual(store.one('SELECT count(*) n FROM messages WHERE room=?',(self.room,))['n'],0)
        self.assertEqual(store.one('SELECT count(*) n FROM deleted_message_ids WHERE room=?',(self.room,))['n'],105)
        self.assertFalse(store.one('SELECT 1 FROM saved WHERE message=?',('shared_clear_0001',)))
        await self.send('shared_clear_new',self.a);self.assertEqual([m['id'] for m in await(await self.get_messages(self.b)).json()],['shared_clear_new'])
    async def test_shared_clear_rejects_group_and_unsupported_scope_atomically(self):
        await self.send('shared_atomic_01',self.a)
        r=await self.client.post('/api/rooms',headers=self.h(self.a),json={'members':[self.b['user']['id'],self.c['user']['id']]});group=(await r.json())['id']
        path='/api/room-history/manage';request={'operation':'clear','rooms':[self.room,group],'scope':'everyone'}
        r=await self.client.post(path,headers=self.h(self.b),json=request);self.assertEqual(r.status,403);self.assertEqual(len(await(await self.get_messages(self.b)).json()),1)
        r=await self.client.post(path,headers=self.h(self.b),json={**request,'operation':'delete','rooms':[self.room]});self.assertEqual(r.status,400)
        r=await self.client.post(path,headers=self.h(self.b),json={**request,'scope':'bogus','rooms':[self.room]});self.assertEqual(r.status,400)
        self.assertEqual(len(await(await self.get_messages(self.a)).json()),1)
    async def test_remove_direct_reappears_on_message_or_explicit_reopen(self):
        await self.send('remove_history_01',self.a);r=await self.manage(self.b,'delete',[self.room]);self.assertEqual(r.status,200,await r.text());self.assertTrue((await self.get_rooms(self.b))[0]['hidden_from_home']);self.assertFalse((await self.get_rooms(self.a))[0].get('hidden_from_home',False))
        await self.send('remove_history_02',self.a);self.assertFalse((await self.get_rooms(self.b))[0]['hidden_from_home']);self.assertEqual([m['id'] for m in await(await self.get_messages(self.b)).json()],['remove_history_02'])
        r=await self.manage(self.b,'delete',[self.room]);self.assertEqual(r.status,200)
        r=await self.client.post('/api/rooms',headers=self.h(self.b),json={'members':[self.a['user']['id']]});self.assertEqual((await r.json())['id'],self.room);self.assertFalse((await self.get_rooms(self.b))[0]['hidden_from_home'])
    async def test_invalid_batch_does_not_modify_any_room(self):
        await self.send('atomic_history_01',self.a)
        r=await self.client.post('/api/rooms',headers=self.h(self.a),json={'members':[self.c['user']['id']]});other=(await r.json())['id']
        r=await self.manage(self.b,'clear',[self.room,other]);self.assertEqual(r.status,403);self.assertEqual(len(await(await self.get_messages(self.b)).json()),1)
        self.assertEqual((await self.manage(None,'clear',[self.room])).status,401)
        self.assertEqual((await self.manage(self.b,'leave',[self.room])).status,400)
        self.assertEqual((await self.manage(self.b,'clear',[])).status,400)
    async def test_group_departure_revokes_access_and_preserves_other_members(self):
        from test_server import ENVELOPE
        users=[x['user']['id'] for x in (self.a,self.b,self.c)]
        r=await self.client.post('/api/rooms',headers=self.h(self.a),json={'members':users[1:],'title':'Grup'});room=(await r.json())['id']
        path='/api/rooms/'+room+'/messages';r=await self.client.post(path,headers=self.h(self.b),json={'id':'group_leave_history_01','envelopes':{u:ENVELOPE for u in users}});self.assertEqual(r.status,201,await r.text())
        self.assertEqual((await self.manage(self.b,'delete',[room])).status,400)
        r=await self.manage(self.b,'leave',[room]);self.assertEqual(r.status,200,await r.text());self.assertNotIn(room,[x['id'] for x in await self.get_rooms(self.b)])
        self.assertEqual((await self.get_messages(self.b,room)).status,403);remaining=await(await self.get_messages(self.a,room)).json();self.assertEqual(len(remaining),1);self.assertEqual(remaining[0]['sender'],users[1]);self.assertIsInstance(remaining[0]['sender_pub'],dict);self.assertEqual(len(await(await self.get_messages(self.c,room)).json()),1)
        r=await self.client.post(path,headers=self.h(self.a),json={'id':'group_leave_history_02','envelopes':{users[0]:ENVELOPE,users[2]:ENVELOPE}});self.assertEqual(r.status,201,await r.text())
        self.assertEqual((await self.manage(self.b,'leave',[room])).status,403)
    async def test_secure_history_and_active_group_call_fail_closed(self):
        store=self.app['store'];r=await self.client.post('/api/rooms',headers=self.h(self.a),json={'members':[self.b['user']['id'],self.c['user']['id']],'title':'Grup'});room=(await r.json())['id']
        import json
        members=[x['user']['id'] for x in (self.a,self.b,self.c)]
        store.run('INSERT INTO ratchet_group_epochs(epoch,room,members_json) VALUES(?,?,?)',('test_epoch_01',room,json.dumps(members)))
        self.assertEqual((await self.manage(self.b,'clear',[room])).status,409)
        store.group_calls.calls['test_active']={'room':room}
        self.assertEqual((await self.manage(self.b,'leave',[room])).status,409);store.group_calls.calls.clear()
        self.assertIn(room,[x['id'] for x in await self.get_rooms(self.b)])
if __name__=='__main__':unittest.main()
