"""Static production flavor contract; live FCM delivery requires Android device tests."""
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
APP=ROOT/'android/app'
JAVA=APP/'src/main/java/com/fs/mesajlasma'
ANDROID='{http://schemas.android.com/apk/res/android}'
TOOLS='{http://schemas.android.com/tools}'
class IdleNotificationTests(unittest.TestCase):
    def test_push_manifest_removes_only_idle_service(self):
        main=ET.parse(APP/'src/main/AndroidManifest.xml').getroot()
        push=ET.parse(APP/'src/push/AndroidManifest.xml').getroot()
        removed=[n.get(ANDROID+'name') for n in push.findall('application/service') if n.get(TOOLS+'node')=='remove']
        self.assertEqual(removed,['.ConnectionService'])
        self.assertTrue({'.CallService','.LocationService'} <= {n.get(ANDROID+'name') for n in main.findall('application/service')})
        self.assertTrue(any(n.get(ANDROID+'name')=='.FirebasePush' for n in push.findall('application/service')))
    def test_production_does_not_start_idle_poll(self):
        source=(JAVA/'MainActivity.java').read_text()
        self.assertEqual(source.count('startForegroundService(new Intent(MainActivity.this,ConnectionService.class))'),1)
        self.assertIn('if(PushSupport.usesFirebase()){stopService(new Intent(MainActivity.this,ConnectionService.class));}else{startForegroundService(new Intent(MainActivity.this,ConnectionService.class));}',source)
        self.assertIn('return BuildConfig.FS_PUSH_ENABLED;', (JAVA/'PushSupport.java').read_text())
        self.assertIn("buildConfigField 'boolean', 'FS_PUSH_ENABLED', fsPush ? 'true' : 'false'", (APP/'build.gradle').read_text())
    def test_push_wakeup_and_user_settings_remain(self):
        source=(APP/'src/push/java/com/fs/mesajlasma/FirebasePush.java').read_text()
        for marker in ('call-wakeup-v1','message-wakeup-v1','CallAlert.post','MessagePushWorker','allowed(this,"available")','allowed(this,"notifications")'):
            self.assertIn(marker,source)
    def test_binary_manifest_guard(self):
        self.assertIn('Unexpected idle polling service in push APK',(ROOT/'tools/verify_push_apk.py').read_text())
if __name__=='__main__':unittest.main()
