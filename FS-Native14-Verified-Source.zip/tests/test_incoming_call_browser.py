"""Actual Chromium layout and click checks for the incoming call component (not Android E2E)."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
app=(root/'app.js').read_text()
avatar=app[app.index('const avatar ='):app.index('const empty =')]
escape=app[app.index('const escape ='):app.index('let emojiItems')]
icons=(root/'icons.js').read_text().replace('export ','')
component='\n'.join(line.replace('export ','') for line in (root/'incoming-call-screen.js').read_text().splitlines() if not line.startswith('import '))
photo='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2240%22 height=%2240%22%3E%3Crect width=%2240%22 height=%2240%22 fill=%22%23b3d6b6%22/%3E%3C/svg%3E'
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
    page=browser.new_page(viewport={'width':390,'height':844},has_touch=True)
    page.set_content('<div id="app"></div>');page.add_style_tag(content=(root/'style.css').read_text())
    page.evaluate('()=>{'+icons+'\n'+escape+'\n'+avatar+'\n'+component+'''
window.draw=(call,light)=>{document.body.classList.toggle('light',light);document.querySelector('#app').innerHTML=incomingCallMarkup(call,avatar);};window.hits=[];document.addEventListener('click',e=>{const b=e.target.closest('[data-action]');if(b)hits.push(b.dataset.action);});}''')
    for w,h in [(320,480),(360,640),(390,844),(412,915),(740,360),(540,320)]:
        page.set_viewport_size({'width':w,'height':h})
        for light in [False,True]:
            for video in [False,True]:
                call={'incoming':True,'video':video,'peer':{'name':'Ayşe Demir','avatar':photo}}
                page.evaluate('([c,l])=>draw(c,l)',[call,light])
                assert page.locator('#incoming-caller').inner_text()=='Ayşe Demir'
                assert page.locator('.incoming-photo img').evaluate('(e)=>e.complete&&e.naturalWidth>0')
                assert page.locator('#incoming-type').inner_text()==('Gelen görüntülü arama' if video else 'Gelen sesli arama')
                assert page.locator('video,audio').count()==0
                assert page.locator('.fs-incoming-screen').evaluate('(e)=>e.scrollWidth<=e.clientWidth+1&&e.scrollHeight<=e.clientHeight+1')
                for action in ['reject-call','accept-call','reply-call']:
                    loc=page.locator(f'[data-action="{action}"]');b=loc.bounding_box();assert b and b['width']>=44 and b['height']>=44 and b['x']>=0 and b['y']>=0 and b['x']+b['width']<=w+1 and b['y']+b['height']<=h+1,(w,h,action,b)
                    loc.click();assert page.evaluate('hits.at(-1)')==action
        print(f'PASS {w}x{h}: 2 themes × 2 call types; profile, layout and click actions')
    page.set_viewport_size({'width':320,'height':480})
    group={'incoming':True,'group':True,'video':True,'host':'a','room':{'title':'Çok uzun grup adı '*14,'members':[{'id':'a','name':'Çok uzun kişi adı '*14}]}}
    page.evaluate('c=>draw(c,false)',group)
    assert page.locator('.incoming-group').count()==1
    assert page.locator('.fs-incoming-screen').evaluate('(e)=>e.scrollWidth<=e.clientWidth+1&&e.scrollHeight<=e.clientHeight+1')
    assert page.locator('[data-action="accept-call"]').is_visible();page.locator('[data-action="accept-call"]').click();assert page.evaluate('hits.at(-1)')=='accept-call'
    group['accepting']=True;page.evaluate('c=>draw(c,false)',group)
    assert page.locator('[data-action="accept-call"]').is_disabled() and page.locator('[data-action="reply-call"]').is_disabled()
    assert page.locator('[data-action="reject-call"]').is_enabled();page.locator('[data-action="reject-call"]').click();assert page.evaluate('hits.at(-1)')=='reject-call'
    print('PASS long names and group, pending accept state and cancellation')
    browser.close()
