"""Chromium isolated chat DOM: actual latest-jump handlers, markup, styles and virtual list."""
from pathlib import Path
import os
import re
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
s=(root/'app.js').read_text(); handlers=s[s.index('function updateLatestButton()'):s.index('function selectionMarker(m)')]
markup=re.search(r'<div class="latest-message-anchor">.*?</button></div>',s).group()
virtual=(root/'virtual-list.js').read_text().replace('export ','')+'\n'+(root/'chat-performance.js').read_text().replace('export ','')+'\nconst countUnread=createUnreadCounter();let deletedRevision=0;'
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
    page=browser.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
    page.set_content('<meta name="viewport" content="width=device-width,initial-scale=1"><div id="app"><section class="screen chat-wall fs-premium fs-chat"><header class="chat-head"><h1>Test</h1></header><main class="scroll messages" id="messages"></main>'+markup+'<div id="reply"></div><form class="composer"><div class="box"><textarea id="message-text" rows="1"></textarea></div><button type="button" class="icon send">➤</button></form></section></div>')
    page.add_style_tag(content=(root/'style.css').read_text())
    page.evaluate('''()=>{'''+virtual+'''\nconst $=s=>document.querySelector(s),list=$('#messages');let locked=false;const isLocked=()=>locked;
const state={page:'chat',room:{id:'r'},user:{id:'me'},messages:[]};const localState={preferences:{read:{r:150}}};const hiddenMessage=m=>m.hidden;let replyJumpFlight=null,replyReturn=null;function rememberChat(){}function markCurrentRead(){if(nearLatest(list))localState.preferences.read.r=state.messages.at(-1)?.created||0;}
'''+handlers+'''
let rows=Array.from({length:150},(_,i)=>({id:String(i+1),html:'<div style="height:'+ (45+(i%7)*14)+'px">Mesaj '+(i+1)+'</div>'}));state.messages=rows.map((r,i)=>({id:r.id,created:i+1,sender:'peer',payload:{type:'text'}}));const virtualMessages=new VirtualMessages(list,(t,h)=>t.innerHTML=h,updateLatestButton);virtualMessages.set(rows,{bottom:true});list.addEventListener('scroll',()=>{markCurrentRead();updateLatestButton()});$('#new-messages').addEventListener('click',jumpToLatest);
window.scrollToOld=()=>{list.scrollTop=150;virtualMessages.draw();updateLatestButton()};window.addMessage=()=>{const i=rows.length+1;rows=[...rows,{id:String(i),html:'<div style="height:130px">Mesaj '+i+'</div>'}];state.messages=[...state.messages,{id:String(i),created:i,sender:'peer',payload:{type:'text'}}];const anchor=virtualMessages.anchor();virtualMessages.set(rows,{bottom:nearLatest(list),anchor});updateLatestButton()};window.lockIt=()=>{locked=true};window.unlockIt=()=>{locked=false};window.tryJump=jumpToLatest;
}''')
    page.wait_for_timeout(300)
    button=page.locator('#new-messages'); badge=page.locator('#new-messages-count')
    assert not button.is_visible(); print('PASS Latest message: arrow hidden')
    page.evaluate('scrollToOld()'); page.wait_for_timeout(150); assert button.is_visible(); assert not badge.is_visible(); print('PASS Scrolling up reveals arrow without a false unread count')
    def bounds():
        return page.evaluate('''()=>{const r=s=>{const b=document.querySelector(s).getBoundingClientRect();return {x:b.x,y:b.y,w:b.width,h:b.height,bottom:b.bottom}};return {arrow:r('#new-messages'),list:r('#messages'),composer:r('.composer')}}''')
    b=bounds(); assert abs(b['arrow']['x']+b['arrow']['w']/2-b['list']['x']-b['list']['w']/2)<1;assert b['arrow']['bottom']<=b['composer']['y'];print('PASS Arrow centered above composer without consuming layout height')
    page.evaluate('addMessage();addMessage()');page.wait_for_timeout(150);assert badge.inner_text()=='2';assert button.is_visible(); print('PASS Two incoming messages counted while reading history')
    page.locator('#message-text').fill('Taslak mesaj');page.set_viewport_size({'width':390,'height':360});page.evaluate("document.querySelector('#app').style.setProperty('--chat-viewport-height','360px')");page.wait_for_timeout(100);b=bounds();assert b['arrow']['y']>=b['list']['y'] and b['arrow']['bottom']<=b['composer']['y'];print('PASS Keyboard-sized viewport keeps arrow above composer')
    button.click();page.wait_for_timeout(350);assert not button.is_visible();assert page.locator('[data-row-id="152"]').count()==1;assert page.evaluate("(()=>{const t=document.querySelector('#messages');return t.scrollHeight-t.scrollTop-t.clientHeight<=2})()");assert page.locator('#message-text').input_value()=='Taslak mesaj';print('PASS One click reaches actual last virtual message and preserves draft')
    page.evaluate('addMessage()');page.wait_for_timeout(250);assert not button.is_visible();assert page.locator('[data-row-id="153"]').count()==1;print('PASS Incoming message follows bottom while already at latest')
    page.evaluate('scrollToOld();lockIt()');old=page.locator('#messages').evaluate('(t)=>t.scrollTop');page.evaluate('tryJump()');assert page.locator('#messages').evaluate('(t)=>t.scrollTop')==old; print('PASS Locked session cannot jump through the action')
    browser.close()
