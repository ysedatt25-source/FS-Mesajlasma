from test_server import APITest, PUB

class LegacyAccountUpgradeTest(APITest):
 async def test_legacy_upgrade_and_reset_preserves_identity(self):
  sent=[]; self.app['email_sender']=lambda address,code:sent.append((address,code))
  uid=self.a['user']['id']; store=self.app['store']; h=self.h(self.a)
  before=store.one('SELECT pub FROM users WHERE id=?',(uid,))['pub']
  self.assertIsNone(store.one('SELECT * FROM account_emails WHERE user_id=?',(uid,)))
  r=await self.client.get('/api/account/email',headers=h); self.assertEqual(await r.json(),{'email':'','verified':False})
  r=await self.client.post('/api/account/email/start',headers=h,json={'email':'legacy@example.com','password':'test-password-123'}); self.assertEqual(r.status,200,await r.text())
  r=await self.client.post('/api/account/email/finish',headers=h,json={'code':sent[-1][1]}); self.assertEqual(r.status,200,await r.text())
  body={'phone':'+905001111111','email':'legacy@example.com'}
  r=await self.client.post('/api/account/recovery/start',json=body); self.assertEqual(r.status,200,await r.text()); self.assertEqual(len(sent),2)
  r=await self.client.post('/api/account/recovery/finish',json={**body,'code':sent[-1][1],'password':'new-password-123'}); self.assertEqual(r.status,200,await r.text())
  r=await self.client.post('/api/session',json={'login':'alice','password':'new-password-123','pub':PUB}); self.assertEqual(r.status,200,await r.text()); self.assertEqual((await r.json())['user']['id'],uid)
  self.assertEqual(store.one('SELECT pub FROM users WHERE id=?',(uid,))['pub'],before)
  self.assertEqual((await self.client.get('/api/account/email',headers=h)).status,401)
