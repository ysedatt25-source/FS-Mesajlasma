"""Real Chromium layout and reply-focus duration using actual application functions."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
s=(root/'app.js').read_text()
jump=s[s.index('async function jumpReply('):s.index('async function reactToMessage(')]
keyed=s[s.index('function keyedMessages('):s.index('const audioUrls')]
dialog=s[s.index('function dialog(title, content)'):s.index('function field(')]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page(viewport={'width':320,'height':640},has_touch=True,is_mobile=True)
 page.set_content('<meta name="viewport" content="width=device-width,initial-scale=1"><div id="app"><section class="screen fs-premium fs-chat"><main id="messages" class="scroll messages"></main></section></div><dialog id="modal"></dialog>');page.add_style_tag(content=(root/'style.css').read_text())
 page.evaluate('''()=>{const $=s=>document.querySelector(s),modal=$('#modal'),state={page:'chat',routeVersion:1,room:{id:'r'},messages:[{id:'m'}],hasOlder:false};let replyReturn=null,replyJumpFlight=null;const isLocked=()=>false,hiddenMessage=()=>false,notice=()=>{},assertAccess=()=>{},closeAlbumViewer=()=>{},closeOnceViewer=()=>{},clearProfileViewer=()=>{},clearMessageMenu=()=>{},escape=s=>String(s),button=(a,i,l,attrs)=>`<button data-action="${a}" ${attrs}>×</button>`;const list=$('#messages');const virtualMessages={rows:[{id:'m'}],jump:()=>true,anchor:()=>({id:'m'})};'''+keyed+jump+dialog+'''
 window.draw=(text='original')=>keyedMessages(list,`<div data-key="m"><article class="message mine" data-message="m">${text}<time>10:00 ✓✓</time></article></div>`);window.jump=()=>jumpReply('m');window.show=()=>dialog('Mesajları sil','<p>1 mesaj seçildi.</p><div class="dialog-action-stack"><button class="secondary" id="delete-local">Yalnızca bu cihazda gizle</button><button class="primary danger" id="confirm-delete">Herkesten sil</button><button class="secondary" data-action="close-dialog">Vazgeç</button></div>');window.general=()=>dialog('Uzun bilgi başlığı ve onay','<form><label>Uzun bilgi</label><input value="örnek"><button class="primary">'+('Uzun işlem açıklaması '.repeat(8))+'</button><button class="secondary" data-action="close-dialog">Vazgeç</button></form><button class="secondary" data-action="close-dialog">Kapat ve geri dön</button>');window.draw();}''')
 page.evaluate('jump()');assert page.locator('.found-message').count()==1;page.wait_for_timeout(1400);page.evaluate('draw("fresh render")');assert page.locator('.found-message').count()==1;page.wait_for_timeout(1050);assert page.locator('.found-message').count()==1;page.wait_for_timeout(750);assert page.locator('.found-message').count()==0;print('PASS 3-second reply highlight survives redraw and clears')
 for w,h in [(280,580),(320,640),(390,844),(390,300),(844,390)]:
  page.set_viewport_size({'width':w,'height':h});page.evaluate('show()')
  result=page.evaluate('''()=>{const d=document.querySelector('#modal'),r=d.getBoundingClientRect(),buttons=[...d.querySelectorAll('.dialog-action-stack button')].map(x=>x.getBoundingClientRect());return {fits:r.left>=0&&r.right<=innerWidth+.5&&r.top>=0&&r.bottom<=innerHeight+.5,within:buttons.every(x=>x.left>=r.left&&x.right<=r.right),noOverlap:buttons.every((x,i)=>!i||x.top>=buttons[i-1].bottom),width:d.scrollWidth<=d.clientWidth+1}}''');assert all(result.values()),(w,h,result)
  assert page.locator('#modal .dialog-close').count()==1;page.evaluate("document.querySelector('#modal').close()")
  page.evaluate('general()');assert page.evaluate('''()=>{const d=document.querySelector('#modal'),b=d.querySelector(':scope > button.secondary');return d.scrollWidth<=d.clientWidth+1&&b.getBoundingClientRect().width>36}''');page.evaluate("document.querySelector('#modal').close()")
  print(f'PASS dialog bounds, action layout and distinct close control {w}x{h}')
 b.close()
