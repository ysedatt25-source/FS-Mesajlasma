"""Render the real direct-call template and controls in Chromium with controlled media state."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
s=(root/'app.js').read_text()
ui=s[s.index('function callElapsedLabel('):s.index('async function endCall(')]
helper=(root/'call-chat-fixes.js').read_text().replace('export ','')
icons=(root/'icons.js').read_text().replace('export ','')
apply=s[s.index('function applyCallControls(c)'):].split('\n',1)[0]
stop_thumbnails=s[s.index('function stopThumbnailObservation()'):].split('\n',1)[0]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page(viewport={'width':320,'height':640},is_mobile=True,has_touch=True)
 page.set_content('<meta name="viewport" content="width=device-width,initial-scale=1"><div id="app"></div>');page.add_style_tag(content=(root/'style.css').read_text())
 page.evaluate('''()=>{const localStorage={},$=s=>document.querySelector(s),app=$('#app'),state={page:'call',user:{id:'u'}},typing={reset(){}},isLocked=()=>false,discardVoice=()=>{},dismissAlbumViewer=()=>{},dismissProfileViewer=()=>{},attachVideo=()=>{},refreshCallVerification=()=>{},callSecurityMarkup=()=>'<span class="call-security-emojis">🐱 🌙 🚀 ⭐</span>',avatar=()=>'<div class="avatar large">A</div>',escape=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;'),selectedVoice=()=> 'normal',voiceLabel=()=> 'Normal',button=(a,i,l)=>`<button class="icon" data-action="${a}" aria-label="${l}">←</button>`;let audio={},thumbnailDisconnects=0,thumbnailObserver={disconnect(){thumbnailDisconnects++}};window.FSNative={audioState:()=>JSON.stringify(audio),activeCall(){}};'''+helper+icons+stop_thumbnails+ui+apply+'''
 window.draw=(video,bt,muted=false)=>{audio={bluetooth:bt,route:bt?'bluetooth':'speaker'};state.call={video,remote:video?{}:null,stream:{getAudioTracks:()=>[{enabled:!muted}],getVideoTracks:()=>video?[{enabled:true}]:[]},pc:{connectionState:'connected'},phase:'Bağlandı',started:Date.now()-65000,peer:{name:'Uzun isim '.repeat(8)}};showCall()};window.thumbnailCleanup=()=>({disconnected:thumbnailDisconnects,cleared:thumbnailObserver===null});window.c=()=>state.call;window.elapsed=callElapsedLabel;window.redraw=showCall;window.sameLayout=()=>{const old=$(".call");refreshCallExtras(state.call);return old===$(".call")};window.refreshMedia=()=>{state.call.extras={mode:"camera",remote:"off",ready:true};state.call.video=false;refreshCallExtras(state.call)};window.update=updateCallControl;window.hide=()=>{state.call.controlsHidden=true;applyCallControls(state.call)};}''')
 for w,h in [(280,580),(320,640),(390,844),(640,360),(844,390)]:
  page.set_viewport_size({'width':w,'height':h})
  for video in (False,True):
   for bt in (False,True):
    page.evaluate('([v,b])=>draw(v,b)',[video,bt]);assert page.locator('.control').count()==5+bt
    result=page.evaluate('''()=>{const c=document.querySelector('.call'),r=c.getBoundingClientRect(),dock=c.querySelector('.controls').getBoundingClientRect(),bs=[...c.querySelectorAll('.control button')].map(x=>x.getBoundingClientRect());return {fits:dock.left>=r.left-.5&&dock.right<=r.right+.5&&dock.bottom<=r.bottom+.5&&dock.top>=r.top,buttons:bs.every(x=>x.width>=44&&x.height>=44&&x.left>=dock.left&&x.right<=dock.right&&x.bottom<=dock.bottom),noOverlap:bs.every((x,i)=>bs.slice(i+1).every(y=>x.right<=y.left||y.right<=x.left||x.bottom<=y.top||y.bottom<=x.top)),timer:document.querySelector('#call-timer').textContent==='01:05',noQuality:!document.querySelector('#call-network').textContent}}''');assert all(result.values()),(w,h,video,bt,result)
  print(f'PASS 4 audio/video/BT combinations at {w}x{h}')
 assert page.evaluate('thumbnailCleanup()')=={'disconnected':1,'cleared':True};print('PASS entering call disconnects previous thumbnail observer once')
 page.evaluate('draw(false,true,true)');assert page.locator('[data-action="mute"]').get_attribute('aria-pressed')=='true';assert page.locator('[data-action="bluetooth"]').get_attribute('aria-pressed')=='true';assert page.locator('[data-action="camera-toggle"]').get_attribute('aria-pressed')=='false';print('PASS real control initial states')
 page.evaluate('update(document.querySelector(\'[data-action="mute"]\'),false,"mic","Mikrofon")');assert page.locator('[data-action="mute"]').get_attribute('aria-pressed')=='false';assert page.locator('[data-action="mute"]').get_attribute('aria-label')=='Mikrofon';print('PASS accessible icon state change')
 page.evaluate('draw(true,true);hide();redraw()');assert page.locator('.controls').get_attribute('aria-hidden')=='true';assert page.locator('.controls').evaluate('(e)=>e.inert');page.locator('#remote-video').click(position={'x':200,'y':155},force=True);assert page.locator('.controls').get_attribute('aria-hidden')=='false';print('PASS video controls hidden across redraw and restored by tap')
 page.evaluate('draw(true,true);hide();refreshMedia()');assert page.locator('.controls').get_attribute('aria-hidden')=='true';assert page.evaluate('c().controlsHidden');page.locator('.person').click(force=True);assert page.locator('.controls').get_attribute('aria-hidden')=='false';print('PASS media-mode change preserves hidden controls even without remote video');assert page.evaluate('sameLayout()');print('PASS unchanged call media layout does not recreate playback elements')
 page.evaluate('draw(false,false);c().started=null;c().phase="Aranıyor…";redraw()');assert page.locator('.call').get_attribute('data-call-phase')=='connecting';assert page.locator('#call-timer').inner_text()=='Aranıyor…'
 waiting=page.locator('.call').evaluate('(e)=>getComputedStyle(e).backgroundImage')
 page.evaluate('c().alertStatus="alerted";c().phase="Çalıyor… (zil bildirimi)";redraw()');assert page.locator('.call').get_attribute('data-call-phase')=='ringing';assert page.locator('.call').evaluate('(e)=>getComputedStyle(e).backgroundImage')!=waiting;assert page.locator('.call-avatar-frame').evaluate('(e)=>getComputedStyle(e).animationName')=='fs-call-ring'
 page.emulate_media(reduced_motion='reduce');assert page.locator('.call-avatar-frame').evaluate('(e)=>getComputedStyle(e).animationName')=='none';page.emulate_media(reduced_motion='no-preference');print('PASS confirmed ringing uses distinct background, no false ringing, reduced motion')
 page.evaluate('c().alertAccepted=true;c().phase="Bağlanıyor…";redraw()');assert page.locator('.call').get_attribute('data-call-phase')=='connecting'
 page.evaluate('draw(false,false)');assert page.locator('.call').get_attribute('data-call-phase')=='active';page.evaluate('c().pc.connectionState="disconnected";redraw()');assert page.locator('.call').get_attribute('data-call-phase')=='connecting';print('PASS active and reconnect visual states')
 page.set_viewport_size({'width':390,'height':844});page.evaluate('draw(false,false);c().peer.name="Ayşe Demir";redraw()');page.screenshot(path=os.environ.get('FS_CALL_SCREENSHOT','/tmp/fs-p8-call.png'))
 assert page.evaluate('elapsed({started:1000}, 62000)')=='01:01';assert page.evaluate('elapsed({phase:"Aranıyor…"}, 62000)')=='Aranıyor…';print('PASS timer starts without duplicate phase and preserves elapsed time')
 b.close()
