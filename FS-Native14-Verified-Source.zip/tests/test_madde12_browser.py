"""Isolated Chromium checks for real app viewport, pointer and map markup; no remote tile network."""
from pathlib import Path
import os, base64
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
src=(root/'app.js').read_text()
view=src[src.index('let viewportFrame=0, previousChatHeight=0,'):src.index('window.visualViewport?.addEventListener',src.index('let viewportFrame=0, previousChatHeight=0,'))]
map_src=src[src.index('const approvedMaps=new Set();'):src.index('// An expired share')]
helpers=(root/'call-chat-fixes.js').read_text().replace('export ','')
markup='''<div id="app"><section class="screen chat-wall fs-premium fs-chat"><button class="call-banner">Aramaya geri dön</button><header class="chat-head"><button class="icon">←</button><button>A</button><h1>Test kişisi</h1></header><nav class="chat-tools"><button>Sohbette ara</button></nav><div id="selection"></div><main class="scroll messages" id="messages"></main><div id="reply"></div><div id="composer-files" hidden></div><div id="upload-progress"></div><div id="voice-status" hidden></div><form class="composer"><div class="box"><textarea id="message-text" rows="1"></textarea></div><button class="icon send">➤</button></form><video id="call-mini" class="chat-pip"></video></section></div>'''
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
 page=b.new_page(viewport={'width':390,'height':844});requests=[]
 page.route('https://fs.test/',lambda route:route.fulfill(body='<meta name="viewport" content="width=device-width,initial-scale=1">'+markup,content_type='text/html'))
 def tile(route):
  requests.append(route.request.url);route.fulfill(content_type='image/png',body=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aZ1sAAAAASUVORK5CYII='))
 page.route('https://tile.openstreetmap.org/**',tile);page.set_content('<meta name="viewport" content="width=device-width,initial-scale=1">'+markup);page.add_style_tag(content=(root/'style.css').read_text())
 page.evaluate('''()=>{'''+helpers+'''
 const $=s=>document.querySelector(s),app=$('#app'),state={page:'chat',user:{id:'test'},call:{chatPipRatio:{x:1,y:1}}};let virtualMessages=null,returns=0;const nearLatest=t=>Math.max(0,t.scrollHeight-t.scrollTop-t.clientHeight)<=32;function updateLatestButton(){}function showCall(){returns++}function escape(s){return String(s).replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;')}
 $('#messages').innerHTML=Array.from({length:70},(_,i)=>'<div class="message-row"><div class="message">Mesaj '+i+'</div></div>').join('');
 '''+view+map_src+'''
 window.sync=syncChatViewport;window.dragState=()=>({ratio:state.call.chatPipRatio,returns});window.setVisual=(height,offsetTop)=>{Object.defineProperty(window,'visualViewport',{configurable:true,value:{height,offsetTop}});syncChatViewport()};
 window.map=(allow=false,lat=41.01,lng=28.97)=>{const m={id:'loc',payload:{type:'location',lat,lng,live:true,expires:Date.now()+100000}};if(allow)approvedMaps.add(mapConsentKey(m));else approvedMaps.clear();$('#messages').innerHTML=locationCard(m);$('#messages').scrollTop=0;};syncChatViewport();bindChatPip();
 }''')
 def box(sel):return page.locator(sel).bounding_box()
 def bounds():
  a,v=box('#messages'),box('#call-mini');assert v['x']>=a['x']-.5 and v['y']>=a['y']-.5 and v['x']+v['width']<=a['x']+a['width']+.5 and v['y']+v['height']<=a['y']+a['height']+.5,(a,v)
 page.evaluate('setVisual(340,110)');bounds();a=box('#messages');v=box('#call-mini');page.mouse.move(v['x']+v['width']/2,v['y']+v['height']/2);page.mouse.down();page.mouse.move(a['x']+10,a['y']+10,steps=8);page.mouse.up();bounds();assert page.evaluate('dragState().ratio.x')<.15;assert page.evaluate('dragState().ratio.y')<.15;assert page.evaluate('dragState().returns')==0;print('PASS Drag to upper left with keyboard open; no accidental return')
 v=box('#call-mini');page.mouse.click(v['x']+v['width']/2,v['y']+v['height']/2);assert page.evaluate('dragState().returns')==1;print('PASS Tap returns to call')
 page.evaluate('''()=>{document.querySelector('#composer-files').hidden=false;document.querySelector('#composer-files').innerHTML='<div>Attachment</div>'.repeat(12);document.querySelector('#reply').innerHTML='<div class="reply-banner">Reply to message</div>';document.querySelector('textarea').style.height='120px';setVisual(265,80)}''');bounds();assert box('#messages')['height']>15;assert box('.composer')['y']+box('.composer')['height']<=345.5;print('PASS Compact viewport fits attachment, reply, composer and video')
 page.evaluate('map(false)');assert page.locator('.location-map-placeholder').count()==1 and page.locator('.location-tiles img').count()==0;assert not requests;print('PASS No map network before consent')
 page.evaluate('map(true)');page.wait_for_function("document.querySelectorAll('.location-tiles img').length===4");page.locator('.location-map').scroll_into_view_if_needed();page.wait_for_timeout(400);assert page.locator('iframe').count()==0;assert page.locator('.location-attribution').count()==1;assert all(u.startswith('https://tile.openstreetmap.org/15/') for u in page.locator('.location-tiles img').evaluate_all('(nodes)=>nodes.map(n=>n.src)'));print('PASS Consented map markup uses four raster images, attribution and no iframe (network not validated)')
 page.evaluate('map(true,90,0)');assert page.locator('.location-tiles img').count()==0 and page.locator('.location-open').count()==1;print('PASS Polar location retains external map fallback')
 b.close()
