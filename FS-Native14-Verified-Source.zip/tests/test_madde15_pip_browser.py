"""Real Chromium pointer events on the actual app's chat and direct-call preview logic."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
s=(root/'app.js').read_text()
helpers=(root/'call-chat-fixes.js').read_text().replace('export ','')
call=s[s.index('function callPipBounds('):s.index('async function endCall(')]
chat=s[s.index('function pipBounds()'):s.index("window.visualViewport?.addEventListener('resize',scheduleChatViewport)")]
markup='''<meta name="viewport" content="width=device-width,initial-scale=1"><div id="app"><section class="screen chat-wall fs-premium fs-chat"><header class="chat-head">Sohbet</header><main id="messages" class="scroll messages"></main><form class="composer"><textarea aria-label="Mesaj yaz"></textarea></form><video id="call-mini" class="chat-pip" tabindex="0"></video></section></div>'''
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page(viewport={'width':390,'height':740},has_touch=True,is_mobile=True)
 page.set_content(markup);page.add_style_tag(content=(root/'style.css').read_text())
 page.evaluate('''()=>{const $=s=>document.querySelector(s),app=$('#app'),state={page:'chat',call:{}};let taps=0;function showCall(){taps++}'''+helpers+call+chat+'''
 window.taps=()=>taps;window.layout=placeChatPip;window.pos=()=>state.call.chatPipRatio;window.preferred=()=>state.call.chatPipHeight;
 window.small=()=>{app.style.setProperty('--chat-viewport-height','180px');placeChatPip()};window.large=()=>{app.style.setProperty('--chat-viewport-height','740px');placeChatPip()};
 window.direct=()=>{state.page='call';app.innerHTML='<section class="call fs-premium fs-direct-call fs-video-live"><header style="height:40px">Başlık</header><div class="person">Test</div><video class="local" id="local-video" tabindex="0"></video><div class="controls" style="height:152px;margin-top:auto">Kontroller</div></section>';const el=$('#local-video');bindFloatingVideo(el,state.call,{bounds:()=>callPipBounds(el),place:placeCallPip,positionKey:'callPipRatio',sizeKey:'callPipHeight',defaultSize:144,onTap:()=>taps++});};window.directLayout=placeCallPip;bindChatPip();}''')
 def rect(sel):return page.locator(sel).bounding_box()
 def fits(sel,area):
  v,a=rect(sel),rect(area);assert v['x']>=a['x']-.6 and v['y']>=a['y']-.6 and v['x']+v['width']<=a['x']+a['width']+.6 and v['y']+v['height']<=a['y']+a['height']+.6,(v,a)
 def drag(sel,x,y):
  v=rect(sel);page.mouse.move(v['x']+v['width']/2,v['y']+v['height']/2);page.mouse.down();page.mouse.move(x,y,steps=8);page.mouse.up()
 fits('#call-mini','#messages');a=rect('#messages');drag('#call-mini',a['x']+5,a['y']+5);fits('#call-mini','#messages');assert page.evaluate('pos().x')<.01 and page.evaluate('pos().y')<.01 and page.evaluate('taps()')==0;print('PASS free drag, upper-left corner, no activation')
 page.locator('[data-pip-resize="call-mini"]').click();assert page.evaluate('preferred()')==180;assert abs(rect('#call-mini')['height']-180)<1;fits('#call-mini','#messages');print('PASS size control increases preview')
 page.evaluate('small()');fits('#call-mini','#messages');assert rect('#call-mini')['height']<180;page.evaluate('large()');assert abs(rect('#call-mini')['height']-180)<1;print('PASS keyboard shrink and restoration of preferred size')
 # Use CDP touch events rather than synthetic JS dispatch, so capture/cancel are real.
 cdp=page.context.new_cdp_session(page);v=rect('#call-mini');x=v['x']+v['width']/2;y=v['y']+v['height']/2
 def touch(kind,pts):cdp.send('Input.dispatchTouchEvent',{'type':kind,'touchPoints':[{'x':xx,'y':yy,'id':ii} for ii,xx,yy in pts]})
 touch('touchStart',[(1,x-15,y),(2,x+15,y)]);touch('touchMove',[(1,x-27,y),(2,x+27,y)]);touch('touchEnd',[]);assert page.evaluate('preferred()')>180, page.evaluate('preferred()');assert page.evaluate('taps()')==0;fits('#call-mini','#messages');print('PASS two-finger pinch resizes without returning to call')
 v=rect('#call-mini');page.touchscreen.tap(v['x']+v['width']/2,v['y']+v['height']/2);assert page.evaluate('taps()')==1;print('PASS touch tap returns once')
 page.evaluate('direct()');fits('#local-video','.call');assert rect('#local-video')['y']>=rect('.call header')['y']+rect('.call header')['height']-.5;assert rect('#local-video')['y']+rect('#local-video')['height']<=rect('.controls')['y']+.5
 page.set_viewport_size({'width':740,'height':390});page.evaluate('directLayout()');fits('#local-video','.call');assert rect('#local-video')['y']+rect('#local-video')['height']<=rect('.controls')['y']+.5;print('PASS full-call preview stays within reserved header/control bounds after rotation')
 v=rect('#local-video');page.touchscreen.tap(v['x']+v['width']/2,v['y']+v['height']/2);assert page.evaluate('taps()')==2;print('PASS full-call preview activates once')
 b.close()
