"""Local HTTP security regression tests; only synthetic accounts and files."""
import asyncio, json, unittest
import test_server

class SecurityTest(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=test_server.APITest.asyncSetUp
    asyncTearDown=test_server.APITest.asyncTearDown
    h=test_server.APITest.h
    register=test_server.APITest.register
    env=test_server.APITest.env

    async def upload(self, complete=True):
        r=await self.client.post('/api/uploads',headers=self.h(self.a),json={'room':self.room,'size':6})
        self.assertEqual(r.status,201); ident=(await r.json())['id']
        if complete:
            r=await self.client.put('/api/uploads/'+ident,headers={**self.h(self.a),'Upload-Offset':'0'},data=b'abcdef')
            self.assertEqual(r.status,200)
        return ident

    async def test_strict_bearer_and_admin_boundary(self):
        for value in [self.a['token'],'Basic '+self.a['token'],'Bearer malformed','Bearer '+self.a['token']+'x']:
            r=await self.client.get('/api/me',headers={'Authorization':value});self.assertEqual(r.status,401)
        self.assertEqual((await self.client.get('/api/me',headers=self.h(self.a))).status,200)
        self.assertEqual((await self.client.get('/api/admin/inventory/users',headers=self.h(self.b))).status,403)

    async def test_other_member_cannot_attach_upload_and_forwarding_owner_can(self):
        ident=await self.upload();path='/api/rooms/'+self.room+'/messages';body={'id':'security_media_001','envelopes':self.env(),'uploads':[ident]}
        r=await self.client.post(path,headers=self.h(self.b),json=body);self.assertEqual(r.status,403,await r.text())
        self.assertEqual(self.app['store'].one('SELECT count(*) n FROM message_uploads')['n'],0)
        r=await self.client.post(path,headers=self.h(self.a),json=body);self.assertEqual(r.status,201,await r.text())
        r=await self.client.get('/api/uploads/'+ident,headers=self.h(self.b));self.assertEqual(await r.read(),b'abcdef')

    async def test_duplicate_upload_ids_rejected_without_partial_message(self):
        ident=await self.upload();path='/api/rooms/'+self.room+'/messages'
        r=await self.client.post(path,headers=self.h(self.a),json={'id':'security_media_002','envelopes':self.env(),'uploads':[ident,ident]});self.assertEqual(r.status,400,await r.text())
        self.assertEqual(self.app['store'].one('SELECT count(*) n FROM messages')['n'],0)

    async def test_slow_upload_cannot_write_after_logout(self):
        ident=await self.upload(False);started=asyncio.Event();finish=asyncio.Event()
        async def data():
            yield b'abc';started.set();await finish.wait();yield b'def'
        pending=asyncio.create_task(self.client.put('/api/uploads/'+ident,headers={**self.h(self.a),'Upload-Offset':'0'},data=data()))
        try:
            await asyncio.wait_for(started.wait(),2);await asyncio.sleep(.05)
            r=await self.client.post('/api/logout',headers=self.h(self.a));self.assertEqual(r.status,200)
        finally:finish.set()
        r=await asyncio.wait_for(pending,3);self.assertEqual(r.status,401,await r.text())
        self.assertEqual(self.app['store'].one('SELECT received FROM uploads WHERE id=?',(ident,))['received'],0)
        self.assertFalse((self.app['store'].dir/ident).exists())

    async def test_slow_upload_after_delete_is_404_not_500(self):
        ident=await self.upload(False);started=asyncio.Event();finish=asyncio.Event()
        async def data():
            yield b'abc';started.set();await finish.wait();yield b'def'
        pending=asyncio.create_task(self.client.put('/api/uploads/'+ident,headers={**self.h(self.a),'Upload-Offset':'0'},data=data()))
        try:
            await asyncio.wait_for(started.wait(),2);await asyncio.sleep(.05)
            r=await self.client.delete('/api/uploads/'+ident,headers=self.h(self.a));self.assertEqual(r.status,200)
        finally:finish.set()
        r=await asyncio.wait_for(pending,3);self.assertEqual(r.status,404,await r.text())
        self.assertFalse((self.app['store'].dir/ident).exists())

    async def test_saved_cannot_leak_after_membership_removed(self):
        r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.a),json={'id':'security_saved_001','envelopes':self.env()});self.assertEqual(r.status,201)
        r=await self.client.post('/api/saved',headers=self.h(self.b),json={'id':'security_saved_001'});self.assertEqual(len(await r.json()),1)
        self.app['store'].run('DELETE FROM members WHERE user=? AND room=?',(self.b['user']['id'],self.room))
        r=await self.client.get('/api/saved',headers=self.h(self.b));self.assertEqual(await r.json(),[])

    async def test_invalid_profile_types_do_not_overwrite_saved_values(self):
        for bad in [{'about':{}},{'theme':[]},{'language':False},{'name':{}},{'name':'  '}]:
            r=await self.client.patch('/api/me',headers=self.h(self.a),json=bad);self.assertEqual(r.status,400,await r.text())
        r=await self.client.get('/api/me',headers=self.h(self.a));self.assertEqual((await r.json())['user']['name'],'Alice')

    async def test_malformed_ws_auth_closes_without_accepting(self):
        for payload in [[],{'token':None},{'token':'short'}]:
            ws=await self.client.ws_connect('/api/socket');await ws.send_json(payload);await ws.receive(timeout=2);self.assertIn(ws.close_code,[4000,4001]);await ws.close()

if __name__=='__main__':unittest.main()
