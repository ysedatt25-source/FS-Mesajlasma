"""Real Chromium menu/layout and route-state rendering with a simulated native bridge."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
s=(root/'app.js').read_text()
functions=s[s.index('function updateCallControl('):s.index('function showCall()')]
events=s[s.index('window.addEventListener("fs-audio-devices"'):s.index('window.addEventListener("fs-audio-error"')]
choose=s[s.index('    case "speaker":\n      if(window.FSNative?.audioRoute)'):s.index('    case "verification":',s.index('    case "speaker":\n      if(window.FSNative?.audioRoute)'))]
icons=(root/'icons.js').read_text().replace('export ','')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page(viewport={'width':280,'height':580},is_mobile=True,has_touch=True)
 page.set_content('<meta name="viewport" content="width=device-width,initial-scale=1"><div id="app"><section class="call fs-premium fs-direct-call"><div class="controls"><div class="control"><button data-action="speaker"></button><span></span></div><div class="control"><button data-action="bluetooth"></button><span></span></div></div></section></div><dialog id="modal"></dialog>');page.add_style_tag(content=(root/'style.css').read_text())
 page.evaluate('''()=>{const state={page:'call',call:{}},modal=document.querySelector('#modal');let info={bluetooth:true,wired:true,earpiece:true,speaker:true,route:'earpiece',preference:'auto',pending:''},requests=[],redraws=0;window.FSNative={audioState:()=>JSON.stringify(info),audioRoute:r=>requests.push(r)};const notice=()=>{},dialog=(t,c)=>{modal.innerHTML=`<h2>${t}</h2>${c}`;modal.showModal()},showCall=()=>{redraws++};'''+icons+functions+events+'''function action(a,el){switch(a){'''+choose+'''}}document.addEventListener('click',e=>{const el=e.target.closest('[data-action]');if(el)action(el.dataset.action,el)});window.info=v=>{Object.assign(info,v);window.dispatchEvent(new CustomEvent('fs-audio-devices',{detail:info}));};window.requests=()=>requests;window.nextCall=()=>{state.call={}};window.openMenu=showAudioRouteMenu;window.redraws=()=>redraws;}''')
 page.evaluate('info({})');assert page.locator('[data-action="speaker"]').get_attribute('aria-label')=='Ahize'
 for w,h in [(280,580),(320,640),(390,844),(640,360)]:
  page.set_viewport_size({'width':w,'height':h});page.evaluate('openMenu()');assert page.locator('[data-action="choose-audio-route"]').count()==5
  assert page.evaluate('''()=>{const r=document.querySelector('#modal').getBoundingClientRect();return r.left>=0&&r.right<=innerWidth+1&&r.top>=0&&r.bottom<=innerHeight+1&&[...document.querySelectorAll('#modal button')].every(b=>{const x=b.getBoundingClientRect();return x.left>=r.left&&x.right<=r.right&&b.scrollWidth<=b.clientWidth+1})}'''),(w,h)
  page.locator('#modal').evaluate('e=>e.close()');print('PASS route menu at',w,h)
 page.evaluate('openMenu()');assert page.locator('[data-route="earpiece"] small').inner_text()=='Etkin';page.locator('[data-route="speaker"]').click();assert page.evaluate('requests()')==['speaker'];assert page.locator('[data-action="speaker"]').get_attribute('aria-pressed')=='false';print('PASS explicit choice does not optimistically mark speaker active')
 page.evaluate('info({route:"speaker",preference:"speaker"})');assert page.locator('[data-action="speaker"]').get_attribute('aria-pressed')=='true';print('PASS confirmed speaker updates accessible state')
 page.locator('[data-action="bluetooth"]').click();assert page.evaluate('requests()')[-1]=='bluetooth';page.evaluate('info({pending:"bluetooth"})');assert page.locator('[data-action="bluetooth"]').get_attribute('aria-busy')=='true';assert page.locator('[data-action="bluetooth"]').get_attribute('aria-pressed')=='false';page.evaluate('info({route:"bluetooth",pending:"",preference:"bluetooth"})');assert page.locator('[data-action="bluetooth"]').get_attribute('aria-pressed')=='true';page.locator('[data-action="bluetooth"]').click();assert page.evaluate('requests()')[-1]=='speaker';print('PASS pending, confirmed Bluetooth and restoration of previous speaker route')
 page.evaluate('info({bluetooth:false,route:"earpiece"})');assert page.evaluate('redraws()')==1;page.evaluate('openMenu()');assert page.locator('[data-route="bluetooth"]').count()==0;page.evaluate('nextCall()');page.locator('[data-route="speaker"]').click();assert page.evaluate('requests()')[-1]=='speaker';print('PASS unplug updates menu and stale-call action ignored')
 b.close()
