import unittest
from unittest.mock import patch
import test_server
import app

class RoomPerformanceTest(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=test_server.APITest.asyncSetUp
    asyncTearDown=test_server.APITest.asyncTearDown
    register=test_server.APITest.register
    h=test_server.APITest.h
    async def test_room_list_loads_admin_once_for_all_rooms(self):
        uid=self.c['user']['id']
        self.app['store'].run("INSERT INTO app_config VALUES('admin',?)",(uid,))
        for n in range(12):
            r=await self.client.post('/api/rooms',headers=self.h(self.a),json={'members':[self.b['user']['id'],uid],'title':f'Grup {n}'})
            self.assertEqual(r.status,201)
        with patch.object(app,'audit_user',wraps=app.audit_user) as spy:
            response=await self.client.get('/api/rooms',headers=self.h(self.a))
            self.assertEqual(response.status,200)
            rows=await response.json()
            self.assertEqual(len(rows),13)
            self.assertTrue(all(r['audit']['id']==uid for r in rows))
            self.assertEqual(spy.call_count,1)
