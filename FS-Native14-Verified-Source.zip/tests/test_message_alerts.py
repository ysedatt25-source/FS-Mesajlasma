import unittest, asyncio, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from test_server import APITest as Fixture
from app import now

class MessageAlertsTest(unittest.IsolatedAsyncioTestCase):
 asyncSetUp=Fixture.asyncSetUp
 asyncTearDown=Fixture.asyncTearDown
 h=Fixture.h
 register=Fixture.register
 env=Fixture.env
 async def send(self,mid,room=None,user=None,env=None):
  r=await self.client.post('/api/rooms/'+(room or self.room)+'/messages',headers=self.h(user or self.a),json={'id':mid,'envelopes':env or self.env()});self.assertEqual(r.status,201,await r.text());return await r.json()
 async def alerts(self,user=None):
  r=await self.client.get('/api/message-alerts',headers=self.h(user or self.b));self.assertEqual(r.status,200,await r.text());return (await r.json())['messages']
 async def settings(self,**kw):
  r=await self.client.patch('/api/me',headers=self.h(self.b),json=kw);self.assertEqual(r.status,200,await r.text())
 async def test_authenticated_metadata_only_and_independent_of_calls(self):
  await self.settings(available=False);await self.send('message_alert_001');rows=await self.alerts();self.assertEqual(len(rows),1);self.assertEqual(set(rows[0]),{'room','id','created'});self.assertEqual(rows[0]['id'],'message_alert_001');self.assertEqual(await self.alerts(self.a),[]);self.assertEqual(await self.alerts(self.c),[]);self.assertEqual((await self.client.get('/api/message-alerts')).status,401)
 async def test_room_mute_peer_mute_global_mute(self):
  await self.send('message_alert_002');await self.settings(mutedRooms=[self.room]);self.assertEqual(await self.alerts(),[]);await self.settings(mutedRooms=[],mutedPeers=[self.a['user']['id']]);self.assertEqual(await self.alerts(),[]);await self.settings(mutedPeers=[],messageAlerts=False);self.assertEqual(await self.alerts(),[]);await self.settings(messageAlerts=True);self.assertEqual(len(await self.alerts()),1)
 async def test_expired_deleted_blocked_and_read(self):
  await self.send('message_alert_003');s=self.app['store'];s.run('UPDATE messages SET created=? WHERE id=?',(now()-310000,'message_alert_003'));self.assertEqual(await self.alerts(),[]);await self.send('message_alert_004');r=await self.client.delete('/api/messages/message_alert_004',headers=self.h(self.a));self.assertEqual(r.status,200);self.assertEqual(await self.alerts(),[]);await self.send('message_alert_005');s.run('INSERT INTO blocks(owner,peer) VALUES(?,?)',(self.b['user']['id'],self.a['user']['id']));self.assertEqual(await self.alerts(),[]);s.run('DELETE FROM blocks');r=await self.client.post('/api/rooms/'+self.room+'/receipts',headers=self.h(self.b),json={'read':['message_alert_005']});self.assertEqual(r.status,200);self.assertEqual(await self.alerts(),[])
 async def test_poll_replay_and_latest(self):
  await self.send('message_alert_006');await asyncio.sleep(.01);await self.send('message_alert_007');r=await asyncio.wait_for(self.client.get('/api/events?ringing=1&messages=1',headers=self.h(self.b)),2);self.assertEqual(r.status,200);d=await r.json();self.assertEqual(d['messages'][0]['id'],'message_alert_007');self.assertEqual(len(d['messages']),1);self.assertEqual(await self.alerts(),d['messages'])
 async def test_notification_read_scope_and_idempotent(self):
  await self.send('message_alert_008');await asyncio.sleep(.01);await self.send('message_alert_009');await asyncio.sleep(.01);await self.send('message_alert_010');path='/api/rooms/'+self.room+'/notification-read';body={'message':'message_alert_009'}
  self.assertEqual((await self.client.post(path,json=body)).status,401);self.assertEqual((await self.client.post(path,headers=self.h(self.c),json=body)).status,403);self.assertEqual((await self.client.post(path,headers=self.h(self.a),json=body)).status,404)
  for _ in range(2):self.assertEqual((await self.client.post(path,headers=self.h(self.b),json=body)).status,200)
  self.assertEqual((await self.alerts())[0]['id'],'message_alert_010');s=self.app['store'];self.assertEqual(s.one('SELECT count(*) n FROM message_receipts WHERE user=? AND read_at IS NOT NULL',(self.b['user']['id'],))['n'],2)
  self.assertEqual((await self.client.post(path,headers=self.h(self.b),json={'message':'not_existing_message'})).status,404)
 async def test_group_mute_and_validation(self):
  from test_server import ENVELOPE
  r=await self.client.post('/api/rooms',headers=self.h(self.a),json={'members':[self.b['user']['id'],self.c['user']['id']],'title':'Group'});self.assertEqual(r.status,201);room=(await r.json())['id'];await self.send('message_alert_011',room,env={x['user']['id']:ENVELOPE for x in [self.a,self.b,self.c]});self.assertEqual((await self.alerts())[0]['room'],room);await self.settings(mutedRooms=[room]);self.assertEqual(await self.alerts(),[]);self.assertEqual(len(await self.alerts(self.c)),1)
  for body in ({'messageAlerts':'false'},{'mutedRooms':'x'},{'mutedRooms':['bad!']}):self.assertEqual((await self.client.patch('/api/me',headers=self.h(self.b),json=body)).status,400)

 async def test_detail_counts_privacy_and_legacy(self):
  await self.send('message_detail_001');await self.send('message_detail_002')
  async def detail(user=None):
   r=await self.client.get('/api/message-alerts?detail=1',headers=self.h(user or self.b));self.assertEqual(r.status,200);return (await r.json())['messages']
  rows=await detail();self.assertEqual(len(rows),1);self.assertEqual(rows[0]['count'],2);self.assertFalse(rows[0]['silent']);self.assertNotIn('label',rows[0]);self.assertEqual(await detail(self.c),[])
  self.assertEqual(set((await self.alerts())[0]),{'room','id','created'})
  await self.settings(notificationDetails=True);rows=await detail();self.assertEqual(rows[0]['label'],self.a['user']['name']);self.assertEqual(set(rows[0]),{'room','id','created','count','silent','label'})
  await self.settings(notificationDetails=False);self.assertNotIn('label',(await detail())[0])
  await self.settings(mutedRooms=[self.room]);self.assertEqual(await detail(),[])
  await self.settings(silentMessageAlerts=True);rows=await detail();self.assertTrue(rows[0]['silent']);self.assertEqual(rows[0]['count'],2);self.assertEqual(await self.alerts(),[])
  await self.settings(messageAlerts=False);self.assertEqual(await detail(),[])
  for k in ('notificationDetails','silentMessageAlerts'):
   self.assertEqual((await self.client.patch('/api/me',headers=self.h(self.b),json={k:'true'})).status,400)
 async def test_detail_excludes_hidden_and_read(self):
  await self.send('message_detail_003');await asyncio.sleep(.01);await self.send('message_detail_004')
  async def detail():
   r=await self.client.get('/api/message-alerts?detail=1',headers=self.h(self.b));return (await r.json())['messages']
  self.assertEqual((await detail())[0]['count'],2)
  s=self.app['store'];s.run('INSERT INTO hidden_messages(user,message) VALUES(?,?)',(self.b['user']['id'],'message_detail_003'))
  self.assertEqual((await detail())[0]['count'],1)
  r=await self.client.post('/api/rooms/'+self.room+'/notification-read',headers=self.h(self.b),json={'message':'message_detail_004'});self.assertEqual(r.status,200);self.assertEqual(await detail(),[])

 async def test_optional_avatar_snapshot_requires_explicit_opt_in(self):
  import re
  photo=re.search(r'"photo":"(data:image/jpeg;base64,[^"]+)"',(Path(__file__).resolve().parents[1]/'web/profile-avatars.js').read_text()).group(1)
  self.assertEqual((await self.client.patch('/api/me',headers=self.h(self.a),json={'avatar':photo})).status,200)
  await self.send('message_avatar_001');await self.settings(notificationDetails=True)
  async def snapshot(query,user=None):
   r=await self.client.get('/api/message-alerts'+query,headers=self.h(user or self.b));self.assertEqual(r.status,200);return (await r.json())['messages']
  self.assertNotIn('avatar',(await snapshot('?detail=1&avatars=1'))[0]);await self.settings(notificationAvatars=True)
  self.assertNotIn('avatar',(await snapshot('?detail=1'))[0]);self.assertNotIn('avatar',(await snapshot('?avatars=1'))[0])
  result=(await snapshot('?detail=1&avatars=1'))[0];self.assertEqual(result['avatar'],photo);self.assertEqual(set(result),{'id','room','created','count','silent','label','avatar'})
  self.assertEqual(await snapshot('?detail=1&avatars=1',self.c),[])
  await self.settings(notificationDetails=False);self.assertNotIn('avatar',(await snapshot('?detail=1&avatars=1'))[0])
  self.assertEqual((await self.client.patch('/api/me',headers=self.h(self.b),json={'notificationAvatars':'true'})).status,400)
 async def test_avatar_invalid_data_omitted(self):
  from app import notification_avatar
  import json
  for value in ('https://example.com/x.jpg','data:image/jpeg;base64,!!!','data:image/jpeg;base64,aGVsbG8=', 'data:image/jpeg;base64,'+'A'*150000,{},None):
   self.assertEqual(notification_avatar(json.dumps({'avatar':value})), '')
  self.assertEqual(notification_avatar('[]'),'')
