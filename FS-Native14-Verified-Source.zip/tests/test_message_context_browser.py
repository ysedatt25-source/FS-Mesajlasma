"""Production context-menu functions in Chromium with real dialog, CSS and touch.
Only app state/network actions are isolated; placement, lifecycle, and action guard are real.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import os
root=Path(__file__).resolve().parents[1]/'web'
src=(root/'app.js').read_text()
def part(a,b): return src[src.index(a):src.index(b,src.index(a))]
code='\n'.join([(root/'emoji-effects.js').read_text().replace('export ',''),(root/'view-once.js').read_text().replace('export ','')+'\n'+(root/'message-interactions.js').read_text().replace('import {isViewOnce} from "./view-once.js";','').replace('export ',''),(root/'icons.js').read_text().replace('export ',''),part('function dialog(', 'function field('),part('function showReactionDetails(', 'function bindSelection()')])
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
    page=browser.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
    errors=[];page.on('pageerror',lambda err:errors.append(str(err)))
    page.set_content('''<meta name="viewport" content="width=device-width,initial-scale=1"><div id="app"><section class="fs-chat fs-premium" style="height:100dvh"><main id="messages" style="position:absolute;inset:20px 0 20px;overflow:auto"><article tabindex="0" data-message="a" class="message" style="position:absolute;left:16px;top:75px;width:155px;height:44px">A</article><article tabindex="0" data-message="b" class="message mine" style="position:absolute;right:16px;bottom:55px;width:155px;height:44px">B</article><article tabindex="0" data-message="c" class="message" style="position:absolute;left:22px;top:40%;width:155px;height:44px">C</article></main></section></div><dialog id="modal"></dialog>''')
    page.add_style_tag(content=(root/'style.css').read_text()+'''\nbody{margin:0}#app{height:100dvh}.fs-chat{position:relative}.fs-chat #messages{padding:0}.fs-chat .message{margin:0}''')
    page.evaluate('()=>{'+code+'''
      const $=s=>document.querySelector(s),app=$('#app'),modal=$('#modal');let messageMenuSession=null;
      const escape=s=>String(s),quickReactions=['👍','❤️','🔥','🥰','👏','😁','😂'],button=(a,i,l,e)=>`<button data-action="${a}" ${e}>${l}</button>`;
      const state={page:'chat',room:{id:'r',members:[{id:'self'},{id:'peer'}]},routeVersion:1,user:{id:'self'},selected:new Set(),messages:[{id:'a',sender:'peer',payload:{type:'text'}},{id:'b',sender:'self',payload:{type:'text'},receipts_v2:[{user:'peer',delivered:1700000000000,read_at:1700000060000}]},{id:'c',sender:'peer',payload:{type:'file'}}]};
      const messageIndex={reactions:new Map([['a',new Map([['self','❤️']])]])};let locked=false;const isLocked=()=>locked,eligibleMessage=id=>state.messages.find(m=>m.id===id&&!m.pending),assertAccess=()=>{},closeOnceViewer=()=>{},closeAlbumViewer=()=>{},clearProfileViewer=()=>{},callRingtones={stop(){}};
      const actions=[];window.actions=actions;window.openMenu=id=>{const node=$(`[data-message="${id}"]`);node.focus();messageMenu(id,node.getBoundingClientRect())};window.closeMenu=()=>modal.close();window.removeRow=id=>{state.messages=state.messages.filter(m=>m.id!==id);$(`[data-message="${id}"]`).remove()};window.route=()=>{state.routeVersion++;};window.lock=()=>{locked=true;};window.unlock=()=>{locked=false;};window.session=()=>!!messageMenuSession;
      document.addEventListener('click',e=>{const el=e.target.closest('[data-action^="context-"]');if(el&&takeMessageMenu(el))actions.push([el.dataset.action,el.dataset.id,el.dataset.op||el.dataset.emoji||'']);});
      modal.addEventListener('close',()=>{if(!modal.open)clearMessageMenu()});modal.addEventListener('click',e=>{if(e.target===modal)modal.close()});
      window.otherDialog=()=>dialog('Başka pencere','<p id="other">Normal</p>');window.details=()=>showReactionDetails('a');
    }''')
    dlg=page.locator('#modal')
    def opened(id):
        page.evaluate('id=>openMenu(id)',id);page.wait_for_timeout(220);assert dlg.is_visible(),errors
    def close():
        page.evaluate('closeMenu()');page.wait_for_timeout(50);assert not dlg.is_visible();assert not page.evaluate('session()')
    def inbounds():
        rect=dlg.bounding_box();v=page.evaluate('({x:visualViewport.offsetLeft,y:visualViewport.offsetTop,w:visualViewport.width,h:visualViewport.height})');assert rect['x']>=v['x']-1 and rect['y']>=v['y']-1 and rect['x']+rect['width']<=v['x']+v['w']+1 and rect['y']+rect['height']<=v['y']+v['h']+1,(rect,v)
    page.evaluate('details()');assert dlg.locator('.fs-reaction-person').count()==1;assert 'Siz' in dlg.locator('.fs-reaction-person').inner_text();close();print('PASS actual reaction details show only known active reactions')
    opened('a');assert dlg.get_attribute('data-menu-side')=='below';assert dlg.bounding_box()['y']>=page.locator('[data-message="a"]').bounding_box()['y']+page.locator('[data-message="a"]').bounding_box()['height'];inbounds();print('PASS top message menu opens below without covering message')
    assert page.locator('[data-message="a"].context-target').count()==1
    assert dlg.locator('.tg-context-reactions').evaluate('el=>el.scrollWidth<=el.clientWidth+1')
    print('PASS focused contextual message and visible quick reactions')
    assert dlg.locator('[data-emoji="❤️"]').get_attribute('aria-pressed')=='true';assert dlg.locator('[data-action=context-reaction-details]').count()==1;assert dlg.locator('[data-op="Düzenle"]').count()==0;assert dlg.locator('[data-op="Bilgi"]').count()==0;print('PASS active reaction and peer action eligibility')
    dlg.locator('[data-op="Yanıtla"]').tap();page.wait_for_timeout(80);assert page.evaluate('actions')==[['context-op','a','Yanıtla']];assert not dlg.is_visible();assert page.locator('.context-target').count()==0;print('PASS tap dispatches selected message action exactly once and clears highlight')
    opened('b');assert dlg.get_attribute('data-menu-side')=='above';assert dlg.bounding_box()['y']+dlg.bounding_box()['height']<=page.locator('[data-message="b"]').bounding_box()['y']+1;inbounds();assert dlg.locator('[data-op="Düzenle"]').count()==1;assert dlg.locator('[data-op="Bilgi"]').inner_text()=='Mesaj bilgileri';print('PASS bottom own message menu flips above and explicit info remains')
    assert dlg.locator('.fs-context-receipt.is-read').count()==1 and 'Okundu' in dlg.locator('.fs-context-receipt').inner_text();print('PASS context shows confirmed read receipt and time only for own message')
    page.keyboard.press('Escape');page.wait_for_timeout(100);assert not dlg.is_visible() and not page.evaluate('session()');print('PASS Escape closes and clears contextual session')
    opened('c');assert not dlg.locator('[data-op="Alıntıla"]').count();close();print('PASS file menu hides text-only actions')
    page.set_viewport_size({'width':300,'height':370});opened('c');inbounds();actions=dlg.locator('.tg-context-actions');assert actions.evaluate('el=>el.scrollHeight>el.clientHeight');top=dlg.locator('.tg-context-reactions').bounding_box()['y'];actions.evaluate('el=>el.scrollTop=el.scrollHeight');assert abs(dlg.locator('.tg-context-reactions').bounding_box()['y']-top)<1;assert dlg.locator('[data-op="Sil"]').is_visible();print('PASS compact screen scrolls actions independently of reactions')
    page.set_viewport_size({'width':270,'height':310});page.wait_for_timeout(180);inbounds();print('PASS visible menu repositions on keyboard-like viewport resize')
    page.evaluate('route()');dlg.locator('[data-op="Sil"]').click();page.wait_for_timeout(100);assert len(page.evaluate('actions'))==1 and not dlg.is_visible();print('PASS stale route action is rejected')
    opened('a');page.evaluate('removeRow("a")');page.wait_for_timeout(150);assert not dlg.is_visible();print('PASS deleted/removed message closes menu automatically')
    opened('b');page.evaluate('lock()');dlg.locator('[data-op="Yanıtla"]').click();page.wait_for_timeout(80);assert len(page.evaluate('actions'))==1;assert not dlg.is_visible();page.evaluate('unlock()');print('PASS locked session cannot dispatch contextual action')
    opened('c');close();page.evaluate('otherDialog()');assert dlg.is_visible() and not dlg.get_attribute('data-menu-side') and not dlg.evaluate('el=>el.classList.contains("message-context")');assert dlg.locator('#other').is_visible();print('PASS unrelated dialog has no stale menu positioning')
    assert not errors,errors
    browser.close()
