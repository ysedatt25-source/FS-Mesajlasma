import unittest
import test_server as base
from app import create_app, expire_messages, dispatch_scheduled, message_alerts, now
from aiohttp.test_utils import TestClient, TestServer
from pathlib import Path

class DeleteTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=base.APITest.asyncSetUp
    asyncTearDown=base.APITest.asyncTearDown
    h=base.APITest.h
    register=base.APITest.register
    env=base.APITest.env
    @property
    def store(self):return self.app['store']
    @property
    def path(self):return '/api/rooms/'+self.room
    async def post(self,mid,**extra):
        r=await self.client.post(self.path+'/messages',headers=self.h(self.a),json={'id':mid,'envelopes':self.env(),**extra});self.assertEqual(r.status,201,await r.text());return await r.json()
    async def hide(self,ids,user=None):return await self.client.post(self.path+'/messages/hide',headers=self.h(user or self.b),json={'ids':ids})
    async def policy(self,seconds,user=None):return await self.client.post(self.path+'/auto-delete',headers=self.h(user or self.a),json={'seconds':seconds})
    async def ids(self,user):return [m['id'] for m in await (await self.client.get(self.path+'/messages',headers=self.h(user))).json()]
    async def test_batch_mixed_call_and_messages_account_scope(self):
        mid='mixed_message_123';cid='mixed_call_12345';await self.post(mid)
        self.store.run('INSERT INTO calls(id,room,caller,callee,video,started,status) VALUES(?,?,?,?,?,?,?)',(cid,self.room,self.a['user']['id'],self.b['user']['id'],0,now(),'ended'))
        path=self.path+'/messages/batch-delete';request={'ids':[mid],'call_ids':[cid],'scope':'self'}
        r=await self.client.post(path,headers=self.h(self.c),json=request);self.assertEqual(r.status,403)
        r=await self.client.post(path,headers=self.h(self.b),json={**request,'scope':'everyone'});self.assertEqual(r.status,400)
        r=await self.client.post(path,headers=self.h(self.b),json={**request,'call_ids':[cid,'not_in_room_123']});self.assertEqual(r.status,404);self.assertEqual(await self.ids(self.b),[mid]);self.assertFalse(self.store.one('SELECT 1 FROM hidden_calls'))
        for _ in range(2):
            r=await self.client.post(path,headers=self.h(self.b),json=request);self.assertEqual(r.status,200,await r.text());self.assertEqual((await r.json())['call_ids'],[cid])
        self.assertEqual(await self.ids(self.b),[]);self.assertEqual(await self.ids(self.a),[mid])
        for endpoint in ['/api/calls',self.path+'/calls']:
            self.assertEqual(await(await self.client.get(endpoint,headers=self.h(self.b))).json(),[])
            self.assertEqual([c['id'] for c in await(await self.client.get(endpoint,headers=self.h(self.a))).json()],[cid])
        await self.client.close();self.app=create_app(self.tmp.name);self.client=TestClient(TestServer(self.app));await self.client.start_server()
        self.assertEqual(await(await self.client.get('/api/calls',headers=self.h(self.b))).json(),[])
        self.assertEqual([c['id'] for c in await(await self.client.get('/api/calls',headers=self.h(self.a))).json()],[cid])
    async def test_hide_account_scope_restart_and_cache(self):
        m='private_delete_123';await self.post(m)
        self.assertEqual((await self.client.post('/api/saved',headers=self.h(self.b),json={'id':m})).status,200)
        self.assertEqual((await self.hide([m],self.c)).status,403)
        self.assertEqual((await self.hide([m])).status,200)
        self.assertEqual((await self.hide([m])).status,200)
        self.assertEqual(await self.ids(self.b),[]);self.assertEqual(await self.ids(self.a),[m]);self.assertTrue(self.store.one('SELECT * FROM messages WHERE id=?',(m,)))
        self.assertEqual(await(await self.client.get('/api/saved',headers=self.h(self.b))).json(),[])
        self.assertEqual(await(await self.client.post(self.path+'/messages/check',headers=self.h(self.b),json={'ids':[m]})).json(),{'existing':[]})
        self.assertEqual((await self.client.get('/api/messages/'+m+'/history',headers=self.h(self.b))).status,404)
        self.assertEqual(message_alerts(self.store,self.b['user']['id']),[])
        rooms=await(await self.client.get('/api/rooms',headers=self.h(self.b))).json();self.assertIsNone(rooms[0]['last'])
        await self.client.close();self.app=create_app(self.tmp.name);self.client=TestClient(TestServer(self.app));await self.client.start_server()
        self.assertEqual(await self.ids(self.b),[]);self.assertEqual(await self.ids(self.a),[m])
    async def test_hide_media_personal_only(self):
        r=await self.client.post('/api/uploads',headers=self.h(self.a),json={'room':self.room,'size':3});ident=(await r.json())['id']
        await self.client.put('/api/uploads/'+ident,headers={**self.h(self.a),'Upload-Offset':'0'},data=b'abc')
        m='media_delete_123';await self.post(m,uploads=[ident]);self.assertEqual((await self.hide([m])).status,200)
        for path in ['/api/uploads/'+ident,'/api/messages/'+m+'/download/'+ident]:
            self.assertEqual((await self.client.get(path,headers=self.h(self.b))).status,404);self.assertEqual((await self.client.get(path,headers=self.h(self.a))).status,200)
        self.assertEqual(await(await self.client.get('/api/media',headers=self.h(self.b))).json(),[]);self.assertTrue((Path(self.tmp.name)/ident).exists())
    async def test_everyone_delete_cascade_no_resurrection(self):
        m='everyone_delete_123';await self.post(m)
        self.assertEqual((await self.client.delete('/api/messages/'+m,headers=self.h(self.c))).status,403)
        self.assertEqual((await self.client.delete('/api/messages/'+m,headers=self.h(self.b))).status,200)
        self.assertEqual(await self.ids(self.a),[]);self.assertEqual(await self.ids(self.b),[])
        self.assertEqual((await self.client.post(self.path+'/messages',headers=self.h(self.a),json={'id':m,'envelopes':self.env()})).status,409)
    async def test_expiry_future_only_and_restart(self):
        old='old_message_123';timed='timed_message_123';new='new_message_123';await self.post(old)
        self.assertEqual((await self.policy(3600,self.c)).status,403)
        self.assertEqual((await self.policy(1)).status,400)
        self.assertEqual((await self.policy(3600,self.b)).status,200)
        rows=await(await self.client.get('/api/rooms',headers=self.h(self.a))).json();self.assertEqual(rows[0]['auto_delete_seconds'],3600)
        msg=await self.post(timed);self.assertEqual(msg['delete_at']-msg['created'],3600000)
        self.assertEqual((await self.policy(0)).status,200);self.assertNotIn('delete_at',await self.post(new))
        self.store.run('UPDATE message_expiry SET due=? WHERE message=?',(now()-1,timed))
        await self.client.close();self.app=create_app(self.tmp.name);self.client=TestClient(TestServer(self.app));await self.client.start_server()
        self.assertEqual(set(await self.ids(self.a)),{old,new});self.assertEqual(set(await self.ids(self.b)),{old,new})
        self.assertFalse(self.store.one('SELECT * FROM message_expiry'));self.assertTrue(self.store.one('SELECT * FROM deleted_message_ids WHERE id=?',(timed,)))
    async def test_scheduled_expiry_from_actual_send(self):
        self.assertEqual((await self.policy(86400)).status,200);mid='schedule_expiry_123';r=await self.client.post(self.path+'/scheduled',headers=self.h(self.a),json={'id':mid,'envelopes':self.env(),'recipient_pubs':{self.a['user']['id']:base.PUB,self.b['user']['id']:base.PUB},'due':now()+60000});self.assertEqual(r.status,201)
        self.store.run('UPDATE scheduled_messages SET due=?',(now()-1,));await dispatch_scheduled(self.store)
        row=self.store.one('SELECT m.created,x.due FROM messages m JOIN message_expiry x ON x.message=m.id WHERE m.id=?',(mid,));self.assertEqual(row['due']-row['created'],86400000)
    async def test_group_cannot_change_policy_or_delete_peer(self):
        r=await self.client.post('/api/rooms',headers=self.h(self.a),json={'members':[self.b['user']['id'],self.c['user']['id']]});self.room=(await r.json())['id']
        self.assertEqual((await self.policy(3600)).status,403)
        m='group_delete_123';await self.post(m,envelopes={**self.env(),self.c['user']['id']:base.ENVELOPE})
        self.assertEqual((await self.client.delete('/api/messages/'+m,headers=self.h(self.b))).status,403)
        self.assertEqual((await self.hide([m])).status,200);self.assertEqual(await self.ids(self.a),[m])
    async def test_file_cleanup_retry_and_shared_reference(self):
        from unittest.mock import patch
        r=await self.client.post('/api/uploads',headers=self.h(self.a),json={'room':self.room,'size':3});ident=(await r.json())['id']
        await self.client.put('/api/uploads/'+ident,headers={**self.h(self.a),'Upload-Offset':'0'},data=b'abc')
        a='shared_file_a_123';b='shared_file_b_123';await self.post(a,uploads=[ident]);await self.post(b,uploads=[ident])
        self.assertEqual((await self.client.delete('/api/messages/'+a,headers=self.h(self.a))).status,200);self.assertTrue((Path(self.tmp.name)/ident).exists())
        original=Path.unlink
        def fail_only_target(path,*args,**kwargs):
            if path.name==ident:raise OSError('simulated unavailable disk')
            return original(path,*args,**kwargs)
        with patch.object(Path,'unlink',fail_only_target):
            self.assertEqual((await self.client.delete('/api/messages/'+b,headers=self.h(self.a))).status,200)
            self.assertTrue(self.store.one('SELECT * FROM deleted_upload_queue WHERE upload=?',(ident,)))
            self.assertEqual((await self.client.get('/api/uploads/'+ident,headers=self.h(self.a))).status,404)
        await expire_messages(self.store)
        self.assertFalse((Path(self.tmp.name)/ident).exists());self.assertFalse(self.store.one('SELECT * FROM deleted_upload_queue'))

    async def batch(self,ids,scope='everyone',user=None):
        return await self.client.post(self.path+'/messages/batch-delete',headers=self.h(user or self.b),json={'ids':ids,'scope':scope})
    async def test_batch_everyone_atomic_retry_and_events(self):
        from unittest.mock import AsyncMock,patch
        ids=['batch_msg_123','batch_msg_456'];[await self.post(mid) for mid in ids]
        self.assertEqual((await self.batch(ids,'everyone',self.c)).status,403)
        self.assertEqual((await self.batch(ids+['missing_msg_123'])).status,404)
        self.assertEqual(set(await self.ids(self.a)),set(ids))
        with patch.object(self.store,'broadcast',new_callable=AsyncMock) as broadcast:
            r=await self.batch(ids);self.assertEqual(r.status,200);self.assertEqual((await r.json())['ids'],ids)
            broadcast.assert_awaited_once();self.assertEqual(broadcast.call_args.args[1]['ids'],ids)
        self.assertEqual(await self.ids(self.a),[]);self.assertEqual(await self.ids(self.b),[])
        self.assertEqual((await self.batch(ids)).status,200)
    async def test_batch_self_only_and_foreign_room_rollback(self):
        ids=['batch_self_123','batch_self_456'];[await self.post(mid) for mid in ids]
        self.assertEqual((await self.batch(ids+['unknown_msg_123'],'self')).status,404)
        self.assertEqual(set(await self.ids(self.b)),set(ids))
        self.assertEqual((await self.batch(ids,'self')).status,200)
        self.assertEqual(await self.ids(self.b),[]);self.assertEqual(set(await self.ids(self.a)),set(ids))
        self.assertEqual((await self.batch(ids,'self')).status,200)
    async def test_batch_group_mixed_ownership_rolls_back(self):
        r=await self.client.post('/api/rooms',headers=self.h(self.a),json={'members':[self.b['user']['id'],self.c['user']['id']]});self.room=(await r.json())['id']
        env={**self.env(),self.c['user']['id']:base.ENVELOPE};a='batch_group_a_123';b='batch_group_b_123'
        await self.post(a,envelopes=env)
        r=await self.client.post(self.path+'/messages',headers=self.h(self.b),json={'id':b,'envelopes':env});self.assertEqual(r.status,201)
        self.assertEqual((await self.batch([b,a])).status,403);self.assertEqual(set(await self.ids(self.a)),{a,b})
        self.assertEqual((await self.batch([b])).status,200);self.assertEqual(await self.ids(self.a),[a])

    async def test_batch_websocket_modern_and_legacy(self):
        ids=['batch_socket_123','batch_socket_456'];[await self.post(mid) for mid in ids]
        modern=await self.client.ws_connect('/api/socket');legacy=await self.client.ws_connect('/api/socket')
        try:
            await modern.send_json({'token':self.a['token'],'batchDelete':True});await modern.receive_json(timeout=2)
            await legacy.send_json({'token':self.b['token']});await legacy.receive_json(timeout=2)
            self.assertEqual((await self.batch(ids)).status,200)
            event=await modern.receive_json(timeout=2);self.assertEqual(event['ids'],ids);self.assertTrue(event['deleted'])
            events=[await legacy.receive_json(timeout=2),await legacy.receive_json(timeout=2)]
            self.assertEqual([e['id'] for e in events],ids);self.assertTrue(all(e['deleted'] for e in events))
        finally:await modern.close();await legacy.close()
