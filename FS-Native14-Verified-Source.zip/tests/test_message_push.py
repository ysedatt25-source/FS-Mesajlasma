import asyncio, unittest
import test_message_alerts
from push_calls import payload

class MessagePushTests(unittest.IsolatedAsyncioTestCase):
 asyncSetUp=test_message_alerts.MessageAlertsTest.asyncSetUp
 asyncTearDown=test_message_alerts.MessageAlertsTest.asyncTearDown
 h=test_message_alerts.MessageAlertsTest.h
 register=test_message_alerts.MessageAlertsTest.register
 env=test_message_alerts.MessageAlertsTest.env
 send=test_message_alerts.MessageAlertsTest.send
 settings=test_message_alerts.MessageAlertsTest.settings
 async def prepare(self,transport=None):
  s=self.app['store'];sent=[]
  s.push.transport=transport or (lambda t,d,ttl:sent.append((t,d,ttl)) or True)
  token='FCM_message_registration_0123456789';binding='message_binding_0123456789abcd'
  self.assertEqual((await self.client.post('/api/push/registration',headers=self.h(self.b),json={'registration':token,'binding':binding})).status,200)
  return s,sent,token,binding
 async def drain(self,s):
  while not s.push.queue.empty():
   item=s.push.queue.get_nowait()
   if isinstance(item,tuple):await s.push.deliver(*item)
   else:await s.push.deliver(item)
   s.push.queue.task_done()
 async def test_payload_auth_and_independence(self):
  s,sent,token,binding=await self.prepare();await self.settings(available=False)
  await self.send('push_message_001');await self.drain(s)
  self.assertEqual(len(sent),1);self.assertEqual(sent[0][:2],(token,{'kind':'message-wakeup-v1','binding':binding}));self.assertTrue(0<sent[0][2]<=300000)
  path='/api/push/messages'
  self.assertEqual((await self.client.get(path)).status,401)
  self.assertEqual((await self.client.get(path,headers=self.h(self.b))).status,403)
  self.assertEqual((await self.client.get(path,headers={**self.h(self.c),'X-FS-Push-Binding':binding})).status,403)
  response=await self.client.get(path,headers={**self.h(self.b),'X-FS-Push-Binding':binding});self.assertEqual(response.status,200)
  msg=(await response.json())['messages'][0];self.assertEqual(set(msg),{'room','id','created'});self.assertEqual(msg['id'],'push_message_001')
 async def test_mute_before_send_and_after_queue(self):
  s,sent,_,_=await self.prepare();await self.settings(mutedRooms=[self.room]);await self.send('push_message_002');self.assertTrue(s.push.queue.empty())
  await self.settings(mutedRooms=[]);await self.send('push_message_003');self.assertFalse(s.push.queue.empty());await self.settings(mutedPeers=[self.a['user']['id']]);await self.drain(s);self.assertEqual(sent,[])
  await self.settings(mutedPeers=[],messageAlerts=False);await self.send('push_message_004');self.assertTrue(s.push.queue.empty())
 async def test_read_and_logout_before_delivery(self):
  s,sent,_,binding=await self.prepare();await self.send('push_message_005')
  response=await self.client.post('/api/rooms/'+self.room+'/notification-read',headers=self.h(self.b),json={'message':'push_message_005'});self.assertEqual(response.status,200);await self.drain(s);self.assertEqual(sent,[])
  await self.send('push_message_006');await self.client.post('/api/logout',headers=self.h(self.b));await self.drain(s);self.assertEqual(sent,[])
  self.assertEqual((await self.client.get('/api/push/messages',headers={**self.h(self.b),'X-FS-Push-Binding':binding})).status,401)
 async def test_invalid_provider_token_removed(self):
  s,_,_,_=await self.prepare(lambda *args:False);await self.send('push_message_007');await self.drain(s)
  self.assertEqual(s.one('SELECT count(*) n FROM push_registrations')['n'],0)
 async def test_provider_failure_does_not_break_api(self):
  def fail(*args):raise RuntimeError('synthetic provider failure')
  s,_,_,_=await self.prepare(fail);await self.send('push_message_008');await self.drain(s)
  self.assertEqual(s.one('SELECT count(*) n FROM push_registrations')['n'],1);self.assertEqual((await self.client.get('/health')).status,200)
 async def test_latest_per_room_and_no_duplicate_send(self):
  s,sent,_,_=await self.prepare();await self.send('push_message_009');await asyncio.sleep(.01);await self.send('push_message_010');await self.drain(s);self.assertEqual(len(sent),1)
  res=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.a),json={'id':'push_message_010','envelopes':self.env()});self.assertEqual(res.status,200);self.assertTrue(s.push.queue.empty())
 async def test_deleted_and_expired(self):
  from app import now
  s,sent,_,_=await self.prepare();await self.send('push_message_011');await self.client.delete('/api/messages/push_message_011',headers=self.h(self.a));await self.drain(s);self.assertEqual(sent,[])
  await self.send('push_message_012');s.run('UPDATE messages SET created=? WHERE id=?',(now()-310000,'push_message_012'));await self.drain(s);self.assertEqual(sent,[])
 def test_bad_kind(self):
  with self.assertRaises(ValueError):payload('valid_binding_123456789012','unknown')

 async def test_opt_in_silent_snapshot_and_content_free_wakeup(self):
  s,sent,token,binding=await self.prepare();await self.settings(mutedRooms=[self.room],silentMessageAlerts=True,notificationDetails=True)
  await self.send('push_silent_001');await self.send('push_silent_002');await self.drain(s)
  self.assertEqual(len(sent),1);self.assertEqual(sent[0][1],{'kind':'message-wakeup-v1','binding':binding})
  path='/api/push/messages?detail=1';headers={**self.h(self.b),'X-FS-Push-Binding':binding}
  response=await self.client.get(path,headers=headers);self.assertEqual(response.status,200);msg=(await response.json())['messages'][0];self.assertTrue(msg['silent']);self.assertEqual(msg['count'],2);self.assertEqual(msg['label'],self.a['user']['name'])
  self.assertEqual((await self.client.get(path,headers={**self.h(self.c),'X-FS-Push-Binding':binding})).status,403)
  response=await self.client.get('/api/push/messages',headers=headers);self.assertEqual((await response.json())['messages'],[])
 async def test_bound_push_avatar_optional_and_wakeup_content_free(self):
  from pathlib import Path
  import re
  photo=re.search(r'"photo":"(data:image/jpeg;base64,[^"]+)"',(Path(__file__).resolve().parents[1]/'web/profile-avatars.js').read_text()).group(1)
  self.assertEqual((await self.client.patch('/api/me',headers=self.h(self.a),json={'avatar':photo})).status,200)
  s,sent,token,binding=await self.prepare();await self.settings(notificationDetails=True,notificationAvatars=True);await self.send('push_avatar_001');await self.drain(s)
  self.assertEqual(sent[0][1],{'kind':'message-wakeup-v1','binding':binding})
  path='/api/push/messages?detail=1&avatars=1'
  self.assertEqual((await self.client.get(path,headers=self.h(self.b))).status,403)
  response=await self.client.get(path,headers={**self.h(self.b),'X-FS-Push-Binding':binding});self.assertEqual(response.status,200)
  self.assertEqual((await response.json())['messages'][0]['avatar'],photo)
  response=await self.client.get('/api/push/messages?detail=1',headers={**self.h(self.b),'X-FS-Push-Binding':binding});self.assertNotIn('avatar',(await response.json())['messages'][0])
if __name__=='__main__':unittest.main()
