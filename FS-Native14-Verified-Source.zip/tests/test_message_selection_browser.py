"""Exercise production gesture handlers and selection popup in real Chromium.
The fixture substitutes only network/message rendering, not the gesture code.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import os
root=Path(__file__).resolve().parents[1]/'web'
src=(root/'app.js').read_text()
def part(a,b): return src[src.index(a):src.index(b,src.index(a))]
code=(root/'view-once.js').read_text().replace('export ','')+'\n'+(root/'icons.js').read_text().replace('export ','')+'\n'+(root/'message-interactions.js').read_text().replace('import {isViewOnce} from "./view-once.js";', '').replace('export ','')+'\n'+(root/'virtual-list.js').read_text().replace('export ','')+'\n'+part('function bindSelection()', 'async function showMessageDetails')
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
    page=browser.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
    page.set_content('<meta name="viewport" content="width=device-width, initial-scale=1"><div id="app"><section class="fs-chat" style="position:relative;height:740px;display:flex;flex-direction:column"><header style="height:80px;flex:none">Sohbet</header><div id="selection"></div><main id="messages" class="messages" style="overflow:auto;flex:1;min-height:0;touch-action:pan-y"></main><footer style="height:45px;flex:none">Yaz</footer></section></div>')
    page.add_style_tag(content=(root/'style.css').read_text()+'''\nbody{margin:0}#app{height:740px}.fs-chat #messages{padding-top:0;padding-bottom:0}.tg-message-line{height:72px;justify-content:center}.fs-chat .message{width:180px;max-width:100%;min-height:48px;margin:0}.fs-chat .tg-message-line>.selection-dot{left:-30px}.fs-chat #selection{z-index:15}''')
    page.evaluate('()=>{'+code+'''
      const $=s=>document.querySelector(s),escape=x=>String(x),quickReactions=['👍','❤️','🔥','🥰','👏','😁','😂'];
      const state={page:'chat',routeVersion:1,room:{id:'test'},user:{id:'self'},selected:new Set(),messages:Array.from({length:18},(_,i)=>({id:'m'+i,sender:i%2?'peer':'self',payload:{type:'text',text:'Message '+i},created:i}))};
      const eligibleMessage=id=>state.messages.find(m=>m.id===id&&!m.pending&&!m.callRecord),isLocked=()=>false;
      let events=[];const notice=()=>{},emojiEffect=()=>events.push('emoji'),beginReply=id=>events.push('reply:'+id),reactToMessage=async(id,e)=>events.push('react:'+id+':'+e),messageMenu=id=>events.push('menu:'+id);
      let virtualMessages=null;
      const markup=m=>`<div class="tg-message-line">${state.selected.size&&eligibleMessage(m.id)?`<button class="selection-dot ${state.selected.has(m.id)?'checked':''}" data-action="toggle-selection" data-id="${m.id}">✓</button>`:''}<article class="message ${state.selected.has(m.id)?'selected':''}" data-message="${m.id}"><span>${m.payload.text}</span><time>12:00 ✓</time></article></div>`;
      function renderMessages(){const list=$('#messages');const top=list.scrollTop;list.classList.toggle('selection-active',state.selected.size>0);if(virtualMessages){const anchor=virtualMessages.anchor();virtualMessages.set(state.messages.map(m=>({id:m.id,html:()=>markup(m)})),{anchor});}else{list.innerHTML=state.messages.map(markup).join('');list.scrollTop=top;}selectionBar();}
      window.ids=()=>[...state.selected].sort((a,b)=>Number(a.slice(1))-Number(b.slice(1)));window.events=events;window.clearSelection=()=>{state.selected.clear();renderMessages()};window.choose=ids=>{state.selected=new Set(ids);renderMessages()};
      window.virtualFixture=()=>{state.selected.clear();state.messages=Array.from({length:140},(_,i)=>({id:'m'+i,sender:'peer',payload:{type:'text',text:'Message '+i},created:i,...(i===8?{pending:true}:i===9?{callRecord:true}:{})}));const list=$('#messages');list.scrollTop=0;virtualMessages=new VirtualMessages(list,(t,html)=>{t.innerHTML=html});renderMessages();};
      window.changeRoute=()=>{state.routeVersion++;state.selected.clear();renderMessages();};
      renderMessages();bindSelection();
      document.addEventListener('click',e=>{const b=e.target.closest('[data-action="selection-menu"]');if(b){const box=$('#selection');box.dataset.collapsed=box.dataset.collapsed==='1'?'0':'1';selectionBar();}});
    }''')
    def pos(i,selector=''):
        rect=page.locator(f'[data-message="m{i}"]'+selector).bounding_box()
        return rect['x']+rect['width']/2,rect['y']+rect['height']/2
    initial=page.locator('#messages').bounding_box()['height']
    # Timestamp uses the same reaction/context route, never message details.
    page.locator('[data-message="m1"] time').click();page.wait_for_timeout(320)
    assert page.evaluate('events')==['menu:m1'];print('PASS timestamp opens ordinary reaction menu only')
    # Long hold chooses one and shows nonmodal popup without moving chat.
    x,y=pos(2);page.mouse.move(x,y);page.mouse.down();page.wait_for_timeout(480);page.mouse.up();page.wait_for_timeout(40)
    assert page.evaluate('ids()')==['m2'];assert page.locator('.fs-select-top').is_visible();assert not page.locator('#selection-menu-actions').is_visible();assert page.locator('#messages').bounding_box()['height']==initial;print('PASS long press selects; menu does not resize viewport')
    # Collapse dropdown to leave the whole message list accessible.
    page.locator('[data-action="selection-menu"]').click();assert page.locator('#selection-menu-actions').is_visible();page.locator('[data-action="selection-menu"]').click();assert not page.locator('#selection-menu-actions').is_visible();print('PASS extra actions open and close without losing selection')
    page.locator('[data-message="m2"]').evaluate('(el)=>{el.tabIndex=0;el.focus()}');page.keyboard.press('Escape');assert page.evaluate('ids()')==[];print('PASS Escape closes selection without dispatch')
    page.evaluate('choose(["m2"])')
    # The drag range is recomputed from baseline; reversing restores prior values.
    x,y=pos(3);page.mouse.move(x,y);page.mouse.down();page.mouse.move(*pos(6),steps=12)
    assert page.evaluate('ids()')==['m2','m3','m4','m5','m6'],page.evaluate('ids()')
    page.mouse.move(*pos(4),steps=10);assert page.evaluate('ids()')==['m2','m3','m4'];page.mouse.up();assert page.evaluate('ids()')==['m2','m3','m4'];print('PASS drag adds contiguous rows and reverse restores rows')
    # Begin on a checked row to remove, then reverse to restore original selection.
    x,y=pos(4);page.mouse.move(x,y);page.mouse.down();page.mouse.move(*pos(2),steps=10);assert page.evaluate('ids()')==[],page.evaluate('ids()');page.mouse.move(*pos(3),steps=8);page.mouse.up();assert page.evaluate('ids()')==['m2'],page.evaluate('ids()');print('PASS drag removes checked range, reversal restores baseline')
    # Dots must work with ordinary tap and not fire duplicate click dispatch.
    page.locator('[data-action="toggle-selection"][data-id="m5"]').click();assert page.evaluate('ids()')==['m2','m5'];page.locator('[data-action="toggle-selection"][data-id="m5"]').click();assert page.evaluate('ids()')==['m2'];print('PASS selection circles toggle exactly once')
    page.evaluate('clearSelection()');page.wait_for_timeout(550)
    # Actual touch input (CDP), not just synthetic PointerEvents.
    cdp=page.context.new_cdp_session(page)
    x,y=pos(2)
    cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':x,'y':y}]});page.wait_for_timeout(490)
    assert page.evaluate('ids()')==['m2'];
    for i in [3,4,5,4,3]:
        a,b=pos(i);cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':a,'y':b}]});page.wait_for_timeout(55)
    cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]});page.wait_for_timeout(50)
    assert page.evaluate('ids()')==['m2','m3'],page.evaluate('ids()');print('PASS actual touch long-hold and reverse drag')
    # Swipe to reply: actual mobile touch, not programmatic pointer events.
    page.evaluate('clearSelection(); events.length=0; document.querySelector("#messages").scrollTop=0');page.wait_for_timeout(550)
    def swipe(i, offsets, cancel=False, start_selector=None):
        x,y=pos(i) if start_selector is None else start_selector
        cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':x,'y':y}]})
        for dx,dy in offsets:
            cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x+dx,'y':y+dy}]});page.wait_for_timeout(32)
        cdp.send('Input.dispatchTouchEvent',{'type':'touchCancel' if cancel else 'touchEnd','touchPoints':[]});page.wait_for_timeout(320)
    swipe(1,[(-15,0),(-34,1),(-65,3),(-75,3)])
    assert page.evaluate('events')==['reply:m1'],page.evaluate('events');print('PASS left swipe on peer message triggers one reply only')
    page.evaluate('events.length=0');swipe(2,[(-15,0),(-35,0),(-72,1)])
    assert page.evaluate('events')==['reply:m2'],page.evaluate('events');print('PASS left swipe on own message')
    page.evaluate('events.length=0');swipe(1,[(-14,0),(-28,0),(-35,0)])
    assert not page.evaluate('events'),page.evaluate('events');print('PASS short swipe does not open reply or menu')
    swipe(1,[(-14,0),(-69,1),(-25,0)])
    assert not page.evaluate('events'),page.evaluate('events');print('PASS reversal below threshold cancels reply')
    swipe(1,[(-15,0),(-70,0)],cancel=True)
    assert not page.evaluate('events');assert page.locator('.swiping').count()==0;print('PASS cancelled touch clears visual state')
    swipe(1,[(0,18),(-10,35),(-70,100)])
    assert not page.evaluate('events'),page.evaluate('events');print('PASS vertical and diagonal gestures do not reply')
    page.evaluate('document.querySelector("#messages").scrollTop=0');page.wait_for_timeout(550)
    page.evaluate('''()=>{const b=document.createElement('button');b.textContent='Medya';b.id='test-media';document.querySelector('[data-message="m2"]').prepend(b);b.onclick=()=>events.push('media');}''')
    box=page.locator('#test-media').bounding_box();swipe(2,[(-15,0),(-70,0)],start_selector=(box['x']+box['width']/2,box['y']+box['height']/2))
    assert not any(x.startswith('reply:') for x in page.evaluate('events'));print('PASS media controls do not initiate reply')
    # Touch cancellation must restore the selection from before the gesture.
    page.evaluate('choose(["m1"]); document.querySelector("#selection").dataset.collapsed="0"; choose(["m1"]); events.length=0; document.querySelector("#messages").scrollTop=0');page.wait_for_timeout(550)
    x,y=pos(3);cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':x,'y':y}]})
    a,b=pos(5);cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':a,'y':b}]});page.wait_for_timeout(60)
    assert page.evaluate('ids()')==['m1','m3','m4','m5'],page.evaluate('ids()')
    cdp.send('Input.dispatchTouchEvent',{'type':'touchCancel','touchPoints':[]});page.wait_for_timeout(60)
    assert page.evaluate('ids()')==['m1'],page.evaluate('ids()');print('PASS touch cancellation restores pre-gesture selection')
    # A virtualized chat has 140 messages, but only a fraction is in the DOM.
    page.evaluate('virtualFixture()');page.wait_for_timeout(500);assert page.locator('[data-message]').count()<140
    x,y=pos(2);page.mouse.move(x,y);page.mouse.down();page.wait_for_timeout(480)
    bounds=page.locator('#messages').bounding_box();edge=bounds['y']+bounds['height']-4
    page.mouse.move(x,edge,steps=10);page.wait_for_timeout(900)
    down=page.locator('#messages').evaluate('(e)=>e.scrollTop');chosen=page.evaluate('ids()');assert down>200 and int(chosen[-1][1:])>=12,(down,chosen)
    assert 'm8' not in chosen and 'm9' not in chosen;print('PASS virtual-list bottom edge scroll selects offscreen messages and skips ineligible rows')
    page.mouse.move(x,bounds['y']+4,steps=8);page.wait_for_timeout(900)
    up=page.locator('#messages').evaluate('(e)=>e.scrollTop');assert up<down and len(page.evaluate('ids()'))<len(chosen),(up,down,page.evaluate('ids()'))
    page.mouse.up();print('PASS reverse edge scroll reduces range and restores baseline')
    page.evaluate('choose(["m2"]); document.querySelector("#selection").dataset.collapsed="0"; choose(["m2"]); document.querySelector("#messages").scrollTop=0');page.wait_for_timeout(120)
    x,y=pos(3);page.mouse.move(x,y);page.mouse.down();page.mouse.move(x,edge,steps=8);page.wait_for_timeout(150);page.evaluate('changeRoute()');page.wait_for_timeout(100);page.mouse.up();assert page.evaluate('ids()')==[];print('PASS route change stops the active selection gesture')
    browser.close()
