import asyncio, unittest
import test_server

class NativeCallWindow(unittest.IsolatedAsyncioTestCase):
 asyncSetUp=test_server.APITest.asyncSetUp
 asyncTearDown=test_server.APITest.asyncTearDown
 h=test_server.APITest.h
 register=test_server.APITest.register
 async def socket(self,user,group=False):
  ws=await self.client.ws_connect('/api/socket');await ws.send_json({'token':user['token'],'callIds':True,'groupCalls':group});await ws.receive_json(timeout=2)
  if group:await ws.receive_json(timeout=2)
  self.addAsyncCleanup(ws.close);return ws
 async def decline(self,user,ident):
  return await self.client.post('/api/calls/decline',headers=self.h(user),json={'callId':ident})
 async def test_direct_decline_is_authenticated_and_id_bound(self):
  a=await self.socket(self.a);ident='native_window_direct'
  await a.send_json({'type':'call','room':self.room,'callId':ident,'video':True});await a.receive_json(timeout=2)
  self.assertEqual((await self.client.post('/api/calls/decline',json={'callId':ident})).status,401)
  self.assertEqual((await self.decline(self.b,'bad/id')).status,400)
  for account,call_id in [(self.c,ident),(self.a,ident),(self.b,'stale_call')]:self.assertEqual((await self.decline(account,call_id)).status,409)
  self.assertEqual((await self.decline(self.b,ident)).status,200)
  event=await a.receive_json(timeout=2);self.assertEqual((event['type'],event['callId']),('call-rejected',ident))
  self.assertEqual(self.app['store'].one('SELECT status FROM calls WHERE id=?',(ident,))['status'],'rejected')
  self.assertEqual((await self.decline(self.b,ident)).status,409)
  self.assertIsNone(await (await self.client.get('/api/calls/current',headers=self.h(self.b))).json())
 async def test_cannot_decline_accepted_or_replaced_invitation(self):
  a=await self.socket(self.a);b=await self.socket(self.b)
  await a.send_json({'type':'call','room':self.room,'callId':'old_native_call','video':False});await a.receive_json(timeout=2);await b.receive_json(timeout=2)
  await b.send_json({'type':'accepted','room':self.room,'callId':'old_native_call'});await a.receive_json(timeout=2);await b.receive_json(timeout=2)
  self.assertEqual((await self.decline(self.b,'old_native_call')).status,409)
  await a.send_json({'type':'hangup','room':self.room,'callId':'old_native_call'});await a.receive_json(timeout=2);await b.receive_json(timeout=2)
  await a.send_json({'type':'call','room':self.room,'callId':'new_native_call','video':False});await a.receive_json(timeout=2);await b.receive_json(timeout=2)
  self.assertEqual((await self.decline(self.b,'old_native_call')).status,409)
  self.assertEqual((await self.decline(self.b,'new_native_call')).status,200)
 async def test_group_decline(self):
  a=await self.socket(self.a,True);b=await self.socket(self.b,True)
  uid=[x['user']['id'] for x in (self.a,self.b,self.c)]
  room=(await (await self.client.post('/api/rooms',headers=self.h(self.a),json={'members':uid[1:],'title':'Native group'})).json())['id']
  ident='native_group_call';await a.send_json({'type':'group-call-start','room':room,'callId':ident,'video':False})
  async def read(ws,kind):
   for _ in range(12):
    event=await ws.receive_json(timeout=2)
    if event['type']==kind:return event
   self.fail('missing '+kind)
  await read(a,'group-call-state');await read(b,'group-call-invite')
  self.assertEqual((await self.decline(self.a,ident)).status,409)
  self.assertEqual((await self.decline(self.b,ident)).status,200)
  self.assertIsNone(self.app['store'].group_calls.ringing(uid[1]))
