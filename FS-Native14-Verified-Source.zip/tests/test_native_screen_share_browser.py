"""Real Chromium canvas/RTP sender with synthetic native JPEG input; no Android projection claim."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
source=(root/'native-screen-share.js').read_text().replace('export ','')+(root/'call-extras.js').read_text().replace('export ','')
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage']);page=browser.new_page();page.set_content('<html></html>')
 result=page.evaluate('''async()=>{'''+source+'''
 const check=(x,m)=>{if(!x)throw Error(m)},wait=ms=>new Promise(r=>setTimeout(r,ms));
 const cv=document.createElement('canvas');cv.width=160;cv.height=90;cv.getContext('2d').fillRect(0,0,160,90);const jpeg=cv.toDataURL('image/jpeg').split(',')[1];
 let seq=0,started=0,stops=0,ended=false,waiting=false;const native={beginScreenShare(){started++;ended=false},screenShareFrame(id,after){return ended?'ended':waiting?'waiting':'frame|'+(++seq)+'|'+jpeg},endScreenShare(){stops++}};
 const md=nativeScreenDevices(native,{getUserMedia(){throw Error('camera not requested')}},{makeId:()=> 'a'.repeat(32)});
 const pc=new RTCPeerConnection(),tx=pc.addTransceiver('video',{direction:'sendrecv'}),ctx=new AudioContext(),mic=ctx.createMediaStreamDestination().stream.getAudioTracks()[0],local=new MediaStream([mic]);
 const x=createCallExtras({pc:{getTransceivers:()=>[{receiver:tx.receiver,sender:tx.sender,currentDirection:'sendrecv'}]},stream:local,initialVideo:false,valid:()=>true,mediaDevices:md,videoConstraints:()=>true});
 const ch={label:CALL_CHANNEL,readyState:'open',bufferedAmount:0,send(){},close(){}};x.bind(ch);ch.onmessage({data:'{"type":"media","mode":"off"}'});
 try{await x.setMode('screen');check(started===1&&tx.sender.track===local.getVideoTracks()[0]&&mic.readyState==='live','RTP screen and audio');
 const first=tx.sender.track;check(first.getSettings().width===160&&first.getSettings().height===90,'frame size');await x.setMode('off');check(stops===1&&first.readyState==='ended'&&tx.sender.track===null,'stop cleanup');
 await x.setMode('screen');ended=true;await wait(1550);check(x.mode==='off'&&tx.sender.track===null&&stops===2,'OS stop cleanup');
 waiting=true;const pending=x.setMode('screen');await wait(180);x.close();let rejected=false;try{await pending}catch{rejected=true}check(rejected&&stops===3,'pending cancellation');check(mic.readyState==='live','audio remains live');return 6;
 }finally{x.close();mic.stop();pc.close();await ctx.close();}
 }''');assert result==6;print('PASS: 6 native-bridge/canvas/RTP checks with synthetic Android frames');browser.close()
