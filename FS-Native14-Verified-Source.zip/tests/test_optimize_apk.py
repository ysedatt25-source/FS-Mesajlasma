import importlib.util, pathlib, tempfile, unittest, zipfile, warnings
spec=importlib.util.spec_from_file_location('optimize_apk',pathlib.Path(__file__).resolve().parents[1]/'tools/optimize_apk.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class ApkTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=pathlib.Path(self.tmp.name);self.a=self.root/'a.apk';self.b=self.root/'b.apk'
        self.files={'AndroidManifest.xml':b'manifest','classes.dex':b'dex','resources.arsc':b'resources','assets/web/emoji/a.webp':b'RIFF'+b'A'*5000,'assets/web/emoji-extra/b.webp':b'RIFF'+b'B'*20,'assets/web/ringtones/r.ogg':b'A'*5000}
    def tearDown(self):self.tmp.cleanup()
    def write(self,p,files):
        with zipfile.ZipFile(p,'w') as z:
            for k,v in files.items():z.writestr(k,v)
    def test_lossless(self):
        self.write(self.a,self.files);r=m.optimize(self.a,self.b);self.assertEqual(r['verified_entries'],6);self.assertEqual(r['optimized_entries'],1);self.assertGreater(r['candidate_bytes_saved'],0)
        with zipfile.ZipFile(self.b) as z:
            self.assertEqual(z.getinfo('assets/web/emoji/a.webp').compress_type,8);self.assertEqual(z.getinfo('assets/web/emoji-extra/b.webp').compress_type,0);self.assertEqual(z.getinfo('assets/web/ringtones/r.ogg').compress_type,0)
            self.assertEqual({n:z.read(n) for n in z.namelist()},self.files)
    def test_signed_v1_rejected(self):
        self.write(self.a,{**self.files,'META-INF/CERT.RSA':b'sig'})
        with self.assertRaises(ValueError):m.optimize(self.a,self.b)
        self.assertFalse(self.b.exists())
    def test_changed_content(self):
        self.write(self.a,self.files);self.write(self.b,{**self.files,'classes.dex':b'bad'})
        with self.assertRaises(ValueError):m.compare(self.a,self.b)
    def test_missing_path(self):
        self.write(self.a,self.files);self.write(self.b,{k:v for k,v in self.files.items() if not k.endswith('a.webp')})
        with self.assertRaises(ValueError):m.compare(self.a,self.b)
    def test_duplicate_rejected(self):
        self.write(self.a,self.files)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            with zipfile.ZipFile(self.a,'a') as z:z.writestr('classes.dex',b'bad')
        with self.assertRaises(ValueError):m.optimize(self.a,self.b)
    def test_no_overwrite(self):
        self.write(self.a,self.files);self.b.write_bytes(b'keep')
        with self.assertRaises(ValueError):m.optimize(self.a,self.b)
        self.assertEqual(self.b.read_bytes(),b'keep')
    def test_missing_manifest(self):
        self.write(self.a,{k:v for k,v in self.files.items() if k!='AndroidManifest.xml'})
        with self.assertRaises(ValueError):m.optimize(self.a,self.b)
if __name__=='__main__':unittest.main()
