from test_server import APITest

class DiscoveryTest(APITest):
 async def test_discovery_privacy(self):
  async def search(q):
   r=await self.client.get('/api/people',params={'q':q},headers=self.h(self.b));self.assertEqual(r.status,200);return await r.json()
  self.assertEqual(await search('05001111111'),[])
  self.assertEqual(len(await search('@alice')),1)
  r=await self.client.patch('/api/me',headers=self.h(self.a),json={'discoverByPhone':True});self.assertEqual(r.status,200)
  rows=await search('05001111111');self.assertEqual(len(rows),1);self.assertNotIn('phone',rows[0]);self.assertNotIn('email',rows[0])
  r=await self.client.patch('/api/me',headers=self.h(self.a),json={'discoverByPhone':False});self.assertEqual(r.status,200)
  self.assertEqual(await search('+905001111111'),[])

 async def test_email_discovery_privacy(self):
  store=self.app['store']
  user=store.one('SELECT id FROM users WHERE nick=?',('alice',))['id']
  store.run('INSERT INTO account_emails(user_id,email,verified) VALUES(?,?,0)',(user,'alice@example.com'))
  async def search(q):
   r=await self.client.get('/api/people',params={'q':q},headers=self.h(self.b));self.assertEqual(r.status,200);return await r.json()
  self.assertEqual(await search('alice@example.com'),[])
  r=await self.client.patch('/api/me',headers=self.h(self.a),json={'discoverByEmail':True});self.assertEqual(r.status,200)
  self.assertEqual(await search('alice@example.com'),[])
  store.run('UPDATE account_emails SET verified=1 WHERE user_id=?',(user,))
  rows=await search('ALICE@example.com');self.assertEqual(len(rows),1);self.assertNotIn('email',rows[0]);self.assertNotIn('phone',rows[0])
  self.assertEqual(await search('ali@example.com'),[])
  r=await self.client.patch('/api/me',headers=self.h(self.a),json={'discoverByEmail':False});self.assertEqual(r.status,200)
  self.assertEqual(await search('alice@example.com'),[])
