from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
source=(root/'virtual-list.js').read_text().replace('export ','')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':390,'height':844},has_touch=True)
 page.set_content('<div id="list" style="height:800px;overflow:auto"></div><style>.message-row{height:100px}</style>')
 result=page.evaluate('()=>{'+source+'''\n const t=document.querySelector('#list');let painted=0,viewport=0;const list=new VirtualMessages(t,(e,h)=>{painted++;e.innerHTML=h},null,()=>viewport++);list.observer.disconnect();const rows=Array.from({length:10000},(_,i)=>({id:'m'+i,html:'<article>'+i+'</article>'}));list.set(rows,{anchor:{id:'m5000',delta:15}});const first=t.querySelector('[data-row-id="m5000"]');const offset=list.offsets();const initial=painted;for(let i=0;i<1000;i++){t.scrollTop=500015+i%5;list.draw(false,null,true);}const stable=painted===initial&&first===t.querySelector('[data-row-id="m5000"]')&&list.offsets()===offset&&viewport===1000;list.jump('m9000');const jumped=!!t.querySelector('[data-row-id="m9000"]')&&painted===initial+1;list.set([{id:'older',html:'older'},...rows],{anchor:{id:'m9000',delta:12}});const anchored=t.scrollTop===900112;list.destroy();return {stable,jumped,anchored};}''')
 assert result['stable'],result;print('PASS real 10000-row DOM window retains nodes and offsets for 1000 unchanged draws')
 assert result['jumped'] and result['anchored'],result;print('PASS real browser jump and prepend preserve target position')

 # Exercise observer churn against a stable DOM and jumps past the old physical scroll range.
 page.set_content('<div id="list" style="height:400px;overflow:auto;overflow-anchor:none"></div><style>.message-row{height:100px}</style>')
 result=page.evaluate('''()=>{'''+source+'''
 const t=document.querySelector('#list');let observed=0,unobserved=0;const original=window.ResizeObserver;window.ResizeObserver=class{observe(){observed++}unobserve(){unobserved++}disconnect(){}};
 try{const patch=(host,html)=>{const tmp=document.createElement('template');tmp.innerHTML=html;const old=new Map([...host.children].map(n=>[n.dataset.key,n]));let cursor=host.firstElementChild;for(const fresh of [...tmp.content.children]){const n=old.get(fresh.dataset.key)||fresh;old.delete(fresh.dataset.key);if(n!==cursor)host.insertBefore(n,cursor);cursor=n.nextElementSibling;if(n.classList.contains('virtual-spacer'))n.style.height=fresh.style.height;}for(const n of old.values())n.remove();};
 const list=new VirtualMessages(t,patch);const rows=Array.from({length:1000},(_,i)=>({id:'m'+i,html:'message '+i}));list.set(rows,{anchor:{id:'m500',delta:15}});const initial=observed;list.set(rows,{anchor:{id:'m500',delta:15}});const stable=initial>0&&observed===initial&&unobserved===0;list.jump('m900');const next=observed>initial&&unobserved===initial&&!!t.querySelector('[data-row-id="m900"]');list.destroy();return {stable,next,cleared:list.observedRows.size===0};}finally{window.ResizeObserver=original;}}''')
 assert all(result.values()),result;print('PASS stable rows retain ResizeObserver subscriptions; changed windows release old rows')
 b.close()
