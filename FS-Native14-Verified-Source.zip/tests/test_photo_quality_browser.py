"""Real canvas: sharp bounded preview, original file unchanged, explicit original path."""
import os
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];web=root/'web'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page(viewport={'width':360,'height':720});page.set_content('<meta name="viewport" content="width=device-width,initial-scale=1"><div id="editor"></div>');page.add_style_tag(content=(web/'style.css').read_text())
 page.evaluate('()=>{'+(web/'photo-preview.js').read_text().replace('export ','')+'\n'+(web/'media-editor.js').read_text().replace('export ','')+'''
 window.check=async()=>{const c=document.createElement('canvas');c.width=1600;c.height=1000;const ctx=c.getContext('2d');ctx.fillStyle='white';ctx.fillRect(0,0,c.width,c.height);ctx.fillStyle='black';ctx.font='bold 120px sans-serif';ctx.fillText('FS original',70,200);const f=new File([await new Promise(r=>c.toBlob(r,'image/png'))],'photo.png',{type:'image/png'});window.original=f;const bitmap=await createImageBitmap(f);const make=(w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;return c};const preview=await encodePhotoPreview(bitmap,make,(c,q)=>new Promise(r=>c.toBlob(r,'image/jpeg',q)));bitmap.close();const pv=await createImageBitmap(preview);const out={width:pv.width,height:pv.height,size:preview.size,originalSize:f.size};pv.close();window.applied=null;mountMediaEditor(document.querySelector('#editor'),f,{valid:()=>true,onCancel:()=>{},onApply:f=>window.applied=f});return out;};}''')
 out=page.evaluate('check()');assert out['width']==320 and out['height']==200 and 0<out['size']<=16000,out;print('PASS real 320px JPEG preview within protocol limit',out)
 page.locator('[data-original]').click();assert page.evaluate('window.applied===window.original');print('PASS original button returns exact same File without recompression')
 page.evaluate('check()');page.wait_for_function("!document.querySelector('[data-apply]').disabled");assert page.locator('[data-quality]').input_value()=='high';print('PASS HD editor defaults to high quality')
 page.locator('[data-apply]').click();page.wait_for_function('window.applied!==null');out=page.evaluate('''async()=>{const img=await createImageBitmap(window.applied);const res={w:img.width,h:img.height,mime:window.applied.type};img.close();return res}''');assert out=={'w':1600,'h':1000,'mime':'image/jpeg'},out;print('PASS HD export retains resolution for supported dimensions',out)
 b.close()
