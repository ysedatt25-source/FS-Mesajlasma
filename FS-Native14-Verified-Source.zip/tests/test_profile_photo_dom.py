"""Actual Chromium layout and image decode/crop, with a modeled API response."""
import os, struct, zlib, base64
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
src=(root/'app.js').read_text()
profile=src[src.index('function profile(peer = state.user)'):src.index('function settings()')]
handler=src[src.index('function profilePhotoChoices()'):src.index('function importKeyDialog()')]
avatars=(root/'profile-avatars.js').read_text().replace('export const ','const ').replace('export function ','function ')
icons=(root/'icons.js').read_text().replace('export const icon','const icon')
def chunk(t,d):return struct.pack('>I',len(d))+t+d+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',4,2,8,2,0,0,0))+chunk(b'IDAT',zlib.compress((b'\0'+b'\xff\0\0'*4)*2))+chunk(b'IEND',b'')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
 pg=b.new_page(viewport={'width':360,'height':720},has_touch=True)
 pg.set_content('<div id="app"></div><div id="notice"></div><dialog id="modal"></dialog>');pg.add_style_tag(content=(root/'style.css').read_text())
 pg.evaluate('()=>{'+icons+'\n'+avatars+'\n'+profile+'\n'+handler+'''\nconst $=s=>document.querySelector(s),modal=$('#modal'),dialog=(title,html)=>{modal.innerHTML='<h2>'+title+'</h2>'+html;modal.showModal()},state={user:{id:'owner',name:'Test'},settings:{},token:'test'},access={epoch:1,valid:e=>e===1},isLocked=()=>false,discardVoice=()=>{},escape=s=>s||'',avatar=()=>'<span class="avatar large">TA</span>',row=()=>'',shell=(title,html)=>$('#app').innerHTML='<section class="screen fs-premium"><main class="scroll">'+html+'</main></section>',notice=(msg)=>$('#notice').textContent=msg;window.saved=null;const patchSettings=async p=>{window.saved=p.avatar;state.user.avatar=p.avatar};window.renderProfile=profile;document.addEventListener('click',e=>{if(e.target.closest('[data-action="profile-photo"]'))profilePhotoChoices()});profile();}''')
 change=pg.locator('.profile-photo-change');avatar=pg.locator('.profile-avatar-button')
 for theme in ['','light']:
  pg.evaluate('(theme)=>document.body.className=theme',theme)
  for width in [280,360,540]:
   pg.set_viewport_size({'width':width,'height':720});a,c=avatar.bounding_box(),change.bounding_box();assert c['y']>=a['y']+a['height']-1 and c['height']>=44 and c['x']>=0 and c['x']+c['width']<=width+1
 print('PASS change icon stays below avatar with minimum 44px touch target in both themes and 3 mobile widths')
 change.click()
 assert pg.locator('#profile-avatar-form input').count()==16 and pg.locator('.avatar-save').is_disabled()
 assert pg.evaluate('async()=>{const imgs=[...document.querySelectorAll(".avatar-option img")];await Promise.all(imgs.map(i=>i.decode()));return imgs.every(i=>i.naturalWidth===512&&i.naturalHeight===512)}')
 for theme in ['','light']:
  pg.evaluate('(theme)=>document.body.className=theme',theme)
  for width in [280,360,540]:
   pg.set_viewport_size({'width':width,'height':720});assert pg.evaluate('()=>{const r=document.querySelector("#modal").getBoundingClientRect();return [...document.querySelectorAll(".avatar-option")].every(e=>{const a=e.getBoundingClientRect();return a.left>=r.left&&a.right<=r.right&&a.width>=40})}')
 print('PASS 16 actual offline JPEGs decode and responsive grid fits both themes and 3 mobile widths')
 pg.locator('input[value=avatar-12]').check();assert pg.locator('.avatar-save').is_enabled() and pg.evaluate('window.saved') is None
 pg.locator('.avatar-save').click();pg.wait_for_function('window.saved?.startsWith("data:image/jpeg;base64,")');assert not pg.locator('#modal').is_visible()
 change.click();assert pg.locator('input[value=avatar-12]').is_checked()
 print('PASS explicit avatar save, selected indicator and persisted preselection')
 with pg.expect_file_chooser() as fc:pg.locator('#profile-avatar-gallery').click()
 pg.evaluate('window.saved=null');fc.value.set_files({'name':'sample.png','mimeType':'image/png','buffer':png});pg.wait_for_function('window.saved?.startsWith("data:image/jpeg;base64,")');assert pg.evaluate('async()=>{const img=new Image();img.src=window.saved;await img.decode();return img.naturalWidth===512&&img.naturalHeight===512}')
 print('PASS actual picker event, real PNG decoding and 512px JPEG encoding in Chromium')
 pg.evaluate('renderProfile({id:"peer",name:"Peer"})');assert change.count()==0 and pg.locator('#profile-photo-file').count()==0
 print('PASS peer profile contains no edit icon or file picker')
 b.close()
