"""Real Chromium responsive two-stage viewer, with local JPEG assets."""
import os
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
src=(root/'app.js').read_text()
viewer=src[src.index('function clearProfileViewer()'):src.index('function profilePhotoChoices()')]
profile=src[src.index('function profile(peer = state.user)'):src.index('function settings()')]
avatars=(root/'profile-avatars.js').read_text().replace('export const ','const ').replace('export function ','function ')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
 pg=b.new_page(viewport={'width':360,'height':720},has_touch=True)
 pg.set_content('<div id="app"></div><dialog id="modal"></dialog>');pg.add_style_tag(content=(root/'style.css').read_text())
 pg.evaluate('()=>{'+avatars+'\n'+profile+'\n'+viewer+'''\nconst $=s=>document.querySelector(s),app=$('#app'),modal=$('#modal'),state={user:{id:'owner',name:'Owner',avatar:PROFILE_AVATARS[0].photo},settings:{}},access={epoch:1,valid:e=>e===1},isLocked=()=>false,discardVoice=()=>{},escape=s=>s||'',avatar=u=>'<span class="avatar large">'+(u.avatar?'<img class="avatar-photo" src="'+u.avatar+'">':'TA')+'</span>',row=()=>'',icon=()=>'',shell=(title,html)=>{dismissProfileViewer();app.innerHTML='<section class="screen fs-premium"><main class="scroll">'+html+'</main></section>'},dialog=(title,html)=>{clearProfileViewer();modal.innerHTML='<button data-action="close-dialog">×</button><h2>'+title+'</h2>'+html;modal.showModal()};window.renderProfile=profile;window.peer={id:'peer',name:'Peer',avatar:PROFILE_AVATARS[15].photo};modal.addEventListener('close',()=>{if(!modal.open)clearProfileViewer()});document.addEventListener('click',e=>{const t=e.target.closest('[data-action]');if(t?.dataset.action==='view-avatar')viewProfilePhoto(t);if(t?.dataset.action==='close-dialog')dismissProfileViewer()});profile();}''')
 trigger=pg.locator('.profile-avatar-button');stage=pg.locator('.profile-viewer-image');modal=pg.locator('#modal')
 for theme in ['', 'light']:
  pg.evaluate('(theme)=>document.body.className=theme',theme)
  for width,height in [(280,640),(360,720),(540,800),(720,360)]:
   pg.set_viewport_size({'width':width,'height':height});trigger.tap();assert stage.is_visible()
   assert pg.evaluate('async()=>{const img=document.querySelector(".profile-viewer-image img");await img.decode();return img.naturalWidth===512&&img.naturalHeight===512}')
   medium=modal.bounding_box();assert medium['width']<width and medium['height']<=height and medium['x']>=0 and medium['y']>=0
   stage.tap();full=modal.bounding_box();assert abs(full['width']-width)<2 and abs(full['height']-height)<2 and abs(full['x'])<2 and abs(full['y'])<2,(width,height,full)
   assert pg.evaluate('()=>{const i=document.querySelector(".profile-viewer-image img"),r=i.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(i).objectFit==="contain"&&r.right<=innerWidth&&r.bottom<=innerHeight}')
   stage.tap();assert not modal.evaluate('(e)=>e.classList.contains("profile-viewer-full")');pg.locator('[data-action="close-dialog"]').tap();assert not modal.is_visible() and stage.count()==0
 print('PASS two-stage touch viewer fits four viewport sizes including landscape in both themes; intact image and close')
 pg.evaluate('renderProfile(window.peer)');assert pg.locator('.profile-photo-change').count()==0;trigger.tap();assert pg.evaluate('document.querySelector(".profile-viewer-image img").src===window.peer.avatar');stage.tap();pg.keyboard.press('Escape');pg.wait_for_function('!document.querySelector("#modal").open&&!document.querySelector(".profile-viewer-image")')
 print('PASS peer displays exact saved avatar and Escape clears full-screen image')
 trigger.tap();stage.tap();pg.evaluate('renderProfile({id:"peer",name:"No photo"})');assert stage.count()==0 and not modal.is_visible() and trigger.is_disabled()
 print('PASS navigation clears viewer and missing photo has no active view button')
 # Real multi-touch using Chromium's input stack, not synthetic DOM events.
 pg.evaluate('renderProfile(window.peer)');pg.set_viewport_size({'width':360,'height':720});trigger.tap();stage.tap()
 pg.locator('.profile-viewer-image img').evaluate('(e)=>e.decode()')
 cdp=pg.context.new_cdp_session(pg)
 def touch(kind,points):
  cdp.send('Input.dispatchTouchEvent',{'type':kind,'touchPoints':[{'x':x,'y':y,'id':i,'radiusX':3,'radiusY':3} for i,x,y in points]})
 def transform():return pg.locator('.profile-viewer-image img').evaluate('(e)=>{const m=new DOMMatrix(getComputedStyle(e).transform);return [m.a,m.e,m.f]}')
 def pinch(cx,cy,start,end):
  touch('touchStart',[(1,cx-start,cy),(2,cx+start,cy)])
  touch('touchMove',[(1,cx-end,cy),(2,cx+end,cy)])
  touch('touchEnd',[])
 box=stage.bounding_box();cx=box['x']+box['width']/2;cy=box['y']+box['height']/2
 pinch(cx,cy,35,90);pg.wait_for_function('parseFloat(document.querySelector(".profile-zoom-controls output").textContent)>200');assert modal.evaluate('(e)=>e.classList.contains("profile-viewer-full")');assert 2<transform()[0]<3
 print('PASS real two-finger spread zooms photo without toggling full-screen mode')
 touch('touchStart',[(1,cx,cy)]);touch('touchMove',[(1,cx+55,cy-65)]);touch('touchEnd',[])
 pg.wait_for_function('Math.abs(new DOMMatrix(getComputedStyle(document.querySelector(".profile-viewer-image img")).transform).e)>30');scale,x,y=transform();assert x>30 and y<-30 and 2<scale<3;assert modal.evaluate('(e)=>e.classList.contains("profile-viewer-full")')
 touch('touchStart',[(1,cx,cy)]);touch('touchMove',[(1,cx-85,cy+95)]);touch('touchEnd',[]);pg.wait_for_function('new DOMMatrix(getComputedStyle(document.querySelector(".profile-viewer-image img")).transform).e<0');assert transform()[2]>0
 print('PASS real one-finger panning in all directions keeps original image and mode')
 pinch(cx,cy,95,15);pg.wait_for_function('document.querySelector(".profile-zoom-controls output").textContent==="100%"');assert transform()==[1,0,0];assert modal.evaluate('(e)=>e.classList.contains("profile-viewer-full")')
 print('PASS real two-finger pinch back to 100 percent resets offsets without accidental tap')
 for _ in range(10):
  if pg.locator('[data-zoom="in"]').is_enabled():pg.locator('[data-zoom="in"]').tap()
 assert transform()[0]==5 and pg.locator('[data-zoom="in"]').is_disabled()
 pg.set_viewport_size({'width':720,'height':360});pg.locator('[data-zoom="reset"]').tap();assert transform()==[1,0,0];assert pg.locator('[data-zoom="out"]').is_disabled();stage.tap();assert not modal.evaluate('(e)=>e.classList.contains("profile-viewer-full")')
 print('PASS explicit zoom controls, max scale, reset and landscape change preserve tap behavior')
 pg.locator('[data-zoom="in"]').tap();pg.keyboard.press('Escape');pg.wait_for_function('!document.querySelector("#modal").open&&!document.querySelector(".profile-viewer-image")');trigger.tap();assert transform()==[1,0,0]
 print('PASS closing enlarged photo clears zoom; reopen starts at original size')
 b.close()
