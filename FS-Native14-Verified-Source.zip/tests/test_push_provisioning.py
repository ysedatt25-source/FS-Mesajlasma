import base64, copy, json, pathlib, sys, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'server'),str(ROOT/'tools')]
from fcm_config import service_account,validate_project
from prepare_push_build import client_configuration

PROJECT='fs-test-project'
CLIENT={'project_info':{'project_id':PROJECT,'project_number':'123456789'},'client':[{'client_info':{'android_client_info':{'package_name':'com.fs.mesajlasma'},'mobilesdk_app_id':'1:123456789:android:ab12'},'api_key':[{'current_key':'synthetic-only'}]}]}
ACCOUNT={'type':'service_account','project_id':PROJECT,'client_email':'sample@fs-test-project.iam.gserviceaccount.com','private_key':'-----BEGIN PRIVATE KEY-----\nSYNTHETIC\n-----END PRIVATE KEY-----\n','token_uri':'https://oauth2.googleapis.com/token'}
def encode(obj):return base64.b64encode(json.dumps(obj).encode()).decode()
class ProvisioningTests(unittest.TestCase):
    def test_client(self):self.assertEqual(client_configuration(PROJECT,encode(CLIENT)),CLIENT)
    def test_adc(self):self.assertIsNone(service_account(PROJECT,None))
    def test_account(self):self.assertEqual(service_account(PROJECT,json.dumps(ACCOUNT)),ACCOUNT)
    def test_wrong_project(self):
        with self.assertRaises(ValueError):client_configuration('different-project',encode(CLIENT))
        with self.assertRaises(ValueError):service_account('different-project',json.dumps(ACCOUNT))
    def test_wrong_package(self):
        config=copy.deepcopy(CLIENT);config['client'][0]['client_info']['android_client_info']['package_name']='wrong.app'
        with self.assertRaises(ValueError):client_configuration(PROJECT,encode(config))
    def test_wrong_sender(self):
        config=copy.deepcopy(CLIENT);config['client'][0]['client_info']['mobilesdk_app_id']='1:99999:android:ab'
        with self.assertRaises(ValueError):client_configuration(PROJECT,encode(config))
    def test_key_not_client_config(self):
        config={**CLIENT,'private_key':'secret-not-for-apk'}
        with self.assertRaises(ValueError):client_configuration(PROJECT,encode(config))
    def test_wrong_token_endpoint(self):
        with self.assertRaises(ValueError):service_account(PROJECT,json.dumps({**ACCOUNT,'token_uri':'https://example.invalid/token'}))
    def test_bad_values(self):
        for project in [None,'bad','UPPERCASE','invalid/path','project-']:
            with self.assertRaises(ValueError):validate_project(project)
        for bad in [None,'not base64','a'*131073,encode([]),encode({})]:
            with self.assertRaises(ValueError):client_configuration(PROJECT,bad)
        with self.assertRaises(ValueError):service_account(PROJECT,'not valid private json')
if __name__=='__main__':unittest.main()
