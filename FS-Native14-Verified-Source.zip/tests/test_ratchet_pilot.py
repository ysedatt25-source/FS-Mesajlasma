import asyncio, json, os, sys, tempfile, unittest, base64
from pathlib import Path
from aiohttp.test_utils import TestClient, TestServer
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from app import create_app
PUB={'kty':'EC','crv':'P-256','x':'fPJ7GI0DT36KUjgDBLUaw8CJaeJ38hs1pgtI_EdmmXg','y':'B3dVENuO0EApPZrGn3Qw27p9reY86YIpngS3nSJ4c9E'}
class PilotTest(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.app=create_app(self.tmp.name,ratchet_pilot=True);self.client=TestClient(TestServer(self.app));await self.client.start_server();self.users=[]
  for i,nick in enumerate(('alice','bob','carol')):
   r=await self.client.post('/api/session',json={'register':True,'privacy_accepted':True,'name':nick,'nick':nick,'phone':f'+90500111111{i}','password':'test-password-123','invite':'0032','pub':PUB});self.assertEqual(r.status,200,await r.text());self.users.append(await r.json())
  self.a,self.b,self.c=self.users;self.room=(await (await self.client.post('/api/rooms',headers=self.h(self.a),json={'members':[self.b['user']['id']]})).json())['id'];self.path='/api/rooms/'+self.room+'/ratchet-pilot'
 async def asyncTearDown(self):await self.client.close();self.tmp.cleanup()
 def h(self,u):return {'Authorization':'Bearer '+u['token']}
 async def test_real_client_server_roundtrip(self):
  self.app['store'].run("INSERT INTO app_config(key,value) VALUES(?,?)",('admin',self.c['user']['id']))
  fixture={'url':str(self.client.make_url('/')),'room':self.room,'a':self.a,'b':self.b};env={**os.environ,'FS_PILOT_FIXTURE':json.dumps(fixture)}
  p=await asyncio.create_subprocess_exec('node','tests/ratchet-pilot-http.mjs',cwd=Path(__file__).resolve().parents[1],env=env,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
  out,err=await asyncio.wait_for(p.communicate(),30);self.assertEqual(p.returncode,0,(out+err).decode());print(out.decode().strip())
  s=self.app['store'];rows=s.all('SELECT * FROM ratchet_pilot_messages');self.assertEqual(len(rows),3);self.assertNotIn('pilot-private',json.dumps(rows));self.assertEqual(s.one('SELECT count(*) n FROM messages')['n'],0)
  sid=rows[0]['session_id'];p=self.path+'/'+sid+'/messages';self.assertEqual((await self.client.get(p,headers=self.h(self.c))).status,403);self.assertEqual((await self.client.get(p)).status,401)
  self.assertEqual((await (await self.client.get('/api/admin/rooms/'+self.room+'/messages',headers=self.h(self.c))).json()),[])
  s.run('INSERT INTO blocks(owner,peer) VALUES(?,?)',(self.b['user']['id'],self.a['user']['id']));self.assertEqual((await self.client.get(p,headers=self.h(self.a))).status,403)
 async def test_offline_media(self):
  fixture={'url':str(self.client.make_url('/')),'room':self.room,'a':self.a,'b':self.b};env={**os.environ,'FS_PILOT_FIXTURE':json.dumps(fixture)}
  p=await asyncio.create_subprocess_exec('node','tests/ratchet-offline-http.mjs',cwd=Path(__file__).resolve().parents[1],env=env,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
  out,err=await asyncio.wait_for(p.communicate(),30);self.assertEqual(p.returncode,0,(out+err).decode());print(out.decode().strip())
  s=self.app['store'];rows=s.all('SELECT * FROM ratchet_pilot_messages');self.assertEqual(len(rows),3);self.assertNotIn('offline-private',json.dumps(rows));self.assertEqual(s.one('SELECT count(*) n FROM messages')['n'],0)
  self.assertEqual(s.one('SELECT count(*) n FROM ratchet_prekeys WHERE used_by IS NOT NULL')['n'],1)
  self.assertEqual((await self.client.get(self.path+'/prekeys',headers=self.h(self.c))).status,403)
  self.assertEqual((await self.client.get(self.path+'/'+rows[0]['session_id']+'/messages',headers=self.h(self.c))).status,403)
 async def test_large_media_and_pool(self):
  fixture={'url':str(self.client.make_url('/')),'room':self.room,'a':self.a,'b':self.b};env={**os.environ,'FS_PILOT_FIXTURE':json.dumps(fixture)}
  p=await asyncio.create_subprocess_exec('node','tests/ratchet-large-http.mjs',cwd=Path(__file__).resolve().parents[1],env=env,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
  out,err=await asyncio.wait_for(p.communicate(),90);self.assertEqual(p.returncode,0,(out+err).decode());print(out.decode().strip())
  s=self.app['store'];rows=s.all('SELECT * FROM ratchet_pilot_messages');self.assertEqual(len(rows),3);self.assertNotIn('offline-private',json.dumps(rows));self.assertEqual(s.one('SELECT count(*) n FROM ratchet_prekeys WHERE used_by IS NULL')['n'],3)
  upload=s.one('SELECT * FROM uploads');self.assertEqual(upload['size'],50*1024*1024+16);self.assertEqual(upload['complete'],1);self.assertEqual((s.dir/upload['id']).stat().st_size,upload['size']);self.assertEqual((await self.client.get('/api/uploads/'+upload['id'],headers=self.h(self.c))).status,403)
  self.assertEqual((await self.client.get(self.path+'/prekeys/own',headers=self.h(self.c))).status,403)
  link=s.one('SELECT * FROM ratchet_pilot_media');self.assertIsNotNone(link)
  route=self.path+'/'+link['session_id']+'/messages/'+link['message_id']+'/media/'+link['upload_id']
  rr=await self.client.get(route,headers={**self.h(self.b),'Range':'bytes=1048576-1048583'});self.assertEqual(rr.status,206);self.assertEqual(rr.headers['Content-Range'],f"bytes 1048576-1048583/{upload['size']}");self.assertEqual(len(await rr.read()),8)
  self.assertEqual((await self.client.get(route,headers=self.h(self.c))).status,403)
  self.assertEqual((await self.client.get('/api/uploads/'+upload['id'],headers=self.h(self.b))).status,403)
  self.assertEqual((await self.client.delete(route,headers=self.h(self.b))).status,403)
  self.assertEqual((await self.client.delete(route,headers=self.h(self.a))).status,200)
  self.assertEqual((await self.client.delete(route,headers=self.h(self.a))).status,200)
  self.assertEqual((await self.client.get(route,headers=self.h(self.b))).status,410)
  self.assertFalse((s.dir/upload['id']).exists());self.assertIsNone(s.one('SELECT 1 FROM uploads WHERE id=?',(upload['id'],)))
  self.assertEqual(s.one('SELECT deleted FROM ratchet_pilot_media')['deleted'],1)
  self.assertEqual(s.one('SELECT count(*) n FROM ratchet_pilot_messages')['n'],3)
  self.assertEqual((await self.client.post('/api/uploads',headers=self.h(self.a),json={'room':self.room,'size':upload['size'],'client_id':upload['id']})).status,409)

 async def test_disabled_and_validation(self):
  self.assertEqual((await self.client.get(self.path,headers=self.h(self.c))).status,403)
  self.assertEqual((await self.client.post(self.path,headers=self.h(self.a),json={'id':'1234567890','offer':{},'signing':'bad'})).status,400)
  rooms=await (await self.client.get('/api/rooms',headers=self.h(self.a))).json();self.assertTrue(rooms[0]['ratchet_pilot'])
  r=await self.client.post('/api/rooms',headers=self.h(self.a),json={'members':[self.b['user']['id'],self.c['user']['id']]});group=(await r.json())['id'];self.assertEqual((await self.client.get('/api/rooms/'+group+'/ratchet-pilot',headers=self.h(self.a))).status,403)
  self.app['ratchet_pilot']=False;self.assertEqual((await self.client.get(self.path,headers=self.h(self.a))).status,404)
  env={'iv':base64.b64encode(bytes(12)).decode(),'data':base64.b64encode(b'legacy').decode()};r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.a),json={'id':'legacy_message_123','envelopes':{u['user']['id']:env for u in (self.a,self.b)}});self.assertEqual(r.status,201,await r.text())

 async def test_mutual_direct_cutover(self):
  self.app['ratchet_cutover']=True
  s=self.app['store'];s.run('INSERT INTO app_config(key,value) VALUES(?,?)',('admin',self.c['user']['id']))
  fixture={'url':str(self.client.make_url('/')),'room':self.room,'a':self.a,'b':self.b,'c':self.c};env={**os.environ,'FS_PILOT_FIXTURE':json.dumps(fixture)}
  p=await asyncio.create_subprocess_exec('node','tests/ratchet-cutover-http.mjs',cwd=Path(__file__).resolve().parents[1],env=env,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
  out,err=await asyncio.wait_for(p.communicate(),30);self.assertEqual(p.returncode,0,(out+err).decode());print(out.decode().strip())
  self.assertEqual(s.one('SELECT count(*) n FROM messages')['n'],1)
  self.assertEqual(s.one('SELECT count(*) n FROM ratchet_cutover_active')['n'],1)
  self.assertNotIn('cutover-private-after',json.dumps(s.all('SELECT * FROM ratchet_pilot_messages')))
  admin=await (await self.client.get('/api/admin/rooms/'+self.room+'/messages',headers=self.h(self.c))).json();self.assertEqual(len(admin),1)
  self.app['ratchet_pilot']=False;self.app['ratchet_cutover']=False
  rooms=await (await self.client.get('/api/rooms',headers=self.h(self.a))).json();self.assertTrue(rooms[0]['ratchet_cutover_active']);self.assertFalse(rooms[0]['ratchet_pilot'])
  self.assertEqual((await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.a),json={})).status,409)

 async def test_real_session_rotation(self):
  self.app['ratchet_cutover']=True
  s=self.app['store'];s.run('INSERT INTO app_config(key,value) VALUES(?,?)',('admin',self.c['user']['id']))
  fixture={'url':str(self.client.make_url('/')),'room':self.room,'a':self.a,'b':self.b,'c':self.c};env={**os.environ,'FS_PILOT_FIXTURE':json.dumps(fixture)}
  p=await asyncio.create_subprocess_exec('node','tests/ratchet-rotation-http.mjs',cwd=Path(__file__).resolve().parents[1],env=env,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
  out,err=await asyncio.wait_for(p.communicate(),90);self.assertEqual(p.returncode,0,(out+err).decode());print(out.decode().strip())
  self.assertEqual(s.one('SELECT count(*) n FROM ratchet_rotations')['n'],1);self.assertEqual(s.one('SELECT count(*) n FROM ratchet_pilot_messages')['n'],101)

 async def test_inline_transport_and_reserve(self):
  self.app['ratchet_cutover']=True
  fixture={'url':str(self.client.make_url('/')),'room':self.room,'a':self.a,'b':self.b};env={**os.environ,'FS_PILOT_FIXTURE':json.dumps(fixture)}
  p=await asyncio.create_subprocess_exec('node','tests/ratchet-inline-http.mjs',cwd=Path(__file__).resolve().parents[1],env=env,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
  out,err=await asyncio.wait_for(p.communicate(),45);self.assertEqual(p.returncode,0,(out+err).decode());print(out.decode().strip())
  s=self.app['store'];rows=s.all('SELECT * FROM ratchet_pilot_messages');self.assertEqual(len(rows),3);self.assertNotIn('inline secret',json.dumps(rows));self.assertEqual(s.one('SELECT count(*) n FROM messages')['n'],0)

 async def test_auto_session_rotation(self):
  self.app['ratchet_cutover']=True
  fixture={'url':str(self.client.make_url('/')),'room':self.room,'a':self.a,'b':self.b,'c':self.c};env={**os.environ,'FS_PILOT_FIXTURE':json.dumps(fixture)}
  p=await asyncio.create_subprocess_exec('node','tests/ratchet-auto-rotation-http.mjs',cwd=Path(__file__).resolve().parents[1],env=env,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
  out,err=await asyncio.wait_for(p.communicate(),45);self.assertEqual(p.returncode,0,(out+err).decode());print(out.decode().strip())
  self.assertEqual(self.app['store'].one('SELECT count(*) n FROM ratchet_rotations')['n'],1)

 async def test_group_epoch_http_and_membership_change(self):
  self.app['ratchet_group_pilot']=True
  s=self.app['store'];group=(await (await self.client.post('/api/rooms',headers=self.h(self.a),json={'members':[self.b['user']['id'],self.c['user']['id']]})).json())['id']
  fixture={'url':str(self.client.make_url('/')),'room':group,'a':self.a,'b':self.b,'c':self.c};env={**os.environ,'FS_PILOT_FIXTURE':json.dumps(fixture)}
  p=await asyncio.create_subprocess_exec('node','tests/ratchet-group-http.mjs',cwd=Path(__file__).resolve().parents[1],env=env,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
  out,err=await asyncio.wait_for(p.communicate(),90);self.assertEqual(p.returncode,0,(out+err).decode());print(out.decode().strip())
  path='/api/rooms/'+group+'/ratchet-group-pilot';old=s.one('SELECT * FROM ratchet_group_packets');self.assertNotIn('group private test',old['packet']);old_epoch=old['epoch']
  # Existing app has no membership-change API; simulate a committed membership removal.
  s.run('DELETE FROM members WHERE room=? AND user=?',(group,self.c['user']['id']))
  self.assertEqual((await self.client.get(path+'/messages',headers=self.h(self.c))).status,403)
  self.assertEqual((await self.client.get(path+'/messages',headers=self.h(self.a))).status,409)
  self.assertEqual((await self.client.post(path+'/messages',headers=self.h(self.a),json=json.loads(old['packet']))).status,409)
  new=await self.client.post(path,headers=self.h(self.a),json={});self.assertEqual(new.status,200,await new.text());new=await new.json();self.assertNotEqual(new['epoch'],old_epoch);self.assertFalse(new['ready']);self.assertEqual(s.one('SELECT count(*) n FROM ratchet_group_packets')['n'],102)
  self.assertEqual((await self.client.get(path+'/messages',headers=self.h(self.a))).status,409)
  self.assertEqual((await self.client.post(path+'/key',headers=self.h(self.c),json={})).status,403)
  archive=await self.client.get(path+'/history',headers=self.h(self.a));self.assertEqual(archive.status,200);self.assertEqual([x['epoch'] for x in (await archive.json())['items']],[old_epoch])
  first=await self.client.get(path+'/history/'+old_epoch,headers=self.h(self.a));self.assertEqual(first.status,200);self.assertTrue((await first.json())['ready'])
  page=await self.client.get(path+'/history/'+old_epoch+'/messages',headers=self.h(self.a));self.assertEqual(page.status,200);packets=await page.json();self.assertEqual(len(packets),100)
  page=await self.client.get(path+'/history/'+old_epoch+'/messages?after='+packets[-1]['id'],headers=self.h(self.a));self.assertEqual(len(await page.json()),2)
  self.assertEqual((await self.client.get(path+'/history/'+old_epoch,headers=self.h(self.c))).status,403)
  self.assertEqual((await self.client.post(path+'/history/'+old_epoch+'/messages',headers=self.h(self.a),json=json.loads(old['packet']))).status,405)
  r=await self.client.post('/api/session',json={'register':True,'privacy_accepted':True,'name':'dora','nick':'dora','phone':'+905001111119','password':'test-password-123','invite':'0032','pub':PUB});self.assertEqual(r.status,200);d=await r.json()
  s.run('INSERT INTO members(room,user) VALUES(?,?)',(group,d['user']['id']))
  self.assertEqual((await self.client.get(path+'/history/'+old_epoch,headers=self.h(d))).status,404)
  self.assertEqual((await (await self.client.get(path+'/history',headers=self.h(d))).json())['items'],[])
  self.app['ratchet_group_pilot']=False
  self.assertEqual((await self.client.get(path,headers=self.h(self.a))).status,404)

 async def test_cutover_feature_disabled_and_group_refused(self):
  path='/api/rooms/'+self.room+'/ratchet-cutover'
  self.assertEqual((await self.client.get(path,headers=self.h(self.a))).status,404)
  self.app['ratchet_cutover']=True
  self.assertEqual((await self.client.post(path,headers=self.h(self.a),json={'session':'nonexistent_1234','consent':True})).status,409)
  r=await self.client.post('/api/rooms',headers=self.h(self.a),json={'members':[self.b['user']['id'],self.c['user']['id']]});group=(await r.json())['id']
  self.assertEqual((await self.client.get('/api/rooms/'+group+'/ratchet-cutover',headers=self.h(self.a))).status,403)
  self.assertEqual(self.app['store'].one('SELECT count(*) n FROM ratchet_cutover_active')['n'],0)

 async def test_cutover_expired_and_mismatched_consent(self):
  self.app['ratchet_cutover']=True
  s=self.app['store'];a=self.a['user']['id'];b=self.b['user']['id'];path='/api/rooms/'+self.room+'/ratchet-cutover'
  # Synthetic established session rows test the server policy only; real cryptography is covered by test_mutual_direct_cutover.
  import time
  now=int(time.time()*1000)
  one='session_fixture_one';two='session_fixture_two'
  for sid in (one,two):s.run('INSERT INTO ratchet_pilot_sessions VALUES(?,?,?,?,?,?,?,?,?,?)',(sid,self.room,a,b,'{}','test','{}','test',now+60000,now))
  async def agree(who,sid):
   r=await self.client.post(path,headers=self.h(who),json={'session':sid,'consent':True});self.assertEqual(r.status,200,await r.text());return await r.json()
  self.assertFalse((await agree(self.a,one))['active'])
  self.assertFalse((await agree(self.b,two))['active'])
  s.run('UPDATE ratchet_cutover_votes SET created=? WHERE room=? AND user=?',(now-601000,self.room,a))
  self.assertFalse((await agree(self.b,one))['active'])
  self.assertTrue((await agree(self.a,one))['active'])
  r=await self.client.post(path,headers=self.h(self.b),json={'session':two,'consent':True});self.assertEqual(r.status,409)
 async def test_lifetime_session_and_prekey_limits(self):
  import time
  s=self.app['store'];a=self.a['user']['id'];b=self.b['user']['id'];now=int(time.time()*1000)
  for i in range(35):
   sid=f'archived_session_{i:03d}';s.run('INSERT INTO ratchet_pilot_sessions VALUES(?,?,?,?,?,?,?,?,?,?)',(sid,self.room,a,b,'{}','test','{}','test',now+60000,now))
  r=await self.client.get(self.path,headers=self.h(self.a));first=await r.json();self.assertEqual(len(first),30)
  r=await self.client.get(self.path+'?before='+first[-1]['id'],headers=self.h(self.a));second=await r.json();self.assertEqual(len(second),5);self.assertEqual(len({x['id'] for x in first+second}),35)
  self.assertEqual((await self.client.get(self.path+'?before=unknown_session',headers=self.h(self.a))).status,404)
  nonce=base64.b64encode(bytes(32)).decode();sid=nonce.rstrip('=').replace('+','-').replace('/','_');key=base64.b64encode(bytes(65)).decode();sig=base64.b64encode(bytes(64)).decode()
  offer={'v':1,'room':self.room,'from':a,'to':b,'nonce':nonce,'dh':key,'expires':now+60000,'sig':sig}
  r=await self.client.post(self.path,headers=self.h(self.a),json={'id':sid,'offer':offer,'signing':key});self.assertEqual(r.status,201,await r.text())
  for i in range(35):
   kid=f'{i:032x}';s.run('INSERT INTO ratchet_prekeys VALUES(?,?,?,?,?,?)',(kid,self.room,b,'{}',now+60000,'used_session_'+str(i)))
  r=await self.client.get(self.path+'/prekeys/own',headers=self.h(self.b));self.assertEqual(await r.json(),[])
  fresh={'v':1,'room':self.room,'owner':b,'peer':a,'id':'f'*32,'dh':key,'signing':key,'expires':now+60000,'sig':sig}
  r=await self.client.post(self.path+'/prekeys',headers=self.h(self.b),json=fresh);self.assertEqual(r.status,201,await r.text())
  self.assertEqual(s.one('SELECT count(*) n FROM ratchet_prekeys WHERE used_by IS NOT NULL')['n'],35)
  self.assertEqual((await (await self.client.get(self.path+'/prekeys/own',headers=self.h(self.b))).json())[0]['id'],fresh['id'])
