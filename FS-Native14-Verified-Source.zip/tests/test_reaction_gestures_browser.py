"""Actual message click/pointer handlers with isolated network and rendered rows."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import os
root=Path(__file__).resolve().parents[1]/'web'
src=(root/'app.js').read_text()
code=(root/'view-once.js').read_text().replace('export ','')+'\n'+(root/'message-interactions.js').read_text().replace('import {isViewOnce} from "./view-once.js";','').replace('export ','')+'\n'+src[src.index('function bindSelection()'):src.index('function selectionBar()')]
with sync_playwright() as p:
    b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),args=['--no-sandbox','--disable-dev-shm-usage'],headless=True)
    page=b.new_page(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
    page.set_content('''<meta name="viewport" content="width=device-width,initial-scale=1"><main id="messages" style="touch-action:manipulation"><article data-message="a" style="padding:24px">Text <button id="media">media</button></article><article data-message="b" class="emoji" style="padding:24px"><span class="emoji-fallback">❤️</span></article></main>''')
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.evaluate('()=>{'+code+'''const $=s=>document.querySelector(s),state={page:'chat',routeVersion:1,room:{id:'r'},user:{id:'self'},selected:new Set()};const eligibleMessage=id=>['a','b'].includes(id),isLocked=()=>false,notice=()=>{},renderMessages=()=>{},beginReply=()=>{};window.events=[];const messageMenu=id=>events.push('menu:'+id),emojiEffect=n=>events.push('effect:'+n.dataset.message),reactToMessage=async(id,e)=>events.push('react:'+id+':'+e);window.changeRoute=()=>state.routeVersion++;window.select=()=>state.selected.add('a');$('#media').onclick=()=>events.push('media');bindSelection();}''')
    def tap(sel):page.locator(sel).tap(position={'x':8,'y':8})
    def reset():page.evaluate('events.length=0')
    def expect(items):page.wait_for_timeout(340);assert page.evaluate('events')==items,(page.evaluate('events'),items,errors)
    tap('[data-message="a"]');expect(['menu:a']);print('PASS single tap opens menu')
    reset();tap('[data-message="a"]');tap('[data-message="a"]');expect(['react:a:👍']);print('PASS double tap sends exactly one reaction')
    reset();tap('[data-message="a"]');tap('[data-message="a"]');tap('[data-message="a"]');expect(['react:a:👍']);print('PASS triple tap does not duplicate reaction or open menu')
    reset();tap('.emoji-fallback');expect(['effect:b']);print('PASS single emoji tap replays original effect')
    reset();tap('.emoji-fallback');tap('.emoji-fallback');expect(['react:b:👍']);print('PASS double tap emoji message reacts without replay')
    reset();tap('[data-message="a"]');tap('#media');expect(['media']);print('PASS media button cancels pending menu')
    reset();tap('[data-message="a"]');page.evaluate('changeRoute()');expect([]);print('PASS route change invalidates pending tap')
    reset();page.evaluate('select()');tap('[data-message="a"]');expect([]);print('PASS selection tap does not react')
    assert not errors,errors
    b.close()
