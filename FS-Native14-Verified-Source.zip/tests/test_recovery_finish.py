from test_server import APITest, PUB

class RecoveryFinishTest(APITest):
 async def test_reset(self):
  sent=[]; self.app['email_sender']=lambda address,code:sent.append(code)
  uid=self.a['user']['id']; s=self.app['store']; s.run('INSERT INTO account_emails(user_id,email,verified) VALUES(?,?,1)',(uid,'a@example.com'))
  before=s.one('SELECT pub FROM users WHERE id=?',(uid,))['pub']
  body={'phone':'+905001111111','email':'a@example.com'}
  self.assertEqual((await self.client.post('/api/account/recovery/start',json=body)).status,200)
  path='/api/account/recovery/finish'; body.update(code='x'*32,password='new-password-123')
  self.assertEqual((await self.client.post(path,json=body)).status,400)
  body['code']=sent[0]; self.assertEqual((await self.client.post(path,json=body)).status,200)
  self.assertEqual((await self.client.post(path,json=body)).status,400)
  self.assertEqual((await self.client.get('/api/account/email',headers=self.h(self.a))).status,401)
  self.assertEqual(s.one('SELECT pub FROM users WHERE id=?',(uid,))['pub'],before)
  for password,status in [('test-password-123',401),('new-password-123',200)]:
   r=await self.client.post('/api/session',json={'login':body['phone'],'password':password,'pub':PUB});self.assertEqual(r.status,status,await r.text())
 async def test_concurrent_reset_consumes_code_once(self):
  import asyncio
  sent=[]; self.app['email_sender']=lambda address,code:sent.append(code)
  uid=self.a['user']['id']; s=self.app['store']; s.run('INSERT INTO account_emails(user_id,email,verified) VALUES(?,?,1)',(uid,'a@example.com'))
  body={'phone':'+905001111111','email':'a@example.com'}
  self.assertEqual((await self.client.post('/api/account/recovery/start',json=body)).status,200)
  async def reset(password):
   r=await self.client.post('/api/account/recovery/finish',json={**body,'code':sent[0],'password':password}); return r.status
  self.assertEqual(sorted(await asyncio.gather(reset('new-password-one'),reset('new-password-two'))),[200,400])
 async def test_changed_email_invalidates_code(self):
  sent=[]; self.app['email_sender']=lambda address,code:sent.append(code)
  uid=self.a['user']['id']; s=self.app['store']; s.run('INSERT INTO account_emails(user_id,email,verified) VALUES(?,?,1)',(uid,'a@example.com'))
  body={'phone':'+905001111111','email':'a@example.com'}
  self.assertEqual((await self.client.post('/api/account/recovery/start',json=body)).status,200)
  s.run('UPDATE account_emails SET email=? WHERE user_id=?',('changed@example.com',uid))
  r=await self.client.post('/api/account/recovery/finish',json={**body,'code':sent[0],'password':'new-password-one'}); self.assertEqual(r.status,400)
 async def test_reset_during_device_login_rejects_stale_session(self):
  import asyncio
  from test_server import NEW_PUB
  sent=[]; self.app['email_sender']=lambda address,code:sent.append(code)
  uid=self.a['user']['id']; s=self.app['store']; s.run('INSERT INTO account_emails(user_id,email,verified) VALUES(?,?,1)',(uid,'a@example.com'))
  body={'phone':'+905001111111','email':'a@example.com'}
  self.assertEqual((await self.client.post('/api/account/recovery/start',json=body)).status,200)
  entered=asyncio.Event(); resume=asyncio.Event(); original=s.group_calls.leave
  async def pause(user,reason):
   if reason=='device_changed':entered.set(); await resume.wait()
   return await original(user,reason)
  s.group_calls.leave=pause
  task=asyncio.create_task(self.client.post('/api/session',json={'login':body['phone'],'password':'test-password-123','pub':NEW_PUB,'new_device':True}))
  try:
   await asyncio.wait_for(entered.wait(),3)
   r=await self.client.post('/api/account/recovery/finish',json={**body,'code':sent[0],'password':'new-password-123'})
   self.assertEqual(r.status,200,await r.text())
  finally:resume.set()
  r=await asyncio.wait_for(task,3);self.assertEqual(r.status,401,await r.text())
  self.assertEqual(s.one('SELECT count(*) n FROM sessions WHERE user=?',(uid,))['n'],0)

 async def test_malformed_unicode_code_is_rejected(self):
  sent=[]; self.app['email_sender']=lambda address,code:sent.append(code)
  uid=self.a['user']['id']; s=self.app['store']; s.run('INSERT INTO account_emails(user_id,email,verified) VALUES(?,?,1)',(uid,'a@example.com'))
  body={'phone':'+905001111111','email':'a@example.com'}
  self.assertEqual((await self.client.post('/api/account/recovery/start',json=body)).status,200)
  path='/api/account/recovery/finish'
  for code in ['\ud800'*32,'é'*32]:
   r=await self.client.post(path,json={**body,'code':code,'password':'new-password-123'});self.assertEqual(r.status,400,await r.text())
  r=await self.client.post(path,json={**body,'code':sent[0],'password':'new-password-123'});self.assertEqual(r.status,200,await r.text())

 async def test_malformed_password_does_not_consume_code(self):
  sent=[]; self.app['email_sender']=lambda address,code:sent.append(code)
  uid=self.a['user']['id']; s=self.app['store']; s.run('INSERT INTO account_emails(user_id,email,verified) VALUES(?,?,1)',(uid,'a@example.com'))
  body={'phone':'+905001111111','email':'a@example.com'}
  self.assertEqual((await self.client.post('/api/account/recovery/start',json=body)).status,200)
  path='/api/account/recovery/finish'
  r=await self.client.post(path,json={**body,'code':sent[0],'password':'\ud800'*8}); self.assertEqual(r.status,400,await r.text())
  r=await self.client.post(path,json={**body,'code':sent[0],'password':'new-password-123'}); self.assertEqual(r.status,200,await r.text())
