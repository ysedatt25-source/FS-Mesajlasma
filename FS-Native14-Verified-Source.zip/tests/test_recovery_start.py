from test_server import APITest

class RecoveryStartTest(APITest):
 async def test_only_verified_matching_account_receives_code(self):
  sent=[];self.app['email_sender']=lambda address,code:sent.append((address,code))
  self.app['store'].run('INSERT INTO account_emails(user_id,email,verified) VALUES(?,?,1)',(self.a['user']['id'],'a@example.com'))
  path='/api/account/recovery/start'
  for phone,email in [('+905002222222','a@example.com'),('+905001111111',' A@Example.com '),('+905001111111','a@example.com')]:
   r=await self.client.post(path,json={'phone':phone,'email':email});self.assertEqual(r.status,200,await r.text());self.assertEqual(await r.json(),{'ok':True})
  self.assertEqual(len(sent),1);self.assertEqual(sent[0][0],'a@example.com');self.assertEqual(len(sent[0][1]),32)
  self.assertEqual((await self.client.post(path,json={'phone':'+905001111111','email':'a@example.com'})).status,429)
