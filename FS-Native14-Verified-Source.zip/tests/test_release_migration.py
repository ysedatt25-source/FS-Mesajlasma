"""Verify existing CI.13 SQLite data survives idempotent startup of Native13."""
import pathlib, sqlite3, tempfile, unittest, sys, os
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'server'))
from database import connect

class ReleaseMigration(unittest.TestCase):
    def test_ci13_data_preserved_and_new_tables_cascade(self):
        with tempfile.TemporaryDirectory() as d, patch.dict(os.environ, {'FS_DB_BACKEND':'sqlite'}):
            path=pathlib.Path(d)
            db=sqlite3.connect(path/'fs.sqlite')
            db.executescript((ROOT/'tests/fixtures/ci13-schema.sql').read_text())
            for u in ('alice','bob'):
                db.execute('INSERT INTO users VALUES(?,?,?,?,?,?,?,?,?)',(u,u,u,'+1234567890'+str(len(u)),b'hash',b'salt','{}','{}',1))
            db.execute('INSERT INTO sessions VALUES(?,?,?)',('token','alice',9999999999999))
            db.execute('INSERT INTO rooms VALUES(?,?,?,?)',('room','Chat','direct',1))
            db.executemany('INSERT INTO members VALUES(?,?)',[('room','alice'),('room','bob')])
            db.execute('INSERT INTO messages VALUES(?,?,?,?,?,?,?)',('message','room','alice','{"alice":{"iv":"test","data":"ciphertext"}}',2,None,None))
            db.execute('INSERT INTO message_keys VALUES(?,?)',('message','{}'))
            db.execute('INSERT INTO contacts VALUES(?,?,0)',('alice','bob'))
            db.execute('INSERT INTO receipts VALUES(?,?,?)',('room','bob',2))
            db.execute('INSERT INTO uploads VALUES(?,?,?,?,?,?,?)',('file','alice','room',8,8,1,2))
            db.execute('INSERT INTO message_uploads VALUES(?,?)',('message','file'))
            db.execute('INSERT INTO calls VALUES(?,?,?,?,?,?,?,?,?)',('call','room','alice','bob',1,1,2,3,'ended'))
            db.execute('INSERT INTO app_config VALUES(?,?)',('admin','alice'))
            db.commit()
            tables=[x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
            before={t:db.execute(f'SELECT * FROM {t} ORDER BY 1,2' if t!='message_keys' else f'SELECT * FROM {t} ORDER BY 1').fetchall() for t in tables}
            db.close()
            media=(path/'fixture.encrypted');media.write_bytes(b'ciphertext')
            for _ in range(2):
                db=connect(path)
                for t,rows in before.items():
                    self.assertEqual([tuple(r) for r in db.execute(f'SELECT * FROM {t} ORDER BY 1,2')],rows,t)
                self.assertEqual(media.read_bytes(),b'ciphertext')
                self.assertEqual(db.execute('PRAGMA integrity_check').fetchone()[0],'ok')
                self.assertEqual(db.execute('PRAGMA foreign_key_check').fetchall(),[])
                self.assertEqual(db.execute('SELECT count(*) FROM message_revisions').fetchone()[0],0)
                self.assertEqual(db.execute('SELECT count(*) FROM message_receipts').fetchone()[0],0)
                db.close()
            db=connect(path)
            db.execute('INSERT INTO message_revisions VALUES(?,?,?,?,?)',('message',2,3,'{}','{}'))
            db.execute('INSERT INTO message_receipts VALUES(?,?,?,?)',('message','bob',3,4))
            db.execute('DELETE FROM messages WHERE id=?',('message',))
            db.commit()
            for t in ('message_revisions','message_receipts'):
                self.assertEqual(db.execute(f'SELECT count(*) FROM {t}').fetchone()[0],0)
            db.close()
