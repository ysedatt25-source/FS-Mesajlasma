"""Browser component regressions, not a replacement for full app/IndexedDB E2E."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
def src(name):
    return '\n'.join(x.replace('export ','') for x in (root/name).read_text().splitlines() if not x.startswith('import '))
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
 pg=b.new_page(viewport={'width':390,'height':844},has_touch=True)
 pg.set_content('<div id="app"></div>');pg.add_style_tag(content=(root/'style.css').read_text())
 pg.evaluate('()=>{'+src('calculator.js')+'\n'+src('calculator-ui.js')+'''\nwindow.format=formatCalculation;window.reset=(floating=false)=>{window.checks=0;window.actions=[];const root=document.querySelector('#app');window.view=mountCalculator(root,{floating,checkPin:async()=>{window.checks++;return true},onUnlock:()=>{throw Error('Unexpected unlock')},windowAction:(...a)=>window.actions.push(a)});};reset();}''')
 def key(k):pg.locator(f'[data-calc="{k}"]').click()
 def keys(seq):
  for k in seq:key(k)
 def result():return pg.locator('.display').inner_text()
 assert pg.evaluate('format(2025)')=='2.025' and pg.evaluate('format(12345.75)')=='12.345,75';print('PASS grouped and decimal formatting')
 keys(['4','5','×','4','5']);assert pg.locator('#calc-preview').inner_text()=='2.025';key('=');assert result()=='2.025';assert pg.locator('#calc-expression').inner_text()=='45×45';print('PASS arithmetic preview and result')
 pg.evaluate('reset()');pg.locator('#calc-science').click();assert pg.locator('[data-calc]').count()==35;keys(['sin','3','0',')','=']);assert result()=='0,5';keys(['AC','inv','sin','0',',','5',')','=']);assert result()=='30';keys(['AC','rad','inv','sin','π','÷','2',')','=']);assert result()=='1';print('PASS scientific calculator modes')
 pg.evaluate('reset(true)');keys(list('123456')+['=']);assert pg.evaluate('checks')==0;pg.locator('#calc-menu').click();assert pg.locator('.calc-popup .row').all_text_contents()==['Tam ekran','Küçült','Kapat'];pg.locator('.calc-popup .row').first.click();assert pg.evaluate('actions[0][0]')=='fullscreen';print('PASS floating calculator cannot unlock')
 pg.evaluate('reset()');keys(['4','5']);state=pg.evaluate('view.snapshot()');assert '45' not in state, 'unsubmitted numeric PIN candidate must not be transferred';pg.evaluate('view.restore({input:"<img src=x onerror=alert(1)>"})');assert pg.locator('#app img').count()==0;print('PASS safe snapshot and injection rejection')
 pg.evaluate('reset()');keys(['4','5']);assert pg.evaluate('JSON.parse(view.snapshot()).input')=='';keys(['+','2']);state=pg.evaluate('view.snapshot()');pg.evaluate('reset()');pg.evaluate('(s)=>view.restore(s)',state);assert result()=='45+2';pg.evaluate('view.restore({input:"<img src=x onerror=alert(1)>"})');assert result()=='45+2' and pg.locator('#app img').count()==0;key('=');assert result()=='47' and pg.evaluate('checks')==0;print('PASS exact CircleCI regression: arithmetic transfers without PIN eligibility')
 pg.evaluate('reset()');pg.evaluate('view.restore({input:"12345",done:false})');key('6');assert result()=='123456';key('=');assert pg.evaluate('checks')==0;print('PASS restored digits plus trusted suffix cannot unlock')
 pg.evaluate('reset()');keys(['1','+','2','⌫','⌫','2','3','4','5','6']);key('=');assert pg.evaluate('checks')==0;print('PASS arithmetic edited into digits cannot unlock')
 pg.set_content('<div id="notice"></div>')
 pg.evaluate('()=>{'+src('feedback.js')+'''\nwindow.runNotices=()=>{const e=document.querySelector('#notice');let cb,time,cancelled;showNotice(e,'Müsaitim',{kind:'success',compact:true,duration:2000,schedule:(f,t)=>{cb=f;time=t;return 42},cancel:()=>{}});const a=e.classList.contains('notice-success')&&e.classList.contains('notice-compact')&&e.getAttribute('role')==='status'&&time===2000;cb();const b=e.style.display==='none';showNotice(e,'Müsait değilim',{kind:'error',schedule:()=>43,cancel:id=>cancelled=id});return [a,b,cancelled===42,e.classList.contains('notice-error')&&!e.classList.contains('notice-success')&&e.getAttribute('role')==='alert'];};}''')
 assert all(pg.evaluate('runNotices()'));print('PASS notices, accessibility and timer replacement')
 pg.set_content('<div id="list" style="height:800px;overflow:auto"><div></div></div><style>.message-row{height:100px}</style>')
 pg.evaluate('()=>{'+src('virtual-list.js')+'''\nconst t=document.querySelector('#list'),list=new VirtualMessages(t,(e,h)=>e.innerHTML=h);const rows=Array.from({length:10000},(_,i)=>({id:'m'+i,html:'<article>'+i+'</article>'}));window.list=list;window.rows=rows;list.set(rows,{bottom:true});}''')
 assert pg.locator('[data-row-id]').count()<30 and pg.locator('[data-row-id="m9999"]').count()==1;assert pg.evaluate('list.jump("m5000")');assert pg.locator('[data-row-id="m5000"]').count()==1;pg.evaluate('list.set([{id:"prepend",html:"older"},...rows],{anchor:{id:"m5000",delta:13}})');assert pg.locator('#list').evaluate('(e)=>e.scrollTop')==500113;pg.evaluate('list.destroy()');print('PASS 10000-row virtualization and preserved anchor')
 pg.set_content('<div class="fs-chat" style="width:360px;height:600px;position:relative"><div id="msg"><span class="emoji-fallback">😂</span></div></div>')
 pg.evaluate('()=>{'+src('emoji-effects.js')+'''\nwindow.emojiCheck=async()=>{const t=document.querySelector('#msg'),tasks=[];const opts={assetPath:'1f602.webp',fetchAsset:async()=>({ok:true,blob:async()=>new Blob(['fixture'])}),schedule:f=>tasks.push(f)};const a=animateEmoji(t,'😂',opts);await new Promise(r=>setTimeout(r,0));const b=animateEmoji(t,'😘',{...opts,assetPath:'1f618.webp'});await new Promise(r=>setTimeout(r,0));tasks[0]();const c=document.querySelectorAll('.emoji-interactive-layer').length===1&&document.querySelectorAll('.emoji-particle').length===0;clearEmojiEffect();const d=!document.querySelector('.emoji-interactive-layer')&&!animateEmoji(t,'💜',{reducedMotion:true});return [a,b,c,d];};}''')
 assert all(pg.evaluate('emojiCheck()'));print('PASS emoji effects replace rather than stack and respect reduced motion')
 b.close()
