"""Isolated Chromium: production cache and foreground timer, simulated visibility events."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import os
source=(Path(__file__).resolve().parents[1]/'web/resource-budget.js').read_text().replace('export function','function').replace('export class','class')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM','/usr/bin/chromium'),args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page()
 result=page.evaluate('''async()=>{'''+source+'''
 let hidden=false,ticks=0;Object.defineProperty(document,'hidden',{configurable:true,get:()=>hidden});
 const change=value=>{hidden=value;document.dispatchEvent(new Event('visibilitychange'));};
 const sleep=ms=>new Promise(r=>setTimeout(r,ms));const dispose=foregroundInterval(document,()=>ticks++,20);
 await sleep(100);const active=ticks>0;change(true);const old=ticks;await sleep(100);const paused=ticks===old;change(false);await sleep(100);const resumed=ticks>old;dispose();const last=ticks;await sleep(80);const stopped=ticks===last;
 const c=new BoundedCache({count:2,bytes:1000,weight:estimateRecordBytes});c.set('1',{text:'one'});c.set('2',{text:'two'});c.get('1');c.set('3',{text:'three'});const lru=c.has('1')&&!c.has('2')&&c.has('3');c.clear();const cleared=c.size===0&&c.estimatedBytes===0;
 return {active,paused,resumed,stopped,lru,cleared};}''')
 assert all(result.values()),result
 for key in result: print('PASS',key)
 b.close()
