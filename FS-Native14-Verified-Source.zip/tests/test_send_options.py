import asyncio, json, tempfile, unittest
import test_server as base
from test_server import ENVELOPE, PUB, NEW_PUB, now
from app import create_app, dispatch_scheduled, message_alerts
from aiohttp.test_utils import TestClient, TestServer

class SendOptionsTest(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=base.APITest.asyncSetUp
    asyncTearDown=base.APITest.asyncTearDown
    h=base.APITest.h
    register=base.APITest.register
    env=base.APITest.env
    def data(self,mid='scheduled_test_123',**extra):
        return {'id':mid,'envelopes':self.env(),'recipient_pubs':{self.a['user']['id']:PUB,self.b['user']['id']:PUB},'due':now()+60000,**extra}
    @property
    def path(self):return '/api/rooms/'+self.room+'/scheduled'
    @property
    def store(self):return self.app['store']
    async def schedule(self,**extra):
        r=await self.client.post(self.path,headers=self.h(self.a),json=self.data(**extra));self.assertEqual(r.status,201,await r.text());return await r.json()
    async def deliver(self):
        self.store.run('UPDATE scheduled_messages SET due=?',(now()-1,));await dispatch_scheduled(self.store)
    async def test_silent_no_alert_but_message_visible(self):
        sent=[];self.store.push.transport=lambda *a:True;self.store.push.wake_message=lambda *a:sent.append(a)
        r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.a),json={'id':'silent_test_123','envelopes':self.env(),'silent':True});self.assertEqual(r.status,201);self.assertTrue((await r.json())['silent']);self.assertEqual(sent,[]);self.assertEqual(message_alerts(self.store,self.b['user']['id']),[])
        rows=await(await self.client.get('/api/rooms/'+self.room+'/messages',headers=self.h(self.b))).json();self.assertEqual(rows[0]['id'],'silent_test_123');self.assertTrue(rows[0]['silent'])
        r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.a),json={'id':'normal_test_123','envelopes':self.env()});self.assertEqual(r.status,201);self.assertEqual(len(sent),1);self.assertEqual(message_alerts(self.store,self.b['user']['id'])[0]['id'],'normal_test_123')
    async def test_scheduled_persistent_private_until_due(self):
        await self.schedule();await dispatch_scheduled(self.store);self.assertFalse(self.store.one('SELECT * FROM messages'))
        rows=await(await self.client.get(self.path,headers=self.h(self.a))).json();self.assertEqual(len(rows),1);self.assertEqual(rows[0]['envelope'],ENVELOPE)
        self.assertEqual(await(await self.client.get(self.path,headers=self.h(self.b))).json(),[])
        self.assertEqual((await self.client.get(self.path,headers=self.h(self.c))).status,403)
        self.assertEqual((await self.client.delete(self.path+'/scheduled_test_123',headers=self.h(self.b))).status,404)
        # Reopen on same disk to model service restart.
        await self.client.close();self.app=create_app(self.tmp.name);self.client=TestClient(TestServer(self.app));await self.client.start_server()
        await self.deliver();await dispatch_scheduled(self.store);self.assertEqual(self.store.one('SELECT count(*) n FROM messages')['n'],1);self.assertFalse(self.store.one('SELECT * FROM scheduled_messages'))
        self.assertEqual(message_alerts(self.store,self.b['user']['id'])[0]['id'],'scheduled_test_123')
    async def test_cancel_and_silent_schedule(self):
        await self.schedule();self.assertEqual((await self.client.delete(self.path+'/scheduled_test_123',headers=self.h(self.a))).status,200);await self.deliver();self.assertFalse(self.store.one('SELECT * FROM messages'))
        await self.schedule(silent=True);await self.deliver();self.assertTrue(self.store.one('SELECT * FROM silent_messages'));self.assertEqual(message_alerts(self.store,self.b['user']['id']),[])
    async def test_key_change_prevents_delivery(self):
        await self.schedule();self.store.run('UPDATE users SET pub=? WHERE id=?',(json.dumps(NEW_PUB),self.b['user']['id']));await self.deliver();self.assertFalse(self.store.one('SELECT * FROM messages'));self.assertIn('anahtarı',self.store.one('SELECT error FROM scheduled_messages')['error'])
    async def test_block_prevents_delivery(self):
        await self.schedule();self.store.run('INSERT INTO blocks VALUES(?,?)',(self.b['user']['id'],self.a['user']['id']));await self.deliver();self.assertFalse(self.store.one('SELECT * FROM messages'));self.assertIn('engellendi',self.store.one('SELECT error FROM scheduled_messages')['error'])
    async def test_invalid_and_idempotent(self):
        for extra in ({'due':now()-1},{'silent':'true'},{'recipient_pubs':{}},{'due':now()+366*86400000}):
            r=await self.client.post(self.path,headers=self.h(self.a),json=self.data(**extra));self.assertIn(r.status,(400,409))
        data=self.data();r=await self.client.post(self.path,headers=self.h(self.a),json=data);self.assertEqual(r.status,201);r=await self.client.post(self.path,headers=self.h(self.a),json=data);self.assertEqual(r.status,200);self.assertEqual(self.store.one('SELECT count(*) n FROM scheduled_messages')['n'],1)
