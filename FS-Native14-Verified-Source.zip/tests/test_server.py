import asyncio, base64, json, sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from app import create_app, MAX_FILE, now
from aiohttp.test_utils import TestClient, TestServer

PUB={'kty': 'EC', 'crv': 'P-256', 'x': 'fPJ7GI0DT36KUjgDBLUaw8CJaeJ38hs1pgtI_EdmmXg', 'y': 'B3dVENuO0EApPZrGn3Qw27p9reY86YIpngS3nSJ4c9E', 'ext': True, 'key_ops': []}
NEW_PUB={'kty':'EC','crv':'P-256','x':base64.urlsafe_b64encode(bytes.fromhex('6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296')).decode().rstrip('='),'y':base64.urlsafe_b64encode(bytes.fromhex('4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5')).decode().rstrip('=')}
ENVELOPE={'iv':base64.b64encode(b'123456789012').decode(),'data':base64.b64encode(b'ciphertext').decode()}
class APITest(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.app=create_app(self.tmp.name);self.client=TestClient(TestServer(self.app));await self.client.start_server()
  self.a=await self.register('alice','+905001111111');self.b=await self.register('bob','+905002222222');self.c=await self.register('carol','+905003333333')
  r=await self.client.post('/api/rooms',headers=self.h(self.a),json={'members':[self.b['user']['id']]});self.room=(await r.json())['id']
 async def asyncTearDown(self):await self.client.close();self.tmp.cleanup()
 def h(self,user):return {'Authorization':'Bearer '+user['token']}
 async def register(self,nick,phone):
  r=await self.client.post('/api/session',json={'register':True,'privacy_accepted':True,'name':nick.title(),'nick':nick,'phone':phone,'password':'test-password-123','invite':'0032','pub':PUB})
  self.assertEqual(r.status,200,await r.text());return await r.json()
 def env(self):return {self.a['user']['id']:ENVELOPE,self.b['user']['id']:ENVELOPE}
 async def message(self):
  r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.a),json={'id':'test_message_123','envelopes':self.env()});self.assertEqual(r.status,201);return await r.json()
 async def test_push_registration_and_authenticated_call_wakeup(self):
  store=self.app['store'];sent=[];token='FCM_test_registration_0123456789';binding='test_binding_0123456789abcdef';path='/api/push/registration';uid=self.b['user']['id']
  body={'registration':token,'binding':binding};self.assertEqual((await self.client.post(path,headers=self.h(self.b),json=body)).status,503)
  store.push.transport=lambda t,d,ttl:sent.append((t,d,ttl)) or True
  self.assertEqual((await self.client.post(path,json=body)).status,401)
  self.assertEqual((await self.client.post(path,headers=self.h(self.b),json={'registration':'bad','binding':binding})).status,400)
  self.assertEqual((await self.client.post(path,headers=self.h(self.b),json=body)).status,200)
  self.assertEqual((await self.client.post(path,headers=self.h(self.c),json=body)).status,409)
  h={**self.h(self.b),'X-FS-Push-Binding':binding};self.assertEqual((await self.client.get('/api/push/ringing',headers=self.h(self.b))).status,403)
  self.assertIsNone((await (await self.client.get('/api/push/ringing',headers=h)).json())['ringing'])
  a=await self.client.ws_connect('/api/socket');await a.send_json({'token':self.a['token'],'callIds':True});await a.receive_json()
  try:
   await a.send_json({'type':'call','room':self.room,'callId':'push_direct_call_123','video':True});await a.receive_json(timeout=2)
   self.assertEqual(await asyncio.wait_for(store.push.queue.get(),2),uid)
   await store.push.deliver(uid);self.assertEqual(len(sent),1);self.assertEqual(sent[0][:2],(token,{'kind':'call-wakeup-v1','binding':binding}));self.assertGreater(sent[0][2],0);self.assertLessEqual(sent[0][2],45000)
   ring=(await(await self.client.get('/api/push/ringing',headers=h)).json())['ringing'];self.assertEqual(set(ring),{'callId','remainingMs','video'});self.assertTrue(ring['video']);self.assertEqual(ring['callId'],'push_direct_call_123')
   self.assertEqual((await self.client.get('/api/push/ringing',headers={**self.h(self.c),'X-FS-Push-Binding':binding})).status,403)
   await a.send_json({'type':'hangup','room':self.room,'callId':'push_direct_call_123'});await a.receive_json(timeout=2);await store.push.deliver(uid);self.assertEqual(len(sent),1);self.assertIsNone((await(await self.client.get('/api/push/ringing',headers=h)).json())['ringing'])
   self.assertEqual((await self.client.post('/api/logout',headers=self.h(self.b))).status,200);self.assertEqual(store.one('SELECT count(*) n FROM push_registrations')['n'],0);self.assertEqual((await self.client.get('/api/push/ringing',headers=h)).status,401)
  finally:await a.close()
 async def test_muted_contact_call_still_delivered_silently(self):
  store=self.app['store'];store.push.transport=lambda t,d,ttl:True
  binding='mute_binding_0123456789abcdef';token='FCM_mute_registration_0123456789'
  await self.client.post('/api/push/registration',headers=self.h(self.b),json={'registration':token,'binding':binding})
  r=await self.client.patch('/api/me',headers=self.h(self.b),json={'mutedPeers':[self.a['user']['id']]});self.assertEqual(r.status,200)
  a=await self.client.ws_connect('/api/socket');await a.send_json({'token':self.a['token'],'callIds':True});await a.receive_json()
  try:
   await a.send_json({'type':'call','room':self.room,'callId':'muted_contact_call_123','video':False});echo=await a.receive_json(timeout=2);self.assertEqual(echo['type'],'call');self.assertNotIn('silent',echo)
   h={**self.h(self.b),'X-FS-Push-Binding':binding};ring=(await (await self.client.get('/api/push/ringing',headers=h)).json())['ringing'];self.assertTrue(ring['silent']);self.assertEqual(ring['callId'],'muted_contact_call_123')
   poll=(await (await self.client.get('/api/events',params={'ringing':'1'},headers=self.h(self.b))).json())['ringing'];self.assertTrue(poll['silent'])
  finally:await a.close()
 async def test_push_group_invite_to_offline_registered_participant(self):
  store=self.app['store'];sent=[];store.push.transport=lambda t,d,ttl:sent.append((t,d,ttl)) or True
  uid=[x['user']['id'] for x in (self.a,self.b,self.c)];binding='group_binding_0123456789abcdef';token='FCM_group_registration_1234567890'
  self.assertEqual((await self.client.post('/api/push/registration',headers=self.h(self.b),json={'registration':token,'binding':binding})).status,200)
  r=await self.client.post('/api/rooms',headers=self.h(self.a),json={'members':uid[1:],'title':'Group push'});room=(await r.json())['id']
  a=await self.client.ws_connect('/api/socket');await a.send_json({'token':self.a['token'],'groupCalls':True,'callIds':True});await a.receive_json();await a.receive_json()
  try:
   await a.send_json({'room':room,'callId':'group_push_call_123','type':'group-call-start','video':False});state=await a.receive_json(timeout=2);self.assertEqual(state['participants'],{uid[0]:'joined',uid[1]:'ringing'})
   self.assertEqual(await asyncio.wait_for(store.push.queue.get(),2),uid[1]);await store.push.deliver(uid[1]);self.assertEqual(sent[0][0],token)
   b=await self.client.ws_connect('/api/socket');await b.send_json({'token':self.b['token'],'groupCalls':True});await b.receive_json();invite=await b.receive_json(timeout=2);self.assertEqual(invite['type'],'group-call-invite');self.assertEqual(invite['callId'],'group_push_call_123');await b.receive_json(timeout=2);await b.close()
   h={**self.h(self.b),'X-FS-Push-Binding':binding};r=await self.client.get('/api/push/ringing',headers=h);self.assertEqual((await r.json())['ringing']['callId'],'group_push_call_123')
   store.run('INSERT INTO blocks(owner,peer) VALUES(?,?)',(uid[1],uid[0]));self.assertIsNone((await(await self.client.get('/api/push/ringing',headers=h)).json())['ringing']);await store.push.deliver(uid[1]);self.assertEqual(len(sent),1)
  finally:await a.close()
 async def test_durable_download_ranges_authorized_and_deleted_message(self):
  contents=b'abcdef0123456789';r=await self.client.post('/api/uploads',headers=self.h(self.a),json={'room':self.room,'size':len(contents)});ident=(await r.json())['id']
  r=await self.client.put('/api/uploads/'+ident,headers={**self.h(self.a),'Upload-Offset':'0'},data=contents);self.assertTrue((await r.json())['complete'])
  mid='download_message_123';path='/api/messages/'+mid+'/download/'+ident
  r=await self.client.get(path,headers=self.h(self.a));self.assertEqual(r.status,404)
  r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.a),json={'id':mid,'envelopes':self.env(),'uploads':[ident]});self.assertEqual(r.status,201)
  r=await self.client.get(path,headers={**self.h(self.b),'Range':'bytes=4-9','Origin':'https://appassets.androidplatform.net'});self.assertEqual(r.status,206);self.assertEqual(r.headers['Content-Range'],'bytes 4-9/16');self.assertIn('Content-Range',r.headers['Access-Control-Expose-Headers']);self.assertEqual(await r.read(),contents[4:10])
  r=await self.client.get(path,headers={**self.h(self.b),'Range':'bytes=10-15'});self.assertEqual(await r.read(),contents[10:])
  r=await self.client.get(path,headers={**self.h(self.c),'Range':'bytes=0-0'});self.assertEqual(r.status,403)
  r=await self.client.get(path);self.assertEqual(r.status,401)
  r=await self.client.delete('/api/messages/'+mid,headers=self.h(self.a));self.assertEqual(r.status,200)
  r=await self.client.get(path,headers={**self.h(self.b),'Range':'bytes=0-0'});self.assertEqual(r.status,404)
 async def test_group_call_three_members_signal_membership_and_end(self):
  uid=[x['user']['id'] for x in (self.a,self.b,self.c)]
  r=await self.client.post('/api/rooms',headers=self.h(self.a),json={'members':uid[1:],'title':'Group'});room=(await r.json())['id'];self.assertEqual(r.status,201)
  async def connect(user):
   ws=await self.client.ws_connect('/api/socket');await ws.send_json({'token':user['token'],'groupCalls':True,'callIds':True});self.assertIn('group-call-v1',(await ws.receive_json(timeout=2))['features']);self.assertEqual((await ws.receive_json(timeout=2))['type'],'group-call-none');return ws
  a,b,c=[await connect(x) for x in (self.a,self.b,self.c)]
  e={'room':room,'callId':'group_call_test_01'}
  async def send(ws,kind,**kw):await ws.send_json({**e,'type':'group-call-'+kind,**kw})
  async def read(ws,kind):
   for _ in range(12):
    x=await ws.receive_json(timeout=2)
    if x.get('type')=='group-call-'+kind:return x
   self.fail('missing '+kind)
  try:
   await send(a,'start',video=True);self.assertTrue((await read(b,'invite'))['video']);await read(c,'invite')
   self.assertEqual((await read(a,'state'))['participants'][uid[0]],'joined')
   await a.send_json({**e,'type':'group-call-signal','to':uid[1],'kind':'offer','description':{'type':'offer','sdp':'v=0 forbidden'}})
   await send(b,'accept');await send(c,'accept')
   for _ in range(3):
    x=await read(a,'state')
    if list(x['participants'].values()).count('joined')==3:break
   self.assertEqual(set(x['participants'].values()),{'joined'})
   await a.send_json({**e,'type':'group-call-signal','to':uid[1],'kind':'offer','description':{'type':'offer','sdp':'v=0 test'}})
   sig=await read(b,'signal');self.assertEqual(sig['from'],uid[0]);self.assertEqual(sig['to'],uid[1]);self.assertEqual(sig['description']['sdp'],'v=0 test')
   lo,hi=sorted([(uid[0],a),(uid[1],b)],key=lambda p:p[0])
   await lo[1].send_json({**e,'type':'group-call-signal','to':hi[0],'kind':'restart-request'})
   await hi[1].send_json({**e,'type':'group-call-signal','to':lo[0],'kind':'restart-request','junk':'ignored'})
   request=await read(lo[1],'signal');self.assertEqual(request['kind'],'restart-request');self.assertEqual(request['from'],hi[0]);self.assertNotIn('junk',request)
   await send(c,'leave');await read(c,'end');await read(a,'state')
   await a.send_json({**e,'type':'group-call-signal','to':uid[2],'kind':'offer','description':{'type':'offer','sdp':'v=0 test'}})
   with self.assertRaises(asyncio.TimeoutError):await c.receive_json(timeout=.15)
   await send(a,'leave');await read(b,'end');self.assertFalse(self.app['store'].group_calls.calls)
  finally:await a.close();await b.close();await c.close()
 async def test_recovery_account_binding_rejects_other_accounts_and_rotation(self):
  request={'login':'alice','password':'test-password-123','pub':PUB,'new_device':False,'recovery_account':self.a['user']['id']}
  for update in ({'login':'bob'},{'pub':NEW_PUB},{'pub':NEW_PUB,'new_device':True},{'new_device':True}):
   r=await self.client.post('/api/session',json={**request,**update});self.assertEqual(r.status,409,await r.text())
  r=await self.client.post('/api/session',json={**request,'password':'wrong-password'});self.assertEqual(r.status,401)
  self.assertEqual((await self.client.get('/api/me',headers=self.h(self.a))).status,200)
  r=await self.client.post('/api/session',json=request);self.assertEqual(r.status,200,await r.text());self.assertFalse((await r.json())['deviceChanged'])
 async def test_recovery_cannot_create_account(self):
  r=await self.client.post('/api/session',json={'register':True,'privacy_accepted':True,'name':'New','nick':'new_recovery','phone':'+905003399999','password':'123456','invite':'0032','pub':PUB,'recovery_account':self.a['user']['id']});self.assertEqual(r.status,400)
 async def test_typing_relay_is_ephemeral_member_scoped_and_stops_on_disconnect(self):
  async def connect(user):
   ws=await self.client.ws_connect('/api/socket');await ws.send_json({'token':user['token']});self.assertIn('typing-v1',(await ws.receive_json())['features']);return ws
  a,b,c=[await connect(x) for x in (self.a,self.b,self.c)]
  try:
   event={'type':'typing-v1','room':self.room,'active':True,'from':'spoof','text':'must not relay'}
   await a.send_json(event);got=await b.receive_json(timeout=2)
   self.assertEqual(got,{'type':'typing-v1','room':self.room,'active':True,'from':self.a['user']['id']})
   await c.send_json(event)
   with self.assertRaises(asyncio.TimeoutError):await b.receive_json(timeout=.12)
   await a.send_json(event)
   with self.assertRaises(asyncio.TimeoutError):await b.receive_json(timeout=.12)
   with self.assertRaises(asyncio.TimeoutError):await c.receive_json(timeout=.12)
   self.assertEqual(self.app['store'].one('SELECT count(*) AS n FROM messages')['n'],0)
   await a.close();self.assertFalse((await b.receive_json(timeout=2))['active'])
  finally:
   await a.close();await b.close();await c.close()
 async def test_typing_reconnect_old_socket_does_not_clear_new_socket(self):
  async def connect(user):
   ws=await self.client.ws_connect('/api/socket');await ws.send_json({'token':user['token']});await ws.receive_json();return ws
  old,new,b=[await connect(x) for x in (self.a,self.a,self.b)]
  try:
   event={'type':'typing-v1','room':self.room,'active':True}
   await old.send_json(event);self.assertTrue((await b.receive_json(timeout=2))['active'])
   await new.send_json(event);self.assertTrue((await b.receive_json(timeout=2))['active'])
   await old.close()
   with self.assertRaises(asyncio.TimeoutError):await b.receive_json(timeout=.15)
   await new.send_json({**event,'active':False});self.assertFalse((await b.receive_json(timeout=2))['active'])
  finally:await old.close();await new.close();await b.close()
 async def test_recording_is_member_scoped_and_stops_on_background(self):
  async def connect(user):
   ws=await self.client.ws_connect('/api/socket');await ws.send_json({'token':user['token'],'presenceSocket':True});self.assertIn('recording-v1',(await ws.receive_json())['features']);return ws
  a=await connect(self.a);b=await connect(self.b);c=await connect(self.c)
  async def next_kind(ws,kind):
   while True:
    event=await ws.receive_json(timeout=2)
    if event.get('type')==kind:return event
  try:
   await a.send_json({'type':'presence-socket-v2','foreground':True,'preference':'online'});await next_kind(b,'profile')
   await a.send_json({'type':'recording-v1','room':self.room,'active':True,'audio':'not relayed','from':'spoof'})
   self.assertEqual(await next_kind(b,'recording-v1'),{'type':'recording-v1','room':self.room,'active':True,'from':self.a['user']['id']})
   with self.assertRaises(asyncio.TimeoutError):await c.receive_json(timeout=.1)
   await a.send_json({'type':'presence-socket-v2','foreground':False,'preference':'online'});self.assertFalse((await next_kind(b,'recording-v1'))['active'])
   rooms=await (await self.client.get('/api/rooms',headers=self.h(self.b))).json();peer=next(x for x in rooms[0]['members'] if x['id']==self.a['user']['id']);self.assertIsInstance(peer['last_seen'],int);self.assertEqual(peer['status'],'offline')
  finally:await a.close();await b.close();await c.close()
 async def test_typing_blocked_peer_and_invalid_event(self):
  a=await self.client.ws_connect('/api/socket');await a.send_json({'token':self.a['token']});await a.receive_json()
  b=await self.client.ws_connect('/api/socket');await b.send_json({'token':self.b['token']});await b.receive_json()
  try:
   await self.client.post('/api/blocks',headers=self.h(self.b),json={'peer':self.a['user']['id']})
   for active in ['true',True]:await a.send_json({'type':'typing-v1','room':self.room,'active':active})
   with self.assertRaises(asyncio.TimeoutError):await b.receive_json(timeout=.2)
  finally:await a.close();await b.close()
 async def test_six_character_password_and_short_rejection(self):
  for password,expected in [('12345',400),('123456',200)]:
   r=await self.client.post('/api/session',json={'register':True,'privacy_accepted':True,'name':'Six','nick':'six_password','phone':'+905004444444','password':password,'invite':'0032','pub':PUB})
   self.assertEqual(r.status,expected,await r.text())
  r=await self.client.post('/api/session',json={'login':'six_password','password':'123456','pub':PUB})
  self.assertEqual(r.status,200,await r.text())
 async def test_health_identifies_api(self):
  r=await self.client.get('/health');self.assertEqual(r.status,200)
  self.assertEqual((await r.json())['service'],'fs-mesajlasma')
 async def test_registration_rejects_malformed_fields(self):
  valid={'register':True,'privacy_accepted':True,'name':'Valid','nick':'valid_qa','phone':'+999123456789','password':'123456','invite':'0032','pub':PUB}
  for field,bad in [('name',{}),('nick',None),('phone','++12345678901'),('pub',None),('password',[]),('name','x'*121)]:
   r=await self.client.post('/api/session',json={**valid,field:bad});self.assertEqual(r.status,400,(field,await r.text()))
 async def test_message_pagination_same_millisecond(self):
  timestamp=now()-1000
  for n in range(85):
   self.client.server.app['store'].run('INSERT INTO messages VALUES(?,?,?,?,?,?,?)',(f'qa_page_{n:03d}',self.room,self.a['user']['id'],json.dumps(self.env()),timestamp,None,None))
  r=await self.client.get('/api/rooms/'+self.room+'/messages',headers=self.h(self.b));first=await r.json();self.assertEqual(len(first),80)
  cursor=first[0];r=await self.client.get('/api/rooms/'+self.room+'/messages',params={'before':str(cursor['created']),'before_id':cursor['id']},headers=self.h(self.b));second=await r.json();self.assertEqual(len(second),5)
  self.assertEqual(len({m['id'] for m in first+second}),85)
 async def test_stun_only_is_not_reported_as_turn(self):
  from unittest.mock import patch
  with patch.dict('os.environ',{'FS_ICE_SERVERS':'[{"urls":"stun:example.com:3478"}]','FS_TURN_HOST':''}):
   r=await self.client.get('/api/config',headers=self.h(self.a));self.assertIs((await r.json())['turnConfigured'],False)
 async def test_admin_deletes_user_with_messages_and_call_history(self):
  store=self.client.server.app['store'];store.run("INSERT INTO app_config VALUES('admin',?)",(self.a['user']['id'],))
  r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.b),json={'envelopes':self.env()});self.assertEqual(r.status,201)
  store.run('INSERT INTO calls VALUES(?,?,?,?,?,?,?,?,?)',('qa_call',self.room,self.b['user']['id'],self.a['user']['id'],0,now(),None,now(),'ended'))
  r=await self.client.delete('/api/admin/users/'+self.b['user']['id'],headers=self.h(self.a));self.assertEqual(r.status,200,await r.text())
  self.assertIsNone(store.one('SELECT 1 FROM users WHERE id=?',(self.b['user']['id'],)))
 async def test_authentication_required(self):
  for path in ['/api/me','/api/rooms','/api/contacts','/api/saved','/api/events','/api/config']:
   r=await self.client.get(path);self.assertEqual(r.status,401,path)
 async def test_account_and_contacts_hide_phone(self):
  r=await self.client.get('/api/people?q=alice',headers=self.h(self.b));people=await r.json();self.assertEqual(len(people),1);self.assertNotIn('phone',people[0]);self.assertNotIn('password',people[0])
  r=await self.client.post('/api/contacts',headers=self.h(self.a),json={'peer':self.b['user']['id']});self.assertEqual(r.status,200)
  r=await self.client.delete('/api/contacts/'+self.b['user']['id'],headers=self.h(self.a));self.assertEqual(r.status,200)
  r=await self.client.get('/api/contacts',headers=self.h(self.a));self.assertEqual((await r.json())[0]['deleted'],1)
 async def test_duplicate_user_rejected(self):
  r=await self.client.post('/api/session',json={'register':True,'privacy_accepted':True,'name':'Alice','nick':'alice','phone':'+905004444444','password':'test-password-123','invite':'0032','pub':PUB});self.assertEqual(r.status,409)
 async def test_invalid_invitation(self):
  r=await self.client.post('/api/session',json={'register':True,'privacy_accepted':True,'name':'David','nick':'david','phone':'+905004444444','password':'test-password-123','invite':'9999','pub':PUB});self.assertEqual(r.status,400)
 async def test_login_wrong_password_and_wrong_key(self):
  r=await self.client.post('/api/session',json={'login':'alice','password':'wrong-password','pub':PUB});self.assertEqual(r.status,401)
  r=await self.client.post('/api/session',json={'login':'alice','password':'test-password-123','pub':{**PUB,'x':'other'}});self.assertEqual(r.status,409)
  r=await self.client.post('/api/session',json={'login':'alice','password':'test-password-123','pub':PUB});self.assertEqual(r.status,200)
 async def test_chat_membership_and_per_user_ciphertext(self):
  await self.message();r=await self.client.get('/api/rooms/'+self.room+'/messages',headers=self.h(self.b));messages=await r.json();self.assertEqual(messages[0]['envelope'],ENVELOPE);self.assertNotIn('envelopes',messages[0]);self.assertNotIn('text',messages[0])
  r=await self.client.get('/api/rooms/'+self.room+'/messages',headers=self.h(self.c));self.assertEqual(r.status,403)
 async def test_cannot_send_incomplete_envelopes(self):
  r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.a),json={'envelopes':{self.a['user']['id']:ENVELOPE}});self.assertEqual(r.status,400)
 async def test_cannot_edit_others_message(self):
  m=await self.message()
  for method in ['PATCH']:
   r=await self.client.request(method,'/api/messages/'+m['id'],headers=self.h(self.b),json={'envelopes':self.env()});self.assertEqual(r.status,403)
 async def test_edit_delete_and_saved_cascade(self):
  m=await self.message();r=await self.client.patch('/api/messages/'+m['id'],headers=self.h(self.a),json={'envelopes':self.env()});self.assertEqual(r.status,200)
  r=await self.client.post('/api/saved',headers=self.h(self.b),json={'id':m['id']});self.assertEqual(len(await r.json()),1)
  r=await self.client.delete('/api/messages/'+m['id'],headers=self.h(self.a));self.assertEqual(r.status,200)
  r=await self.client.get('/api/saved',headers=self.h(self.b));self.assertEqual(await r.json(),[])
 async def test_encrypted_history_and_revision_conflict_and_delete(self):
  m=await self.message();path='/api/messages/'+m['id'];edit={k:{**v,'data':base64.b64encode(b'new encrypted content').decode()} for k,v in self.env().items()}
  data={'envelopes':edit,'save_revision':True,'expected_edited':None}
  self.assertEqual((await self.client.patch(path,headers=self.h(self.b),json=data)).status,403)
  self.assertEqual((await self.client.patch(path,headers=self.h(self.a),json=data)).status,200)
  self.assertEqual((await self.client.patch(path,headers=self.h(self.a),json=data)).status,409)
  self.assertEqual((await self.client.get(path+'/history',headers=self.h(self.c))).status,403)
  r=await self.client.get(path+'/history',headers=self.h(self.b));history=await r.json();self.assertEqual(len(history),1);self.assertEqual(history[0]['envelope'],ENVELOPE);self.assertEqual(history[0]['sender_pub']['x'],PUB['x']);self.assertNotIn('envelopes',history[0])
  row=(await (await self.client.get('/api/rooms/'+self.room+'/messages',headers=self.h(self.b))).json())[0];self.assertEqual(row['history_count'],1);self.assertEqual(row['envelope'],edit[self.b['user']['id']])
  self.assertEqual((await self.client.delete(path,headers=self.h(self.a))).status,200);self.assertEqual((await self.client.get(path+'/history',headers=self.h(self.b))).status,404);self.assertFalse(self.app['store'].all('SELECT * FROM message_revisions'))
 async def test_legacy_updates_do_not_save_history(self):
  m=await self.message();path='/api/messages/'+m['id'];self.assertEqual((await self.client.patch(path,headers=self.h(self.a),json={'envelopes':self.env()})).status,200)
  self.assertEqual(await (await self.client.get(path+'/history',headers=self.h(self.b))).json(),[])
 async def test_explicit_receipts_distinguish_accept_delivery_read_and_delete(self):
  m=await self.message();mid=m['id'];path='/api/rooms/'+self.room+'/receipts';data={'delivered':[mid]}
  self.assertEqual(m['receipts_v2'],[]);self.assertEqual((await self.client.post(path,headers=self.h(self.c),json=data)).status,403)
  self.assertEqual((await (await self.client.post(path,headers=self.h(self.a),json=data)).json())['receipts'],{})
  ws=await self.client.ws_connect('/api/socket');await ws.send_json({'token':self.a['token']});await ws.receive_json()
  try:
   first=(await (await self.client.post(path,headers=self.h(self.b),json=data)).json())['receipts'][mid];self.assertIsNone(first['read_at'])
   event=await ws.receive_json(timeout=2);self.assertEqual(event['type'],'receipt-v2');self.assertEqual(event['receipt'],first)
   again=(await (await self.client.post(path,headers=self.h(self.b),json=data)).json())['receipts'][mid];self.assertEqual(first,again)
   read=(await (await self.client.post(path,headers=self.h(self.b),json={'read':[mid]})).json())['receipts'][mid];self.assertEqual(read['delivered'],first['delivered']);self.assertGreaterEqual(read['read_at'],first['delivered']);self.assertEqual((await ws.receive_json(timeout=2))['receipt'],read)
   row=(await (await self.client.get('/api/rooms/'+self.room+'/messages',headers=self.h(self.a))).json())[0];self.assertEqual(row['receipts_v2'],[read]);self.assertIn(self.b['user']['id'],row['read_by'])
   self.assertEqual((await self.client.delete('/api/messages/'+mid,headers=self.h(self.a))).status,200);self.assertFalse(self.app['store'].all('SELECT * FROM message_receipts'))
  finally:await ws.close()
 async def test_idempotent_message_retry(self):
  await self.message();r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.a),json={'id':'test_message_123','envelopes':self.env()});self.assertEqual(r.status,200)
  r=await self.client.get('/api/rooms/'+self.room+'/messages',headers=self.h(self.a));self.assertEqual(len(await r.json()),1)
 async def test_durable_upload_create_retries_are_idempotent_and_owner_scoped(self):
  ident='durable_upload_id_001';payload={'client_id':ident,'room':self.room,'size':20}
  r=await self.client.post('/api/uploads',headers=self.h(self.a),json=payload);self.assertEqual(r.status,201);self.assertEqual((await r.json())['id'],ident)
  r=await self.client.put('/api/uploads/'+ident,headers={**self.h(self.a),'Upload-Offset':'0'},data=b'1234567890');self.assertEqual(r.status,200)
  r=await self.client.post('/api/uploads',headers=self.h(self.a),json=payload);self.assertEqual(r.status,200);self.assertEqual((await r.json())['offset'],10)
  self.assertEqual((await self.client.post('/api/uploads',headers=self.h(self.b),json=payload)).status,409)
  self.assertEqual((await self.client.post('/api/uploads',headers=self.h(self.a),json={**payload,'size':21})).status,409)
  self.assertEqual(self.app['store'].one('SELECT count(*) n FROM uploads')['n'],1)
 async def test_pending_delivery_pages_are_member_scoped_and_do_not_mark_read(self):
  m=await self.message();path='/api/delivery-pending'
  r=await self.client.get(path,headers=self.h(self.b));self.assertEqual(r.status,200);rows=await r.json();self.assertEqual([x['id'] for x in rows],[m['id']]);self.assertNotIn('envelopes',rows[0]);self.assertEqual(rows[0]['envelope'],ENVELOPE)
  for actor in (self.a,self.c):self.assertEqual(await (await self.client.get(path,headers=self.h(actor))).json(),[])
  self.assertFalse(self.app['store'].all('SELECT * FROM message_receipts'))
  after=await self.client.get(path,params={'after':str(m['created']),'after_id':m['id']},headers=self.h(self.b));self.assertEqual(await after.json(),[])
  r=await self.client.post('/api/rooms/'+self.room+'/receipts',headers=self.h(self.b),json={'delivered':[m['id']],'read':[]});self.assertEqual(r.status,200)
  self.assertEqual(await (await self.client.get(path,headers=self.h(self.b))).json(),[])
  self.assertIsNone(self.app['store'].one('SELECT read_at FROM message_receipts WHERE message=?',(m['id'],))['read_at'])
 async def test_upload_limit_and_resume_and_access(self):
  r=await self.client.post('/api/uploads',headers=self.h(self.a),json={'room':self.room,'size':MAX_FILE+17});self.assertEqual(r.status,413)
  r=await self.client.post('/api/uploads',headers=self.h(self.a),json={'room':self.room,'size':6});ident=(await r.json())['id']
  r=await self.client.put('/api/uploads/'+ident,headers={**self.h(self.a),'Upload-Offset':'0'},data=b'abc');self.assertEqual((await r.json())['offset'],3)
  r=await self.client.head('/api/uploads/'+ident,headers=self.h(self.a));self.assertEqual(r.headers['Upload-Offset'],'3')
  r=await self.client.put('/api/uploads/'+ident,headers={**self.h(self.a),'Upload-Offset':'0'},data=b'bad');self.assertEqual(r.status,409)
  r=await self.client.put('/api/uploads/'+ident,headers={**self.h(self.b),'Upload-Offset':'3'},data=b'def');self.assertEqual(r.status,403)
  r=await self.client.put('/api/uploads/'+ident,headers={**self.h(self.a),'Upload-Offset':'3'},data=b'def');self.assertTrue((await r.json())['complete'])
  r=await self.client.get('/api/uploads/'+ident,headers=self.h(self.b));self.assertEqual(await r.read(),b'abcdef')
  r=await self.client.get('/api/uploads/'+ident,headers=self.h(self.c));self.assertEqual(r.status,403)
 async def test_room_reused_for_same_two_people(self):
  r=await self.client.post('/api/rooms',headers=self.h(self.b),json={'members':[self.a['user']['id']]});self.assertEqual((await r.json())['id'],self.room)
 async def test_logout_revokes_token(self):
  r=await self.client.post('/api/logout',headers=self.h(self.a));self.assertEqual(r.status,200)
  r=await self.client.get('/api/me',headers=self.h(self.a));self.assertEqual(r.status,401)
 async def test_cross_origin_rejected(self):
  r=await self.client.get('/api/me',headers={**self.h(self.a),'Origin':'https://attacker.invalid'});self.assertEqual(r.status,403)
 async def test_availability_and_settings(self):
  r=await self.client.patch('/api/me',headers=self.h(self.a),json={'available':False,'status':'busy','theme':'light'});b=await r.json();self.assertFalse(b['user']['available']);self.assertEqual(b['settings']['theme'],'light')
 async def test_call_signaling(self):
  a=await self.client.ws_connect('/api/socket');b=await self.client.ws_connect('/api/socket')
  await a.send_json({'token':self.a['token']});await b.send_json({'token':self.b['token']});await a.receive_json();await b.receive_json()
  await a.send_json({'type':'call','room':self.room,'video':False});received=await b.receive_json(timeout=2);self.assertEqual(received['type'],'call');self.assertEqual(received['from'],self.a['user']['id']);await a.receive_json()
  await b.send_json({'type':'accepted','room':self.room});self.assertEqual((await a.receive_json(timeout=2))['type'],'accepted');await b.receive_json()
  await a.send_json({'type':'hangup','room':self.room});self.assertEqual((await b.receive_json(timeout=2))['type'],'hangup')
  await a.close();await b.close()
 async def test_unavailable_rejects_call(self):
  await self.client.patch('/api/me',headers=self.h(self.b),json={'available':False})
  a=await self.client.ws_connect('/api/socket');await a.send_json({'token':self.a['token']});await a.receive_json();await a.send_json({'type':'call','room':self.room,'video':False});self.assertEqual((await a.receive_json(timeout=2))['type'],'call-rejected');await a.close()
 async def test_blocking_prevents_send_and_can_be_removed(self):
  peer=self.b['user']['id'];r=await self.client.post('/api/blocks',headers=self.h(self.a),json={'peer':peer});self.assertEqual(r.status,200)
  r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.b),json={'envelopes':self.env()});self.assertEqual(r.status,403)
  r=await self.client.delete('/api/blocks/'+peer,headers=self.h(self.a));self.assertEqual(r.status,200)
  await self.message()
 async def test_administrator_authorization_and_ciphertext_envelope(self):
  r=await self.client.get('/api/admin/inventory/users',headers=self.h(self.a));self.assertEqual(r.status,403)
  self.app['store'].run("INSERT INTO app_config VALUES('admin',?)",(self.c['user']['id'],))
  r=await self.client.get('/api/rooms',headers=self.h(self.a));self.assertEqual((await r.json())[0]['audit']['id'],self.c['user']['id'])
  r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.a),json={'envelopes':self.env()});self.assertEqual(r.status,400)
  env={**self.env(),self.c['user']['id']:ENVELOPE};r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.a),json={'envelopes':env});self.assertEqual(r.status,201);mid=(await r.json())['id']
  r=await self.client.get('/api/admin/rooms/'+self.room+'/messages',headers=self.h(self.c));self.assertEqual((await r.json())[0]['envelope'],ENVELOPE)
  r=await self.client.delete('/api/admin/messages/'+mid,headers=self.h(self.b));self.assertEqual(r.status,403)
  r=await self.client.delete('/api/admin/messages/'+mid,headers=self.h(self.c));self.assertEqual(r.status,200)
 async def test_file_is_erased_when_its_message_is_deleted(self):
  r=await self.client.post('/api/uploads',headers=self.h(self.a),json={'room':self.room,'size':3});ident=(await r.json())['id']
  r=await self.client.put('/api/uploads/'+ident,headers={**self.h(self.a),'Upload-Offset':'0'},data=b'abc');self.assertTrue((await r.json())['complete'])
  r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.a),json={'id':'file_message_123','envelopes':self.env(),'uploads':[ident]});self.assertEqual(r.status,201)
  path=Path(self.tmp.name)/ident;self.assertTrue(path.exists())
  r=await self.client.delete('/api/messages/file_message_123',headers=self.h(self.a));self.assertEqual(r.status,200);self.assertFalse(path.exists())
  r=await self.client.get('/api/uploads/'+ident,headers=self.h(self.b));self.assertEqual(r.status,404)
 async def test_privacy_consent_is_required(self):
  r=await self.client.post('/api/session',json={'register':True,'name':'David','nick':'david','phone':'+905004444444','password':'test-password-123','invite':'0032','pub':PUB});self.assertEqual(r.status,400)
 async def test_read_receipt_requires_membership(self):
  m=await self.message();path='/api/rooms/'+self.room+'/read'
  r=await self.client.post(path,headers=self.h(self.c),json={'message':m['id']});self.assertEqual(r.status,403)
  r=await self.client.post(path,headers=self.h(self.b),json={'message':m['id']});self.assertEqual(r.status,200)
  r=await self.client.get('/api/rooms/'+self.room+'/messages',headers=self.h(self.a));self.assertIn(self.b['user']['id'],(await r.json())[0]['read_by'])
 async def test_media_listing_is_scoped_to_chat_members(self):
  r=await self.client.post('/api/uploads',headers=self.h(self.a),json={'room':self.room,'size':3});ident=(await r.json())['id']
  await self.client.put('/api/uploads/'+ident,headers={**self.h(self.a),'Upload-Offset':'0'},data=b'abc')
  r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.a),json={'id':'media_message_123','envelopes':self.env(),'uploads':[ident]});self.assertEqual(r.status,201)
  r=await self.client.get('/api/media',headers=self.h(self.b));self.assertEqual(len(await r.json()),1)
  r=await self.client.get('/api/media',headers=self.h(self.c));self.assertEqual(await r.json(),[])
 async def test_cancel_upload_requires_owner_and_unreferenced_file(self):
  r=await self.client.post('/api/uploads',headers=self.h(self.a),json={'room':self.room,'size':3});ident=(await r.json())['id']
  r=await self.client.delete('/api/uploads/'+ident,headers=self.h(self.b));self.assertEqual(r.status,403)
  r=await self.client.delete('/api/uploads/'+ident,headers=self.h(self.a));self.assertEqual(r.status,200)
  r=await self.client.head('/api/uploads/'+ident,headers=self.h(self.a));self.assertEqual(r.status,404)
 async def test_reinstall_login_keeps_account_and_revokes_previous_device(self):
  await self.client.post('/api/contacts',headers=self.h(self.a),json={'peer':self.b['user']['id']})
  message=await self.message()
  self.app['store'].run('DELETE FROM message_keys WHERE message=?',(message['id'],))
  ws=await self.client.ws_connect('/api/socket');await ws.send_json({'token':self.a['token']});await ws.receive_json()
  r=await self.client.post('/api/session',json={'login':'alice','password':'test-password-123','pub':NEW_PUB,'new_device':True})
  self.assertEqual(r.status,200,await r.text());user=await r.json();self.assertTrue(user['deviceChanged']);self.assertEqual(user['user']['id'],self.a['user']['id'])
  self.assertEqual((await ws.receive_json(timeout=2))['type'],'session-revoked');await ws.close()
  self.assertEqual((await self.client.get('/api/me',headers=self.h(self.a))).status,401)
  r=await self.client.get('/api/rooms',headers=self.h(user));self.assertEqual((await r.json())[0]['id'],self.room)
  r=await self.client.get('/api/contacts',headers=self.h(user));self.assertEqual((await r.json())[0]['id'],self.b['user']['id'])
  r=await self.client.get('/api/rooms/'+self.room+'/messages',headers=self.h(self.b));self.assertEqual((await r.json())[0]['sender_pub'],PUB)
  self.assertEqual(self.app['store'].one('SELECT count(*) n FROM users WHERE id=?',(user['user']['id'],))['n'],1)
 async def test_reinstall_login_wrong_password_or_invalid_public_key_changes_nothing(self):
  for password,pub,status in [('wrong-password',NEW_PUB,401),('test-password-123',{**NEW_PUB,'x':'invalid'},400),('test-password-123',{**NEW_PUB,'d':'private'},400)]:
   r=await self.client.post('/api/session',json={'login':'alice','password':password,'pub':pub,'new_device':True});self.assertEqual(r.status,status)
  r=await self.client.get('/api/me',headers=self.h(self.a));self.assertEqual(r.status,200);self.assertEqual((await r.json())['user']['pub'],PUB)
 async def test_stale_recipient_key_is_rejected_and_fresh_key_is_accepted(self):
  r=await self.client.post('/api/session',json={'login':'bob','password':'test-password-123','pub':NEW_PUB,'new_device':True});self.assertEqual(r.status,200)
  body={'id':'recipient_rotation_test','envelopes':self.env(),'recipient_pubs':{self.a['user']['id']:PUB,self.b['user']['id']:PUB}}
  r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.a),json=body);self.assertEqual(r.status,409);self.assertEqual((await r.json())['code'],'KEY_CHANGED')
  body['recipient_pubs'][self.b['user']['id']]=NEW_PUB
  r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.a),json=body);self.assertEqual(r.status,201,await r.text())
 async def test_existing_device_login_and_turkish_phone_alias_do_not_replace_identity(self):
  r=await self.client.post('/api/session',json={'login':'0 (500) 111 11 11','password':'test-password-123','pub':PUB,'new_device':True});self.assertEqual(r.status,200,await r.text());result=await r.json();self.assertFalse(result['deviceChanged']);self.assertEqual(result['user']['id'],self.a['user']['id'])
  self.assertEqual((await self.client.get('/api/me',headers=self.h(self.a))).status,200)
 async def test_live_relay_delivers_only_to_room_member_and_replay_ignored(self):
  m=await self.message();a=await self.client.ws_connect('/api/socket');b=await self.client.ws_connect('/api/socket');c=await self.client.ws_connect('/api/socket')
  try:
   for sock,user in ((a,self.a),(b,self.b),(c,self.c)):
    await sock.send_json({'token':user['token']});self.assertIn('emoji-interaction-v1',(await sock.receive_json())['features'])
   envelope={'iv':base64.b64encode(b'123456789012').decode(),'data':base64.b64encode(b'0123456789abcdef').decode()}
   event={'type':'emoji-interaction-v1','room':self.room,'target':m['id'],'id':'event123','envelopes':{self.b['user']['id']:envelope,self.c['user']['id']:envelope}}
   await a.send_json(event);got=await b.receive_json(timeout=2);self.assertEqual(got['envelope'],envelope);self.assertEqual(got['from'],self.a['user']['id']);self.assertNotIn('envelopes',got)
   await a.send_json(event);await c.send_json({**event,'id':'unauthorized'});await a.send_json({**event,'id':'missingtarget','target':'missing'});
   for sock in (b,c):
    with self.assertRaises(asyncio.TimeoutError):await sock.receive_json(timeout=.15)
   self.assertEqual(self.app['store'].one('SELECT count(*) AS n FROM messages')['n'],1)
  finally:
   for sock in (a,b,c):await sock.close()
 async def test_direct_delete_both_and_outsider_denial(self):
  m=await self.message();path='/api/messages/'+m['id'];self.assertEqual((await self.client.delete(path,headers=self.h(self.c))).status,403)
  a=await self.client.ws_connect('/api/socket');await a.send_json({'token':self.a['token']});await a.receive_json()
  try:
   self.assertEqual((await self.client.delete(path,headers=self.h(self.b))).status,200);got=await a.receive_json(timeout=2);self.assertTrue(got['deleted']);self.assertEqual(got['id'],m['id']);self.assertIsNone(self.app['store'].one('SELECT 1 FROM messages WHERE id=?',(m['id'],)))
  finally:await a.close()
 async def test_cache_reconciliation_after_offline_deletion(self):
  m=await self.message();path='/api/rooms/'+self.room+'/messages/check'
  payload={'ids':[m['id'],'missing_message_123']}
  r=await self.client.post(path,headers=self.h(self.b),json=payload);self.assertEqual(r.status,200);self.assertEqual((await r.json())['existing'],[m['id']])
  self.assertEqual((await self.client.post(path,headers=self.h(self.c),json=payload)).status,403)
  self.assertEqual((await self.client.post(path,json=payload)).status,401)
  # Fill the newest page so the deleted original cannot be inferred from that page alone.
  store=self.app['store']
  with store.db:
   store.db.execute('UPDATE messages SET created=? WHERE id=?',(m['created']-1000,m['id']))
   store.db.executemany('INSERT INTO messages VALUES(?,?,?,?,?,?,?)',[(f'newer_message_{i:03d}',self.room,self.a['user']['id'],json.dumps(self.env()),m['created']-999+i,None,None) for i in range(81)])
  latest=await self.client.get('/api/rooms/'+self.room+'/messages',headers=self.h(self.b));latest=await latest.json();self.assertEqual(len(latest),80);self.assertNotIn(m['id'],[x['id'] for x in latest])
  self.assertEqual((await self.client.delete('/api/messages/'+m['id'],headers=self.h(self.a))).status,200)
  r=await self.client.post(path,headers=self.h(self.b),json=payload);self.assertEqual((await r.json())['existing'],[])
  self.assertIsNone(self.app['store'].one('SELECT 1 FROM messages WHERE id=?',(m['id'],)))
 async def test_cache_reconciliation_validation(self):
  path='/api/rooms/'+self.room+'/messages/check'
  for bad in [None,'abc',[1],['short'],['valid_message_123']*201]:
   self.assertEqual((await self.client.post(path,headers=self.h(self.a),json={'ids':bad})).status,400)
  r=await self.client.post(path,headers=self.h(self.a),json={'ids':[]});self.assertEqual(await r.json(),{'existing':[]})
 async def test_group_delete_still_sender_only(self):
  ids=[self.a['user']['id'],self.b['user']['id'],self.c['user']['id']];r=await self.client.post('/api/rooms',headers=self.h(self.a),json={'members':ids});room=(await r.json())['id']
  r=await self.client.post('/api/rooms/'+room+'/messages',headers=self.h(self.a),json={'id':'group_message_123','envelopes':{x:ENVELOPE for x in ids}});self.assertEqual(r.status,201)
  self.assertEqual((await self.client.delete('/api/messages/group_message_123',headers=self.h(self.b))).status,403)
  self.assertEqual((await self.client.delete('/api/messages/group_message_123',headers=self.h(self.a))).status,200)
 async def test_presence_foreground_heartbeat_and_disconnect(self):
  store=self.app['store'];store.presence.ttl=.20
  a=await self.client.ws_connect('/api/socket');await a.send_json({'token':self.a['token']});await a.receive_json()
  async def status():
   r=await self.client.get('/api/people?q=alice',headers=self.h(self.b));return (await r.json())[0]['status']
  try:
   self.assertEqual(await status(),'offline')
   r=await self.client.patch('/api/me',headers=self.h(self.a),json={'status':'online','available':False});self.assertFalse((await r.json())['user']['available']);self.assertEqual(await status(),'online')
   await asyncio.sleep(.25);self.assertEqual(await status(),'offline')
   await self.client.patch('/api/me',headers=self.h(self.a),json={'status':'busy'});self.assertEqual(await status(),'busy')
   await a.close();await asyncio.sleep(.05);self.assertEqual(await status(),'offline')
  finally:await a.close()
 async def test_presence_v2_background_reconnect_and_availability(self):
  async def connect():
   ws=await self.client.ws_connect('/api/socket');await ws.send_json({'token':self.a['token'],'presenceSocket':True});self.assertIn('presence-socket-v2',(await ws.receive_json())['features']);return ws
  async def status(expected):
   for _ in range(30):
    r=await self.client.get('/api/people?q=alice',headers=self.h(self.b));actual=(await r.json())[0]['status']
    if actual==expected:return
    await asyncio.sleep(.01)
   self.assertEqual(actual,expected)
  async def presence(ws,visible,preference='online'):
   await ws.send_json({'type':'presence-socket-v2','foreground':visible,'preference':preference})
  a=await connect();b=None
  try:
   await status('offline');await presence(a,True);await status('online')
   r=await self.client.patch('/api/me',headers=self.h(self.a),json={'available':False});self.assertFalse((await r.json())['user']['available']);await status('online')
   await presence(a,False);await status('offline')
   # A legacy PATCH cannot resurrect a background v2 connection.
   await self.client.patch('/api/me',headers=self.h(self.a),json={'status':'online'});await status('offline')
   await presence(a,True,'busy');await status('busy')
   b=await connect();await presence(b,True);await status('online');await a.close();await status('online')
   await presence(b,True,'offline');await status('offline');await presence(b,True);await status('online')
   await b.close();await status('offline')
  finally:
   await a.close()
   if b:await b.close()
 async def test_presence_v2_expiry_and_background_typing(self):
  store=self.app['store'];store.presence.ttl=.15
  a=await self.client.ws_connect('/api/socket');await a.send_json({'token':self.a['token'],'presenceSocket':True});await a.receive_json()
  b=await self.client.ws_connect('/api/socket');await b.send_json({'token':self.b['token']});await b.receive_json()
  async def next_event(kind):
   while True:
    event=await b.receive_json(timeout=2)
    if event.get('type')==kind:return event
  try:
   await a.send_json({'type':'typing-v1','room':self.room,'active':True})
   with self.assertRaises(asyncio.TimeoutError):await b.receive_json(timeout=.08)
   await a.send_json({'type':'presence-socket-v2','foreground':True,'preference':'online'});await next_event('profile')
   await a.send_json({'type':'typing-v1','room':self.room,'active':True});self.assertTrue((await next_event('typing-v1'))['active'])
   await a.send_json({'type':'presence-socket-v2','foreground':False,'preference':'online'});self.assertFalse((await next_event('typing-v1'))['active']);await next_event('profile')
   await a.send_json({'type':'presence-socket-v2','foreground':True,'preference':'online'});await next_event('profile')
   await asyncio.sleep(.2);self.assertEqual(store.presence.status(self.a['user']['id']),'offline')
  finally:await a.close();await b.close()
 async def test_cursor_preserves_messages_with_same_timestamp(self):
  store=self.app['store'];stamp=1000
  for i in range(85):store.run('INSERT INTO messages VALUES(?,?,?,?,?,?,?)',(f'msg_{i:03}',self.room,self.a['user']['id'],json.dumps(self.env()),stamp,None,None))
  path='/api/rooms/'+self.room+'/messages';r=await self.client.get(path,headers=self.h(self.a));first=await r.json();self.assertEqual(len(first),80)
  r=await self.client.get(path+f'?before={stamp}&before_id='+first[0]['id'],headers=self.h(self.a));second=await r.json();self.assertEqual(len(second),5);self.assertEqual(len({r['id'] for r in first+second}),85)
 async def test_new_device_requires_correct_password_valid_key_and_revokes_previous_token(self):
  def coord(v):return base64.urlsafe_b64encode(v.to_bytes(32,'big')).decode().rstrip('=')
  pub={'kty':'EC','crv':'P-256','x':coord(0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296),'y':coord(0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5)}
  body={'login':'alice','password':'test-password-123','pub':pub,'new_device':True};r=await self.client.post('/api/session',json={**body,'password':'wrong-password'});self.assertEqual(r.status,401)
  r=await self.client.post('/api/session',json={**body,'pub':{**pub,'x':'invalid'}});self.assertEqual(r.status,400)
  r=await self.client.post('/api/session',json=body);self.assertEqual(r.status,200,await r.text());new=await r.json();self.assertTrue(new['deviceChanged']);self.assertEqual(new['user']['id'],self.a['user']['id']);self.assertEqual((await self.client.get('/api/me',headers=self.h(self.a))).status,401)
  self.assertEqual((await self.client.get('/api/me',headers=self.h(new))).status,200)
 async def test_reinstall_phone_password_keeps_same_account_and_room(self):
  def coord(v):return base64.urlsafe_b64encode(v.to_bytes(32,'big')).decode().rstrip('=')
  pub={'kty':'EC','crv':'P-256','x':coord(0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296),'y':coord(0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5)}
  body={'login':'0500 111 11 11','password':'test-password-123','pub':pub,'new_device':True,'register':False}
  r=await self.client.post('/api/session',json={**body,'password':'bad-password'});self.assertEqual(r.status,401)
  r=await self.client.post('/api/session',json=body);self.assertEqual(r.status,200,await r.text());new=await r.json()
  self.assertTrue(new['deviceChanged']);self.assertEqual(new['user']['id'],self.a['user']['id'])
  r=await self.client.get('/api/rooms',headers=self.h(new));self.assertEqual(r.status,200);self.assertIn(self.room,[room['id'] for room in await r.json()])
  self.assertEqual(self.app['store'].one('SELECT COUNT(*) FROM users')[0],3)
  self.assertEqual((await self.client.get('/api/me',headers=self.h(self.a))).status,401)
 async def test_phone_alias_login_and_duplicate_registration(self):
  for number in ['+90 (500) 111-11-11','905001111111','00905001111111','5001111111','05001111111']:
   r=await self.client.post('/api/session',json={'login':number,'password':'test-password-123','pub':PUB,'register':False});self.assertEqual(r.status,200,number);self.assertEqual((await r.json())['user']['id'],self.a['user']['id'])
  r=await self.client.post('/api/session',json={'register':True,'privacy_accepted':True,'name':'Duplicate','nick':'duplicate','phone':'05001111111','password':'test-password-123','invite':'0032','pub':PUB});self.assertEqual(r.status,409)
  self.assertEqual(self.app['store'].one('SELECT COUNT(*) FROM users')[0],3)
 async def test_ambiguous_legacy_phone_alias_does_not_select_other_account(self):
  store=self.app['store'];store.run('UPDATE users SET phone=? WHERE id=?',('05001111111',self.b['user']['id']))
  r=await self.client.post('/api/session',json={'login':'5001111111','password':'test-password-123','pub':PUB});self.assertEqual(r.status,401)
  r=await self.client.post('/api/session',json={'login':'+905001111111','password':'test-password-123','pub':PUB});self.assertEqual(r.status,200);self.assertEqual((await r.json())['user']['id'],self.a['user']['id'])
 async def test_health_contract_for_current_web(self):
  r=await self.client.get('/health');self.assertEqual((await r.json())['service'],'fs-mesajlasma')

 async def test_background_call_snapshot_replays_a_consumed_notification(self):
  a=await self.client.ws_connect('/api/socket')
  try:
   await a.send_json({'token':self.a['token'],'callIds':True});await a.receive_json(timeout=2)
   await a.send_json({'type':'call','room':self.room,'callId':'background_replay','video':True});await a.receive_json(timeout=2)
   async def poll(known=''):
    r=await asyncio.wait_for(self.client.get('/api/events',params={'ringing':'1','known':known},headers=self.h(self.b)),2);self.assertEqual(r.status,200);return await r.json()
   first=await poll();self.assertEqual(first['ringing']['callId'],'background_replay');self.assertTrue(first['ringing']['video']);self.assertGreater(first['ringing']['remainingMs'],0)
   self.assertTrue(self.app['store'].events[self.b['user']['id']].empty())
   # No new WebSocket event: reconnect still obtains the current invitation.
   replay=await poll();self.assertEqual(replay['ringing']['callId'],'background_replay');self.assertEqual(replay['events'],[])
   self.assertLessEqual(replay['ringing']['remainingMs'],first['ringing']['remainingMs'])
   pending=asyncio.create_task(poll('background_replay'));await asyncio.sleep(.05)
   await a.send_json({'type':'hangup','room':self.room,'callId':'background_replay'});await a.receive_json(timeout=2)
   self.assertIsNone((await pending)['ringing'])
  finally:await a.close()
 async def test_background_call_snapshot_stops_on_accept_and_excludes_stale_invitation(self):
  a=await self.client.ws_connect('/api/socket');b=await self.client.ws_connect('/api/socket')
  try:
   for ws,user in [(a,self.a),(b,self.b)]:await ws.send_json({'token':user['token'],'callIds':True});await ws.receive_json(timeout=2)
   await a.send_json({'type':'call','room':self.room,'callId':'background_accept'});await a.receive_json(timeout=2);await b.receive_json(timeout=2)
   async def poll(known=''):
    r=await asyncio.wait_for(self.client.get('/api/events',params={'ringing':'1','known':known},headers=self.h(self.b)),2);return await r.json()
   self.assertEqual((await poll())['ringing']['callId'],'background_accept')
   pending=asyncio.create_task(poll('background_accept'));await asyncio.sleep(.05)
   await b.send_json({'type':'accepted','room':self.room,'callId':'background_accept'});await a.receive_json(timeout=2);await b.receive_json(timeout=2)
   self.assertIsNone((await pending)['ringing'])
   current=await (await self.client.get('/api/calls/current',headers=self.h(self.b))).json();self.assertFalse(current['ringing']);self.assertTrue(current['incoming'])
   await a.send_json({'type':'hangup','room':self.room,'callId':'background_accept'});await a.receive_json(timeout=2);await b.receive_json(timeout=2)
   await a.send_json({'type':'call','room':self.room,'callId':'background_new'});await a.receive_json(timeout=2);await b.receive_json(timeout=2)
   self.assertEqual((await poll('background_accept'))['ringing']['callId'],'background_new')
  finally:await a.close();await b.close()
 async def test_background_snapshot_respects_availability_block_expiry_and_auth(self):
  a=await self.client.ws_connect('/api/socket')
  try:
   await a.send_json({'token':self.a['token'],'callIds':True});await a.receive_json(timeout=2)
   await a.send_json({'type':'call','room':self.room,'callId':'background_privacy'});await a.receive_json(timeout=2)
   async def poll(user,known='background_privacy'):
    r=await asyncio.wait_for(self.client.get('/api/events',params={'ringing':'1','known':known},headers=self.h(user)),2);self.assertEqual(r.status,200);return await r.json()
   self.assertIsNone((await poll(self.a))['ringing']);self.assertIsNone((await poll(self.c))['ringing'])
   store=self.app['store'];uid=self.b['user']['id'];settings=json.loads(store.one('SELECT settings FROM users WHERE id=?',(uid,))['settings'])
   store.run('UPDATE users SET settings=? WHERE id=?',(json.dumps({**settings,'available':False}),uid));self.assertIsNone((await poll(self.b))['ringing'])
   store.run('UPDATE users SET settings=? WHERE id=?',(json.dumps(settings),uid));store.run('INSERT INTO blocks(owner,peer) VALUES(?,?)',(uid,self.a['user']['id']));self.assertIsNone((await poll(self.b))['ringing'])
   store.run('DELETE FROM blocks WHERE owner=?',(uid,));store.calls[uid]['started']=now()-46000;self.assertIsNone((await poll(self.b))['ringing'])
   r=await self.client.get('/api/events?ringing=1');self.assertEqual(r.status,401)
  finally:await a.close()
 async def test_stale_call_id_cannot_end_new_call(self):
  a=await self.client.ws_connect('/api/socket');b=await self.client.ws_connect('/api/socket')
  try:
   for sock,user in [(a,self.a),(b,self.b)]:
    await sock.send_json({'token':user['token'],'callIds':True});self.assertIn('call-id-v1',(await sock.receive_json())['features'])
   for cid in ['first_call','second_call']:
    await a.send_json({'type':'call','room':self.room,'callId':cid,'video':True})
    self.assertEqual((await b.receive_json(timeout=2))['callId'],cid);await a.receive_json(timeout=2)
    current=await (await self.client.get('/api/calls/current',headers=self.h(self.b))).json();self.assertEqual(current['callId'],cid)
    if cid=='second_call':
     await b.send_json({'type':'hangup','room':self.room,'callId':'first_call'})
     await b.send_json({'type':'hangup','room':self.room})
     await b.send_json({'type':'accepted','room':self.room,'callId':cid})
     event=await a.receive_json(timeout=2);self.assertEqual(event['type'],'accepted');self.assertEqual(event['callId'],cid);await b.receive_json(timeout=2)
    await a.send_json({'type':'hangup','room':self.room,'callId':cid});self.assertEqual((await b.receive_json(timeout=2))['callId'],cid);await a.receive_json(timeout=2)
   self.assertIsNone(await (await self.client.get('/api/calls/current',headers=self.h(self.a))).json())
  finally:await a.close();await b.close()
 async def test_expired_socket_does_not_receive_events(self):
  import hashlib
  a=await self.client.ws_connect('/api/socket')
  try:
   await a.send_json({'token':self.a['token']});await a.receive_json(timeout=2)
   store=self.app['store'];store.run('UPDATE sessions SET expires=0 WHERE token=?',(hashlib.sha256(self.a['token'].encode()).hexdigest(),))
   await store.emit(self.a['user']['id'],{'type':'profile','from':self.b['user']['id']})
   with self.assertRaises(asyncio.TimeoutError):await a.receive_json(timeout=.2)
   await a.send_json({'type':'call','room':self.room});msg=await a.receive(timeout=2);self.assertEqual(msg.data,4001)
  finally:await a.close()
 async def test_legacy_caller_modern_receiver_compatible(self):
  a=await self.client.ws_connect('/api/socket');b=await self.client.ws_connect('/api/socket')
  try:
   await a.send_json({'token':self.a['token']});await a.receive_json(timeout=2)
   await b.send_json({'token':self.b['token'],'callIds':True});await b.receive_json(timeout=2)
   await a.send_json({'type':'call','room':self.room});incoming=await b.receive_json(timeout=2);await a.receive_json(timeout=2)
   await b.send_json({'type':'accepted','room':self.room,'callId':incoming['callId']});self.assertEqual((await a.receive_json(timeout=2))['type'],'accepted');await b.receive_json(timeout=2)
   await a.send_json({'type':'hangup','room':self.room});self.assertEqual((await b.receive_json(timeout=2))['callId'],incoming['callId']);await a.receive_json(timeout=2)
  finally:await a.close();await b.close()

 async def test_restart_request_only_accepted_callee_current_id(self):
  a=await self.client.ws_connect('/api/socket');b=await self.client.ws_connect('/api/socket')
  try:
   for ws,u in [(a,self.a),(b,self.b)]:
    await ws.send_json({'token':u['token'],'callIds':True});await ws.receive_json(timeout=2)
   base={'room':self.room,'callId':'recovery_call_0123'}
   await a.send_json({**base,'type':'call','video':True});await a.receive_json(timeout=2);await b.receive_json(timeout=2)
   await b.send_json({**base,'type':'restart-request'})
   with self.assertRaises(asyncio.TimeoutError):await a.receive_json(timeout=.12)
   await b.send_json({**base,'type':'accepted'});await a.receive_json(timeout=2);await b.receive_json(timeout=2)
   await a.send_json({**base,'type':'restart-request'})
   with self.assertRaises(asyncio.TimeoutError):await b.receive_json(timeout=.12)
   await b.send_json({**base,'callId':'stale_call_0123','type':'restart-request'})
   with self.assertRaises(asyncio.TimeoutError):await a.receive_json(timeout=.12)
   await b.send_json({**base,'type':'restart-request','from':'spoof','junk':'no'})
   self.assertEqual(await a.receive_json(timeout=2),{**base,'type':'restart-request','from':self.b['user']['id']})
  finally:await a.close();await b.close()

 async def test_call_recovery_disconnect_timer_is_bound_to_current_outage(self):
  from unittest.mock import patch
  store=self.app['store'];user=self.b['user']['id'];base={'room':self.room,'callId':'recovery_reconnect_test'}
  async def connect(u):
   ws=await self.client.ws_connect('/api/socket');await ws.send_json({'token':u['token'],'callIds':True});await ws.receive_json(timeout=2);return ws
  async def marker():
   for _ in range(100):
    mark=store.calls.get(user,{}).get('disconnect_marker')
    if mark is not None:return mark
    await asyncio.sleep(.01)
   self.fail('disconnect marker not installed')
  a=await connect(self.a);b=await connect(self.b)
  try:
   await a.send_json({**base,'type':'call','video':True});await a.receive_json(timeout=2);await b.receive_json(timeout=2)
   await b.send_json({**base,'type':'accepted'});await a.receive_json(timeout=2);await b.receive_json(timeout=2)
   with patch('app.CALL_DISCONNECT_GRACE',.8):
    await b.close();first=await marker();await asyncio.sleep(.4)
    b=await connect(self.b);self.assertNotIn('disconnect_marker',store.calls[user]);await b.close();second=await marker();self.assertIsNot(first,second)
    await asyncio.sleep(.45);self.assertIn(user,store.calls)
    event=await a.receive_json(timeout=2);self.assertEqual(event['type'],'hangup');self.assertEqual(event['callId'],base['callId']);self.assertNotIn(user,store.calls)
  finally:await a.close();await b.close()

if __name__=='__main__':unittest.main(verbosity=2)
