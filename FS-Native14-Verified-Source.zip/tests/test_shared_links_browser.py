from pathlib import Path
import os
from playwright.sync_api import sync_playwright
web=Path(__file__).resolve().parents[1]/'web'
source=(web/'app.js').read_text()
media=source[source.index('let mediaCursor='):source.index('function showOutbox()')]
urlsource=(web/'call-chat-fixes.js').read_text();urls=urlsource[urlsource.index('export function urlParts'):urlsource.index('export function mapUrls')].replace('export ','')
icons=(web/'icons.js').read_text().replace('export ','')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page(viewport={'width':390,'height':844});page.set_content('<div id="app"></div>');page.add_style_tag(path=str(web/'style.css'))
 page.evaluate('''()=>{const $=s=>document.querySelector(s),app=$('#app'),state={page:'peer',room:{id:'r',kind:'direct'},user:{id:'self'},settings:{},token:'t',mediaFilter:'Tümü',mediaDate:'',mediaQuery:''},isLocked=()=>false,rememberChat=()=>{},escape=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;'),hiddenMessage=m=>!!m.hidden,localDay=()=>'',isViewOnce=m=>!!m.payload.viewOnce,loadThumbnails=()=>{},upsertMessages=(a,b)=>[...a,...b],access={epoch:1,valid:e=>e===1},apiRoot='local';async function decode(m){return m;}async function api(path){return path.startsWith('/rooms/')?[{id:'1',room:'r',created:1,payload:{type:'text',text:'https://example.org/'+ 'x'.repeat(180)+' www.example.net'}},{id:'2',room:'r',created:2,hidden:true,payload:{type:'text',text:'https://hidden.example'}}]:[];}function shell(t,h){app.innerHTML=`<section class="screen fs-premium fs-${state.page}"><header><h1>${escape(t)}</h1></header><main class="scroll">${h}</main></section>`;}'''+icons+'\n'+urls+'\n'+media+''';window.openLinks=async()=>{state.page='peer';state.mediaFilter='Tümü';await mediaPage('r');state.mediaFilter='Bağlantılar';await mediaPage();};}''')
 for theme in ('','light'):
  page.evaluate('(t)=>document.body.className=t',theme)
  for w,h in ((280,580),(360,720),(390,844),(640,360)):
   page.set_viewport_size({'width':w,'height':h});page.evaluate('openLinks()');assert page.locator('.fs-shared-link a').count()==2;assert not page.locator('[data-action="download-all"]').is_visible();assert page.evaluate('document.querySelector(".scroll").scrollWidth<=innerWidth');assert page.locator('.fs-shared-link a').first.get_attribute('rel')=='noopener noreferrer';assert 'hidden.example' not in page.locator('#app').inner_text();print('PASS shared links',theme or 'dark',w,h)
 page.set_viewport_size({'width':390,'height':844});page.screenshot(path='/tmp/fs-shared-links.png');b.close()
