import os, sys, unittest
from pathlib import Path
from unittest.mock import patch, MagicMock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from account_verify import send_email

class SMTPTransportTest(unittest.TestCase):
    def test_ssl_and_starttls(self):
        for mode, port, factory in [('ssl',465,'SMTP_SSL'),('starttls',587,'SMTP')]:
            with self.subTest(mode=mode), patch.dict(os.environ,{'FS_SMTP_HOST':'smtp.example.com','FS_SMTP_FROM':'fs@example.com','FS_SMTP_USER':'fs','FS_SMTP_PASSWORD':'test','FS_SMTP_MODE':mode},clear=True), patch('account_verify.smtplib.'+factory) as connect:
                smtp=connect.return_value.__enter__.return_value
                smtp.send_message.return_value={}
                send_email('user@example.com','test-code')
                self.assertEqual(connect.call_args.args,('smtp.example.com',port))
                if mode=='starttls': self.assertEqual([x[0] for x in smtp.method_calls],['ehlo','starttls','ehlo','login','send_message'])
                else: self.assertEqual([x[0] for x in smtp.method_calls],['login','send_message'])
                self.assertIn('test-code',smtp.send_message.call_args.args[0].get_content())
    def test_recipient_refusal_is_failure(self):
        import smtplib
        with patch.dict(os.environ,{'FS_SMTP_HOST':'smtp.example.com','FS_SMTP_FROM':'fs@example.com','FS_SMTP_USER':'fs','FS_SMTP_PASSWORD':'test'},clear=True), patch('account_verify.smtplib.SMTP_SSL') as connect:
            smtp=connect.return_value.__enter__.return_value
            smtp.send_message.return_value={'user@example.com':(550,b'refused')}
            with self.assertRaises(smtplib.SMTPRecipientsRefused): send_email('user@example.com','test-code')
    def test_no_plaintext(self):
        with patch.dict(os.environ,{'FS_SMTP_HOST':'smtp.example.com','FS_SMTP_FROM':'fs@example.com','FS_SMTP_MODE':'plain'},clear=True), patch('account_verify.smtplib.SMTP') as connect:
            with self.assertRaises(ValueError): send_email('user@example.com','test-code')
            connect.assert_not_called()
    def test_tls_failure_never_authenticates(self):
        with patch.dict(os.environ,{'FS_SMTP_HOST':'smtp.example.com','FS_SMTP_FROM':'fs@example.com','FS_SMTP_MODE':'starttls'},clear=True), patch('account_verify.smtplib.SMTP') as connect:
            smtp=connect.return_value.__enter__.return_value
            smtp.starttls.side_effect=RuntimeError('TLS failed')
            with self.assertRaises(RuntimeError): send_email('user@example.com','test-code')
            smtp.login.assert_not_called(); smtp.send_message.assert_not_called()
if __name__=='__main__': unittest.main()
