"""Prevent accidental production builds from historical asset-only source."""
import ast
import pathlib
import subprocess
import sys
import tempfile
import unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class SourceCleanupTests(unittest.TestCase):
    def test_old_apk_tool_rejects_release_and_plain_prepare(self):
        with tempfile.TemporaryDirectory() as temp:
            base=pathlib.Path(temp)/'input.apk';base.write_bytes(b'not an apk')
            out=pathlib.Path(temp)/'output.apk'
            for flags in ([],['--prepare-only'],['--legacy-archive-only']):
                with self.subTest(flags=flags):
                    r=subprocess.run([sys.executable,str(ROOT/'tools/prepare_apk.py'),str(base),str(out),*flags],capture_output=True,text=True)
                    self.assertNotEqual(r.returncode,0)
                    self.assertIn('Legacy tool disabled',r.stderr)
                    self.assertFalse(out.exists())
    def test_current_build_scripts_use_current_sources(self):
        manual=(ROOT/'tools/build_android.py').read_text()
        gradle=(ROOT/'android/app/build.gradle').read_text()
        self.assertIn("(ROOT/'web').rglob('*')",manual)
        self.assertIn("from('../../web')",gradle)
        self.assertNotIn('web-patch',manual+gradle)
    def test_python_modules_have_no_duplicate_top_level_or_class_definitions(self):
        for path in sorted([*(ROOT/'server').glob('*.py'),*(ROOT/'tools').glob('*.py')]):
            tree=ast.parse(path.read_text(),filename=str(path))
            for scope in [tree,*[n for n in ast.walk(tree) if isinstance(n,ast.ClassDef)]]:
                names=[x.name for x in scope.body if isinstance(x,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef))]
                self.assertEqual(len(names),len(set(names)),str(path))
if __name__=='__main__':unittest.main()
