"""Narrow-screen regression for actual shared rows and headers; offline DOM only."""
from pathlib import Path
import os
import unittest
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'

class NarrowLayoutTest(unittest.TestCase):
    def test_shared_rows_and_headers(self):
        with sync_playwright() as p:
            b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM','/usr/bin/chromium'),args=['--no-sandbox','--disable-dev-shm-usage'])
            page=b.new_page()
            page.set_content('<meta name="viewport" content="width=device-width,initial-scale=1"><div id="app"><section class="screen"><header><button class="icon">←</button><h1 id="title"></h1><button class="icon">⋮</button></header><main class="scroll"><button class="row"><svg viewBox="0 0 24 24"></svg><span class="copy" id="copy"></span><svg viewBox="0 0 24 24"></svg></button></main></section></div>')
            page.add_style_tag(path=str(root/'style.css'))
            page.evaluate("() => {document.querySelector('#title').textContent='ÇokUzunBaşlık'.repeat(12);document.querySelector('#copy').textContent='ÇokUzunDosyaAdı'.repeat(20)}")
            for light in (False, True):
                page.evaluate('v=>document.body.classList.toggle("light",v)',light)
                for w,h in [(280,560),(320,640),(390,300),(844,390)]:
                    page.set_viewport_size({'width':w,'height':h})
                    assert page.evaluate('''()=>['header','.row'].every(s=>{const e=document.querySelector(s),r=e.getBoundingClientRect();return e.scrollWidth<=e.clientWidth+1&&[...e.children].every(c=>c.getBoundingClientRect().right<=r.right+1)})'''),(w,h,light)
                    print(f'PASS shared header/row {w}x{h} light={light}')
            b.close()

if __name__=="__main__":unittest.main()
