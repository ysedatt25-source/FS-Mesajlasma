"""Exercise the real button helper and dialog with long titles in Chromium."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web';src=(root/'app.js').read_text()
button=src[src.index('const button ='):src.index('const avatar =')]
dialog=src[src.index('function dialog(title, content)'):src.index('function field(')]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page()
 page.set_content('<meta name="viewport" content="width=device-width,initial-scale=1"><div id="app"><section class="screen fs-premium fs-chat"></section></div><dialog id="modal"></dialog>');page.add_style_tag(path=str(root/'style.css'))
 page.evaluate('''()=>{const modal=document.querySelector('#modal'),escape=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;'),icon=()=>'<svg viewBox="0 0 24 24"></svg>',state={},assertAccess=()=>{},closeOnceViewer=()=>{},closeAlbumViewer=()=>{},clearProfileViewer=()=>{},clearMessageMenu=()=>{};'''+button+dialog+'''window.show=()=>dialog('Çokuzunbaşlık'.repeat(12),'<p>Örnek içerik</p>');}''')
 for light in (False,True):
  page.evaluate('v=>document.body.classList.toggle("light",v)',light)
  for w,h in [(280,560),(320,640),(390,300),(844,390)]:
   page.set_viewport_size({'width':w,'height':h});page.evaluate('show()');close=page.locator('#modal > .dialog-close.icon');assert close.count()==1
   result=page.evaluate('''()=>{const d=document.querySelector('#modal'),r=d.getBoundingClientRect(),c=d.firstElementChild.getBoundingClientRect();return d.scrollWidth<=d.clientWidth+1&&r.left>=0&&r.right<=innerWidth+1&&r.top>=0&&r.bottom<=innerHeight+1&&c.right<=r.right&&c.top>=r.top}''');assert result,(w,h,light)
   page.evaluate('document.querySelector("#modal").close()');print(f'PASS production dialog {w}x{h} {"light" if light else "dark"}')
 b.close()
