"""Real picker filtering and exact glyph recovery from a thumbnail decode failure."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import os,json
root=Path(__file__).resolve().parents[1]/'web'
app=(root/'app.js').read_text();effects=(root/'emoji-effects.js').read_text().replace('export ','')
picker=app[app.index('function emojiPicker(panel=null)'):app.index('const liveLocations = new Map();')]
listener=app[app.index("document.addEventListener('error',event=>{const image=event.target"):app.index('let messageActionFlight=false;')]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),args=['--no-sandbox','--disable-dev-shm-usage'],headless=True)
 page=b.new_page(viewport={'width':320,'height':500});page.set_content('<dialog id="modal"></dialog>');page.add_style_tag(content=(root/'style.css').read_text())
 rows=[{'emoji':e,'file':f} for e,f in [('❤️','abc.webp'),('☀️','abc.webp'),('🐱','abc.webp'),('🥰','abc.webp'),('✈️','abc.webp')]]
 page.evaluate('([code,rows])=>{const state={};const $=s=>document.querySelector(s);const escape=s=>String(s).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(\'"\',"&quot;");const dialog=(t,h)=>{const d=$("#modal");d.innerHTML=h;d.showModal()};const emojiItems=rows;eval(code+"\\nemojiPicker();");}',[effects+'\n'+listener+'\n'+picker,rows])
 page.locator('[data-category="Kalpler"]').click();assert page.locator('#emoji-list button').count()==1;assert page.locator('#emoji-list button').get_attribute('data-emoji')=='❤️'
 page.locator('[data-category="Diğer"]').click();assert page.locator('#emoji-list button').count()==2
 page.locator('[data-category="Tümü"]').click();page.locator('#emoji-search').fill('kalp');assert page.locator('#emoji-list button').count()==1
 # src references a missing bundled asset: the production capture listener replaces it.
 page.wait_for_function('document.querySelector("#emoji-list .emoji-picker-glyph")?.textContent==="❤️"')
 assert page.locator('#emoji-list button').get_attribute('aria-label')=='❤️'
 print('PASS exclusive categories, Turkish search and broken thumbnail recovery in real Chromium')
 page.set_content('<meta name="viewport" content="width=device-width,initial-scale=1"><div id="app"><section class="fs-chat fs-premium"></section></div><dialog id="modal"></dialog>');page.add_style_tag(content=(root/'style.css').read_text())
 page.evaluate(r'''([code,rows])=>{const state={reactionTarget:{id:'m'},user:{id:'me'}},messageIndex={reactions:new Map([['m',new Map([['me','❤️']])]])};const $=s=>document.querySelector(s);const escape=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;');const sameReaction=(a,b)=>a===b;const dialog=(t,h)=>{const d=$('#modal');d.innerHTML='<h2>'+t+'</h2>'+h;d.showModal()};const emojiItems=rows;eval(code+'\nemojiPicker();');}''',[effects+'\n'+listener+'\n'+picker,rows])
 assert page.locator('.fs-reaction-picker').count()==1
 assert page.locator('[data-action="choose-reaction"][data-emoji="❤️"][aria-pressed="true"]').count()==1
 assert page.locator('[data-remove-only="true"]').count()==1
 page.locator('[data-category="Hayvanlar"]').click();assert page.locator('#emoji-list button').get_attribute('data-emoji')=='🐱'
 for width,height in [(280,580),(320,640),(390,844),(640,360)]:
  page.set_viewport_size({'width':width,'height':height});page.wait_for_timeout(70);r=page.locator('#modal').bounding_box();assert r['x']>=-1 and r['y']>=-1 and r['x']+r['width']<=width+1 and abs(r['y']+r['height']-height)<=1,(width,height,r)
 print('PASS expanded reaction sheet, existing reaction, remove option, filter and four viewport bounds')
 b.close()
