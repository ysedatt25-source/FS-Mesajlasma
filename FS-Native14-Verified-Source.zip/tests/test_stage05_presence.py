import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from emoji_relay import PresenceLeases

class PresenceSeen(unittest.TestCase):
 def test_confirmed_last_seen_not_invisible_or_guessed(self):
  t=[1000];s=PresenceLeases(ttl=25,clock=lambda:t[0],wall=lambda:t[0]);uid='user_123456';sid='session_123456'
  self.assertIsNone(s.last_seen(uid));s.heartbeat(uid,sid,False,'online');self.assertIsNone(s.last_seen(uid))
  s.heartbeat(uid,sid,True,'online');self.assertEqual(s.status(uid),'online');self.assertEqual(s.last_seen(uid),1000000)
  t[0]+=5;s.heartbeat(uid,sid,True,'offline');self.assertEqual(s.status(uid),'offline');self.assertEqual(s.last_seen(uid),1000000)
  t[0]+=8*86400;self.assertIsNone(s.last_seen(uid))
 def test_expired_lease_retains_only_last_confirmed_heartbeat(self):
  t=[2000];s=PresenceLeases(ttl=25,clock=lambda:t[0],wall=lambda:t[0]);uid='user_123456';sid='session_123456';s.heartbeat(uid,sid,True,'busy');t[0]+=30
  self.assertEqual(s.sweep(),{uid});self.assertEqual(s.status(uid),'offline');self.assertEqual(s.last_seen(uid),2000000)
if __name__=='__main__':unittest.main()
