"""Isolated local security and admin query regression tests."""
import json, unittest
from unittest.mock import patch
import test_server
from app import message_for

class FinalFollowup(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=test_server.APITest.asyncSetUp
    asyncTearDown=test_server.APITest.asyncTearDown
    h=test_server.APITest.h
    register=test_server.APITest.register
    env=test_server.APITest.env

    async def test_login_rejects_private_key_fields(self):
        request={'login':'alice','password':'test-password-123','pub':{**test_server.PUB,'d':'invalid-private-key-field'}}
        store=self.app['store'];count=store.one('SELECT count(*) n FROM sessions')['n']
        r=await self.client.post('/api/session',json=request)
        self.assertEqual(r.status,400)
        self.assertEqual(store.one('SELECT count(*) n FROM sessions')['n'],count)
        r=await self.client.post('/api/session',json={**request,'pub':test_server.PUB})
        self.assertEqual(r.status,200)

    async def test_admin_message_batch_preserves_metadata_with_bounded_queries(self):
        store=self.app['store'];admin=self.c['user']['id'];sender=self.a['user']['id'];peer=self.b['user']['id']
        store.run("INSERT INTO app_config VALUES('admin',?)",(admin,))
        env=json.dumps({**self.env(),admin:test_server.ENVELOPE})
        for i in range(30):
            mid=f'final_msg_{i:04d}';store.run('INSERT INTO messages VALUES(?,?,?,?,?,?,?)',(mid,self.room,sender,env,1000+i,None,None))
            if i%2:store.run('INSERT INTO silent_messages VALUES(?)',(mid,))
            if i%3==0:store.run('INSERT INTO message_expiry VALUES(?,?)',(mid,9999999999999))
            if i%4==0:store.run('INSERT INTO message_keys VALUES(?,?)',(mid,json.dumps(test_server.PUB)))
            if i%5==0:store.run('INSERT INTO message_revisions VALUES(?,?,?,?,?)',(mid,1,1000,env,None))
            store.run('INSERT INTO message_receipts VALUES(?,?,?,?)',(mid,peer,1000,None))
        store.run('INSERT INTO uploads(id,owner,room,size,created) VALUES(?,?,?,?,?)',('final_upload_0001',sender,self.room,3,1000))
        store.run('INSERT INTO view_once_uploads(upload,message,recipient,opened) VALUES(?,?,?,?)',('final_upload_0001','final_msg_0000',peer,1001))
        expected=[message_for(r,admin,store) for r in store.db.execute('SELECT * FROM messages WHERE room=? ORDER BY created DESC LIMIT 200',(self.room,))]
        trace=[];store.db.set_trace_callback(trace.append)
        try:
            response=await self.client.get('/api/admin/rooms/'+self.room+'/messages',headers=self.h(self.c));got=await response.json()
        finally:store.db.set_trace_callback(None)
        self.assertEqual(response.status,200);self.assertEqual(got,expected)
        count=sum(q.lstrip().upper().startswith('SELECT') for q in trace)
        print(f'Admin messages: {count} SELECTs for 30 rows')
        self.assertLessEqual(count,10)
        self.assertEqual((await self.client.get('/api/admin/rooms/'+self.room+'/messages',headers=self.h(self.b))).status,403)
