"""Final audit: isolated synthetic accounts only, never production."""
import asyncio, json, tempfile, unittest
from pathlib import Path
import test_server
from database import connect

class FinalSecurityTest(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=test_server.APITest.asyncSetUp
    asyncTearDown=test_server.APITest.asyncTearDown
    h=test_server.APITest.h
    register=test_server.APITest.register
    env=test_server.APITest.env

    async def test_block_while_request_body_is_in_flight(self):
        started,finish=asyncio.Event(),asyncio.Event()
        raw=json.dumps({'id':'stage08_race_message','envelopes':self.env()}).encode()
        async def data():
            yield raw[:10];started.set();await finish.wait();yield raw[10:]
        pending=asyncio.create_task(self.client.post('/api/rooms/'+self.room+'/messages',headers={**self.h(self.a),'Content-Type':'application/json'},data=data()))
        try:
            await asyncio.wait_for(started.wait(),2);await asyncio.sleep(.05)
            r=await self.client.post('/api/blocks',headers=self.h(self.b),json={'peer':self.a['user']['id']});self.assertEqual(r.status,200,await r.text())
        finally:finish.set()
        r=await asyncio.wait_for(pending,3);self.assertEqual(r.status,403,await r.text())
        self.assertIsNone(self.app['store'].one('SELECT id FROM messages WHERE id=?',('stage08_race_message',)))

    async def test_admin_inventory_constant_queries_and_permission(self):
        store=self.app['store'];store.run("INSERT INTO app_config VALUES('admin',?)",(self.c['user']['id'],))
        for i in range(25):
            ident='test_room_'+str(i);store.run('INSERT INTO rooms VALUES(?,?,?,?)',(ident,'Group','group',i));store.run('INSERT INTO members VALUES(?,?)',(ident,self.a['user']['id']))
        queries=[];store.db.set_trace_callback(queries.append)
        try:r=await self.client.get('/api/admin/inventory/rooms',headers=self.h(self.c));rows=await r.json()
        finally:store.db.set_trace_callback(None)
        self.assertEqual(r.status,200);self.assertEqual(len(rows),26)
        self.assertTrue(all(r['audit']['id']==self.c['user']['id'] for r in rows))
        self.assertLessEqual(len([x for x in queries if x.lstrip().upper().startswith('SELECT')]),5)
        self.assertEqual((await self.client.get('/api/admin/inventory/rooms',headers=self.h(self.a))).status,403)

class IndexMigrationTest(unittest.TestCase):
    def test_indexes_idempotent_and_existing_data_intact(self):
        with tempfile.TemporaryDirectory() as d:
            db=connect(d);db.execute('INSERT INTO app_config VALUES(?,?)',('test','unchanged'));db.commit();db.close()
            db=connect(d)
            try:
                self.assertEqual(db.execute('SELECT value FROM app_config WHERE key=?',('test',)).fetchone()[0],'unchanged')
                self.assertEqual(db.execute('PRAGMA quick_check').fetchone()[0],'ok')
                names={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='index' AND name LIKE 'fs_%'")}
                self.assertEqual(len(names),6)
                for sql,expected in [('SELECT room FROM members WHERE user=?','fs_members_user_room'),('SELECT message FROM message_uploads WHERE upload=?','fs_message_uploads_reverse'),('SELECT * FROM calls WHERE room=? ORDER BY started DESC','fs_calls_room_started')]:
                    self.assertIn(expected,' '.join(str(tuple(r)) for r in db.execute('EXPLAIN QUERY PLAN '+sql,('synthetic',))))
            finally:db.close()
