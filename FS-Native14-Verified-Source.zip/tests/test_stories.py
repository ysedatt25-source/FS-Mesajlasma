import base64, json, sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from app import create_app, now
from stories import sweep, TTL, PENDING_TTL, MAX_MEDIA
from aiohttp.test_utils import TestClient, TestServer
PUB={'kty':'EC','crv':'P-256','x':'fPJ7GI0DT36KUjgDBLUaw8CJaeJ38hs1pgtI_EdmmXg','y':'B3dVENuO0EApPZrGn3Qw27p9reY86YIpngS3nSJ4c9E'}
NEW={'kty':'EC','crv':'P-256','x':base64.urlsafe_b64encode(bytes.fromhex('6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296')).decode().rstrip('='),'y':base64.urlsafe_b64encode(bytes.fromhex('4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5')).decode().rstrip('=')}
PACKET={'iv':base64.b64encode(b'x'*12).decode(),'data':base64.b64encode(b'y'*40).decode()}
ID='1'*32;DATA=b'ciphertext only data'*2
class StoryTest(unittest.IsolatedAsyncioTestCase):
 async def asyncSetUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.app=create_app(self.tmp.name);self.c=TestClient(TestServer(self.app));await self.c.start_server();self.users=[]
  for i,n in enumerate(('alice','bob','carol')):
   r=await self.c.post('/api/session',json={'register':True,'privacy_accepted':True,'name':n,'nick':n,'phone':'+90500111111'+str(i),'password':'test-password-123','invite':'0032','pub':PUB});self.assertEqual(r.status,200,await r.text());self.users.append(await r.json())
  self.a,self.b,self.x=self.users;self.s=self.app['store'];await self.c.post('/api/contacts',headers=self.h(self.a),json={'peer':self.uid(self.b)})
 async def asyncTearDown(self):await self.c.close();self.tmp.cleanup()
 def h(self,u):return {'Authorization':'Bearer '+u['token']}
 def uid(self,u):return u['user']['id']
 def payload(self,other=None,ident=ID):
  ids=[self.uid(self.a),self.uid(other or self.b)];return {'id':ident,'size':len(DATA),'recipient_pubs':{i:PUB for i in ids},'envelopes':{i:PACKET for i in ids}}
 async def create(self,**kw):return await self.c.post('/api/stories',headers=self.h(self.a),json=self.payload(**kw))
 async def publish(self):
  self.assertEqual((await self.create()).status,201);self.assertEqual((await self.c.put('/api/stories/'+ID+'/media',headers=self.h(self.a),data=DATA)).status,200)
 async def test_audience_and_pending_not_visible(self):
  r=await self.c.get('/api/stories/audience',headers=self.h(self.a));self.assertEqual([p['id'] for p in await r.json()],[self.uid(self.b)]);self.assertEqual((await self.create()).status,201);self.assertEqual(await (await self.c.get('/api/stories',headers=self.h(self.b))).json(),[]);self.assertEqual((await self.c.get('/api/stories/'+ID+'/media',headers=self.h(self.b))).status,404);self.assertEqual((await self.c.put('/api/stories/'+ID+'/media',headers=self.h(self.b),data=DATA)).status,404)
 async def test_publish_privacy_ciphertext_views_and_delete(self):
  await self.publish();lst=await (await self.c.get('/api/stories',headers=self.h(self.b))).json();self.assertEqual(lst[0]['id'],ID);self.assertIsNone(lst[0]['viewed']);self.assertNotIn('envelopes',lst[0]);self.assertEqual(await (await self.c.get('/api/stories',headers=self.h(self.x))).json(),[])
  for suffix in ('','/media','/viewers'):
   self.assertEqual((await self.c.get('/api/stories/'+ID+suffix,headers=self.h(self.x))).status,404)
  self.assertEqual((await self.c.get('/api/stories/'+ID+'/media')).status,401);self.assertEqual(await (await self.c.get('/api/stories/'+ID+'/media',headers=self.h(self.b))).read(),DATA);self.assertEqual((await self.c.get('/api/stories/'+ID+'/viewers',headers=self.h(self.b))).status,404);self.assertEqual((await self.c.delete('/api/stories/'+ID,headers=self.h(self.b))).status,404)
  self.assertEqual((await self.c.post('/api/stories/'+ID+'/view',headers=self.h(self.b))).status,200);v=await (await self.c.get('/api/stories/'+ID+'/viewers',headers=self.h(self.a))).json();self.assertEqual(v[0]['user']['id'],self.uid(self.b));await self.c.post('/api/stories/'+ID+'/view',headers=self.h(self.b));self.assertEqual(v,await (await self.c.get('/api/stories/'+ID+'/viewers',headers=self.h(self.a))).json());self.assertEqual((await self.c.delete('/api/stories/'+ID,headers=self.h(self.a))).status,200);self.assertIsNone(self.s.one('SELECT 1 FROM story_recipients WHERE story=?',(ID,)));self.assertEqual((await self.c.get('/api/stories/'+ID+'/media',headers=self.h(self.b))).status,404)
 async def test_block_and_contact_revocation(self):
  await self.publish();self.s.run('INSERT INTO blocks(owner,peer) VALUES(?,?)',(self.uid(self.b),self.uid(self.a)));self.assertEqual((await self.c.get('/api/stories/'+ID+'/media',headers=self.h(self.b))).status,404);self.s.run('DELETE FROM blocks');self.s.run('UPDATE contacts SET deleted=1 WHERE owner=? AND peer=?',(self.uid(self.a),self.uid(self.b)));self.assertEqual((await self.c.get('/api/stories/'+ID,headers=self.h(self.b))).status,404)
 async def test_reject_unapproved_and_stale_key(self):
  self.assertEqual((await self.create(other=self.x)).status,403);p=self.payload();p['recipient_pubs'][self.uid(self.b)]=NEW;self.assertEqual((await self.c.post('/api/stories',headers=self.h(self.a),json=p)).status,409);self.assertEqual((await self.create()).status,201);self.s.run('UPDATE users SET pub=? WHERE id=?',(json.dumps(NEW),self.uid(self.b)));self.assertEqual((await self.c.put('/api/stories/'+ID+'/media',headers=self.h(self.a),data=DATA)).status,409)
 async def test_expiry_and_pending_sweep(self):
  await self.publish();self.s.run('UPDATE stories SET expires=? WHERE id=?',(now()-1,ID));self.assertEqual((await self.c.get('/api/stories/'+ID+'/media',headers=self.h(self.b))).status,404);sweep(self.s,now());self.assertIsNone(self.s.one('SELECT 1 FROM stories WHERE id=?',(ID,)));self.assertEqual((await self.create()).status,201);self.s.run('UPDATE stories SET created=? WHERE id=?',(now()-PENDING_TTL-1,ID));sweep(self.s,now());self.assertIsNone(self.s.one('SELECT 1 FROM stories WHERE id=?',(ID,)))
 async def test_file_bound_and_single_commit(self):
  p=self.payload();p['size']=MAX_MEDIA+17;self.assertEqual((await self.c.post('/api/stories',headers=self.h(self.a),json=p)).status,400);self.assertEqual((await self.create()).status,201);self.assertEqual((await self.c.put('/api/stories/'+ID+'/media',headers=self.h(self.a),data=b'short')).status,400);self.assertEqual((await self.c.put('/api/stories/'+ID+'/media',headers=self.h(self.a),data=DATA)).status,200);self.assertEqual((await self.c.put('/api/stories/'+ID+'/media',headers=self.h(self.a),data=DATA)).status,409)
 async def test_duration_options_and_default(self):
  for i,hours in enumerate((6,12,24,48)):
   ident=str(i+2)*32;p=self.payload(ident=ident);p['duration_hours']=hours
   r=await self.c.post('/api/stories',headers=self.h(self.a),json=p);self.assertEqual(r.status,201);self.assertEqual((await r.json())['duration_hours'],hours)
   row=self.s.one('SELECT created,expires FROM stories WHERE id=?',(ident,));self.assertEqual(row['expires']-row['created'],hours*3600000)
   t=now();self.assertEqual((await self.c.put('/api/stories/'+ident+'/media',headers=self.h(self.a),data=DATA)).status,200);row=self.s.one('SELECT expires FROM stories WHERE id=?',(ident,));self.assertGreaterEqual(row['expires'],t+hours*3600000);self.assertLessEqual(row['expires'],now()+hours*3600000)
  for value in (0,72,'6',True,None):
   p=self.payload();p['duration_hours']=value;self.assertEqual((await self.c.post('/api/stories',headers=self.h(self.a),json=p)).status,400)
  r=await self.create();self.assertEqual((await r.json())['duration_hours'],24)
 async def test_like_and_cascade(self):
  await self.publish();url='/api/stories/'+ID
  for u,status in ((self.x,404),(self.a,400),(self.b,409)):self.assertEqual((await self.c.post(url+'/like',headers=self.h(u),json={'liked':True})).status,status)
  await self.c.post(url+'/view',headers=self.h(self.b))
  for _ in range(2):self.assertEqual((await (await self.c.post(url+'/like',headers=self.h(self.b),json={'liked':True})).json())['liked'],True)
  self.assertEqual(self.s.one('SELECT count(*) n FROM story_likes')['n'],1)
  self.assertTrue((await (await self.c.get(url+'/viewers',headers=self.h(self.a))).json())[0]['liked'])
  self.assertTrue((await (await self.c.get('/api/stories',headers=self.h(self.b))).json())[0]['liked'])
  await self.c.post(url+'/like',headers=self.h(self.b),json={'liked':False});self.assertEqual(self.s.one('SELECT count(*) n FROM story_likes')['n'],0)
  await self.c.post(url+'/like',headers=self.h(self.b),json={'liked':True});await self.c.delete(url,headers=self.h(self.a));self.assertEqual(self.s.one('SELECT count(*) n FROM story_likes')['n'],0)
 async def test_mute_personal(self):
  await self.publish();url='/api/stories/'+ID
  for u,status in ((self.x,404),(self.a,400)):self.assertEqual((await self.c.post(url+'/mute',headers=self.h(u),json={'muted':True})).status,status)
  for flag in (True,True,False):
   self.assertEqual((await (await self.c.post(url+'/mute',headers=self.h(self.b),json={'muted':flag})).json())['muted'],flag)
   self.assertEqual((await (await self.c.get('/api/stories',headers=self.h(self.b))).json())[0]['muted'],flag)
   self.assertFalse((await (await self.c.get('/api/stories',headers=self.h(self.a))).json())[0]['muted'])
 async def test_revoke(self):
  await self.publish();url='/api/stories/'+ID;bob=self.uid(self.b)
  await self.c.post(url+'/view',headers=self.h(self.b));await self.c.post(url+'/like',headers=self.h(self.b),json={'liked':True})
  self.assertEqual((await self.c.get(url+'/recipients',headers=self.h(self.b))).status,404)
  self.assertEqual((await self.c.post(url+'/recipients',headers=self.h(self.b),json={'remove':[bob]})).status,404)
  self.assertEqual((await self.c.post(url+'/recipients',headers=self.h(self.a),json={'remove':[self.uid(self.a)]})).status,400)
  self.assertEqual([r['id'] for r in await (await self.c.get(url+'/recipients',headers=self.h(self.a))).json()],[bob])
  self.assertEqual((await self.c.post(url+'/recipients',headers=self.h(self.a),json={'remove':[bob]})).status,200)
  for suffix in ('','/media','/viewers'):self.assertEqual((await self.c.get(url+suffix,headers=self.h(self.b))).status,404)
  self.assertEqual(await (await self.c.get('/api/stories',headers=self.h(self.b))).json(),[])
  self.assertEqual(self.s.one('SELECT count(*) n FROM story_likes')['n'],0)
  self.assertEqual((await self.c.get(url+'/media',headers=self.h(self.a))).status,200)
 async def test_close_friends_saved_private_and_filtered(self):
  url='/api/stories/close-friends';a=self.h(self.a);b=self.h(self.b);bob=self.uid(self.b);carol=self.uid(self.x)
  self.assertEqual((await self.c.post(url,headers=a,json={'peers':[carol]})).status,403)
  self.assertEqual((await self.c.post(url,headers=a,json={'peers':[bob,bob]})).status,400)
  self.assertEqual((await self.c.post(url,headers=a,json={'peers':[self.uid(self.a)]})).status,400)
  self.assertEqual(await (await self.c.post(url,headers=a,json={'peers':[bob]})).json(),{'peers':[bob]})
  self.assertTrue((await (await self.c.get('/api/stories/audience',headers=a)).json())[0]['close_friend'])
  self.assertEqual(await (await self.c.get('/api/stories/audience',headers=b)).json(),[])
  self.assertEqual((await self.c.delete('/api/contacts/'+bob,headers=a)).status,200)
  self.assertEqual(await (await self.c.get('/api/stories/audience',headers=a)).json(),[])
  self.assertEqual(self.s.one('SELECT count(*) n FROM story_close_friends')['n'],0)
  self.assertEqual((await self.create()).status,403)
  self.assertEqual(await (await self.c.post(url,headers=a,json={'peers':[]})).json(),{'peers':[]})
  self.assertEqual(self.s.one('SELECT count(*) n FROM story_close_friends')['n'],0)

 async def test_caption_edit_owner_only_atomic_and_preserves_story(self):
  await self.publish();url='/api/stories/'+ID;a=self.h(self.a);b=self.h(self.b);x=self.h(self.x)
  await self.c.post(url+'/view',headers=b);await self.c.post(url+'/like',headers=b,json={'liked':True})
  original=self.s.one('SELECT * FROM stories WHERE id=?',(ID,));views=await (await self.c.get(url+'/viewers',headers=a)).json()
  for headers in (b,x):
   self.assertEqual((await self.c.get(url+'/caption',headers=headers)).status,404);self.assertEqual((await self.c.post(url+'/caption',headers=headers,json={})).status,404)
  d=await (await self.c.get(url+'/caption',headers=a)).json();self.assertEqual(set(d['recipient_pubs']),{self.uid(self.a),self.uid(self.b)});self.assertNotIn('content',d)
  new={'iv':base64.b64encode(b'z'*12).decode(),'data':base64.b64encode(b'k'*45).decode()};packets={p:new for p in d['recipient_pubs']};payload={'expected':d['envelope'],'envelopes':packets}
  self.assertEqual((await self.c.post(url+'/caption',headers=a,json={**payload,'envelopes':{self.uid(self.a):new}})).status,409)
  self.assertEqual((await self.c.post(url+'/caption',headers=a,json={**payload,'envelopes':{**packets,self.uid(self.b):{'iv':'bad','data':'bad'}}})).status,400)
  self.assertEqual((await (await self.c.get(url,headers=b)).json())['envelope'],PACKET)
  self.assertEqual((await self.c.post(url+'/caption',headers=a,json=payload)).status,200)
  self.assertEqual((await (await self.c.get(url,headers=b)).json())['envelope'],new)
  self.assertEqual((await self.c.post(url+'/caption',headers=a,json=payload)).status,409)
  self.assertEqual(dict(self.s.one('SELECT * FROM stories WHERE id=?',(ID,))),dict(original));self.assertEqual(await (await self.c.get(url+'/viewers',headers=a)).json(),views)
  self.assertEqual(await (await self.c.get(url+'/media',headers=b)).read(),DATA)
  self.assertEqual((await self.c.post(url+'/recipients',headers=a,json={'remove':[self.uid(self.b)]})).status,200)
  self.assertEqual((await self.c.post(url+'/caption',headers=a,json={'expected':new,'envelopes':packets})).status,409)
  self.assertEqual((await self.c.get(url,headers=b)).status,404)

 async def test_online_and_offline_recipient_delivery_and_expiry(self):
  # Distinct device public keys; actual WebSocket + HTTP endpoints with isolated accounts.
  bob=self.uid(self.b);carol=self.uid(self.x)
  self.s.run('UPDATE users SET pub=? WHERE id=?',(json.dumps(NEW),bob))
  await self.c.post('/api/contacts',headers=self.h(self.a),json={'peer':carol})
  a=self.h(self.a);b=self.h(self.b);c=self.h(self.x)
  ws=await self.c.ws_connect('/api/socket')
  try:
   await ws.send_json({'token':self.b['token']});self.assertIn('stories-v1',(await ws.receive_json(timeout=2))['features'])
   p=self.payload();p['recipient_pubs'][bob]=NEW;p['recipient_pubs'][carol]=PUB;p['envelopes'][carol]=PACKET;p['duration_hours']=6
   r=await self.c.post('/api/stories',headers=a,json=p);self.assertEqual(r.status,201);self.assertEqual((await r.json())['duration_hours'],6)
   self.assertEqual(await (await self.c.get('/api/stories',headers=b)).json(),[])
   self.assertEqual(await (await self.c.get('/api/stories',headers=c)).json(),[])
   self.assertEqual((await self.c.put('/api/stories/'+ID+'/media',headers=a,data=DATA)).status,200)
   self.assertEqual((await ws.receive_json(timeout=2))['type'],'stories-changed-v1')
   for headers in (a,b,c):
    rows=await (await self.c.get('/api/stories',headers=headers)).json();self.assertEqual([r['id'] for r in rows],[ID]);self.assertEqual(await (await self.c.get('/api/stories/'+ID+'/media',headers=headers)).read(),DATA)
   await ws.close()
   ws=await self.c.ws_connect('/api/socket');await ws.send_json({'token':self.b['token']});await ws.receive_json(timeout=2)
   self.assertEqual([r['id'] for r in await (await self.c.get('/api/stories',headers=b)).json()],[ID])
   self.s.run('UPDATE stories SET expires=? WHERE id=?',(now()-1,ID))
   for headers in (a,b,c):
    self.assertEqual(await (await self.c.get('/api/stories',headers=headers)).json(),[])
    self.assertEqual((await self.c.get('/api/stories/'+ID+'/media',headers=headers)).status,404)
   sweep(self.s,now());self.assertIsNone(self.s.one('SELECT 1 FROM story_recipients WHERE story=?',(ID,)))
  finally:await ws.close()
