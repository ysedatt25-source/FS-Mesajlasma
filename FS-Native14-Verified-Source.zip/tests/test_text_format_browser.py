from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web';s=(root/'app.js').read_text()
def part(a,b):return s[s.index(a):s.index(b,s.index(a))]
code=(root/'text-format.js').read_text().replace('export ','')+'\n'+part('function textPayload(','function linkText(')+'\n'+part('function chooseQuote(','async function jumpReply(')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').is_file() else None),headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page(viewport={'width':360,'height':640},has_touch=True);page.set_content('<meta name="viewport" content="width=device-width,initial-scale=1"><textarea id="message-text"></textarea><dialog id="modal"></dialog>');page.add_style_tag(content=(root/'style.css').read_text())
 page.evaluate('()=>{'+code+'''
 const $=s=>document.querySelector(s),modal=$('#modal'),state={room:{id:'r'},routeVersion:1,reply:null},access={epoch:1,valid:e=>e===1};const isLocked=()=>false,escape=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');let notices=[],msg={id:'m',payload:{type:'text',text:'Bir iki üç'}};const eligibleMessage=id=>msg.id===id?msg:null;function notice(s){notices.push(s)}function dialog(t,h){modal.innerHTML=h;modal.showModal()}function beginReply(id){state.reply={id}}function renderReply(){}function rememberChat(){}window.quote=()=>chooseQuote('m');window.payload=()=>textPayload($('#message-text'));window.reply=()=>state.reply;window.change=()=>{msg.payload.text='değişti'};window.notices=notices;
 }''')
 entry=page.locator('#message-text');entry.fill('  Merhaba dünya  ');assert page.evaluate('payload()')=={'type':'text','text':'Merhaba dünya'};print('PASS plain composer payload')
 page.evaluate('quote()');q=page.locator('#quote-source');assert page.locator('#quote-confirm').is_disabled();q.evaluate('e=>{e.focus();e.setSelectionRange(4,7);e.dispatchEvent(new Event("select"))}');assert page.locator('#quote-count').inner_text()=='3 / 512';page.locator('#quote-confirm').tap();assert page.evaluate('reply()')['quoteText']=='iki';print('PASS exact selected quote')
 page.evaluate('quote()');q.evaluate('e=>{e.focus();e.setSelectionRange(0,3);e.dispatchEvent(new Event("select"))}');page.evaluate('change()');page.locator('#quote-confirm').tap();assert 'yeniden seç' in page.evaluate('notices')[-1];assert page.evaluate('reply()')['quoteText']=='iki';print('PASS edited source guard');b.close()
