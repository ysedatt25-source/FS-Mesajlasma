from pathlib import Path
import os
from playwright.sync_api import sync_playwright
web=Path(__file__).resolve().parents[1]/'web'
with sync_playwright() as p:
    b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    page=b.new_page();page.set_content('<meta name="viewport" content="width=device-width,initial-scale=1"><div id="app"><section class="fs-chat fs-premium"><div id="upload-progress"><progress class="file-transfer-progress" max="52428816" value="2000000"></progress><small role="status">Bağlantı bekleniyor · Kuyruk korundu</small></div><div class="transfer-state">İndirme kesildi. <button>Yeniden dene</button></div></section></div>');page.add_style_tag(content=(web/'style.css').read_text())
    for w,h in [(280,560),(320,640),(390,844),(640,360),(800,260)]:
        page.set_viewport_size({'width':w,'height':h})
        assert page.evaluate('''()=>[...document.querySelectorAll('#upload-progress,#upload-progress progress,#upload-progress small,.transfer-state,.transfer-state button')].every(e=>{let r=e.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth+1&&e.scrollWidth<=e.clientWidth+1})'''),(w,h)
    print('PASS transfer progress and retry controls on five portrait/landscape viewports');b.close()
