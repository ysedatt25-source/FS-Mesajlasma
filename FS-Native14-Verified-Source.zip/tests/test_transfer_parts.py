import sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from transfer_parts import check_prefix,write_chunk,MissingPrefix

class TransferPartsTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'ciphertext'
    def tearDown(self):self.tmp.cleanup()
    def test_restart_and_resume(self):
        self.assertEqual(write_chunk(self.path,0,b'abc'),3)
        self.assertEqual(write_chunk(self.path,3,b'def'),6)
        check_prefix(self.path,6,True);self.assertEqual(self.path.read_bytes(),b'abcdef')
    def test_crash_uncommitted_suffix_replaced(self):
        self.path.write_bytes(b'abcwrong-tail')
        self.assertEqual(write_chunk(self.path,3,b'def'),6)
        self.assertEqual(self.path.read_bytes(),b'abcdef')
    def test_missing_prefix_never_zero_pads(self):
        with self.assertRaises(MissingPrefix):write_chunk(self.path,3,b'def')
        self.assertFalse(self.path.exists());self.path.write_bytes(b'a')
        with self.assertRaises(MissingPrefix):write_chunk(self.path,3,b'def')
        self.assertEqual(self.path.read_bytes(),b'a')
    def test_complete_size_must_match(self):
        self.path.write_bytes(b'abc')
        with self.assertRaises(MissingPrefix):check_prefix(self.path,2,True)
        with self.assertRaises(MissingPrefix):check_prefix(self.path,4,True)
    def test_sync_failure_does_not_return_committable_offset(self):
        with patch('transfer_parts.os.fsync',side_effect=OSError('disk error')):
            with self.assertRaises(OSError):write_chunk(self.path,0,b'abc')
        self.assertEqual(write_chunk(self.path,0,b'xyz'),3)
        self.assertEqual(self.path.read_bytes(),b'xyz')
