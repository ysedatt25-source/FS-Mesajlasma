import os, sys, unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'server'))
from aiohttp import web
from turn import TurnCredentials
class TurnTest(unittest.IsolatedAsyncioTestCase):
 async def test_no_provider_returns_none(self):
  with patch.dict(os.environ,{},clear=True): self.assertIsNone(await TurnCredentials().get('a'))
 async def test_per_user_credentials_cached_and_token_rotation_refreshes(self):
  issuer=TurnCredentials();issuer.fetch=AsyncMock(return_value=[{'urls':['turns:turn.cloudflare.com:443'],'username':'short','credential':'ephemeral'}])
  with patch.dict(os.environ,{'FS_CF_TURN_KEY_ID':'test-key-123','FS_CF_TURN_API_TOKEN':'server-only'}):
   await issuer.get('a');await issuer.get('a');self.assertEqual(issuer.fetch.await_count,1)
   await issuer.get('b');self.assertEqual(issuer.fetch.await_count,2)
   os.environ['FS_CF_TURN_API_TOKEN']='rotated';await issuer.get('a');self.assertEqual(issuer.fetch.await_count,3)
 async def test_provider_failure_does_not_disclose_token(self):
  issuer=TurnCredentials();issuer.fetch=AsyncMock(side_effect=RuntimeError('super-secret'))
  with patch.dict(os.environ,{'FS_CF_TURN_KEY_ID':'test-key-123','FS_CF_TURN_API_TOKEN':'super-secret'}):
   with self.assertRaises(web.HTTPServiceUnavailable) as error:await issuer.get('a')
   self.assertNotIn('super-secret',error.exception.text)

 async def test_turnix_rechecks_each_connection_without_exposing_api_token(self):
  issuer=TurnCredentials();servers=[{'urls':['turn:relay.example:3478'],'username':'ephemeral','credential':'short-lived'}]
  issuer.fetch_turnix=AsyncMock(return_value=servers)
  with patch.dict(os.environ,{'TURNIX_API_TOKEN':'private-token'},clear=True):
   self.assertEqual(await issuer.get('a'),servers);await issuer.get('a')
   self.assertEqual(issuer.fetch_turnix.await_count,2)
   self.assertNotIn('private-token',str(servers))
 async def test_turnix_denies_paid_plan_overage_or_exhausted_quota(self):
  valid={'current_plan':'FREE','is_overage_available':False,'current_period_usage_gb':0,'limit_before_avarage_gb':10}
  TurnCredentials.validate_free_plan(valid)
  for changed in [{'current_plan':'BASIC'},{'is_overage_available':True},{'is_overage_available':None},{'current_period_usage_gb':10},{'limit_before_avarage_gb':None}]:
   with self.assertRaises(web.HTTPServiceUnavailable):TurnCredentials.validate_free_plan({**valid,**changed})
