"""Stage 1: real stylesheet and native chrome bridge on Chromium, no live account."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'web'
html='''<meta name="theme-color" content="#160d1b"><div id="app"><section class="screen fs-premium fs-settings"><header><button class="icon"><svg viewBox="0 0 24 24" stroke-width="1.65"><path d="M4 12h16"/></svg></button><h1>Ayarlar</h1></header><main class="scroll"><div class="fs-detail-group"><button class="row">Gizlilik ve güvenlik</button></div><button class="primary">Kaydet</button><button class="secondary">Vazgeç</button></main></section></div><dialog id="modal"></dialog>'''
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':390,'height':844});page.set_content(html);page.add_style_tag(path=str(root/'style.css'))
 page.evaluate('window.modes=[];window.FSNative={uiChrome:m=>modes.push(m)}');page.add_script_tag(path=str(root/'ui-chrome.js'))
 page.wait_for_function('modes.at(-1)==="dark"');assert page.locator('meta').get_attribute('content')=='#17212b'
 for light in (False,True):
  page.evaluate('(v)=>document.body.classList.toggle("light",v)',light)
  want='light' if light else 'dark';page.wait_for_function('(v)=>modes.at(-1)===v',arg=want)
  for w,h in [(280,560),(320,640),(390,844),(844,390)]:
   page.set_viewport_size({'width':w,'height':h})
   page.wait_for_timeout(220)
   result=page.evaluate('''()=>{const q=s=>document.querySelector(s),c=s=>getComputedStyle(q(s)),r=q('.fs-settings');return {bg:c('.fs-settings').backgroundColor,fg:c('.fs-settings').color,primary:c('.primary').backgroundColor,stroke:c('.icon svg').strokeWidth,font:c('.fs-settings').fontFamily,rad:c('.primary').borderRadius,padding:c('.scroll').paddingLeft,width:r.clientWidth,scroll:r.scrollWidth,animation:c('header').animationDuration,transition:c('.icon').transitionDuration}}''')
   assert result['bg']==('rgb(255, 255, 255)' if light else 'rgb(23, 33, 43)'),result
   assert result['fg']==('rgb(33, 33, 33)' if light else 'rgb(242, 245, 247)'),result
   assert result['primary']==('rgb(22, 116, 180)' if light else 'rgb(41, 122, 185)'),result
   # Package 09 deliberately uses edge-to-edge settings groups; row padding remains 16px (12px on narrow screens).
   assert result['stroke']=='1.8px' and result['rad']=='12px' and result['padding']=='0px',result
   assert page.locator('.fs-detail-group .row').evaluate('(e)=>getComputedStyle(e).paddingLeft')==('12px' if w<=320 else '16px')
   assert 'Roboto' in result['font'] and result['scroll']<=result['width']+1,result
   assert result['animation']=='0.18s' and result['transition']=='0.12s, 0.12s',result
   print(f'PASS palette, font, icon, radius, spacing and motion {want} {w}x{h}')
 page.set_viewport_size({'width':390,'height':844});page.locator('.icon').hover();page.mouse.down();page.wait_for_timeout(160);assert page.locator('.icon').evaluate('(e)=>getComputedStyle(e).backgroundColor')=='rgba(23, 33, 43, 0.05)';page.mouse.up();print('PASS touch/press visual state')
 page.emulate_media(reduced_motion='reduce');assert page.locator('header').evaluate('(e)=>getComputedStyle(e).animationName')=='none';assert page.locator('.icon').evaluate('(e)=>getComputedStyle(e).transitionProperty')=='none';print('PASS reduced motion')
 page.evaluate('document.querySelector("#app").innerHTML="<section class=lock></section>"');page.wait_for_function('modes.at(-1)==="legacy"');assert page.locator('meta').get_attribute('content')=='#160d1b';assert page.locator('.lock').evaluate('(e)=>getComputedStyle(e).backgroundImage').startswith('radial-gradient');print('PASS lock retains original CSS and system chrome')
 page.evaluate('(v)=>document.querySelector("#app").innerHTML=v','<section class="call fs-premium fs-direct-call"></section>');page.wait_for_timeout(50);assert page.evaluate('modes.at(-1)')=='legacy';print('PASS call remains on legacy system chrome')
 page.evaluate('(v)=>document.querySelector("#app").innerHTML=v','<section class="screen fs-premium fs-settings"></section>');page.wait_for_function('modes.at(-1)==="light"');before=page.evaluate('modes.length');page.evaluate('document.querySelector(".fs-settings").append(document.createElement("div"))');page.wait_for_timeout(50);assert page.evaluate('modes.length')==before;print('PASS native sync only on mode change; no message DOM observer')
 b.close()
