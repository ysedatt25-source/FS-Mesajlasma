import ast, asyncio, concurrent.futures, sqlite3, sys, tempfile, unittest
from pathlib import Path
from aiohttp import web
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'server'))
from view_once import private_message, private_upload, claim

class Store:
    def __init__(self, path):
        self.dir=path.parent;self.db=sqlite3.connect(path,timeout=10);self.db.row_factory=sqlite3.Row;self.db.execute('PRAGMA foreign_keys=ON')
    def one(self,sql,args=()):return self.db.execute(sql,args).fetchone()
    def run(self,sql,args=()):c=self.db.execute(sql,args);self.db.commit();return c
    def member(self,u,r):
        if not self.one('SELECT 1 FROM members WHERE room=? AND user=?',(r,u)):raise web.HTTPForbidden()

# The archived patch omits database.py and other imports. Execute the exact
# production handler AST in isolation with the real SQLite schema and adapter.
source=ast.parse((ROOT/'server/app.py').read_text())
handlers=[n for n in source.body if isinstance(n,ast.AsyncFunctionDef) and n.name in {'open_view_once','download_message_file','upload_part','admin_upload'}]
ns=dict(web=web,auth=lambda r:r.user,auth_admin=lambda r:r.user,private_upload=private_upload,hidden_for=lambda s,u,m:bool(s.one('SELECT 1 FROM hidden_messages WHERE user=? AND message=?',(u,m))),blocked=lambda s,u,v:False,claim=claim,now=lambda:123,MAX_FILE=50*1024*1024)
exec(compile(ast.Module(body=handlers,type_ignores=[]),str(ROOT/'server/app.py'),'exec'),ns)
open_once=ns['open_view_once']
class OnceTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'db.sqlite';self.s=Store(self.path)
        self.s.db.executescript((ROOT/'server/schema.sql').read_text())
        for u in ['alice','bob','eve']:
            self.s.run('INSERT INTO users VALUES(?,?,?,?,?,?,?,?,?)',(u,u,u,u,b'p',b's','{}','{}',0))
        self.s.run('INSERT INTO rooms VALUES(?,?,?,?)',('room','test','direct',0))
        for u in ['alice','bob']:self.s.run('INSERT INTO members VALUES(?,?)',('room',u))
        self.s.run('INSERT INTO uploads VALUES(?,?,?,?,?,?,?)',('upload','alice','room',6,6,1,0))
        self.s.run('INSERT INTO view_once_uploads(upload) VALUES(?)',('upload',))
        self.s.run('INSERT INTO messages VALUES(?,?,?,?,?,?,?)',('message','room','alice','{}',0,None,None))
        self.s.run('INSERT INTO message_uploads VALUES(?,?)',('message','upload'))
        self.s.run('UPDATE view_once_uploads SET message=?,recipient=? WHERE upload=?',('message','bob','upload'))
        (self.s.dir/'upload').write_bytes(b'cipher')
    def tearDown(self):self.s.db.close();self.tmp.cleanup()
    def request(self,user='bob',headers=None):return SimpleNamespace(user=user,app={'store':self.s},match_info={'id':'message'},headers=headers or {})
    def test_reservation(self):self.assertEqual(private_upload(self.s,'upload')['recipient'],'bob');self.assertEqual(private_message(self.s,'message')['upload'],'upload')
    def test_read_once_and_unlink(self):
        response=asyncio.run(open_once(self.request()));self.assertEqual(response.body,b'cipher');self.assertIn('no-store',response.headers['Cache-Control']);self.assertFalse((self.s.dir/'upload').exists())
        with self.assertRaises(web.HTTPGone):asyncio.run(open_once(self.request()))
    def test_sender_denied(self):
        with self.assertRaises(web.HTTPNotFound):asyncio.run(open_once(self.request('alice')))
        self.assertIsNone(private_message(self.s,'message')['opened'])
    def test_outsider_denied(self):
        with self.assertRaises(web.HTTPNotFound):asyncio.run(open_once(self.request('eve')))
    def test_range_denied(self):
        with self.assertRaises(web.HTTPBadRequest):asyncio.run(open_once(self.request(headers={'Range':'bytes=0-1'})))
        self.assertIsNone(private_message(self.s,'message')['opened'])
    def test_hidden_denied(self):
        self.s.run('INSERT INTO hidden_messages VALUES(?,?)',('bob','message'))
        with self.assertRaises(web.HTTPNotFound):asyncio.run(open_once(self.request()))
    def test_bad_length_does_not_consume(self):
        (self.s.dir/'upload').write_bytes(b'bad')
        with self.assertRaises(web.HTTPNotFound):asyncio.run(open_once(self.request()))
        self.assertIsNone(private_message(self.s,'message')['opened'])
    def test_two_connections_only_one_claim(self):
        def attempt(i):
            s=Store(self.path)
            try:return claim(s,'upload','message','bob',i+1)
            finally:s.db.close()
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:results=list(pool.map(attempt,range(16)))
        self.assertEqual(sum(results),1)
    def test_normal_message_download_denied(self):
        r=self.request();r.match_info['upload']='upload'
        with self.assertRaises(web.HTTPForbidden):asyncio.run(ns['download_message_file'](r))
    def test_normal_upload_download_denied(self):
        r=self.request();r.match_info['id']='upload';r.method='GET'
        with self.assertRaises(web.HTTPForbidden):asyncio.run(ns['upload_part'](r))
    def test_admin_normal_download_denied(self):
        r=self.request('alice');r.match_info['id']='upload'
        with self.assertRaises(web.HTTPForbidden):asyncio.run(ns['admin_upload'](r))
    def test_wrong_recipient_never_claims(self):self.assertFalse(claim(self.s,'upload','message','alice',123));self.assertIsNone(private_message(self.s,'message')['opened'])
if __name__=='__main__':unittest.main()
