from pathlib import Path
import os
from playwright.sync_api import sync_playwright
web=Path(__file__).resolve().parents[1]/'web'
with sync_playwright() as p:
    b=p.chromium.launch(executable_path=os.environ.get('FS_CHROMIUM') or '/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    page=b.new_page();page.set_content('''<meta name="viewport" content="width=device-width,initial-scale=1"><div id="app"><section class="fs-chat fs-premium"><div id="composer-files"><div><span>çok-uzun-dosya-adı-1234567890-fotoğraf.png</span><button class="composer-edit-media">Düzenle</button><button class="composer-once" aria-pressed="true">1 · Açık</button><button>×</button></div></div><article class="message mine"><button class="once-media"><span class="once-symbol">1</span><span><strong>Tek görüntülemelik fotoğraf</strong><small>Bir kez görüntüle</small></span></button></article><div class="once-view-host"><img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='2400' height='1000'%3E%3Crect width='2400' height='1000' fill='red'/%3E%3C/svg%3E"></div></section></div>''');page.add_style_tag(content=(web/'style.css').read_text())
    for w,h in [(280,560),(320,640),(390,844),(640,360),(800,260)]:
        page.set_viewport_size({'width':w,'height':h})
        assert page.evaluate('''()=>[...document.querySelectorAll('#composer-files button,.once-media,.once-media span,.once-view-host,.once-view-host img')].every(e=>{let r=e.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth+1&&e.scrollWidth<=e.clientWidth+1})'''),(w,h)
    print('PASS one-time composer, message card and media bounds on 5 viewports');b.close()
