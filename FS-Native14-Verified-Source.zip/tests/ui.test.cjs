// Isolated automated regression tests for the local application, no external accounts.
const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.FS_CHROMIUM||'/usr/bin/chromium',args:['--no-sandbox']});
 const reports=[],errors=[];
 async function account(nick,phone,reducedMotion){
  const context=await browser.newContext({viewport:{width:412,height:915},reducedMotion}),page=await context.newPage();
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:8787/index.html');
  await page.locator('#pin').fill('864209');await page.locator('#confirm-pin').fill('864209');await page.getByRole('button',{name:'Şifre oluştur'}).click();
  await page.locator('.android-calculator').waitFor();
  assert.equal(await page.locator('#account-form').count(),0,'account must remain hidden until trusted PIN entry');
  for(const digit of '864209')await page.locator(`[data-calc="${digit}"]`).click();
  await page.locator('[data-calc="="]').click();
  await page.getByRole('button',{name:'Yeni hesap oluştur',exact:true}).click();
  await page.locator('#name').fill(nick==='test_alice'?'Test Alice':'Test Bob');await page.locator('#nick').fill(nick);await page.locator('#phone').fill(phone);await page.locator('#password').fill('isolated-test-password-123');
  await page.locator('#passwordConfirm').fill('isolated-test-password-123');await page.locator('#email').fill(nick+'@example.test');await page.locator('[name=privacy]').check();await page.getByRole('button',{name:'Hesap oluştur',exact:true}).click();await page.getByRole('button',{name:'Yeni sohbet',exact:true}).waitFor();
  await page.locator('.welcome').waitFor({state:'detached'});
  reports.push(nick+' registration and PIN setup passed');return {page,context};
 }
 try{
 const stamp=Date.now().toString().slice(-7);const alice=await account('alice_'+stamp,'+9051'+stamp+'1','no-preference'),bob=await account('bob_'+stamp,'+9052'+stamp+'2','reduce');const a=alice.page,b=bob.page;
 await a.getByRole('button',{name:'Yeni sohbet',exact:true}).click();await a.locator('#query').fill('bob_'+stamp);await a.getByRole('button',{name:'Bul',exact:true}).click();await a.locator('[data-action="start-chat"]').click();await a.locator('#message-text').fill('Şifreli merhaba 💜');await a.locator('#compose').getByRole('button',{name:'Gönder',exact:true}).click();await a.locator('.message').filter({hasText:'Şifreli merhaba'}).waitFor();reports.push('Alice encrypted message send passed');
 await b.reload();await b.getByRole('button',{name:'8',exact:true}).click();await b.getByRole('button',{name:'6',exact:true}).click();await b.getByRole('button',{name:'4',exact:true}).click();await b.getByRole('button',{name:'2',exact:true}).click();await b.getByRole('button',{name:'0',exact:true}).click();await b.getByRole('button',{name:'9',exact:true}).click();await b.getByRole('button',{name:'=',exact:true}).click();await b.locator('[data-action="open-room"]').first().click();await b.locator('.message').filter({hasText:'Şifreli merhaba'}).waitFor();reports.push('Bob PIN unlock and peer decryption passed');
 await b.locator('#message-text').fill('Karşılıklı mesaj testi');await b.locator('#compose').getByRole('button',{name:'Gönder',exact:true}).click();await a.locator('.message').filter({hasText:'Karşılıklı mesaj testi'}).waitFor();reports.push('Realtime bidirectional delivery passed');
 // Select an exact bundled animated emoji, not an arbitrary first catalog entry.
 await a.getByRole('button',{name:'İfade seç',exact:true}).click();await a.locator('#emoji-search').fill('😀');await a.locator('[data-action="choose-emoji"][data-emoji="😀"]').click();
 assert.equal(await a.locator('#message-text').inputValue(),'😀');await a.locator('#compose').getByRole('button',{name:'Gönder',exact:true}).click();
 const sentEmoji=a.locator('.message.mine[data-emoji="😀"]'),receivedEmoji=b.locator('.message:not(.mine)[data-emoji="😀"]');
 await sentEmoji.locator('img.animated-emoji[alt="😀"]').waitFor();await a.waitForFunction(()=>{const img=document.querySelector('.message.mine[data-emoji="😀"] img.animated-emoji');return img?.complete&&img.naturalWidth>0});
 await receivedEmoji.locator('.emoji-fallback').waitFor();assert.equal(await receivedEmoji.locator('.emoji-fallback').textContent(),'😀');assert.equal(await receivedEmoji.locator('.animated-emoji').count(),0);
 assert.equal(await a.evaluate(()=>matchMedia('(prefers-reduced-motion: reduce)').matches),false);assert.equal(await b.evaluate(()=>matchMedia('(prefers-reduced-motion: reduce)').matches),true);
 reports.push('Animated emoji image loads and peer receives exact Unicode with accessible reduced-motion fallback');
 await a.getByRole('button',{name:'Dosya ekle',exact:true}).click();const attachment=a.locator('#modal[open] .attach-grid');await attachment.waitFor();const poll=attachment.getByRole('button',{name:'Anket: Seçenekli soru',exact:true});assert.equal(await poll.getAttribute('data-action'),'poll');await poll.click();await a.locator('#poll-question').fill('Test sorusu');await a.locator('textarea[name="options"]').fill('Evet\nHayır');await a.getByRole('button',{name:'Anket gönder'}).click();await b.locator('.message').filter({hasText:'Test sorusu'}).waitFor();await a.locator('#modal').waitFor({state:'hidden'});reports.push('Poll creation delivery passed');
 await a.locator('.chat-head').getByRole('button',{name:'Sohbetler',exact:true}).click();await a.locator('.fs-home header').getByRole('button',{name:'Menü',exact:true}).click();await a.locator('#modal[open] [data-action="profile"]').click();await a.locator('[data-action="qr"]').click();await a.locator('#qr-canvas[width="260"]').waitFor();assert.equal(await a.locator('#qr-canvas').getAttribute('width'),'260');await a.locator('#modal[open]').getByRole('button',{name:'Kapat',exact:true}).click();await a.locator('#modal').waitFor({state:'hidden'});reports.push('Profile and real QR generation passed');
 await a.locator('.themes [data-action="light"]').click();await a.locator('body.light').waitFor();await a.locator('[data-action="light"].active').waitFor();assert(await a.locator('body').evaluate(el=>el.classList.contains('light')));await a.waitForFunction(()=>document.querySelector('#notice')?.textContent==='Tema kaydedildi.');reports.push('Persisted light theme passed');
 fs.mkdirSync('fs-mesajlasma/build/test-evidence',{recursive:true});await a.screenshot({path:'fs-mesajlasma/build/test-evidence/profile-light.png'});await b.screenshot({path:'fs-mesajlasma/build/test-evidence/chat-dark.png'});
 assert.deepEqual(errors,[]);reports.push('No browser JavaScript errors');
 console.log(JSON.stringify({passed:reports.length,reports,errors},null,2));fs.writeFileSync('fs-mesajlasma/build/test-evidence/ui-results.json',JSON.stringify({passed:reports.length,reports,errors},null,2));
 }catch(e){console.error('UI TEST FAILED',e);console.error('completed',reports,'page errors',errors);process.exitCode=1}finally{await browser.close()}
})();
