import test from 'node:test';import assert from 'node:assert/strict';import {videoTime,seekTarget,VIDEO_RATES} from '../web/video-player.js';
test('duration formatting',()=>{assert.equal(videoTime(65.9),'1:05');assert.equal(videoTime(3661),'1:01:01');assert.equal(videoTime(NaN),'0:00');assert.equal(videoTime(-10),'0:00')});
test('relative seek stays inside duration',()=>{assert.equal(seekTarget(2,-10,20),0);assert.equal(seekTarget(15,10,20),20);assert.equal(seekTarget(4,3,20),7)});
test('unknown duration cannot seek',()=>{for(const d of [NaN,Infinity,-1,0])assert.equal(seekTarget(0,10,d),null)});
test('valid bounded playback rates',()=>assert.deepEqual(VIDEO_RATES,[.5,.75,1,1.25,1.5,1.75,2]));
