"""Deterministic tool inputs; uses Android platform/build-tools and Eclipse ECJ.
No cloud build, publishing, or signing-key creation takes place in this script.
Supply an existing keystore through environment variables to sign the APK.
"""
import hashlib, json, os, pathlib, shutil, subprocess, sys, zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
CACHE=pathlib.Path(os.environ.get('FS_ANDROID_TOOLS',str(ROOT.parent/'build-tools-cache')))
PLATFORM=CACHE/'platform/android-35/android.jar'
TOOLS=CACHE/'tools/android-15'
OUT=ROOT/'build/android'
def run(args):
    subprocess.run([str(a) for a in args],check=True)
def build():
    if os.environ.get("FS_FCM_PROJECT") or os.environ.get("FS_GOOGLE_SERVICES_JSON_B64"):
        sys.exit("FCM requires the Gradle push build; see docs/PUSH-KURULUM.md. Manual APK will not include FCM.")
    def sources_hash():
        selected=[p for folder in ['web','android/app/src/main','server'] for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
        return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(selected)}
    input_hashes=sources_hash()
    if not PLATFORM.is_file() or not (CACHE/'ecj.jar').is_file():
        sys.exit('Android API 35, build tools 35.0.0 ve ECJ 3.39.0 gerekli. docs/BUILD.md dosyasına bakın.')
    if OUT.exists():shutil.rmtree(OUT)
    for folder in ['res','generated','classes','dex']: (OUT/folder).mkdir(parents=True)
    aapt=TOOLS/'aapt2';run([aapt,'compile','--dir',ROOT/'android/app/src/main/res','-o',OUT/'res'])
    args=[aapt,'link','-I',PLATFORM,'--manifest',ROOT/'android/app/src/main/AndroidManifest.xml','--java',OUT/'generated','--min-sdk-version','26','--target-sdk-version','35','--version-code','13','--version-name','34.32','-o',OUT/'resources.apk']
    args.extend(sorted((OUT/'res').glob('*.flat')));run(args)
    sources=list((ROOT/'android/app/src/main/java').rglob('*.java'))+list((OUT/'generated').rglob('*.java'))
    run(['java','-jar',CACHE/'ecj.jar','-1.8','-proc:none','-bootclasspath',str(PLATFORM)+os.pathsep+str(CACHE/'compiler-stubs.jar'),'-d',OUT/'classes',*sources])
    with zipfile.ZipFile(OUT/'classes.jar','w') as z:
        for p in (OUT/'classes').rglob('*.class'):z.write(p,p.relative_to(OUT/'classes'))
    run(['java','-cp',TOOLS/'lib/d8.jar','com.android.tools.r8.D8','--release','--min-api','26','--lib',PLATFORM,'--output',OUT/'dex',OUT/'classes.jar'])
    shutil.copy(OUT/'resources.apk',OUT/'unsigned.apk')
    with zipfile.ZipFile(OUT/'unsigned.apk','a',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        z.writestr('assets/build-info.json',json.dumps({'version':'34.32','package':'com.fs.mesajlasma','sources':input_hashes},sort_keys=True))
        for p in (OUT/'dex').glob('*.dex'):z.write(p,p.name)
        for p in sorted((ROOT/'web').rglob('*')):
            if p.is_file():z.write(p,'assets/web/'+str(p.relative_to(ROOT/'web')))
    if sources_hash()!=input_hashes:raise RuntimeError('Sources changed while building; retry with frozen inputs.')
    run([TOOLS/'zipalign','-P','16','-f','4',OUT/'unsigned.apk',OUT/'aligned.apk'])
    keystore=os.environ.get('FS_KEYSTORE')
    if 'FS_KEY_PASSWORD' not in os.environ and 'FS_KEYSTORE_PASSWORD' in os.environ:os.environ['FS_KEY_PASSWORD']=os.environ['FS_KEYSTORE_PASSWORD']
    if not keystore:print('Unsigned APK:',OUT/'aligned.apk');return
    dest=ROOT/'FS-Mesajlasma-34.32-gelistirme.apk'
    run(['java','-jar',TOOLS/'lib/apksigner.jar','sign','--ks',keystore,'--ks-key-alias',os.environ.get('FS_KEY_ALIAS','fs-development'),'--ks-pass','env:FS_KEYSTORE_PASSWORD','--key-pass','env:FS_KEY_PASSWORD','--out',dest,OUT/'aligned.apk'])
    run(['java','-jar',TOOLS/'lib/apksigner.jar','verify','--verbose','--print-certs',dest])
    print('APK:',dest,'SHA256:',hashlib.sha256(dest.read_bytes()).hexdigest())
if __name__=='__main__':build()
