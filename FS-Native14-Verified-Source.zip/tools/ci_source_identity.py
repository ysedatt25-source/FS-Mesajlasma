"""Bind regression, build and signing jobs to a single verified source manifest."""
import argparse
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


JVM_SUITES = ('CallWindowPolicy', 'ExternalWebLink', 'IncomingCallNotice', 'MessageAlertPolicy',
              'RatchetReservePolicy', 'AudioRoutePolicy', 'ProjectionSession')


def required_suites(root):
    return ({'dom', 'ui', 'node', 'java-parser-compile', 'java-syntax'}
            | {p.stem for p in (root / 'tests').glob('test_*.py')}
            | {name for name in JVM_SUITES}
            | {name + '-compile' for name in JVM_SUITES})


def verify_results(path, root):
    results = json.loads(path.read_text())
    if not isinstance(results, dict) or not results:
        raise ValueError('Missing regression results')
    missing = required_suites(root) - results.keys()
    if missing:
        raise ValueError('Required regression suites missing: ' + ', '.join(sorted(missing)))
    if any(type(code) is not int or code != 0 for code in results.values()):
        raise ValueError('Regression suite failed')


def verify_manifest(root, manifest):
    seen = set()
    for line in manifest.read_text().splitlines():
        match = re.fullmatch(r'([0-9a-f]{64})  (.+)', line)
        if not match:
            raise ValueError('Malformed source manifest')
        expected, name = match.groups()
        rel = Path(name)
        if rel.is_absolute() or '..' in rel.parts or name in seen:
            raise ValueError('Invalid or duplicate manifest entry: ' + name)
        path = root / rel
        if (not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(root.resolve())
                or digest(path) != expected):
            raise ValueError('Source digest mismatch: ' + name)
        seen.add(name)
    if not seen:
        raise ValueError('Empty source manifest')
    # Gradle and npm may load configuration outside android/app/src.
    for name in ('package.json', 'package-lock.json', '.npmrc', '.circleci/config.yml'):
        path = root / name
        if (path.exists() or path.is_symlink()) and name not in seen:
            raise ValueError('Untracked build configuration: ' + name)
    for path in (root / 'android').rglob('*'):
        rel = path.relative_to(root).as_posix()
        if any(rel == prefix or rel.startswith(prefix + '/') for prefix in
               ('android/.gradle', 'android/.kotlin', 'android/build', 'android/app/build')):
            continue
        if (path.is_file() or path.is_symlink()) and rel not in seen:
            raise ValueError('Untracked Android build input: ' + rel)
    # Block untracked runtime inputs from slipping into an otherwise verified build.
    for folder in ('web', 'android/app/src', 'server', 'tools', 'tests', 'deploy', 'server-integration', 'licenses'):
        for path in (root / folder).rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts and path.relative_to(root).as_posix() not in seen:
                raise ValueError('Untracked build, test or runtime file: ' + str(path.relative_to(root)))


def verify(root, directory, mode):
    manifest = root / 'FS-FINAL-SHA256.txt'
    results = directory / 'test-logs' / 'results.json'
    approval = directory / 'regression-source.json'
    build = directory / 'build-source.json'
    source_id = digest(manifest)
    verify_manifest(root, manifest)
    verify_results(results, root)
    identity = {'source_manifest_sha256': source_id,
                'regression_results_sha256': digest(results)}
    if mode == 'record-tests':
        approval.write_text(json.dumps(identity, sort_keys=True) + '\n')
        return
    if json.loads(approval.read_text()) != identity:
        raise ValueError('Regression source or result digest mismatch')
    if mode == 'check-tests':
        return
    apk = directory / 'FS-Mesajlasma-34.32-native14-push-unsigned.apk'
    metadata = directory.parent / 'push-metadata' / 'build-info.json'
    built = {**identity, 'unsigned_apk_sha256': digest(apk),
             'build_metadata_sha256': digest(metadata)}
    if mode == 'record-build':
        build.write_text(json.dumps(built, sort_keys=True) + '\n')
    elif mode == 'check-build' and json.loads(build.read_text()) != built:
        raise ValueError('Build source, APK or metadata digest mismatch')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('record-tests', 'check-tests', 'record-build', 'check-build'))
    args = parser.parse_args()
    try:
        verify(ROOT, ROOT / 'build/ci', args.mode)
    except (OSError, ValueError, TypeError) as exc:
        parser.exit(1, f'CI source identity rejected: {exc}\n')
    print('CI source identity verified:', args.mode)


if __name__ == '__main__':
    main()
