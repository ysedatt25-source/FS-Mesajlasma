"""Run the complete regression gate against an isolated local source tree."""
from pathlib import Path
import os, sys, subprocess, json, tempfile, time, urllib.request
ROOT=Path(__file__).resolve().parents[1]
LOG=ROOT/'build/ci/test-logs'; LOG.mkdir(parents=True,exist_ok=True)
os.chdir(ROOT)
results={}
env={**os.environ,'FS_TEST_PYTHON':sys.executable,'FS_DB_BACKEND':'sqlite','FS_REQUIRE_ADMIN':'0'}
# Never let deployment credentials or production database configuration enter tests.
for key in list(env):
    if key.startswith('FS_') and key not in {'FS_TEST_PYTHON','FS_DB_BACKEND','FS_REQUIRE_ADMIN','FS_CHROMIUM'}: env.pop(key)
for key in ('DATABASE_URL','MYSQL_URL','MARIADB_URL','ANDROID_KEYSTORE_BASE64','ANDROID_KEYSTORE_PASSWORD','ANDROID_KEY_ALIAS'): env.pop(key,None)
def run(name,cmd,timeout=180):
    with (LOG/(name+'.log')).open('w') as f:
        try: rc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout).returncode
        except subprocess.TimeoutExpired: rc=124
        except OSError as e: f.write(str(e)+'\n');rc=127
    results[name]=rc; print(name,rc,flush=True)
    return rc
# Run both integration suites first; a successful gate still requires every suite below.
run('dom',['node','tests/dom.test.mjs'],300)
# The historical UI suite explicitly targets a locally started test server.
with tempfile.TemporaryDirectory(prefix='fs-ci-ui-') as data:
    with (LOG/'ui-server.log').open('w') as f:
        server=subprocess.Popen([sys.executable,'-u','server/app.py'],env={**env,'FS_HOST':'127.0.0.1','FS_PORT':'8787','FS_DATA':data},stdout=f,stderr=subprocess.STDOUT)
        try:
            for _ in range(80):
                if server.poll() is not None: break
                try:
                    with urllib.request.urlopen('http://127.0.0.1:8787/index.html',timeout=.5): break
                except OSError: time.sleep(.25)
            else: results['ui-server']=1
            if server.poll() is not None: results['ui-server']=1
            if 'ui-server' not in results: run('ui',['node','tests/ui.test.cjs'],240)
        finally:
            server.terminate()
            try: server.wait(timeout=10)
            except subprocess.TimeoutExpired: server.kill();server.wait()
# Keep every regression suite mandatory, but collect all failures in one CI run.
# An integration failure never permits APK generation; it only no longer masks later failures.
print('Integration suites finished; collecting all remaining regression results.',flush=True)
node_suites=sorted(str(p.relative_to(ROOT)) for p in (ROOT/'tests').glob('*.test.mjs') if p.name!='dom.test.mjs')
run('node',['node','--test','--test-concurrency=1',*node_suites],300)
for p in sorted((ROOT/'tests').glob('test_*.py')):
    if p.name.endswith(('_browser.py','_dom.py')): run(p.stem,[sys.executable,str(p)],90)
    else: run(p.stem,[sys.executable,'-m','unittest','discover','-s','tests','-p',p.name,'-v'],240)
# Validate native Java syntax and isolated JVM policies before the Android build.
with tempfile.TemporaryDirectory(prefix='fs-ci-jvm-') as classes:
    src=ROOT/'android/app/src/main/java/com/fs/mesajlasma'
    if run('java-parser-compile',['javac','-d',classes,'tests/jvm/JavaSyntaxCheck.java'])==0:
        run('java-syntax',['java','-cp',classes,'JavaSyntaxCheck',*map(str,sorted((ROOT/'android/app/src').rglob('*.java')))])
    for name in ('CallWindowPolicy','ExternalWebLink','IncomingCallNotice','MessageAlertPolicy','RatchetReservePolicy','AudioRoutePolicy','ProjectionSession'):
        t=ROOT/'tests/native'/(name+'Test.java')
        if not t.is_file(): t=ROOT/'tests/jvm'/(name+'Test.java')
        if run(name+'-compile',['javac','-d',classes,str(src/(name+'.java')),str(t)])==0:
            run(name,['java','-cp',classes,'com.fs.mesajlasma.'+name+'Test'])
(LOG/'results.json').write_text(json.dumps(results,indent=2)+'\n')
for name,code in results.items():
    if code:
        log=LOG/(name+'.log')
        if log.exists(): print('\n--- '+log.name+' ---\n'+log.read_text(errors='replace'),flush=True)
        else: print(f'{name}: failed ({code}), log unavailable',flush=True)
sys.exit(int(any(results.values())))
