#!/usr/bin/env python3
"""Compare two locally collected ADB reports without claiming visual/network parity."""
import argparse
import json
import math
from pathlib import Path
from device_performance import PACKAGE, TELEGRAM_PACKAGES


def compare(fs, telegram):
    if fs.get('package') != PACKAGE or telegram.get('package') not in TELEGRAM_PACKAGES:
        raise ValueError('FS ve Telegram raporları gerekli.')
    for field in ('device_id_sha256', 'scenario', 'requested_seconds', 'interval_seconds'):
        if not fs.get(field) or fs[field] != telegram.get(field):
            raise ValueError(f'Karşılaştırma koşulu eşleşmiyor: {field}')
    for report in (fs, telegram):
        if report.get('same_main_process') is not True or not report.get('version'):
            raise ValueError('Süreç değişti veya uygulama sürümü eksik.')
        elapsed = report.get('duration_seconds')
        if not isinstance(elapsed,(int,float)) or not math.isfinite(elapsed) or abs(elapsed-report['requested_seconds']) > max(5,report['requested_seconds']*.1):
            raise ValueError('Ölçüm süresi geçersiz.')
    def number(v):
        return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and v>=0
    def item(label, a, b, min_samples=None, group=None):
        if min_samples and any(not number(r.get(group,{}).get('samples')) or r[group]['samples']<min_samples for r in (fs,telegram)):
            a=b=None
        valid=number(a) and number(b)
        return {'metric':label,'fs':a if valid else None,'telegram':b if valid else None,
                'fs_minus_telegram':round(a-b,2) if valid else None,
                'fs_vs_telegram_percent':round(100*(a-b)/b,2) if valid and b>0 else None}
    rows=[]
    for group, label, minimum in [('pss_kib','PSS KiB',3),('frame_duration_ms_sampled','Örneklenen kare süresi ms',20)]:
        for key in ('median','p95'):
            rows.append(item(f'{label} {key}',fs.get(group,{}).get(key),telegram.get(group,{}).get(key),minimum,group))
    a,b=(r.get('gfx_counter_delta') or {} for r in (fs,telegram))
    adequate=all(number(x.get('frames')) and x['frames']>=20 for x in (a,b))
    rows.append(item('Janky frame %',a.get('jank_percent') if adequate else None,b.get('jank_percent') if adequate else None))
    return {'scenario':fs['scenario'],'fs_version':fs['version'],'telegram_version':telegram['version'],
            'same_device':True,'requested_seconds':fs['requested_seconds'],'metrics':rows,
            'limitations':['Aynı cihaz ve ölçüm ayarları doğrulandı; kullanıcı hareketleri, veri kümesi, ağ ve sıcaklık eşitliği otomatik doğrulanmaz.',
                           'Eksik ya da yetersiz örnekler null olarak gösterilir; bunlar başarı sayılmaz.',
                           'Piksel eşitliği, mesaj gecikmesi, görüşme kalitesi, CPU ve uygulamaya özgü pil tüketimi bu raporla doğrulanmaz.']}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('fs',type=Path);p.add_argument('telegram',type=Path);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    try: result=compare(json.loads(args.fs.read_text()),json.loads(args.telegram.read_text()))
    except (OSError,ValueError,TypeError,KeyError) as e:p.exit(1,f'{e}\n')
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')

if __name__=='__main__':main()
