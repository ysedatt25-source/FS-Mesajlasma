#!/usr/bin/env python3
"""Read-only Android release-candidate measurement. Requires authorized ADB device.
No app data, chat contents, tokens, logcat or screenshots are collected.
"""
import argparse, hashlib, json, re, shutil, statistics, subprocess, time
from datetime import datetime, timezone
from pathlib import Path

PACKAGE = 'com.fs.mesajlasma'
TELEGRAM_PACKAGES = ('org.telegram.messenger', 'org.telegram.messenger.web')
PACKAGES = (PACKAGE, *TELEGRAM_PACKAGES)

def pss_kib(text):
    values=re.findall(r'(?m)^\s*TOTAL PSS:\s*([\d,]+)',text)
    if not values:values=re.findall(r'(?m)^\s*TOTAL\s+([\d,]+)\s+\d',text)
    return sum(int(v.replace(',','')) for v in values) if values else None

def gfx_counts(text):
    result={}
    for key,label in [('frames','Total frames rendered'),('janky','Janky frames')]:
        m=re.search(r'(?m)^\s*'+label+r':\s*([\d,]+)',text)
        result[key]=int(m.group(1).replace(',','')) if m else None
    return result

def frame_times(text):
    """Return unique valid framestats rows, keyed by intended vsync/completion."""
    result={}; header=None; active=False
    for line in text.splitlines():
        line=line.strip()
        if line=='---PROFILEDATA---':
            active=not active;header=None;continue
        if not active:continue
        if line.startswith('Flags,'):
            header=line.split(',');continue
        if not header:continue
        cells=line.split(',')
        try:
            flags=int(cells[header.index('Flags')]);start=int(cells[header.index('IntendedVsync')]);end=int(cells[header.index('FrameCompleted')])
        except (ValueError,IndexError):continue
        if flags==0 and 0<start<end<2**63-1 and end-start<=10_000_000_000:result[(start,end)]=(end-start)/1e6
    return result

def battery(text):
    result={}
    for key,label in [('level_percent','level'),('charge_counter_uAh','Charge counter'),('temperature_tenths_C','temperature'),('status','status')]:
        m=re.search(r'(?im)^\s*'+label+r':\s*(-?\d+)\s*$',text);result[key]=int(m.group(1)) if m else None
    return result

def metrics(values):
    a=sorted(v for v in values if v is not None)
    if not a:return {'samples':0,'median':None,'p95':None,'max':None}
    return {'samples':len(a),'median':round(statistics.median(a),2),'p95':round(a[max(0,(95*len(a)+99)//100-1)],2),'max':round(a[-1],2)}

def frame_delta(before,after):
    if any(before[k] is None or after[k] is None or after[k]<before[k] for k in ('frames','janky')):return None
    frames=after['frames']-before['frames'];janky=after['janky']-before['janky']
    if frames==0 or not 0<=janky<=frames:return None
    return {'frames':frames,'janky':janky,'jank_percent':round(100*janky/frames,2)}

def adb_command(serial,args):
    command=['adb']+(['-s',serial] if serial else [])+args
    p=subprocess.run(command,capture_output=True,text=True,timeout=25)
    if p.returncode:raise RuntimeError('ADB komutu başarısız: '+ ' '.join(args[:3]))
    return p.stdout

def run(args):
    if not shutil.which('adb'):raise RuntimeError('ADB bulunamadı; Android platform-tools kurun.')
    shell=lambda *x:adb_command(args.serial,['shell',*x])
    if adb_command(args.serial,['get-state']).strip()!='device':raise RuntimeError('Yetkili Android cihaz bağlı değil.')
    package=args.package
    if package not in PACKAGES:raise RuntimeError('Desteklenmeyen uygulama paketi.')
    if not shell('pm','path',package).strip().startswith('package:'):raise RuntimeError('Seçilen uygulama kurulu değil.')
    serial=adb_command(args.serial,['get-serialno']).strip()
    if not serial or serial=='unknown':raise RuntimeError('Cihaz kimliği doğrulanamadı.')
    device_id=hashlib.sha256(('FS-local-comparison:'+serial).encode()).hexdigest()
    version=re.search(r'(?m)^\s*versionName=(.+)$',shell('dumpsys','package',package))
    if not version:raise RuntimeError('Uygulama sürümü doğrulanamadı.')
    start_pid=shell('pidof',package).strip()
    if not start_pid:raise RuntimeError('Ölçümden önce uygulamayı açın.')
    before=shell('dumpsys','gfxinfo',package,'framestats');before_bat=battery(shell('dumpsys','battery'));initial=set(frame_times(before));sampled=[];new_frames={}
    latest_initial=max((x[0] for x in initial),default=0)
    begin=time.monotonic();deadline=begin+args.seconds
    print('Ölçüm başladı. Seçtiğiniz senaryoyu cihazda uygulayın.',flush=True)
    while True:
        sampled.append(pss_kib(shell('dumpsys','meminfo',package)))
        current=shell('dumpsys','gfxinfo',package,'framestats')
        new_frames.update({k:v for k,v in frame_times(current).items() if k not in initial and k[0]>latest_initial})
        now=time.monotonic()
        if now>=deadline:break
        time.sleep(min(args.interval,deadline-now))
    after_bat=battery(shell('dumpsys','battery'));same_pid=shell('pidof',package).strip()==start_pid
    return {'scenario':args.scenario,'package':package,'version':version.group(1).strip(),'device_id_sha256':device_id,'requested_seconds':args.seconds,'interval_seconds':args.interval,'utc':datetime.now(timezone.utc).isoformat(),'duration_seconds':round(time.monotonic()-begin,1),'same_main_process':same_pid,'pss_kib':metrics(sampled),'frame_duration_ms_sampled':metrics(new_frames.values()) if same_pid else metrics([]),'gfx_counter_delta':frame_delta(gfx_counts(before),gfx_counts(current)) if same_pid else None,'battery_device_before':before_bat,'battery_device_after':after_bat,'limitations':['PSS: dumpsys meminfo paket toplamı; süreç değişirse karşılaştırma geçersiz olabilir.','Framestats örneklenir; WebView/video FPS ölçümü değildir.','Pil verisi tüm cihaza aittir; uygulamaya özgü tüketim için kontrollü, eş süreli karşılaştırma gerekir.','Şarj durumu değişirse pil karşılaştırması geçersizdir.','Ölçüm uygulama davranışına küçük ek yük getirebilir.']}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--serial');p.add_argument('--package',choices=PACKAGES,default=PACKAGE);p.add_argument('--scenario',required=True,choices=['idle','chat-scroll','photo','call','background']);p.add_argument('--seconds',type=int,default=120);p.add_argument('--interval',type=int,default=5);p.add_argument('--output',required=True,type=Path);a=p.parse_args()
    if not 15<=a.seconds<=3600 or not 1<=a.interval<=60:p.error('seconds: 15–3600; interval: 1–60')
    try:
        report=run(a);a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(a.output)
    except (RuntimeError,subprocess.TimeoutExpired,OSError) as e:p.exit(1,str(e)+'\n')

if __name__=='__main__':main()
