"""Restore versioned emoji assets, validating content before extraction."""
import hashlib, pathlib, urllib.request, zipfile
ROOT = pathlib.Path(__file__).resolve().parents[1]
URL = 'https://github.com/ysedatt25-source/FS-Mesajlasma/releases/download/v34.32-dev.1/FS-emoji-assets-34.32.zip'
SHA256 = 'e5c03330fe4b6293df99d148f19cc84fb2b5c664643a04d89435224c5a50f20a'
def main():
    archive = ROOT / 'build-assets/emoji.zip'
    archive.parent.mkdir(parents=True, exist_ok=True)
    if not archive.exists(): urllib.request.urlretrieve(URL, archive)
    with archive.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    if digest != SHA256:
        raise RuntimeError('Emoji archive SHA-256 mismatch')
    with zipfile.ZipFile(archive) as z:
        for entry in z.infolist():
            target = (ROOT / entry.filename).resolve()
            if not target.is_relative_to((ROOT / 'web/emoji').resolve()):
                raise ValueError('Unexpected archive entry')
        z.extractall(ROOT)
    print('Emoji assets verified and restored')
if __name__ == '__main__': main()
