#!/usr/bin/env python3
"""Generate original, offline, illustrated profile avatars. No external artwork or network."""
import base64, io, json
from pathlib import Path
import cairosvg
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
# name, background, accent, skin, shadow, hair, clothing, hairstyle, glasses, beard
DESIGNS=[
 ('Kadın 1','#ecd9ed','#b66caa','#e9b995','#be815e','#432835','#9c528e','long',False,False),
 ('Erkek 1','#d9e7eb','#5793a9','#d4a17c','#9a6549','#352e2e','#395b76','short',False,True),
 ('Kadın 2','#d7e9de','#77a58b','#9d6248','#70412e','#25222b','#415e77','curls',True,False),
 ('Erkek 2','#efdcc8','#cc9862','#edbc94','#b57b53','#79502c','#3c7770','sweep',False,False),
 ('Kadın 3','#e1def4','#8d83d2','#f2c8ae','#bc8c72','#b36d42','#74629c','bob',False,False),
 ('Erkek 3','#d7e5d9','#729b77','#895439','#603622','#252123','#a3714a','fade',True,False),
 ('Kadın 4','#f1e1cf','#d39c76','#c18c6b','#8f583e','#33282d','#ba654e','bun',False,False),
 ('Erkek 4','#e4dced','#9a80b9','#f1c3a5','#c08a69','#3f3030','#5f577b','short',True,True),
 ('Kadın 5','#dce9ef','#6fa7bd','#b77b5b','#855039','#544035','#347b8b','scarf',False,False),
 ('Erkek 5','#efe1d7','#c58d79','#c38b65','#895b42','#211e24','#9c594d','curls-short',False,True),
 ('Kadın 6','#e6e7d4','#a0a872','#f2c5a2','#c18a65','#c28a45','#69784d','sweep-long',True,False),
 ('Erkek 6','#dae5f5','#869fc7','#e7b18b','#ac7355','#c1834e','#455f96','quiff',False,False),
 ('Kadın 7','#f0dadd','#ca8ca0','#88543f','#5c352b','#201c25','#8d455e','braids',False,False),
 ('Erkek 7','#e6e8e2','#94a19a','#b78466','#81543d','#676068','#415852','bald',True,True),
 ('Kadın 8','#dce3ed','#8d9db9','#e0a98a','#aa755f','#52414b','#4c6596','pixie',False,False),
 ('Erkek 8','#eee7d7','#b5a16f','#f0c7a8','#bc8a6c','#4f3730','#766b49','sweep',False,False),
]
def portrait(d):
 name,bg,accent,skin,shade,hair,shirt,style,glasses,beard=d
 f=[]
 def p(path,fill,extra=''): f.append(f'<path d="{path}" fill="{fill}" {extra}/>')
 def e(x,y,rx,ry,fill,extra=''): f.append(f'<ellipse cx="{x}" cy="{y}" rx="{rx}" ry="{ry}" fill="{fill}" {extra}/>')
 def line(path,stroke,w=4):p(path,'none',f'stroke="{stroke}" stroke-width="{w}" stroke-linecap="round" stroke-linejoin="round"')
 e(256,256,208,208,accent,'opacity=".18"');e(256,256,164,164,accent,'opacity=".12"')
 # Back of hair / scarf
 if style in ['long','sweep-long','bob','braids','curls','scarf']:
  p('M144 279 Q121 224 132 151 Q145 74 256 75 Q367 74 380 155 L389 293 Q379 350 324 361 L185 359 Q132 340 144 279Z', hair if style!='scarf' else shirt)
 if style=='bun':e(256,79,55,46,hair)
 if style in ['curls','curls-short']:
  for x,y in [(153,142),(175,105),(218,91),(258,84),(302,94),(345,114),(365,153)]: e(x,y,42,39,hair)
 if style=='braids':
  for x in [154,358]:
   for y in range(191,361,27):e(x,y,24,28,hair)
 # body and shoulders
 p('M65 512 L79 437 Q92 378 185 352 L221 338 L291 338 L327 352 Q420 378 433 437 L447 512 Z',shirt)
 p('M214 304 L298 304 L298 350 Q286 384 256 384 Q226 384 214 350Z',skin)
 p('M214 307 Q256 337 298 307 L298 332 Q256 353 214 331Z',shade)
 p('M189 352 L214 343 Q256 404 298 343 L323 352 Q301 400 256 410 Q211 400 189 352Z','#ffffff','opacity=".24"')
 # ears, face
 e(169,227,19,30,skin);e(343,227,19,30,skin);e(169,230,8,15,shade);e(343,230,8,15,shade)
 p('M173 159 Q185 112 256 110 Q327 112 339 159 L340 232 Q337 285 302 311 Q284 327 256 329 Q228 327 210 311 Q175 285 172 232Z',skin)
 # hair foreground
 if style=='bald':
  p('M171 205 Q165 147 199 127 Q174 167 185 198 L180 225Z',hair);p('M341 205 Q347 147 313 127 Q338 167 327 198 L332 225Z',hair)
 elif style=='scarf':
  p('M153 222 Q125 155 163 110 Q205 64 256 72 Q333 69 367 128 Q386 169 359 235 L340 218 Q341 150 310 129 Q269 148 206 140 Q176 162 172 223 Z',shirt)
  p('M155 245 Q169 299 211 324 L256 356 L202 393 L155 347 Q137 304 155 245Z',shirt);p('M357 245 Q343 299 301 324 L256 356 L310 393 L357 347 Q375 304 357 245Z',shirt)
 elif style in ['short','fade','quiff','sweep','curls-short','pixie']:
  paths={
  'short':'M170 213 L159 170 Q155 111 211 94 Q274 69 333 112 Q360 138 343 207 L331 174 Q326 145 310 140 Q256 161 199 139 Q180 169 183 207Z',
  'fade':'M171 208 L161 165 Q166 110 219 92 Q294 72 336 129 L349 196 L333 202 L330 155 Q265 135 183 158 L182 207Z',
  'quiff':'M170 209 L158 164 Q147 108 224 101 Q270 48 324 87 Q358 110 350 164 L341 207 L330 170 Q305 175 285 137 Q231 160 183 148 L182 207Z',
  'sweep':'M171 207 Q144 142 181 108 Q228 72 291 87 Q355 96 352 162 L341 213 L330 178 Q305 163 285 128 Q237 163 183 161 L182 208Z',
  'curls-short':'M170 211 L159 169 Q150 131 188 116 Q219 86 251 100 Q286 75 320 107 Q361 125 348 169 L343 210 L331 171 Q291 157 266 164 Q225 153 184 173 L181 211Z',
  'pixie':'M172 214 Q141 159 165 124 Q196 88 251 80 Q320 80 347 123 L345 205 L328 173 Q294 154 279 117 Q253 162 186 165 L181 214Z'}
  p(paths[style],hair)
 else:
  p('M171 215 Q139 184 151 137 Q176 83 256 87 Q328 84 357 144 Q373 190 341 228 L330 178 Q300 157 278 119 Q238 163 184 172 L183 218Z',hair)
  if style=='bob':p('M150 207 L184 216 Q180 281 203 306 L151 317 Q133 267 150 207Z',hair);p('M362 207 L328 216 Q332 281 309 306 L361 317 Q379 267 362 207Z',hair)
 if beard:
  p('M174 245 Q179 293 210 313 Q256 350 302 313 Q333 293 338 245 L322 265 Q310 294 287 296 Q277 274 256 279 Q235 274 225 296 Q202 294 190 265Z',hair,'opacity=".85"')
 # face
 for x in (218,294):
  line(f'M{x-18} 199 Q{x} 190 {x+18} 199',hair,5);e(x,218,7,10,'#322b32');e(x-2,215,2,2,'#ffffff')
 line('M256 218 L248 250 Q253 254 263 251',shade,4)
 line('M236 274 Q256 286 276 274','#954f50' if not beard else skin,4)
 if not beard:
  e(201,249,12,6,'#c87373','opacity=".28"');e(311,249,12,6,'#c87373','opacity=".28"')
 if glasses:
  color='#4a414f';e(218,219,31,23,'none',f'stroke="{color}" stroke-width="5"');e(294,219,31,23,'none',f'stroke="{color}" stroke-width="5"');line('M249 216 Q256 211 263 216 M187 216 L175 212 M325 216 L337 212',color,5)
 if name.startswith('Kadın') and style!='scarf':e(177,252,5,7,'#e5b85e');e(335,252,5,7,'#e5b85e')
 return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" fill="'+bg+'"/>'+''.join(f)+'</svg>'
entries=[]
for i,d in enumerate(DESIGNS,1):
 svg=portrait(d)
 png=cairosvg.svg2png(bytestring=svg.encode(),output_width=768,output_height=768)
 img=Image.open(io.BytesIO(png)).convert('RGB').resize((512,512),Image.Resampling.LANCZOS)
 out=io.BytesIO();img.save(out,format='JPEG',quality=89,optimize=True,subsampling=0)
 data='data:image/jpeg;base64,'+base64.b64encode(out.getvalue()).decode()
 assert len(data)<150000
 entries.append(dict(id=f'avatar-{i:02d}',label=d[0],photo=data))
(ROOT/'web/profile-avatars.js').write_text('// Generated by tools/generate_avatars.py — original illustrations, no external dependencies at runtime.\nexport const PROFILE_AVATARS = Object.freeze('+json.dumps(entries,ensure_ascii=False,separators=(',',':'))+'.map(Object.freeze));\nexport function profileAvatar(id) { return PROFILE_AVATARS.find(a=>a.id===id) || null; }\n',encoding='utf8')
print('Generated',len(entries),'original avatars;',sum(len(x['photo']) for x in entries),'data-URL characters')
