"""Original, individually drawn character animation frames (no mesh warping)."""
from pathlib import Path
from PIL import Image, ImageDraw
import math
ROOT=Path(__file__).resolve().parents[1]/'web'/'emoji-character'
N=16

def frame(kind,i):
    im=Image.new('RGBA',(128,128)); d=ImageDraw.Draw(im); t=2*math.pi*i/N
    def ellipse(box,fill): d.ellipse(box,fill=fill)
    if kind=='smirk':
        ellipse((12,12,116,116),'#ffc83d'); dark='#633b22'
        for x in (44,84):
            d.line((x-10,37,x+10,33),fill=dark,width=4)
            d.arc((x-10,43,x+10,55),180,360,fill=dark,width=4)
            ellipse((x+round(3*math.sin(t)),47,x+5+round(3*math.sin(t)),54),dark)
        d.arc((45,62,91,88+round(4*math.sin(t))),0,145,fill=dark,width=5)
    elif kind=='pray':
        for sign in (-1,1):
            x=64+sign*(4+round(3*(1+math.cos(t))))
            d.polygon([(x,15),(x+sign*17,48),(x+sign*27,79),(x+sign*17,100),(x,83)],fill='#ffc83d')
            d.line((x+sign*5,35,x+sign*13,65),fill='#d99b38',width=3)
            d.polygon([(x,83),(x+sign*17,100),(x+sign*29,121),(x+sign*7,121)],fill='#5087d8')
    elif kind=='rainbow':
        for j,c in enumerate(['#e94364','#f68b38','#ffc83d','#55b96d','#5688df','#9b70d9']):
            r=55-j*7; d.arc((64-r,88-r,64+r,88+r),180,360,fill=c,width=7)
        for x in (20,108):
            ellipse((x-17,78,x+17,100),'#e5eef5'); ellipse((x-9,70,x+9,92),'#f5f8fc')
        a=math.pi+math.pi*i/N; x=64+round(51*math.cos(a)); y=88+round(51*math.sin(a)); d.line((x-4,y,x+4,y),fill='white',width=2); d.line((x,y-4,x,y+4),fill='white',width=2)
    elif kind=='sob':
        ellipse((12,12,116,116),'#ffc83d')
        for x in (43,85):
            d.arc((x-12,39,x+12,59),180,360,fill='#633b22',width=5)
            for j in range(3):
                y=58+(i*4+j*22)%65; d.rounded_rectangle((x-6,y,x+6,min(y+17,127)),5,fill='#48b9ed')
        ellipse((43,65,85,96+round(4*math.sin(t))),'#633b22')
    elif kind=='rocket':
        d.polygon([(64,8),(42,45),(42,91),(86,91),(86,45)],fill='#e5e8ef')
        d.polygon([(64,8),(48,32),(80,32)],fill='#e94364')
        ellipse((53,42,75,64),'#4385bc')
        d.polygon([(42,65),(26,98),(42,90)],fill='#e94364'); d.polygon([(86,65),(102,98),(86,90)],fill='#e94364')
        d.polygon([(48,92),(80,92),(64,112+round(9*math.sin(t)))],fill='#f56b24')
        d.polygon([(57,92),(71,92),(64,105+round(5*math.sin(t)))],fill='#ffc83d')
    elif kind=='music':
        d.line((52,28,52,91),fill='#6552a5',width=9); d.line((94,18,94,77),fill='#6552a5',width=9)
        d.polygon([(48,25),(98,13),(98,30),(48,42)],fill='#6552a5')
        ellipse((25,82,56,103),'#6552a5'); ellipse((67,68,98,89),'#6552a5')
        for j in range(3):
            r=5+(i*2+j*9)%27; d.arc((52-r,52-r,52+r,52+r),195,275,fill='#ed78a5',width=3)
    elif kind=='clap':
        gap=round(8*(1+math.cos(t)))
        for sign in (-1,1):
            x=64+sign*(19+gap)
            d.rounded_rectangle((x-15,49,x+15,105),12,fill='#e9a33c')
            for j in range(4):
                xx=x-12+j*7; d.rounded_rectangle((xx,27+j*2,xx+6,66),3,fill='#ffc83d')
        if gap<5:
            for x in (48,64,80): d.line((x,20,x,9),fill='#ffc83d',width=3)
    elif kind=='balloon':
        w=round(3*math.sin(t)); ellipse((30-w,8,98+w,83),'#e94364')
        ellipse((42,19,53,40),'#ff9bac'); d.polygon([(64,80),(58,89),(70,89)],fill='#e94364')
        d.line([(64,89),(64+w,99),(60-w,110),(64,123)],fill='#633b22',width=2)
    elif kind=='sad':
        ellipse((12,12,116,116),'#ffc83d'); dark='#633b22'
        for x in (44,84):
            h=2 if 5<=i<=7 else 12; ellipse((x-5,48-h//2,x+5,48+h//2),dark)
            d.line((x-9,38,x+9,34 if x==44 else 42),fill=dark,width=3)
        d.arc((43,76+round(3*math.sin(t)),85,101),180,360,fill=dark,width=5)
    elif kind=='shock':
        ellipse((12,12,116,116),'#ffc83d'); dark='#633b22'
        for x in (43,85):
            ellipse((x-10,34,x+10,59),'white'); ellipse((x-4,42,x+4,51),dark)
        h=12+round(5*math.sin(t)); ellipse((48,76-h,80,76+h),dark)
        for x in (20,108): ellipse((x-8,65,x+8,94),'#ffd87a')
    elif kind=='broken':
        gap=round(3*(1+math.sin(t))); c='#e94364'
        ellipse((14-gap,24,64-gap,75),c); ellipse((64+gap,24,114+gap,75),c)
        d.polygon([(14-gap,50),(61-gap,50),(52-gap,67),(64-gap,77),(58-gap,111)],fill=c)
        d.polygon([(67+gap,50),(114+gap,50),(66+gap,111),(72+gap,76),(60+gap,66)],fill=c)
    elif kind=='fish':
        w=12+round(8*math.sin(t)); d.polygon([(83,64),(111,64-w),(111,64+w)],fill='#ef913b')
        ellipse((16,35,94,93),'#f6b34e'); ellipse((28,49,42,63),'white'); ellipse((30,52,36,59),'#493323')
        d.arc((47,44,70,84),270,90,fill='#c87932',width=3)
        y=30-i; d.ellipse((8,y,15,y+7),outline='#72c9e8',width=2)
    elif kind=='cool':
        ellipse((12,12,116,116),'#ffc83d'); d.rounded_rectangle((23,37,60,62),7,fill='#252c39'); d.rounded_rectangle((68,37,105,62),7,fill='#252c39'); d.line((60,44,68,44),fill='#252c39',width=5)
        x=30+round(15*(1+math.sin(t))/2)
        for offset in (0,45): d.line((x+offset,41,x+offset-7,55),fill='#9cc9df',width=3)
        d.arc((40,57,88,94),0,180,fill='#633b22',width=5)
    elif kind=='bee':
        h=12+round(10*math.sin(t)**2)
        ellipse((30,45-h,65,55),'#b9e5f2'); ellipse((62,45-h,97,55),'#b9e5f2')
        ellipse((25,48,104,100),'#ffc83d'); d.rectangle((48,51,58,97),fill='#493323'); d.rectangle((72,51,82,97),fill='#493323'); ellipse((15,55,45,88),'#ffc83d'); ellipse((23,64,29,70),'#493323'); d.polygon([(101,66),(117,74),(101,81)],fill='#493323')
    elif kind=='thumb':
        d.rounded_rectangle((28,65,52,112),6,fill='#e9a33c'); d.rounded_rectangle((48,57,105,111),12,fill='#ffc36a')
        x=round(5*math.sin(t)); d.rounded_rectangle((51+x,19,72+x,76),10,fill='#ffc36a'); d.line((55,77,95,77),fill='#d18b39',width=2); d.line((55,91,95,91),fill='#d18b39',width=2)
    elif kind=='candle':
        d.rounded_rectangle((43,58,85,119),8,fill='#f5d9a0'); ellipse((43,52,85,67),'#fff1cb'); d.line((64,60,64,43),fill='#493323',width=4)
        x=64+round(5*math.sin(t)); y=13+round(5*math.cos(t)); d.polygon([(64,49),(49,35),(x,y),(79,35)],fill='#ff9b25'); ellipse((58,32,70,47),'#fff2a0')
    elif kind=='wave':
        # Palm stays fixed; fingers articulate independently.
        d.rounded_rectangle((43,48,92,104),18,fill='#ffc83d')
        d.rounded_rectangle((53,91,80,123),8,fill='#ffc83d')
        for j in range(4):
            x=47+j*12; dx=round(9*math.sin(t+j*.4)); y=13+abs(j-1)*5
            d.line((x,61,x+dx,y),fill='#ffc83d',width=12); ellipse((x+dx-6,y-6,x+dx+6,y+6),'#ffc83d')
        d.line((49,81,27,61+round(5*math.sin(t))),fill='#ffc83d',width=15)
    elif kind=='star':
        pts=[(64+round((49 if j%2==0 else 23)*math.sin(j*math.pi/5)),64-round((49 if j%2==0 else 23)*math.cos(j*math.pi/5))) for j in range(10)]
        d.polygon(pts,fill='#ffc83d'); x=45+round(18*math.sin(t)); y=47+round(8*math.cos(t)); d.line((x-8,y,x+8,y),fill='#fff6b8',width=3); d.line((x,y-8,x,y+8),fill='#fff6b8',width=3)
    elif kind=='flower':
        d.line((64,64,64,121),fill='#38945a',width=7); ellipse((35,87,64,105),'#55b96d'); ellipse((64,79,93,97),'#55b96d')
        for j in range(6):
            a=j*math.pi/3; r=24+round(4*math.sin(t)); x=64+round(r*math.cos(a)); y=47+round(r*math.sin(a)); ellipse((x-17,y-17,x+17,y+17),'#ed78a5')
        ellipse((48,31,80,63),'#ffc83d')
    elif kind=='heart':
        # A stationary heart with a rhythmic contraction around its center.
        r=23+round(3*math.sin(t)); y=48
        ellipse((64-2*r,y-r,64,y+r),'#e94364'); ellipse((64,y-r,64+2*r,y+r),'#e94364')
        d.polygon([(64-2*r,y),(64+2*r,y),(64,103+round(3*math.sin(t)))],fill='#e94364')
    elif kind=='fire':
        x=64+round(8*math.sin(t)); y=8+round(5*math.cos(t))
        d.polygon([(64,119),(27,98),(22,70),(43,38),(48,65),(x,y),(91,47),(105,77),(100,103)],fill='#f56b24')
        ellipse((43,65,85,115),'#ffcc45'); d.polygon([(43,88),(64,48+round(6*math.sin(t))),(85,88)],fill='#ffcc45')
    elif kind=='butterfly':
        w=25+round(15*math.sin(t)**2)
        for sign in (-1,1):
            x=64+sign*w; ellipse((min(x,64)-5,19,max(x,64)+5,76),'#5688df'); ellipse((min(x,64),67,max(x,64),107),'#9b70d9')
        d.rounded_rectangle((59,39,69,105),5,fill='#493323'); d.line((62,43,51,23),fill='#493323',width=2); d.line((66,43,77,23),fill='#493323',width=2)
    elif kind in ('grin','tongue','think'):
        ellipse((12,12,116,116),'#ffc83d'); dark='#633b22'
        for x in (44,84):
            if 5<=i<=7: d.line((x-7,48,x+7,48),fill=dark,width=4)
            else: ellipse((x-5,40,x+5,55),dark)
        if kind=='grin':
            d.rounded_rectangle((36,65,92,91+round(3*math.sin(t))),10,fill=dark)
            d.rounded_rectangle((41,68,87,80),4,fill='white')
        elif kind=='tongue':
            ellipse((40,64,88,91),dark)
            d.rounded_rectangle((54,77,76,94+round(5*math.sin(t))),9,fill='#ed718b')
        else:
            d.line((35,34,53,39),fill=dark,width=4)
            d.line((57,77,76,74),fill=dark,width=4)
            y=round(3*math.sin(t)); d.rounded_rectangle((64,88+y,105,109+y),10,fill='#e9a33c'); d.rounded_rectangle((63,81+y,91,92+y),5,fill='#e9a33c')
    elif kind in ('love','sleep','surprise'):
        ellipse((12,12,116,116),'#ffc83d'); dark='#633b22'
        for x in (44,84):
            if kind=='love':
                r=9+round(2*math.sin(t)); y=47
                ellipse((x-r,y-r,x,y),'#e94364'); ellipse((x,y-r,x+r,y),'#e94364'); d.polygon([(x-r,y-3),(x+r,y-3),(x,y+r)],fill='#e94364')
            elif kind=='sleep': d.arc((x-10,40,x+10,54),0,180,fill=dark,width=4)
            else: ellipse((x-6,39,x+6,55),dark)
        if kind=='love': d.arc((40,54,88,91),0,180,fill=dark,width=5)
        else:
            h=8+round(4*(1+math.sin(t))); ellipse((53,78-h,75,78+h),dark)
            if kind=='sleep':
                x=96; y=35-i; d.line([(x,y),(x+10,y),(x,y+10),(x+10,y+10)],fill='#4385bc',width=3)
    elif kind in ('laugh','cry','angry'):
        ellipse((12,12,116,116),'#f07845' if kind=='angry' else '#ffc83d'); dark='#633b22'
        for x in (44,84):
            if kind=='laugh': d.arc((x-12,40,x+12,61),180,360,fill=dark,width=5)
            else: ellipse((x-5,43,x+5,57),dark)
            if kind in ('cry','laugh'):
                y=57+int((i%8)*4); ellipse((x-8,y,x+1,y+13),'#48b9ed')
            if kind=='angry': d.line((x-12,32 if x==44 else 43,x+12,43 if x==44 else 32),fill=dark,width=6)
        if kind=='laugh':
            ellipse((39,62,89,98+int(3*math.sin(t))),dark); d.rounded_rectangle((45,65,83,74),3,fill='white')
        else: d.arc((43,72-int(3*math.sin(t)),85,100),180,360,fill=dark,width=5)
    elif kind in ('kiss','smile','wink'):
        ellipse((12,12,116,116),'#ffc83d'); dark='#633b22'
        blink=5<=i<=8
        for x in (44,84):
            if blink and (kind!='wink' or x==44):
                d.arc((x-10,40,x+10,53),180,360,fill=dark,width=4)
            else: ellipse((x-5,40,x+5,54),dark)
        if kind=='kiss':
            ellipse((52,69,73,82),'#a64a35'); d.line((61,69,61,82),fill=dark,width=2)
            if i>=3:
                x=78+2*(i-3); y=72-(i-3)*3; r=8
                ellipse((x-r,y-r,x,y),'#e94364');ellipse((x,y-r,x+r,y),'#e94364');d.polygon([(x-r,y-3),(x+r,y-3),(x,y+r)],fill='#e94364')
        else:
            d.arc((40,54,88,91+round(4*math.sin(t))),0,180,fill=dark,width=5)
            if kind=='smile':
                ellipse((24,65,38,73),'#f49b53');ellipse((90,65,104,73),'#f49b53')
    else:
        cat=kind=='cat'; fur='#e9a34b' if cat else '#c58c57'; dark='#74452e'
        if cat:
            d.polygon([(19,48),(18,9),(53,31)],fill=fur);d.polygon([(109,48),(110,9),(75,31)],fill=fur)
            d.polygon([(25,34),(24,18),(43,32)],fill='#f3a0a0');d.polygon([(103,34),(104,18),(85,32)],fill='#f3a0a0')
        else:
            ellipse((8,22,40,83),dark);ellipse((88,22,120,83),dark)
        ellipse((21,25,107,112),fur);ellipse((39,65,89,103),'#ffe1b5')
        h={5:8,6:4,7:2,8:4,9:8}.get(i,14)
        for x in (45,83): ellipse((x-5,52-h//2,x+5,52+h//2),'#38251f')
        ellipse((58,68,70,77),'#65413a');d.arc((49,72,64,86),0,180,fill=dark,width=2);d.arc((64,72,79,86),0,180,fill=dark,width=2)
        if cat:
            for y in (76,83):
                d.line((15,y-3,39,y),fill=dark,width=2);d.line((89,y,113,y-3),fill=dark,width=2)
        else:
            length=round(9+7*(1+math.sin(t))/2);d.rounded_rectangle((59,85,69,85+length),5,fill='#ef8291')
    return im

def main():
    ROOT.mkdir(exist_ok=True)
    for name,kind in [('e-1f431.webp','cat'),('e-1f436.webp','dog'),('e-1f56f.webp','candle'),('e-1f618.webp','kiss'),('e-1f60a.webp','smile'),('e-1f609.webp','wink'),('e-1f602.webp','laugh'),('e-1f622.webp','cry'),('e-1f621.webp','angry'),('e-1f60d.webp','love'),('e-1f634.webp','sleep'),('e-1f62e.webp','surprise'),('e-2764.webp','heart'),('e-1f525.webp','fire'),('e-1f98b.webp','butterfly'),('e-1f44b.webp','wave'),('e-2b50.webp','star'),('e-1f338.webp','flower'),('e-1f601.webp','grin'),('e-1f61b.webp','tongue'),('e-1f914.webp','think'),('e-1f60e.webp','cool'),('e-1f41d.webp','bee'),('e-1f44d.webp','thumb'),('e-1f631.webp','shock'),('e-1f494.webp','broken'),('e-1f41f.webp','fish'),('e-1f44f.webp','clap'),('e-1f388.webp','balloon'),('e-1f614.webp','sad'),('e-1f62d.webp','sob'),('e-1f680.webp','rocket'),('e-1f3b5.webp','music'),('e-1f60f.webp','smirk'),('e-1f64f.webp','pray'),('e-1f308.webp','rainbow')]:
        frames=[frame(kind,i) for i in range(N)]
        frames[0].save(ROOT/name,save_all=True,append_images=frames[1:],duration=100,loop=0,lossless=True)
if __name__=='__main__': main()
