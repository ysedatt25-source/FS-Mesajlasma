"""Build local frame animations from Noto Color Emoji bitmap glyphs.

Requires Python Pillow, fontTools, numpy, opencv-python and Node 22 (Unicode 16).
No font is redistributed; existing original animation catalog stays byte-identical.
Generated frames deform the actual glyph (not its message bubble or screen position).
"""
import argparse, concurrent.futures, hashlib, io, itertools, json, math, pathlib, subprocess
from collections import defaultdict
from fontTools.ttLib import TTFont
from PIL import Image
import cv2
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parents[1]
SIZE=80
FRAMES=8
# Fixed edges, internal mesh deformation. Different geometry for flags / other glyphs.
Y,X=np.mgrid[0:SIZE,0:SIZE].astype('float32')
edge=np.sin(np.pi*X/(SIZE-1))*np.sin(np.pi*Y/(SIZE-1))
MAPS={}
for kind in ('flag','glyph'):
    maps=[]
    for i in range(FRAMES):
        t=2*math.pi*i/FRAMES
        if kind=='flag':
            dx=np.zeros_like(X); dy=2.6*edge*np.sin(X*.21-t)
        else:
            dx=1.8*edge*np.sin(Y*.15-t); dy=1.35*edge*np.sin(X*.18+t)
        maps.append(((X+dx).astype('float32'),(Y+dy).astype('float32')))
    MAPS[kind]=maps

def render(task):
    emoji,glyph,data=task
    name='e-'+'_'.join(f'{ord(c):x}' for c in emoji if c!='\ufe0f')+'.webp'
    target=ROOT/'web/emoji-extra'/name
    kind='flag' if any(0x1f1e6<=ord(c)<=0x1f1ff or 0xe0020<=ord(c)<=0xe007f for c in emoji) else 'glyph'
    im=Image.open(io.BytesIO(data)).convert('RGBA');im=im.crop(im.getbbox());im.thumbnail((72,72),Image.Resampling.LANCZOS)
    canvas=Image.new('RGBA',(SIZE,SIZE));canvas.paste(im,((SIZE-im.width)//2,(SIZE-im.height)//2))
    pix=np.asarray(canvas).copy();# Premultiply for clean transparent edges.
    f=pix.astype('float32');f[:,:,:3]*=f[:,:,3:4]/255
    frames=[]
    for mx,my in MAPS[kind]:
        z=cv2.remap(f,mx,my,cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT)
        z[:,:,:3]*=255/np.maximum(z[:,:,3:4],1)
        frames.append(Image.fromarray(np.rint(z).clip(0,255).astype('uint8')))
    frames[0].save(target,format='WEBP',save_all=True,append_images=frames[1:],duration=120,loop=0,quality=80,method=1)
    with Image.open(target) as result:
        if result.n_frames<2 or result.size!=(SIZE,SIZE):raise ValueError(f'Invalid animation: {name}')
    return {'emoji':emoji,'file':name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'frames':FRAMES,'style':kind}

def main():
    p=argparse.ArgumentParser();p.add_argument('--font',default='/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf');p.add_argument('--workers',type=int,default=4);p.add_argument('--allow-legacy-warp',action='store_true',help='Explicitly regenerate deprecated mesh-warp assets for historical reproducibility only');a=p.parse_args()
    if not a.allow_legacy_warp:p.error('Generic mesh warp is deprecated; use individually authored animations. No files changed.')
    cv2.setNumThreads(1);font=TTFont(a.font);cmap=font.getBestCmap();rev=defaultdict(list)
    for cp,g in cmap.items():rev[g].append(cp)
    bitmaps=font['CBDT'].strikeData[0];pairs={chr(cp):g for cp,g in cmap.items() if g in bitmaps}
    # Resolve full ligatures from their exact Unicode scalar sequence, never from a different tone/gender.
    for lookup in font['GSUB'].table.LookupList.Lookup:
        if lookup.LookupType!=4:continue
        for subtable in lookup.SubTable:
            for base,ligs in subtable.ligatures.items():
                for lig in ligs:
                    if lig.LigGlyph not in bitmaps:continue
                    for seq in itertools.product(*(rev[x] for x in [base,*lig.Component])):
                        pairs[''.join(map(chr,seq))]=lig.LigGlyph
    js=r'''const fs=require('fs');const data=JSON.parse(fs.readFileSync(0,'utf8'));const key=s=>s.replace(/\ufe0f/g,'');const old=new Set(JSON.parse(fs.readFileSync('web/emojis.json')).map(x=>key(x.emoji)));const rgi=/^\p{RGI_Emoji}$/v;const qualify=s=>[...s].map(c=>/\p{Emoji}/u.test(c)&&!/\p{Emoji_Presentation}/u.test(c)?c+'\ufe0f':c).join('');const found=new Set();const rows=[];for(const [s,g] of Object.entries(data)){const q=rgi.test(s)?s:qualify(s);if(rgi.test(q)&&!old.has(key(q))&&!found.has(key(q))){rows.push([q,g]);found.add(key(q))}}process.stdout.write(JSON.stringify(rows));'''
    rows=json.loads(subprocess.check_output(['node','-e',js],input=json.dumps(pairs).encode(),cwd=ROOT))
    target=ROOT/'web/emoji-extra';target.mkdir(exist_ok=True)
    tasks=[]
    for emoji,glyph in rows:
        b=bitmaps[glyph];b.ensureDecompiled();tasks.append((emoji,glyph,b.imageData))
    with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
        entries=list(pool.map(render,tasks,chunksize=16))
    entries.sort(key=lambda x:tuple(map(ord,x['emoji'])))
    (ROOT/'web/emoji-extension.json').write_text(json.dumps([{'emoji':x['emoji'],'file':x['file']} for x in entries],ensure_ascii=False,separators=(',',':'))+'\n')
    out=ROOT/'docs/madde10-dogrulama';out.mkdir(exist_ok=True)
    (out/'assets.json').write_text(json.dumps({'fontVersion':font['name'].getDebugName(5),'unicode':subprocess.check_output(['node','-p','process.versions.unicode'],text=True).strip(),'assets':entries},ensure_ascii=False,indent=1)+'\n')
    print(f'Generated {len(entries)} exact-sequence animated WebP files, {sum((target/x["file"]).stat().st_size for x in entries)} bytes.')
if __name__=='__main__':main()
