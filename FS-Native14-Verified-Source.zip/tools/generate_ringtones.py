"""Generate original, long, offline FS ringtone samples (no external music)."""
from pathlib import Path
import math, struct, wave, shutil
ROOT=Path(__file__).resolve().parents[1]
RATE=22050
# (start seconds, length, pitch Hz); original simple notification motifs.
TONES={
 'classic':[(0,.30,659.25),(.37,.30,659.25),(.87,.30,783.99),(1.24,.45,659.25)],
 'crystal':[(0,.24,1046.5),(.27,.24,1318.5),(.54,.24,1568),(.84,.45,1046.5),(1.55,.32,1318.5)],
 'soft':[(0,.48,440),(.52,.44,554.37),(1.0,.70,493.88)],
 'pulse':[(0,.17,523.25),(.22,.17,783.99),(.44,.17,523.25),(.96,.17,523.25),(1.18,.17,783.99),(1.40,.17,523.25)],
 'aurora':[(0,.32,587.33),(.35,.32,739.99),(.70,.38,880),(1.12,.68,739.99)],
}
web=ROOT/'web'/'ringtones'; raw=ROOT/'android/app/src/main/res/raw';web.mkdir(exist_ok=True);raw.mkdir(exist_ok=True)
for name,notes in TONES.items():
 samples=[]
 for i in range(int(RATE*2.4)):
  t=i/RATE;value=0
  for start,length,pitch in notes:
   x=t-start
   if 0<=x<length:
    envelope=min(1,x/.018,(length-x)/.075)*math.exp(-1.6*x/length)
    value+=.40*envelope*(math.sin(2*math.pi*pitch*x)+.20*math.sin(4*math.pi*pitch*x))
  samples.append(round(max(-1,min(1,value))*32767))
 dest=web/(name+'.wav')
 with wave.open(str(dest),'wb') as f:
  f.setparams((1,2,RATE,0,'NONE','not compressed'));f.writeframes(struct.pack('<'+'h'*len(samples),*samples)*15)
 shutil.copyfile(dest,raw/('fs_ring_'+name+'.wav'))
