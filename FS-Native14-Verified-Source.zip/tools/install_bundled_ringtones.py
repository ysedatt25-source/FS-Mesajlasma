"""Install two user-authorized, already arranged polyphonic PCM WAV ringtones.
No song content is included by this tool. Run before building the Android APK.
"""
import argparse
from pathlib import Path
import wave

ROOT = Path(__file__).resolve().parents[1]
SLOTS = ('sura_derinlere', 'sezen_tukenecegiz')

def prepare(source):
    with wave.open(str(source), 'rb') as w:
        channels, width, rate, count, compression, _ = w.getparams()
        if channels not in (1, 2) or width != 2 or not 8000 <= rate <= 48000 or compression != 'NONE' or not rate <= count <= 180 * rate:
            raise ValueError('Expected 1–180 seconds of mono/stereo 16-bit PCM WAV')
        data = w.readframes(min(count, 45 * rate))
        if len(data) != min(count, 45 * rate) * channels * width:
            raise ValueError('Incomplete WAV')
    # Repeat whole short motifs, with a bounded 45-second total.
    if len(data) < 30 * rate * channels * width:
        data = (data * ((30 * rate * channels * width + len(data) - 1) // len(data)))[:45 * rate * channels * width]
    return channels, width, rate, data

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for slot in SLOTS:
        p.add_argument('--' + slot.replace('_', '-'), type=Path, required=True)
    args = p.parse_args()
    prepared = {slot: prepare(getattr(args, slot)) for slot in SLOTS}
    for slot, (channels, width, rate, data) in prepared.items():
        dest = ROOT / 'android/app/src/main/res/raw' / ('fs_ring_' + slot + '.wav')
        with wave.open(str(dest), 'wb') as w:
            w.setparams((channels, width, rate, 0, 'NONE', 'not compressed'))
            w.writeframes(data)
        print(dest.name)

if __name__ == '__main__':
    main()
