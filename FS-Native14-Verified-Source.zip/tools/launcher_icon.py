"""Replace only the existing compiled vector drawable, preserving Android resource IDs."""
import struct as st
U=lambda n:st.pack('<I',n)
paths=[
(0xff111e2d,'M24,7H84Q101,7 101,24V84Q101,101 84,101H24Q7,101 7,84V24Q7,7 24,7Z'),
(0xff40566b,'M28,16H80Q92,16 92,28V43Q92,49 85,49H23Q16,49 16,43V28Q16,16 28,16Z'),
(0xff07121f,'M28,18H80Q90,18 90,28V42Q90,47 85,47H23Q18,47 18,42V28Q18,18 28,18Z'),
(0xffe8f4ff,'M37,24H49V28H37Z M33,28H37V34H33Z M37,32H47V36H37Z M33,36H37V42H33Z'),
(0xff31a5ff,'M63,24H75V28H63Z M59,28H63V34H59Z M63,32H73V36H63Z M73,36H77V41H73Z M60,41H73V45H60Z'),
(0xff465b70,'M29,53H48Q54,53 54,59V68Q54,74 48,74H29Q23,74 23,68V59Q23,53 29,53Z M65,53H79Q85,53 85,59V68Q85,74 79,74H65Q59,74 59,68V59Q59,53 65,53Z M29,77H48Q54,77 54,83V89Q54,95 48,95H29Q23,95 23,89V83Q23,77 29,77Z'),
(0xff1888eb,'M65,77H79Q85,77 85,83V89Q85,95 79,95H65Q59,95 59,89V83Q59,77 65,77Z'),
(0xfff2f7ff,'M37,57H40V62H46V65H40V70H37V65H31V62H37Z M65,62H79V66H65Z M32,80L39,86L46,80L48,82L41,86L48,91L46,93L39,88L32,93L30,91L37,86L30,82Z M65,82H79V85H65Z M65,88H79V91H65Z'),
]
def length(n):return bytes([n]) if n<128 else bytes([0x80|(n>>8),n&255])
def replace_vector(data):
 assert data[:4]==b'\x03\x00\x08\x00'
 typ,head,size,n,styles,flags,start,styles_start=st.unpack_from('<HHIIIIII',data,8)
 assert (typ,head,styles,flags)==(1,28,0,256)
 pool_at=8;old=[];base=pool_at+start
 def readlen(pos):
  a=data[pos];return (((a&127)<<8)|data[pos+1],pos+2) if a&128 else (a,pos+1)
 for i in range(n):
  pos=base+st.unpack_from('<I',data,36+4*i)[0];_,pos=readlen(pos);length_b,pos=readlen(pos);old.append(data[pos:pos+length_b].decode())
 assert old[11:13]==['path','vector']
 strings=old+[p for _,p in paths];payload=b'';offsets=[]
 for v in strings:
  b=v.encode();offsets.append(len(payload));payload+=length(len(v.encode('utf-16-le'))//2)+length(len(b))+b+b'\0'
 payload+=b'\0'*(-len(payload)%4)
 start=28+4*len(strings);pool=st.pack('<HHIIIIII',1,28,start+len(payload),len(strings),0,256,start,0)+b''.join(map(U,offsets))+payload
 chunks=[];pos=8+size
 while pos<len(data):
  t,h,z=st.unpack_from('<HHI',data,pos);chunks.append((t,data[pos:pos+z]));pos+=z
 assert [t for t,_ in chunks]==[0x180,0x100,0x102,0x102,0x103,0x102,0x103,0x102,0x103,0x103,0x101]
 startpath=chunks[3][1];endpath=chunks[4][1];generated=[]
 for i,(color,path) in enumerate(paths):
  v=bytearray(startpath);st.pack_into('<I',v,8,i+2);st.pack_into('<I',v,52,color);st.pack_into('<I',v,64,n+i);st.pack_into('<I',v,72,n+i)
  assert st.unpack_from('<I',v,44)[0]==0xffffffff and st.unpack_from('<I',v,68)[0]==0x03000008
  e=bytearray(endpath);st.pack_into('<I',e,8,i+2);generated+=[bytes(v),bytes(e)]
 tail=b''.join(x[1] for x in chunks[:3])+b''.join(generated)+b''.join(x[1] for x in chunks[-2:]);body=pool+tail
 return b'\x03\x00\x08\x00'+U(8+len(body))+body

def svg():return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108">'+''.join(f'<path fill="#{c&0xffffff:06x}" d="{p}"/>' for c,p in paths)+'</svg>'
