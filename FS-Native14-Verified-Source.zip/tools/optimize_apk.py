#!/usr/bin/env python3
"""Lossless container optimization for unsigned APKs. Align before signing."""
import argparse, copy, hashlib, json, os, tempfile, zipfile, zlib
from pathlib import Path
PREFIXES = ('assets/web/emoji/', 'assets/web/emoji-extra/')

def media(i):
    return i.filename.startswith(PREFIXES) and i.filename.endswith('.webp')

def entries(z, unsigned=False):
    items = z.infolist(); names = {i.filename for i in items}
    if len(names) != len(items): raise ValueError('Duplicate APK entries')
    if not {'AndroidManifest.xml', 'resources.arsc', 'classes.dex'} <= names: raise ValueError('Missing APK entries')
    if any(i.flag_bits & 1 or i.compress_type not in (0, 8) for i in items): raise ValueError('Unsupported APK entry')
    if unsigned:
        for n in names:
            n = n.upper()
            if n.startswith('META-INF/') and (n.endswith(('.SF','.RSA','.DSA','.EC')) or n.rsplit('/',1)[-1].startswith('SIG-')):
                raise ValueError('Already signed APK')
        if z.start_dir >= 16:
            z.fp.seek(z.start_dir-16)
            if z.fp.read(16)==b'APK Sig Block 42': raise ValueError('Already signed APK')
    return items

def compare(original, candidate):
    with zipfile.ZipFile(original) as a, zipfile.ZipFile(candidate) as b:
        aa, bb = entries(a), entries(b)
        if {i.filename for i in aa} != {i.filename for i in bb}: raise ValueError('APK paths changed')
        for x in aa:
            y=b.getinfo(x.filename)
            if x.file_size!=y.file_size or hashlib.sha256(a.read(x)).digest()!=hashlib.sha256(b.read(y)).digest():
                raise ValueError('APK content changed: '+x.filename)
            if x.compress_type!=y.compress_type and not (media(x) and x.compress_type==0 and y.compress_type==8):
                raise ValueError('Unexpected compression change: '+x.filename)
        return len(aa)

def optimize(original, candidate):
    original,candidate=Path(original),Path(candidate)
    if original.resolve()==candidate.resolve() or candidate.exists(): raise ValueError('Use a new output path')
    fd,name=tempfile.mkstemp(prefix='.apk-opt-',dir=candidate.parent);os.close(fd);tmp=Path(name)
    count=saved=total=media_size=0
    try:
        with zipfile.ZipFile(original) as src, zipfile.ZipFile(tmp,'w',allowZip64=False) as dst:
            items=entries(src,True);dst.comment=src.comment
            for info in items:
                data=src.read(info);out=copy.copy(info);level=6
                if media(info):
                    total+=1;media_size+=info.compress_size
                    if info.compress_type==0:
                        c=zlib.compressobj(9,zlib.DEFLATED,-15);size=len(c.compress(data)+c.flush());delta=len(data)-size
                        if delta>=1024 and delta>=len(data)*.01:
                            out.compress_type=8;level=9;count+=1;saved+=delta
                dst.writestr(out,data,compress_type=out.compress_type,compresslevel=level)
        verified=compare(original,tmp)
        report=dict(original_bytes=original.stat().st_size,candidate_bytes=tmp.stat().st_size,emoji_entries=total,emoji_original_compressed_bytes=media_size,optimized_entries=count,emoji_bytes_saved=saved,verified_entries=verified,candidate_is_unaligned=True)
        report['candidate_bytes_saved']=report['original_bytes']-report['candidate_bytes']
        os.replace(tmp,candidate);return report
    finally: tmp.unlink(missing_ok=True)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('original',type=Path);p.add_argument('candidate',type=Path);p.add_argument('--verify-only',action='store_true');a=p.parse_args()
    print(json.dumps({'verified_entries':compare(a.original,a.candidate)} if a.verify_only else optimize(a.original,a.candidate),indent=2))

if __name__=='__main__':main()
