"""Prepare asset-only update using the existing Premium APK; requires original release key for signing.
Historical Premium asset-only tool; NOT a current source build.
Only exact verified base accepted. Do not install the unaligned output.
"""
import argparse, hashlib, json, pathlib, re, subprocess, zipfile
from launcher_icon import replace_vector
ROOT=pathlib.Path(__file__).resolve().parents[1]
BASE_SHA='a6c2236b1df6d59af63508ef6f46a1416cccc32f9a4f17efd1ebecda72923581'
CERT='30a4f0f403108ce30d349576d5f999df2c12f4dc839e90731bb93b136a487428'
def digest(p):
    with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(args):return subprocess.run([str(x) for x in args],check=True,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).stdout
def cert(apksigner,apk):
    data=run([apksigner,'verify','--verbose','--print-certs',apk])
    hashes=re.findall(r'Signer #\d+ certificate SHA-256 digest: ([0-9a-fA-F]{64})',data)
    if [h.lower() for h in hashes]!=[CERT]:raise RuntimeError('APK signer does not match installed Premium release')
    return data

def prepare(base,dest,*,legacy=False):
    if not legacy:raise RuntimeError('Historical web-patch disabled for current releases. Use tools/build_android.py or tools/build_push_ci.sh.')
    if digest(base)!=BASE_SHA:raise RuntimeError('Wrong base APK SHA-256')
    patches={'assets/web/'+p.relative_to(ROOT/'web-patch').as_posix():p for p in (ROOT/'web-patch').rglob('*') if p.is_file()}
    with zipfile.ZipFile(base) as src,zipfile.ZipFile(dest,'w') as dst:
        icon_bytes=replace_vector(src.read('res/drawable/ic_launcher.xml'))
        info=json.loads(src.read('assets/build-info.json'));info['launcherVectorSha256']=hashlib.sha256(icon_bytes).hexdigest()
        for name,p in patches.items():info['sources']['web/'+name.removeprefix('assets/web/')]=digest(p)
        info['derivedFromApkSha256']=BASE_SHA;info['releaseCandidate']=True
        seen=set()
        for entry in src.infolist():
            name=entry.filename
            if name in seen:raise RuntimeError('Duplicate base entry')
            seen.add(name)
            if name.startswith('META-INF/') and name.upper().endswith(('.SF','.RSA','.DSA','.EC','MANIFEST.MF')):continue
            data=patches[name].read_bytes() if name in patches else json.dumps(info,sort_keys=True).encode() if name=='assets/build-info.json' else icon_bytes if name=='res/drawable/ic_launcher.xml' else src.read(name)
            dst.writestr(entry,data)
        for name,p in patches.items():
            if name not in seen:dst.writestr(name,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED)
    with zipfile.ZipFile(base) as src,zipfile.ZipFile(dest) as dst:
        if dst.testzip():raise RuntimeError('damaged APK archive')
        for name in src.namelist():
            if name.startswith('META-INF/') or name in ('assets/build-info.json','res/drawable/ic_launcher.xml') or name in patches:continue
            if src.read(name)!=dst.read(name):raise RuntimeError('Unexpected changed entry: '+name)
        for name,p in patches.items():
            if digest(p)!=hashlib.sha256(dst.read(name)).hexdigest():raise RuntimeError('Patch mismatch: '+name)
        assert dst.read('res/drawable/ic_launcher.xml')==icon_bytes
        print(f'PASS: {len(patches)} patched web entries and launcher vector; all other APK payloads unchanged.')

def main():
    p=argparse.ArgumentParser();p.add_argument('base',type=pathlib.Path);p.add_argument('out',type=pathlib.Path);p.add_argument('--prepare-only',action='store_true');p.add_argument('--legacy-archive-only',action='store_true',help='Historical unsigned archive reproduction only');p.add_argument('--zipalign',default='zipalign');p.add_argument('--apksigner',default='apksigner');a=p.parse_args()
    if a.base.resolve()==a.out.resolve() or a.out.exists():raise SystemExit('Use a new output path.')
    if not (a.legacy_archive_only and a.prepare_only):raise SystemExit('Legacy tool disabled for release signing; build current sources with tools/build_android.py or tools/build_push_ci.sh.')
    if a.prepare_only:
        prepare(a.base,a.out,legacy=True);print('UNALIGNED / UNSIGNED — NOT INSTALLABLE');return
if __name__=='__main__':main()
