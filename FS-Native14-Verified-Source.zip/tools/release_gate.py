"""Fail closed unless human/device evidence is bound to the exact source and signed APK."""
import argparse, hashlib, json, os, re, shutil, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
EXPECTED_CERT='9c2daf267765845ed6ffa497d8f592ac23f336c17e54383f9a2fa9bbbaf341b4'
CHECKS=['reference_visual_review','physical_android_install','two_device_messages_media','bluetooth_audio_routes','background_call_and_message','camera_video_call','turn_cross_network_call','encrypted_history_transfer','keyboard_and_selection','all_requested_features_complete','security_review','performance_comparison']

def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def validate(root, apk, evidence):
    missing=[key for key in CHECKS if evidence.get(key) is not True]
    manifest=root/'FS-FINAL-SHA256.txt'
    if not manifest.is_file():missing.append('source_manifest_missing')
    elif evidence.get('source_manifest_sha256')!=digest(manifest):missing.append('source_manifest_sha256_mismatch')
    else:
        seen=set()
        for line in manifest.read_text().splitlines():
            match=re.fullmatch(r'([a-f0-9]{64})  (.+)',line)
            if not match:missing.append('source_manifest_invalid');break
            sha,name=match.groups();p=root/name
            if name in seen or not p.resolve().is_relative_to(root.resolve()) or not p.is_file() or digest(p)!=sha:
                missing.append('source_integrity:'+name);break
            seen.add(name)
        if not seen:missing.append('source_manifest_empty')
    if not apk.is_file():missing.append('signed_apk_missing')
    elif evidence.get('signed_apk_sha256')!=digest(apk):missing.append('signed_apk_sha256_mismatch')
    return missing

def certificate_matches(output):
    certs=re.findall(r'^Signer #\d+ certificate SHA-256 digest: ([0-9a-fA-F]{64})\s*$',output,re.M)
    return len(certs)==1 and certs[0].lower()==EXPECTED_CERT and bool(re.search(r'^Verified using v2 scheme .*: true\s*$',output,re.M))

def verify_signature(apk):
    android=os.environ.get('ANDROID_HOME') or os.environ.get('ANDROID_SDK_ROOT')
    sdk=Path(android)/'build-tools/35.0.0/apksigner' if android else None
    signer=str(sdk) if sdk and sdk.is_file() else shutil.which('apksigner')
    if not signer:return 'apksigner_missing'
    try: result=subprocess.run([signer,'verify','--verbose','--print-certs',str(apk)],capture_output=True,text=True,timeout=60)
    except (OSError,subprocess.TimeoutExpired):return 'apksigner_failed'
    return None if result.returncode==0 and certificate_matches(result.stdout) else 'release_certificate_or_signature_invalid'

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--apk',type=Path,default=ROOT/'build/ci/signed/FS-Mesajlasma-34.32-Native13-imzali.apk')
    p.add_argument('--evidence',type=Path,default=ROOT/'build/test-evidence/release-approval.json')
    a=p.parse_args()
    try:
        evidence=json.loads(a.evidence.read_text()) if a.evidence.is_file() else {}
        if not isinstance(evidence,dict):raise ValueError('Geçersiz kanıt biçimi')
        missing=validate(ROOT,a.apk,evidence)
    except (OSError,ValueError,TypeError) as e:p.exit(1,'YAYIN BEKLİYOR: '+str(e)+'\n')
    if missing:p.exit(1,'YAYIN BEKLİYOR: '+', '.join(missing)+'\n')
    signature=verify_signature(a.apk)
    if signature:p.exit(1,'YAYIN BEKLİYOR: '+signature+'\n')
    print('Kontrol beyanları kaynak ve APK özetleriyle eşleşiyor; mevcut sertifika doğrulandı. Cihaz kanıtlarının bağımsız incelemesi ve yayın onayı ayrıca gerekir. Bu komut yayın yapmaz.')

if __name__=='__main__':main()
