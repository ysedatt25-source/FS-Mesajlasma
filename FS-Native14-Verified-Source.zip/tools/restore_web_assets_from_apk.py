#!/usr/bin/env python3
"""Restore only missing original web files, verified against frozen source hashes."""
import argparse, hashlib, pathlib, zipfile

def restore(apk, root):
    expected={name:sha for line in (root/'source-madde17.sha256').read_text().splitlines() if '  ' in line for sha,name in [line.split('  ',1)] if name.startswith('web/')}
    count=0; missing=[]; mismatches=[]
    with zipfile.ZipFile(apk) as z:
        names=set(z.namelist())
        for name,sha in expected.items():
            rel=pathlib.PurePosixPath(name)
            if '..' in rel.parts or rel.is_absolute():raise ValueError('Unsafe manifest path')
            target=root/name
            if target.exists():continue
            entry='assets/'+name
            if entry not in names:missing.append(name);continue
            data=z.read(entry)
            if hashlib.sha256(data).hexdigest()!=sha:mismatches.append(name);continue
            target.parent.mkdir(parents=True,exist_ok=True)
            with target.open('xb') as f:f.write(data)
            count+=1
    print(f'Restored {count}; missing {len(missing)}; mismatched {len(mismatches)}')
    for n in missing:print('MISSING',n)
    for n in mismatches:print('HASH_MISMATCH',n)
    return not(missing or mismatches)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('apk',type=pathlib.Path);p.add_argument('--root',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parents[1]);a=p.parse_args();raise SystemExit(0 if restore(a.apk,a.root) else 1)
