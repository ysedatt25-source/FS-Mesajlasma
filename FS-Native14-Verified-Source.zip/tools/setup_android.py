"""Download fixed official Android/ECJ build inputs and validate SHA-256.
Does not install software system-wide or accept a license prompt.
"""
import concurrent.futures, hashlib, os, pathlib, subprocess, urllib.request, zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
CACHE=pathlib.Path(os.environ.get('FS_ANDROID_TOOLS',str(ROOT.parent/'build-tools-cache')))
FILES={
 'platform.zip':('https://dl.google.com/android/repository/platform-35_r02.zip','0988cacad01b38a18a47bac14a0695f246bc76c1b06c0eeb8eb0dc825ab0c8e0'),
 'tools.zip':('https://dl.google.com/android/repository/build-tools_r35_linux.zip','bd3a4966912eb8b30ed0d00b0cda6b6543b949d5ffe00bea54c04c81e1561d88'),
 'ecj.jar':('https://repo.maven.apache.org/maven2/org/eclipse/jdt/ecj/3.39.0/ecj-3.39.0.jar','01f5a92ac19bb2b3bf85e295a68f2c73c264369109158b566ce9b490af982948')}
def download(item):
 name,(url,digest)=item;p=CACHE/name
 if not p.exists():urllib.request.urlretrieve(url,p)
 if hashlib.sha256(p.read_bytes()).hexdigest()!=digest:raise RuntimeError('SHA-256 mismatch: '+name)
 if name.endswith('.zip'):
  target=CACHE/name[:-4]
  with zipfile.ZipFile(p) as z:
   for info in z.infolist():
    if not (target/info.filename).resolve().is_relative_to(target.resolve()):raise ValueError('Unsafe archive path')
   z.extractall(target)
 print(name,'verified')
def main():
 CACHE.mkdir(parents=True,exist_ok=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(download,FILES.items()))
 for p in (CACHE/'tools/android-15').iterdir():
  if p.is_file():p.chmod(p.stat().st_mode|0o100)
 # android.jar excludes this compile-time bootstrap class. D8 desugars lambdas;
 # the stub is never packaged in the application or used as a runtime API.
 stub=CACHE/'compiler-stub/java/lang/invoke/LambdaMetafactory.java';stub.parent.mkdir(parents=True,exist_ok=True)
 stub.write_text('package java.lang.invoke; public final class LambdaMetafactory {}\n')
 classes=CACHE/'compiler-stub-classes'
 subprocess.run(['java','-jar',str(CACHE/'ecj.jar'),'-1.8','-proc:none','-bootclasspath',str(CACHE/'platform/android-35/android.jar'),'-d',str(classes),str(stub)],check=True)
 with zipfile.ZipFile(CACHE/'compiler-stubs.jar','w') as z:
  for p in classes.rglob('*.class'):z.write(p,p.relative_to(classes))
if __name__=='__main__':main()
