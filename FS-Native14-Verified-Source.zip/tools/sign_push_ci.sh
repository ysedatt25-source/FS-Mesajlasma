#!/usr/bin/env bash
# Release signer; uses the same private PKCS12 key as the last Native13 APK.
set -euo pipefail
umask 077
cd "$(dirname "$0")/.."
: "${ANDROID_HOME:?Android SDK required}"
: "${ANDROID_KEYSTORE_BASE64:?Set existing private PKCS12 as a CircleCI secret}"
: "${ANDROID_KEYSTORE_PASSWORD:?Set existing private key password as a CircleCI secret}"
: "${ANDROID_KEY_ALIAS:?Set existing key alias in CircleCI}"
[[ "$ANDROID_KEY_ALIAS" == gm-release ]] || { echo 'Unexpected release alias' >&2; exit 1; }
[[ "${CIRCLE_BRANCH:-}" == main ]] || { echo 'Release signing is restricted to main' >&2; exit 1; }
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
printf '%s' "$ANDROID_KEYSTORE_BASE64" | base64 --decode > "$tmp/release.p12"
unset ANDROID_KEYSTORE_BASE64
sdk="$ANDROID_HOME/build-tools/35.0.0"
unsigned=build/ci/FS-Mesajlasma-34.32-native14-push-unsigned.apk
out=build/ci/signed
signed="$tmp/FS-Mesajlasma-34.32-Native14-imzali.apk"
expected=9c2daf267765845ed6ffa497d8f592ac23f336c17e54383f9a2fa9bbbaf341b4
# The public certificate can be compared before any signing takes place.
keytool -exportcert -storetype PKCS12 -keystore "$tmp/release.p12" -storepass:env ANDROID_KEYSTORE_PASSWORD -alias "$ANDROID_KEY_ALIAS" -file "$tmp/cert.der" >/dev/null 2>&1
printf '%s  %s\n' "$expected" "$tmp/cert.der" | sha256sum -c -
# Optimize only a newly built unsigned APK, then align and verify before signing.
python3 tools/optimize_apk.py "$unsigned" "$tmp/optimized-unaligned.apk" > "$tmp/APK-BOYUT-RAPORU.json"
"$sdk/zipalign" -f -P 16 4 "$tmp/optimized-unaligned.apk" "$tmp/optimized-aligned.apk"
"$sdk/zipalign" -c -P 16 4 "$tmp/optimized-aligned.apk"
python3 tools/optimize_apk.py "$unsigned" "$tmp/optimized-aligned.apk" --verify-only
# Keep the original if alignment overhead cancels the size saving.
if (( $(stat -c %s "$tmp/optimized-aligned.apk") < $(stat -c %s "$unsigned") )); then
  unsigned="$tmp/optimized-aligned.apk"
fi
"$sdk/zipalign" -c -P 16 4 "$unsigned"
python3 tools/verify_push_apk.py "$unsigned" "$sdk/aapt"
"$sdk/apksigner" sign --ks "$tmp/release.p12" --ks-type PKCS12 --ks-key-alias "$ANDROID_KEY_ALIAS" --ks-pass env:ANDROID_KEYSTORE_PASSWORD --key-pass env:ANDROID_KEYSTORE_PASSWORD --v1-signing-enabled false --v2-signing-enabled true --v3-signing-enabled true --v4-signing-enabled false --out "$signed" "$unsigned"
unset ANDROID_KEYSTORE_PASSWORD
"$sdk/apksigner" verify --verbose --print-certs "$signed" > "$tmp/verify.txt"
grep -Fq 'Verified using v2 scheme (APK Signature Scheme v2): true' "$tmp/verify.txt"
actual=$(sed -n 's/^Signer #1 certificate SHA-256 digest: //p' "$tmp/verify.txt")
[[ "$actual" == "$expected" ]] || { echo 'Release certificate mismatch' >&2; exit 1; }
"$sdk/zipalign" -c -P 16 4 "$signed"
python3 tools/verify_push_apk.py "$signed" "$sdk/aapt"
# Only expose the signed and verified APK, not the key, unsigned APK or passwords.
mkdir -p "$out"
cp "$signed" "$out/FS-Mesajlasma-34.32-Native14-imzali.apk"
cp "$tmp/verify.txt" "$out/APK-IMZA-DOGRULAMA.txt"
cp "$tmp/APK-BOYUT-RAPORU.json" "$out/APK-BOYUT-RAPORU.json"
(cd "$out" && sha256sum FS-Mesajlasma-34.32-Native14-imzali.apk > SHA256SUMS.txt)
