"""Check an actual unsigned push APK; refuse an APK missing the receiver or frozen assets."""
import hashlib, json, pathlib, subprocess, sys, zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]

def verify(apk,aapt):
    with zipfile.ZipFile(apk) as z:
        assert z.testzip() is None,'Corrupt APK'
        names=z.namelist();assert len(names)==len(set(names)),'Duplicate APK entries'
        info=json.loads(z.read('assets/build-info.json'))
        expected=json.loads((ROOT/'build/push-metadata/build-info.json').read_text())
        assert info==expected and info['transport']=='fcm' and info['versionCode']==14
        for path,digest in info['sources'].items():
            assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest,path
            if path.startswith('web/'):
                assert hashlib.sha256(z.read('assets/'+path)).hexdigest()==digest,path
        for folder,count in [('emoji',881),('emoji-extra',2876)]:
            assert sum(n.startswith('assets/web/'+folder+'/') and n.endswith('.webp') for n in names)==count,folder
        dex=[z.read(n) for n in names if n.startswith('classes') and n.endswith('.dex')]
        for marker in (b'Lcom/fs/mesajlasma/FirebasePush;',b'Lcom/google/firebase/messaging/FirebaseMessagingService;',b'Lcom/fs/mesajlasma/MessagePushWorker;'):
            assert any(marker in d for d in dex),'FCM code missing from APK'
        assert not any(n.endswith('google-services.json') or 'service-account' in n or 'service_account' in n or n.endswith('/emoji.zip') for n in names),'Unexpected provisioning/archive file in APK'
    badging=subprocess.check_output([aapt,'dump','badging',str(apk)],text=True)
    assert "name='com.fs.mesajlasma'" in badging and "versionCode='14'" in badging and "versionName='34.32'" in badging,'APK identity mismatch'
    manifest=subprocess.check_output([aapt,'dump','xmltree',str(apk),'AndroidManifest.xml'],text=True)
    assert 'com.fs.mesajlasma.FirebasePush' in manifest or '".FirebasePush"' in manifest,'Missing Firebase service registration'
    assert 'com.google.firebase.MESSAGING_EVENT' in manifest,'Missing FCM intent'
    assert 'com.fs.mesajlasma.ConnectionService' not in manifest and '".ConnectionService"' not in manifest,'Unexpected idle polling service in push APK'
    assert 'android.permission.FOREGROUND_SERVICE_REMOTE_MESSAGING' not in manifest,'Unexpected idle polling permission in push APK'
    for service in ('CallService','LocationService'):
        assert 'com.fs.mesajlasma.'+service in manifest or '".'+service+'"' in manifest, 'Missing active service '+service
    # Require the actual generated Android client resources, not just Java symbols.
    resources=subprocess.check_output([aapt,'dump','resources',str(apk)],text=True)
    for name in ('google_app_id','gcm_defaultSenderId','project_id'):
        assert 'string/'+name in resources, 'Missing Firebase configuration resource '+name
    print('Verified APK ID, version, complete assets, FCM receiver, SDK and generated resources. Actual provider delivery not yet tested.')

if __name__=='__main__':
    if len(sys.argv)!=3:sys.exit('usage: verify_push_apk.py APK AAPT')
    verify(pathlib.Path(sys.argv[1]),sys.argv[2])
