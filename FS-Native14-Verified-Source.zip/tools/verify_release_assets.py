"""Fail closed if the frozen local animations or source asset manifest is incomplete."""
import hashlib, json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
expected={'emoji':('emojis.json',881),'emoji-extra':('emoji-extension.json',2876)}
for directory,(manifest,count) in expected.items():
    rows=json.loads((root/'web'/manifest).read_text())
    files={r['file'] for r in rows}
    local={p.name for p in (root/'web'/directory).glob('*.webp')}
    assert len(rows)==len(files)==count and files==local, f'{directory} manifest mismatch'
    for name in files:
        assert Path(name).name==name and name.endswith('.webp')
        with (root/'web'/directory/name).open('rb') as f: header=f.read(12)
        assert header[:4]==b'RIFF' and header[8:12]==b'WEBP',name
    print(f'{directory}: {count}/{count} WebP assets verified')
assert hashlib.sha256((root/'web/emojis.json').read_bytes()).hexdigest()=='245d5917149d3ee8043ebf72079c1662da8dcc8e743c347f2243c6f3954ff70d'
# The old emoji order is part of the call verification protocol.
print('Legacy emoji verification catalog unchanged.')
