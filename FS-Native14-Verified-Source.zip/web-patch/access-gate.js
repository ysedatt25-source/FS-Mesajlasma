// Fresh per document; no persistent unlocked flag. Revoke invalidates in-flight checks.
export function createAccessGate(verify) {
 let epoch=0,granted=false,pending=false;
 return Object.freeze({
  get locked(){return !granted},
  get epoch(){return epoch},
  valid(value){return granted&&value===epoch},
  lock(){epoch++;granted=false},
  async submit(pin, explicitEquals){
   if(!explicitEquals||!/^\d{6,}$/.test(pin)||granted||pending)return false;
   const attempt=epoch;pending=true;
   try{const valid=await verify(pin);if(attempt!==epoch||valid!==true)return false;granted=true;return true;}
   finally{pending=false;}
  }
 });
}
