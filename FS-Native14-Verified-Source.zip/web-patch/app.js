import {TYPING_EVENT,createTypingStatus} from "./typing-status.js";
import {composerMode,createMicGesture} from "./composer-action.js";
import {EMOJI_EVENT,validInteraction,matchesInteraction,createInteractionWindow} from "./realtime-emoji.js";
import {gestureIntent,reactionValue,selectionOps} from "./message-interactions.js";
import {clamp,pipPosition,urlParts,mapUrls,effectiveStatus,callControlState,callEventMatches} from "./call-chat-fixes.js";
import {LocalChats,chatList,buildMessageIndex,searchMessages,localDay,toggleId} from "./chat-tools.js";
import {VirtualMessages, nearLatest} from "./virtual-list.js";
import {prepareMedia} from "./media-preparation.js";
import {accountIssues,showNotice} from "./feedback.js";
import {VoiceRecorder,voiceExtension} from "./voice-recorder.js";
import {isSingleEmoji,animateEmoji,buildEmojiIndex,emojiAsset,clearEmojiEffect} from "./emoji-effects.js";
import {createAccessGate} from "./access-gate.js";
import {mountCalculator} from "./calculator-ui.js";
import { missingCachedMessages, mergeMessagePage, upsertMessage as upsertMessages } from "./message-state.js";
import { DEFAULT_API_ROOT } from "./runtime-config.js";
import { serverRoot, fetchServer, verifyServer } from "./connection.js";
import { privacyPolicy } from "./privacy-policy.js";
import { validatePayload } from "./payload.js";
import QRCode from "./vendor/qr.js";
import { icon } from "./icons.js";
import {
  vault,
  identity,
  peerKey,
  seal,
  open,
  b64,
  unb64,
  setPin,
  checkPin,
  encryptFile,
  decryptFile,
  calculate,
  prepareRecovery,
  restoreRecovery,
} from "./crypto.js";
const $ = (s) => document.querySelector(s),
  app = $("#app"),
  modal = $("#modal");
const escape = (s) =>
  String(s ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
let emojiItems = [];
let emojiIndex = new Map();
const emojiWindow=createInteractionWindow();let lastEmojiTap=0;let replyReturn=null,replyJumpFlight=null;const deletedInSession=new Set();
const access = createAccessGate(checkPin);
let bootReady=false;
const isLocked=()=>access.locked;
function assertAccess(){if(isLocked())throw new DOMException("Kilitli oturum", "AbortError");}
function assertEpoch(epoch){if(!access.valid(epoch))throw new DOMException("Oturum kilitlendi veya değişti", "AbortError");}
const state = {
  user: null,
  token: null,
  settings: {},
  rooms: [],
  contacts: [],
  messages: [],
  page: "lock",
  room: null,
  tab: "Sohbetler",
  selected: new Set(),
  cache: new Map(),
  keys: new Map(),
  reply: null,
  call: null,
  socket: null,
  get locked(){return access.locked},
  pin: "",
  recording: null,
  recorder: null,
  media: [],
  mediaFilter: "Tümü",
  routeVersion: 0,
  reconnectTimer: null,
};
const typing=createTypingStatus({
 context:()=>!isLocked()&&!document.hidden&&state.page==='chat'&&state.room&&state.user?{room:state.room.id,enabled:state.typingEnabled===true,members:new Map(state.room.members.filter(m=>m.id!==state.user.id).map(m=>[m.id,m.name]))}:null,
 send:event=>{if(state.typingEnabled!==true||state.socket?.readyState!==1)return false;try{state.socket.send(JSON.stringify(event));return true}catch{return false}},
 render:names=>{const label=document.querySelector('#typing-status');if(!label)return;label.hidden=!names.length;label.textContent=names.length?(state.room?.kind==='group'?(names.length===1?names[0]+' yazıyor…':names.length+' kişi yazıyor…'):'Yazıyor…'):'';const status=document.querySelector('.chat-head [data-action="status"]');if(status)status.hidden=!!names.length;}
});
let localData=null,localWrite=null,virtualMessages=null,messageIndex=buildMessageIndex([]),outboxSending=false;
let localState={drafts:{},positions:{},preferences:{pinned:[],archived:[],read:{}},pages:{},playback:{},outbox:[]};
state.chatFilter='Tümü';state.chatQuery='';state.mediaDate='';state.mediaQuery='';
async function initLocal(){
 assertAccess();const epoch=access.epoch;
 if(localData?.user===state.user?.id)return;
 clearTimeout(localWrite);
 const store=new LocalChats(state.user.id,state.identity);const data=await store.get('workspace',{});
 assertEpoch(epoch);if(store.user!==state.user?.id)return;
 localData=store;localState={drafts:{},positions:{},preferences:{pinned:[],archived:[],read:{}},pages:{},playback:{},outbox:[],...data};
 if(data.rooms?.length)state.rooms=data.rooms;
 if(data.settings)state.settings=data.settings;
}
function persistLocal(immediate=false){
 if(!localData)return immediate?Promise.reject(Error('Yerel oturum hazır değil.')):Promise.resolve();
 clearTimeout(localWrite);const store=localData;
 const save=()=>store.put('workspace',structuredClone({...localState,rooms:state.rooms.slice(0,40),settings:state.settings}));
 if(immediate)return save();localWrite=setTimeout(()=>save().catch(error=>console.warn('local-store',error.message)),180);return Promise.resolve();
}
function markCurrentRead(){
 const room=state.room?.id,target=$('#messages');if(!room||!target||!nearLatest(target))return;
 const last=state.messages.filter(m=>!m.callRecord&&!m.pending).at(-1);if(!last)return;
 localState.preferences.read??={};if(last.created<=(localState.preferences.read[room]||0))return;
 localState.preferences.read[room]=last.created;persistLocal();if(navigator.onLine!==false)api('/rooms/'+room+'/read',{method:'POST',body:{message:last.id}}).catch(()=>{});
}

function rememberChat(){
 const input=$('#message-text'),list=$('#messages');const id=input?.dataset.room;
 if(!id||!localData)return;
 localState.drafts[id]={text:input.value,reply:state.reply?.room===id?state.reply.id:null,quote:state.reply?.room===id?state.reply.quoteText||null:null};
 if(list)localState.positions[id]={top:list.scrollTop,anchor:virtualMessages?.anchor(),bottom:nearLatest(list)};
 rememberPlayback();persistLocal();
}
function rememberPlayback(){for(const audio of document.querySelectorAll('audio[data-audio]'))if(Number.isFinite(audio.currentTime)&&audio.currentTime>0)localState.playback[audio.dataset.audio]={time:audio.currentTime,rate:audio.playbackRate||1};}
function storePage(room,messages){delete localState.pages[room];const page=[];let size=0;for(const m of messages.filter(m=>!m.pending).slice(-80).reverse()){const length=JSON.stringify(m).length;if(size+length>300000)break;size+=length;page.unshift(m)}localState.pages[room]=page;const keys=Object.keys(localState.pages);while(keys.length>10)delete localState.pages[keys.shift()];persistLocal();}
async function flushOutbox(){
  if(isLocked())return;
 if(outboxSending||!localData||navigator.onLine===false||!state.token)return;
 outboxSending=true;const owner=state.user.id,epoch=access.epoch;
 try{for(const item of [...localState.outbox]){if(!access.valid(epoch)||state.user?.id!==owner)break;const room=state.rooms.find(r=>r.id===item.room);if(!room){item.error='Sohbet bulunamadı.';continue}try{await send(item.payload,room,item.id,{replyId:item.reply,fromQueue:true});if(!access.valid(epoch))break;localState.outbox=localState.outbox.filter(x=>x.id!==item.id);state.messages=state.messages.map(m=>m.id===item.id?{...m,pending:false,queued:false}:m);if(state.page==="chat")renderMessages();await persistLocal(true)}catch(error){if(!access.valid(epoch))break;item.error=error.message;await persistLocal(true);break}}}finally{outboxSending=false;}
}
window.addEventListener('online',()=>{connect();flushOutbox().catch(err=>notice(err.message,4000,'error'))});
document.addEventListener('visibilitychange',()=>{if(document.hidden){rememberChat();persistLocal(true)}});
const defaultApiRoot = location.hostname === "appassets.androidplatform.net" ? DEFAULT_API_ROOT : location.origin;
let apiRoot = serverRoot(defaultApiRoot);
try { apiRoot = serverRoot(localStorage.getItem("fs-server") || defaultApiRoot); } catch {}
const time = (t) =>
  new Date(t).toLocaleTimeString("tr-TR", {
    hour: "2-digit",
    minute: "2-digit",
  });
const name = (r) =>
  r.title ||
  r.members
    ?.filter((x) => x.id !== state.user?.id)
    .map((x) => x.name)
    .join(", ") ||
  "Sohbet";
const button = (action, ico, label, extra = "") =>
  `<button class="icon" data-action="${action}" aria-label="${escape(label)}" title="${escape(label)}" ${extra}>${icon(ico)}</button>`;
const avatar = (u, large = false) =>
  `<span class="avatar ${large ? "large" : ""}">${
    u?.avatar
      ? `<img class="avatar-photo" src="${escape(u.avatar)}" alt="Profil fotoğrafı">`
      : escape(
          (u?.name || "?")
            .split(" ")
            .slice(0, 2)
            .map((x) => x[0])
            .join(""),
        )
  }${u?.status === "online" ? '<span class="dot"></span>' : ""}</span>`;
const empty = (title, description) =>
  `<div class="empty"><span class="big">Fs</span><strong>${escape(title)}</strong><br>${escape(description)}</div>`;
const row = (action, ico, title, sub = "") =>
  `<button class="row" data-action="${action}">${icon(ico)}<span class="copy">${escape(title)}${sub ? `<small>${escape(sub)}</small>` : ""}</span>${icon("chevron")}</button>`;
function notice(text, duration = 3000, kind = "info", compact = false) {
  if(isLocked()&&state.page!=="setup")return;
  showNotice($("#notice"), text, {duration, kind, compact});
}
function formIssues(form, issues) {
  form.querySelectorAll('.field-error').forEach(e => e.remove());
  form.querySelectorAll('[aria-invalid]').forEach(e => {e.removeAttribute('aria-invalid');e.removeAttribute('aria-describedby')});
  form.querySelector('.error').textContent = issues.length ? "Bilgileri kontrol edin: " + issues.map(e => e.message).join(' ') : '';
  for (const issue of issues) {
    const input=form.elements.namedItem(issue.field);if(!input)continue;
    const error=document.createElement('small');error.className='field-error';error.id='error-'+issue.field;error.textContent=issue.message;
    input.setAttribute('aria-invalid','true');input.setAttribute('aria-describedby',error.id);input.insertAdjacentElement('afterend',error);
  }
  if(issues.length)form.elements.namedItem(issues[0].field)?.focus();
}

function dialog(title, content) {
  assertAccess();
  modal.classList.remove("message-context");modal.style.removeProperty("--menu-x");modal.style.removeProperty("--menu-y");
  modal.innerHTML = `${button("close-dialog", "close", "Kapat", 'class="dialog-close"')}<h2>${escape(title)}</h2>${content}`;
  modal.showModal();
}
function field(name, label, type = "text", value = "", required = true) {
  return `<label for="${name}">${escape(label)}</label><input id="${name}" name="${name}" type="${type}" value="${escape(value)}" ${required ? "required" : ""} autocomplete="off">`;
}
async function api(path, options = {}) {
  assertAccess();const accessEpoch=access.epoch;
  const headers = {
    ...(options.body instanceof Uint8Array
      ? {}
      : { "Content-Type": "application/json" }),
    ...options.headers,
  };
  if (state.token) headers.Authorization = "Bearer " + state.token;
  const requestToken = state.token;
  const response = await fetchServer(apiRoot, "/api" + path, {
    ...options,
    headers,
    body:
      options.body instanceof Uint8Array
        ? options.body
        : options.body
          ? JSON.stringify(options.body)
          : undefined,
  });
  if(!access.valid(accessEpoch))throw new DOMException("Kilitli oturum", "AbortError");
  if (requestToken !== state.token) throw Error("Oturum değişti; işlem iptal edildi.");
  if (!response.ok) {
    let data;
    try {
      data = await response.json();
    } catch {}
    const error=Error(data?.error || (response.status === 404 ? "Sunucuda istenen API bulunamadı. Sunucu adresini ve sunucu sürümünü kontrol edin." : `İşlem başarısız (${response.status})`));
    error.status=response.status;error.code=data?.code;throw error;
  }
  const data=response.status===204?null:await response.json();
  if(!access.valid(accessEpoch))throw new DOMException("Kilitli oturum", "AbortError");
  return data;
}
async function keyFor(peer) {
  assertAccess();const epoch=access.epoch;
  const id = peer.id + JSON.stringify(peer.pub);
  if (!state.keys.has(id)) {
    const key=await peerKey(state.identity.pair.privateKey, peer.pub);
    assertEpoch(epoch);state.keys.set(id,key);
  }
  return state.keys.get(id);
}
async function envelopes(room, payload) {
  const result = {};
  await Promise.all(
    [
      ...new Map(
        [...room.members, ...(room.audit ? [room.audit] : [])].map((m) => [
          m.id,
          m,
        ]),
      ).values(),
    ].map(async (m) => {
      result[m.id] = await seal(await keyFor(m), payload, room.id);
    }),
  );
  return result;
}
async function decode(m) {
  assertAccess();const epoch=access.epoch;
  const cached = state.cache.get(m.id);
  if (cached && cached.edited === m.edited)
    return { ...cached, ...m, payload: cached.payload };
  const room = state.rooms.find((r) => r.id === m.room),
    sender = room?.members.find((u) => u.id === m.sender);
  if (!sender)
    return {
      ...m,
      payload: { type: "text", text: "Gönderen anahtarı bulunamadı." },
    };
  try {
    const payload = validatePayload(
      await open(await keyFor({...sender,pub:m.sender_pub||sender.pub}), m.envelope, m.room),
    );
    assertEpoch(epoch);
    const result = { ...m, payload };
    state.cache.set(m.id, result);
    while (state.cache.size > 512)
      state.cache.delete(state.cache.keys().next().value);
    return result;
  } catch {
    assertEpoch(epoch);
    return {
      ...m,
      payload: {
        type: "locked",
        text: "Bu cihazda mesaj anahtarı bulunamadı.",
      },
    };
  }
}
let roomRefreshQueue = Promise.resolve();
function refreshRooms() {
  const epoch=access.epoch;
  roomRefreshQueue = roomRefreshQueue.catch(() => {}).then(()=>{if(access.valid(epoch))return refreshRoomsNow();});
  return roomRefreshQueue;
}
async function refreshRoomsNow() {
  if(isLocked())return;
  if (!state.token) return;
  const epoch=access.epoch;
  const rooms=await api("/rooms");assertEpoch(epoch);state.rooms=rooms;
  if (state.room)
    state.room = state.rooms.find((r) => r.id === state.room.id) || state.room;
  await Promise.all(
    state.rooms.map(async (r) => {
      if (r.last) {const last=await decode(r.last);assertEpoch(epoch);r.last=last;}
    }),
  );
  assertEpoch(epoch);persistLocal();
  state.rooms.sort(
    (a, b) => (b.last?.created || b.created) - (a.last?.created || a.created),
  );
}
function shell(title, body, options = "") {
  assertAccess();typing.reset();
  rememberChat();virtualMessages?.destroy();virtualMessages=null;
  app.innerHTML = `<section class="screen fs-premium fs-${state.page}">${state.call && state.page !== "call" ? '<button class="call-banner" data-action="return-call">Aramaya geri dön</button>' : ""}<header>${button("back", "back", "Geri")}<h1>${title}</h1>${options}</header><main class="scroll">${body}</main></section>`;
  if(state.call)attachVideo();
}
let calculatorView;
function showLock() {
  // Revoke synchronously and obscure all sensitive DOM before any fallible cleanup.
  access.lock();app.inert=true;app.style.visibility="hidden";modal.inert=true;modal.style.visibility="hidden";
  try {
  clearEmojiEffect();typing.reset();
  emojiWindow.clear();deletedInSession.clear();state.emojiRealtime=false;state.directDelete=false;state.messageCacheCheck=false;replyReturn=null;replyJumpFlight=null;
  clearComposer();state.routeVersion++;homeListSequence++;mediaEpoch++;
  try{rememberChat();virtualMessages?.destroy();discardVoice();}catch(error){console.warn("lock cleanup",error.message)}
  virtualMessages=null;
  state.page="lock";syncPresence();
  if(modal.open)modal.close();modal.replaceChildren();
  const noticeEl=$("#notice");noticeEl.textContent="";noticeEl.style.display="none";
  const files=$("#files");files.onchange=null;files.value="";
  clearTimeout(reconnectTimer);clearTimeout(state.reconnectTimer);
  // Clear active call before disconnecting; do not expose it via a return route.
  if(state.call){const c=state.call;try{if(state.socket?.readyState===1)state.socket.send(JSON.stringify({type:"hangup",room:c.room.id,...(c.callId?{callId:c.callId}:{})}))}catch{}state.call=null;clearTimeout(state.controlsTimer);clearInterval(state.callTimer);clearInterval(c.statsTimer);c.stream?.getTracks().forEach(t=>t.stop());c.pc?.close();window.FSNative?.activeCall(false,false);}
  const socket=state.socket;state.socket=null;socket?.close();presenceAuthenticated=false;
  state.room=null;state.reply=null;state.selected.clear();state.messages=[];state.saved=[];state.media=[];state.cache.clear();state.keys.clear();
  for(const cache of [audioUrls,thumbnailUrls]){for(const url of cache.values())URL.revokeObjectURL(url);cache.clear()}
  recentPhotos=[];
  } catch(error) {
    // Any cleanup error must not restore the previous protected screen.
    console.warn("lock cleanup",error.message);
    try{state.socket?.close()}catch{}state.socket=null;presenceAuthenticated=false;
  } finally {
  state.page="lock";
  try{if(modal.open)modal.close();modal.replaceChildren();}catch{}
  if(!modal.open){modal.inert=false;modal.style.visibility="";}
  app.replaceChildren();calculatorView=null;
  const lockEpoch=access.epoch;
  try {calculatorView=mountCalculator(app,{checkPin:async(pin,explicitEquals)=>{
      if(!access.locked||access.epoch!==lockEpoch||state.page!=="lock")return false;
      return access.submit(pin,explicitEquals);
    },onUnlock:async()=>{try{await unlock(lockEpoch)}catch(error){if(access.valid(lockEpoch))showLock();console.warn("unlock",error.message)}},windowAction:(action,value)=>{
    if(action==='float'&&window.FSNative?.calculatorWindow){showLock();window.FSNative.calculatorWindow(value);return;}
    if(action==='close'||action==='minimize'){showLock();window.FSNative?.minimize?.();return;}
    app.querySelector('.android-calculator')?.classList.toggle('calc-compact',action==='float');
  }});}catch(error){app.textContent="Hesap makinesi başlatılamadı. Uygulamayı yeniden başlatın.";console.warn("calculator",error.message);}
  app.inert=false;app.style.visibility="";
  }
}
window.addEventListener('fs-calculator-restore',event=>{if(!bootReady||state.page==="setup")return;showLock();calculatorView?.restore(event.detail)});

async function unlock(epoch) {
  if(!access.valid(epoch)||state.page!=="lock")return;
  if (!state.token) {
    authPage(false);
    return;
  }
  await initLocal();
  if(!access.valid(epoch))return;
  if(state.rooms.length){applyTheme();home();}
  try {
    const result = await api("/me");
    if(!access.valid(epoch))return;
    state.user = result.user;
    state.settings = result.settings;
    state.isAdmin = !!result.isAdmin;
    nativeSession();
    applyTheme();
    await refreshRooms();
    if(!access.valid(epoch))return;
    connect();
    home();
  } catch (err) {
    if(!access.valid(epoch))return;
    if(state.rooms.length && ![401,403].includes(err.status)){home();connect();notice("Çevrimdışı: cihazdaki sohbetler gösteriliyor.",3000,"info");}
    else {
      if([401,403].includes(err.status)){
        state.token=null;state.user=null;state.isAdmin=false;state.rooms=[];state.contacts=[];state.settings={};state.cache.clear();state.keys.clear();localData=null;clearTimeout(localWrite);
        window.FSNative?.logout();await vault("session",null);if(!access.valid(epoch))return;
      }
      authPage(false);notice(err.message,4000,"error");
    }
  }
}
function authPage(register) {
  if(isLocked())return;
  state.page = "auth";
  app.innerHTML = `<section class="screen"><header><span class="brand">Fs</span><h1>FS Mesajlaşma</h1></header><main class="scroll form-page"><h2>${register ? "Aramıza katıl" : "Tekrar hoş geldin"}</h2><p class="hint">${register ? "Yalnızca yeni hesabın yoksa kayıt ol." : "Telefon numaranı ve mevcut hesap şifreni gir. Tekrar üye olmana gerek yok."}</p><form id="account-form" novalidate>${register ? field("name", "Adınız") + field("nick", "Kullanıcı adı") + field("phone", "Telefon", "tel") + field("invite", "Davet kodu", "text", "0032") : field("login", "Telefon numarası (veya kullanıcı adı)", "text")}${field("password", "Hesap şifresi (en az 6 karakter)", "password")}<p class="security-note">Hesap şifresi, hesap makinesi giriş şifrenden ayrıdır. Yeni kurulumda telefon ve hesap şifrenle giriş yapabilirsin. Yeni cihazın anahtarını etkinleştirmek eski oturumları kapatabilir; eski şifreli mesajlar anahtar yedeği olmadan açılamaz.</p>${register ? '<label class="toggle"><span><button type="button" data-action="privacy-policy">Gizlilik politikasını</button> okudum, kabul ediyorum.</span><input name="privacy" type="checkbox" required></label>' : ""}<button class="primary">${register ? "Hesap oluştur" : "Giriş yap"}</button><div class="error" role="alert"></div></form><button class="secondary" data-action="auth-toggle" data-register="${register ? "0" : "1"}">${register ? "Zaten hesabım var" : "Yeni hesap oluştur"}</button><button class="secondary" data-action="import-key">Anahtar yedeğini içe aktar</button></main></section>`;
  const accountForm=$("#account-form");
  accountForm.elements.namedItem("password").autocomplete=register?"new-password":"current-password";
  if(!register)accountForm.elements.namedItem("login").autocomplete="username";
  accountForm.onsubmit = async (e) => {
    e.preventDefault();
    if(isLocked()||state.page!=="auth"||!e.target.isConnected)return;const epoch=access.epoch;
    const form = e.target,
      submit = form.querySelector("button.primary");
    if (submit.disabled) return;
    submit.disabled = true;
    try {
      const b = Object.fromEntries(new FormData(form));
      const issues = accountIssues(b, register);
      formIssues(form, issues);
      if (issues.length) return;
      for (const key of ["name","nick","phone","invite","login"]) if (b[key]) b[key]=b[key].trim();
      // Preserve exact registered digits for legacy API compatibility; accept formatting separators.
      if(!register && /^\+?[0-9() .-]+$/.test(b.login)) b.login=b.login.replace(/[() .-]/g,"");
      const current=()=>access.valid(epoch)&&state.page==="auth"&&form.isConnected;
      const check=()=>{if(!current())throw new DOMException("Giriş işlemi iptal edildi", "AbortError");};
      await verifyServer(apiRoot);check();
      const deviceIdentity=await identity();check();
      const r = await api("/session", {
        method: "POST",
        body: {
          ...b,
          register,
          privacy_accepted: b.privacy === "on",
          new_device: !register,
          pub: deviceIdentity.pub,
        },
      });
      check();
      if (register || r.deviceChanged) {await prepareRecovery(b.password);check();}
      // Persist authenticated session before exposing protected routes. PIN access is never persisted.
      await vault("session", { token: r.token, user: r.user });check();
      state.identity=deviceIdentity;
      state.token = r.token;
      state.user = r.user;
      state.settings = r.settings;
      state.isAdmin = !!r.isAdmin;
      await initLocal();check();
      state.settings=r.settings;
      nativeSession();
      await refreshRooms();check();
      connect();
      home();
      welcome();
    } catch (err) {
      if(access.valid(epoch)&&form.isConnected&&err.name!=="AbortError"){
        form.querySelector(".error").textContent = err.message;
        notice(err.message, 4000, "error");
      }
    } finally {
      submit.disabled = false;
    }
  };
}
function welcome() {
  if(isLocked())return;
  const w = document.createElement("div");
  w.className = "welcome";
  w.innerHTML = `<div>Hoş geldin, ${escape(state.user.name)}!<br><small>Güven içinde, keyifli sohbetler dileriz.</small></div>${Array.from({ length: 30 }, (_, i) => `<i style="left:${i * 3.3}%;animation-delay:${(i % 5) * 0.08}s;background:hsl(${270 + i * 3} 65% 75%)"></i>`).join("")}`;
  app.append(w);
  setTimeout(() => w.remove(), 2000);
}
function home() {
  if(isLocked())return;
  if(!state.token||!state.user||state.page==="setup"){authPage(false);return;}
  rememberChat();virtualMessages?.destroy();virtualMessages=null;
  clearComposer();discardVoice();
  state.page = "home";
  typing.reset();clearEmojiEffect();replyReturn=null;
  syncPresence();
  state.room = null;
  state.selected.clear();
  app.innerHTML = `<section class="screen fs-premium fs-home">${state.call ? '<button class="call-banner" data-action="return-call">Aramaya geri dön</button>' : ""}<header><span class="brand">Fs</span><h1>Mesajlaşma</h1>${button("search", "search", "Sohbet ara")}${button("menu", "more", "Menü")}</header><nav class="tabs">${["Sohbetler", "Aramalar", "Kişiler"].map((t) => `<button class="${state.tab === t ? "active" : ""}" data-action="tab" data-tab="${t}">${t}</button>`).join("")}</nav><nav class="chat-filters" ${state.tab !== "Sohbetler" ? "hidden" : ""}>${["Tümü","Okunmamış","Gruplar","Arşiv"].map(f=>`<button data-action="chat-filter" data-filter="${f}" class="${state.chatFilter===f?"active":""}">${f}</button>`).join("")}</nav><main class="scroll" id="home-list"></main><button class="fab" data-action="new-chat" aria-label="Yeni sohbet">${icon("edit")}</button></section>`;
  if(state.call)attachVideo();
  homeList().catch(err => notice(err.message));
}
let homeListSequence = 0;
async function homeList(filter = state.chatQuery || "") {
  const sequence = ++homeListSequence;
  const list = $("#home-list"), tab = state.tab;
  const current = () => sequence === homeListSequence && list?.isConnected && state.page === "home" && state.tab === tab;
  if (!list) return;
  if (state.tab === "Kişiler") {
    const contacts = await api("/contacts");
    if (!current()) return;
    state.contacts = contacts;
    list.innerHTML =
      row("new-chat", "plus", "Kişi ekle") +
      row("deleted", "trash", "Silinen kişiler") +
      state.contacts
        .filter((c) => !c.deleted)
        .map(
          (c) =>
            `<button class="contact" data-action="contact" data-id="${c.id}">${avatar(c)}<span class="copy"><strong>${escape(c.name)}</strong><p>@${escape(c.nick)}</p></span>${icon("chevron")}</button>`,
        )
        .join("");
    return;
  }
  if (state.tab === "Aramalar") {
    const calls = await api("/calls");
    if (!current()) return;
    list.innerHTML =
      calls
        .map((c) => {
          const r = state.rooms.find((r) => r.id === c.room);
          return `<button class="contact" data-action="open-room" data-id="${c.room}">${avatar(r?.members?.find(x=>x.id!==state.user.id))}<span class="copy"><strong>${escape(r ? name(r) : "Görüşme")}</strong><p>${c.caller === state.user.id ? "↗ Giden" : "↙ Gelen"} · ${escape(callLabel(c))}</p></span><time>${time(c.started)}</time></button>`;
        })
        .join("") || empty("Arama geçmişi", "İlk görüşmeni başlat.");
    return;
  }
  const rooms=chatList(state.rooms,localState.preferences,state.chatFilter,filter,state.user.id);
  list.innerHTML =
    rooms
      .map(
        (r) =>
          `<button class="contact" data-action="open-room" data-id="${r.id}">${avatar(r.members.find((x) => x.id !== state.user.id))}<span class="copy"><strong>${localState.preferences.pinned?.includes(r.id)?"📌 ":""}${escape(name(r))}</strong><p>${localState.drafts[r.id]?.text ? "Taslak: "+escape(localState.drafts[r.id].text) : escape(r.last&&hiddenMessage(r.last)?"Mesaj gizlendi":preview(r.last?.payload))}</p></span><span class="contact-meta"><time>${r.last ? time(r.last.created) : ""}</time>${r.last?.sender===state.user.id?`<span class="list-check${r.last.read_by?.some(id=>id!==state.user.id)?" read":""}">${r.last.read_by?.some(id=>id!==state.user.id)?"✓✓":"✓"}</span>`:""}</span></button>`,
      )
      .join("") ||
    empty(
      "İlk sohbetini başlat",
      "Sağ alttaki kalemden arkadaşını kullanıcı adıyla bul.",
    );
}
function preview(p) {
  if (!p) return "Güvenli sohbet";
  if (p.type === "file")
    return p.mime.startsWith("image/")
      ? "Fotoğraf"
      : p.mime.startsWith("video/")
        ? "Video"
        : p.name;
  if (p.type === "call") return p.text;
  return p.text || p.type;
}
async function newChat() {
  dialog(
    "Yeni sohbet",
    `<form id="find-form">${field("query", "Arkadaşının kullanıcı adı")}<button class="primary">Bul</button></form><div id="people-results"></div><p class="hint">Telefon numaranız arama sonuçlarında paylaşılmaz.</p><button class="secondary" data-action="invite">Arkadaşına Davet Gönder</button><button class="secondary" data-action="invite-contact">Rehberden Davet Gönder</button>`,
  );
  let searchSequence = 0;
  const resultsTarget = $("#people-results");
  $("#find-form").onsubmit = async (e) => {
    e.preventDefault();
    const sequence = ++searchSequence;
    try {
      const results = await api(
        "/people?q=" + encodeURIComponent($("#query").value),
      );
      if (sequence !== searchSequence || !resultsTarget.isConnected || !modal.open) return;
      resultsTarget.innerHTML =
        results
          .filter((p) => p.id !== state.user.id)
          .map(
            (p) =>
              `<button class="contact" data-action="start-chat" data-id="${p.id}">${avatar(p)}<span class="copy"><strong>${escape(p.name)}</strong><p>@${escape(p.nick)}</p></span>${icon("plus")}</button>`,
          )
          .join("") || '<p class="hint">Bu kullanıcı adı bulunamadı.</p>';
    } catch (err) {
      notice(err.message, 4000, "error");
    }
  };
}
async function startChat(peer) {
  await api("/contacts", { method: "POST", body: { peer } });
  const r = await api("/rooms", { method: "POST", body: { members: [peer] } });
  modal.close();
  await refreshRooms();
  await openRoom(r.id);
}
async function openRoom(id) {
  if(isLocked())return;
  rememberChat();virtualMessages?.destroy();virtualMessages=null;
  const room = state.rooms.find((r) => r.id === id);
  if (!room) return;
  typing.reset();clearEmojiEffect();replyReturn=null;replyJumpFlight=null;
  if (state.room?.id !== id) {clearComposer();discardVoice();state.messages = [];state.reply = null;state.reactionTarget = null;}
  state.page = "chat";
  state.room = room;
  state.selected.clear();
  const route = ++state.routeVersion;
  state.unreadSince=localState.preferences.read?.[id]||0;state.restorePosition=localState.positions[id];
  const peer = room.members.find((x) => x.id !== state.user.id);
  app.innerHTML = `<section class="screen chat-wall fs-premium fs-chat">${state.call ? '<button class="call-banner" data-action="return-call">Aramaya geri dön</button>' : ""}<header class="chat-head">${button("home", "back", "Sohbetler")}<button data-action="peer-profile">${avatar(peer)}</button><h1>${escape(name(room))}<small><button data-action="status">${peer?.status === "online" ? "🟢 Çevrimiçi" : peer?.status === "busy" ? "Meşgul" : "Çevrimdışı"}</button><span id="typing-status" role="status" aria-live="polite" hidden></span></small></h1>${button("audio-call", "phone", "Sesli ara")}${button("video-call", "video", "Görüntülü ara")}<button class="available ${state.settings.available === false ? "off" : ""}" data-action="available" aria-pressed="${state.settings.available !== false}" aria-label="${state.settings.available !== false ? "Müsaitim; değiştirmek için dokunun" : "Müsait değilim; değiştirmek için dokunun"}">${icon("check")}</button></header><nav class="chat-tools"><button data-action="chat-search">Sohbette ara</button><button data-action="chat-options">Sohbet seçenekleri</button><button data-action="outbox">Gönderim kuyruğu</button><button data-action="return-reply" id="return-reply" hidden>↩ Önceki konuma dön</button></nav><div id="selection"></div><main class="scroll messages" id="messages"></main><div class="latest-message-anchor"><button type="button" data-action="newest" id="new-messages" aria-label="En yeni mesaja git" hidden><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg><span id="new-messages-count" hidden></span></button></div><div id="reply"></div><div id="composer-files" hidden></div><div id="upload-progress"></div><div id="voice-status" role="status" aria-live="polite" hidden></div><form class="composer" id="compose"><div class="box">${button("emoji", "smile", "İfade seç", 'type="button"')}<textarea id="message-text" placeholder="Mesaj yaz…" aria-label="Mesaj yaz" rows="1" maxlength="4000"></textarea>${button("attach", "clip", "Dosya ekle", 'type="button"')}</div><button class="icon composer-action" id="composer-action" type="button" data-mode="mic" aria-label="Basılı tutarak ses kaydet">${icon("mic")}</button></form>${state.call?.video ? '<video id="call-mini" class="chat-pip" autoplay playsinline role="button" tabindex="0" aria-label="Görüşmeye dön; sürükleyerek taşı"></video>' : ""}</section>`;
  syncChatViewport();
  if(state.call?.video) bindChatPip();
  attachVideo();
  const draft=localState.drafts[id];$("#message-text").dataset.room=id;$("#message-text").value=draft?.text||"";
  $("#messages").addEventListener("scroll",()=>{rememberChat();markCurrentRead();updateLatestButton()},{passive:true});
  bindComposer(room);
  $("#message-text").onblur = ()=>typing.stop();
  $("#message-text").oninput = (e) => {
    typing.input(e.target.value);syncComposer();rememberChat();
    e.target.style.height = "auto";
    e.target.style.height = Math.min(app.classList.contains("chat-compact-viewport")?64:120, e.target.scrollHeight) + "px";
    scheduleChatViewport();
  };
  if(localState.pages[id]?.length){state.messages=localState.pages[id];renderMessages();}
  if(draft?.reply){const m=state.messages.find(m=>m.id===draft.reply&&!hiddenMessage(m));state.reply=m?{...m,room:id,quoteText:validQuote(m,draft.quote)}:null;if(state.reply)renderReply();}
  bindSelection();
  await loadMessages(route).catch(error=>{if(!localState.pages[id]?.length)notice(error.message,4000,'error')});
}
let messageLoadSequence = 0;
async function loadMessages(route = state.routeVersion) {
  if(isLocked())return;
  const sequence = ++messageLoadSequence;
  if (!state.room) return;
  const room = state.room.id;
  const epoch=access.epoch;
  const rows = await api("/rooms/" + room + "/messages");assertEpoch(epoch);
  const decoded = (await Promise.all(rows.map(decode))).filter(m=>!deletedInSession.has(m.id));
  assertEpoch(epoch);
  const calls = await api("/rooms/" + room + "/calls");
  assertEpoch(epoch);decoded.push(
    ...calls.map((c) => ({
      id: "call_" + c.id,
      room,
      sender: c.caller,
      created: c.started,
      payload: { type: "call", text: callLabel(c) },
      callRecord: true,
    })),
  );
  decoded.sort((a, b) => a.created - b.created);
  if (
    sequence !== messageLoadSequence ||
    route !== state.routeVersion ||
    state.room?.id !== room ||
    state.page !== "chat"
  )
    return;
  if(state.messageCacheCheck){
    const current=()=>access.valid(epoch)&&sequence===messageLoadSequence&&route===state.routeVersion&&state.room?.id===room&&state.page==="chat";
    try{
      const missing=await missingCachedMessages(state.messages,decoded,room,ids=>api(`/rooms/${encodeURIComponent(room)}/messages/check`,{method:"POST",body:{ids}}),current);
      if(!current())return;
      for(const id of missing)removeDeletedMessage(id);
    }catch(error){if(!current())return;console.warn("message cache check",error.message);}
  }
  const queued=localState.outbox.filter(m=>m.room===room).map(m=>({...m,pending:true,queued:true,sender:state.user.id}));
  state.messages = upsertMessages(mergeMessagePage(state.messages, decoded, room),queued).filter(m=>!deletedInSession.has(m.id));
  if(!state.reply&&localState.drafts[room]?.reply){const m=state.messages.find(m=>m.id===localState.drafts[room].reply&&!hiddenMessage(m));if(m){state.reply={...m,room,quoteText:validQuote(m,localState.drafts[room].quote)};renderReply();}}
  state.hasOlder = rows.length === 80;
  storePage(room,state.messages);
  renderMessages();
  markCurrentRead();
}
function renderMessages() {
  if(isLocked())return;
  const target = $("#messages");
  if (!target) return;
  const bottom = nearLatest(target);
  messageIndex=buildMessageIndex(state.messages.filter(m=>!hiddenMessage(m)));
  let day = "", unreadPlaced=false;
  const visible = [];
  for (const m of state.messages) {
    if (hiddenMessage(m)||m.payload.type === "reaction" || m.payload.type === "vote") continue;
    const previous = visible.at(-1);
    if (
      m.callRecord &&
      previous?.callRecord &&
      new Date(m.created).toDateString() ===
        new Date(previous.created).toDateString()
    ) {
      previous.count = (previous.count || 1) + 1;
      previous.payload = {
        ...m.payload,
        text: m.payload.text + " ×" + previous.count,
      };
    } else if (
      m.payload.type === "file" &&
      m.payload.mime.startsWith("image/") &&
      previous?.album &&
      previous.sender === m.sender &&
      m.created - previous.created < 30000
    ) {
      previous.album.push(m);
    } else
      visible.push({
        ...m,
        ...(m.payload.type === "file" && m.payload.mime.startsWith("image/")
          ? { album: [m] }
          : {}),
      });
  }
  const rows=visible.map(m=>{
    const date=new Date(m.created).toLocaleDateString('tr-TR');let divider=day!==date?`<div class="day">${date}</div>`:'';day=date;
    if(!unreadPlaced&&m.sender!==state.user.id&&m.created>state.unreadSince&&!m.callRecord){divider+='<div class="unread-divider">Okunmamış mesajlar</div>';unreadPlaced=true;}
    return {id:m.id,albumIds:m.album?.map(x=>x.id)||[],html:()=>divider+`<div class="tg-message-line">${selectionMarker(m)}${renderMessage(m)}</div>`};
  });
  if(state.hasOlder)rows.unshift({id:'older',html:'<button class="secondary" data-action="older">Önceki mesajları yükle</button>'});
  const previousAnchor=virtualMessages?.anchor();rememberPlayback();
  if(!virtualMessages||virtualMessages.target!==target){virtualMessages?.destroy();virtualMessages=new VirtualMessages(target,keyedMessages,()=>{loadThumbnails();restoreAudio();updateLatestButton()});}
  const position=state.restorePosition;state.restorePosition=null;
  virtualMessages.set(rows,{bottom:position?position.bottom:bottom,anchor:position?.anchor||previousAnchor});
  if(position&&!position.anchor&&!position.bottom)target.scrollTop=position.top||0;
  updateLatestButton();
  selectionBar();
}

function updateLatestButton(){
 const list=$('#messages'),button=$('#new-messages'),badge=$('#new-messages-count');
 if(isLocked()||state.page!=='chat'||!state.room||!list||!button||!badge)return;
 button.hidden=nearLatest(list);
 const read=localState.preferences.read?.[state.room.id]||0;
 const count=button.hidden?0:state.messages.filter(m=>!hiddenMessage(m)&&m.sender!==state.user.id&&!m.callRecord&&!m.pending&&m.created>read&&!['reaction','vote'].includes(m.payload.type)).length;
 badge.hidden=!count;badge.textContent=count>99?'99+':String(count||'');
 button.setAttribute('aria-label',count?`${count} yeni mesaj; en yeni mesaja git`:'En yeni mesaja git');
}
function jumpToLatest(){
 if(isLocked()||state.page!=='chat')return;
 const list=$('#messages');if(!list)return;
 replyJumpFlight=null;replyReturn=null;const back=$('#return-reply');if(back)back.hidden=true;
 // Render the last virtual window first, then jump to its actual measured bottom.
 if(virtualMessages?.target===list)virtualMessages.draw(true);else list.scrollTop=list.scrollHeight;
 markCurrentRead();rememberChat();updateLatestButton();
}

function selectionMarker(m){return state.selected.size&&!m.callRecord&&!m.pending?`<button type="button" class="selection-dot ${state.selected.has(m.id)?"checked":""}" data-action="toggle-selection" data-id="${escape(m.id)}" aria-label="Mesajı seç" aria-pressed="${state.selected.has(m.id)}">${state.selected.has(m.id)?icon("check"):""}</button>`:"";}
function renderMessage(m) {
  const p = m.payload;
  const emoji = p.type === "text" && isSingleEmoji(p.text);
  const asset = emoji ? emojiAsset(emojiIndex,p.text) : null;
  let content = p.type === "text" ? linkText(p.text) : escape(p.text || "");
  if (p.type === "file")
    content = `<button class="file-button" data-action="download" data-id="${m.id}">${icon(p.mime.startsWith("image/") ? "image" : "file")}<span>${escape(p.name)}<small class="muted"> ${(p.size / 1048576).toFixed(1)} MB · Aç / İndir</small></span></button>`;
  if (p.type === "file" && p.mime.startsWith("image/"))
    content = `<button data-action="download" data-id="${m.id}"><img class="thumb ${state.settings.blur !== false ? "blurred" : ""}" data-thumb="${m.id}" alt="${escape(p.name)}"><small>${escape(p.name)}</small></button>`;
  if (p.type === "file" && p.mime.startsWith("audio/"))
    content = `<audio controls data-audio="${m.id}" ${audioUrls.has(m.id) ? `src="${audioUrls.get(m.id)}"` : ""}></audio><button data-action="play-audio" data-id="${m.id}">Sohbette dinle</button><button data-action="audio-speed" data-id="${m.id}">${localState.playback[m.id]?.rate||1}×</button>`;
  if (m.album?.length > 1)
    content = `<div class="album">${m.album
      .slice(0, 4)
      .map(
        (item, i) =>
          `<button data-action="download" data-id="${item.id}"><img class="thumb ${state.settings.blur !== false ? "blurred" : ""}" data-thumb="${item.id}" alt="${escape(item.payload.name)}">${i === 3 && m.album.length > 4 ? `<span class="album-count">${m.album.length}</span>` : ""}</button>`,
      )
      .join("")}</div>`;
  if (p.type === "location")
    content = locationCard(m);
  if (p.type === "poll")
    content = `<strong>${escape(p.text)}</strong>${p.options
      .map((o, i) => {
        const votes = messageIndex.votes.get(m.id)||new Map();
        const count = [...votes.values()].filter((v) => v === i).length;
        return `<button class="row" data-action="vote" data-id="${m.id}" data-choice="${i}">${escape(o)} <span class="badge">${count}</span></button>`;
      })
      .join("")}`;
  if (p.type === "event") content = `📅 ${escape(p.text)}<br>${escape(p.date)}`;
  const quote = messageIndex.byId.get(m.reply);
  const exactQuote=validQuote(quote,p.replyQuote);
  const latestReactions = messageIndex.reactions.get(m.id)||new Map();
  const reactionCounts = new Map();
  for (const value of latestReactions.values())
    if(value)reactionCounts.set(value, (reactionCounts.get(value) || 0) + 1);
  const reactionBar = [...reactionCounts]
    .map(
      ([emoji, count]) =>
        `<button type="button" class="reaction-chip ${latestReactions.get(state.user.id)===emoji?"own-reaction":""}" data-action="message-reaction" data-id="${escape(m.id)}" data-emoji="${escape(emoji)}" aria-pressed="${latestReactions.get(state.user.id)===emoji}" aria-label="${escape(emoji)} ${count} tepki">${escape(emoji)}${count>1?` <span>${count}</span>`:""}</button>`,
    )
    .join("");
  return `<article class="message ${m.sender === state.user.id ? "mine" : ""} ${state.selected.has(m.id) ? "selected" : ""} ${emoji ? "emoji" : ""}" data-message="${m.id}" data-emoji="${emoji ? escape(p.text) : ""}" tabindex="0" aria-label="${escape(preview(p))}">${m.reply ? `<button type="button" class="quote reply-quote" data-action="jump-reply" data-id="${escape(m.reply)}"><strong>${escape(quote?senderName(quote):"Yanıtlanan mesaj")}</strong><span>${escape(quote?(exactQuote||preview(quote.payload).slice(0,120)):"Mesaja git")}</span></button>` : ""}${emoji ? (asset ? `<img class="animated-emoji" src="emoji/${escape(asset)}" alt="${escape(p.text)}" loading="lazy" decoding="async" draggable="false">` : `<span class="emoji-fallback">${escape(p.text)}</span>`) : content}${p.type==="file"?`<div class="transfer-state" data-transfer="${m.id}" role="status"></div>`:""}${reactionBar ? `<div class="reactions">${reactionBar}</div>` : ""}<time>${time(m.created)}${m.edited ? " · düzenlendi" : ""}${m.sender === state.user.id ? (m.queued ? " · Kuyrukta" : m.pending ? " · ◷" : m.read_by?.some((id) => id !== state.user.id) ? " · ✓✓" : " · ✓") : ""}</time></article>`;
}
async function send(payload, room = state.room, fixedId = null, options = {}) {
  assertAccess();const epoch=access.epoch;
  if (!room) throw Error("Sohbet seçin.");
  validatePayload(payload);
  if(navigator.onLine===false&&payload.type==='text'&&!options.fromQueue&&localState.outbox.length>=100)throw Error('Gönderim kuyruğunda 100 mesaj var. Önce kuyruğu tamamlayın.');
  const id = fixedId || crypto.randomUUID().replaceAll("-", ""),
    reply = Object.hasOwn(options,"replyId") ? options.replyId : (["reaction","vote"].includes(payload.type)?null:(state.reply?.room === room.id ? state.reply.id : null));
  if(reply&&state.reply?.id===reply&&state.reply.room===room.id){const q=validQuote(state.reply,state.reply.quoteText);if(q)payload={...payload,replyQuote:q};}
  const visible = state.page === "chat" && state.room?.id === room.id;
  if (visible) {
    state.messages = upsertMessages(state.messages, [{
      id,
      room: room.id,
      sender: state.user.id,
      created: Date.now(),
      pending: true,
      queued: !!options.fromQueue,
      payload,
      reply,
    }]);
    renderMessages();
    if(!["reaction","vote"].includes(payload.type))$("#messages").scrollTop = $("#messages").scrollHeight;
  }
  if(navigator.onLine===false && payload.type==='text' && !options.fromQueue){
    const item={id,room:room.id,payload,reply,created:Date.now()};if(!localState.outbox.some(m=>m.id===id))localState.outbox.push(item);
    try{await persistLocal(true)}catch(error){assertEpoch(epoch);localState.outbox=localState.outbox.filter(m=>m.id!==id);state.messages=state.messages.filter(m=>m.id!==id);if(visible&&state.room?.id===room.id&&state.page==='chat')renderMessages();throw Error('Mesaj cihazda saklanamadı. Taslağınızı koruyup tekrar deneyin.')}
    assertEpoch(epoch);if(state.room?.id===room.id&&state.page==='chat'){if(state.reply?.id===reply){state.reply=null;if($('#reply'))$('#reply').innerHTML='';}rememberChat();}if(visible&&state.room?.id===room.id&&state.page==='chat'){state.messages=upsertMessages(state.messages,[{...item,sender:state.user.id,pending:true,queued:true}]);renderMessages();}return id;
  }
  try {
    const packets=await envelopes(room,payload);assertEpoch(epoch);
    const record = await api("/rooms/" + room.id + "/messages", {
      method: "POST",
      body: {
        id,
        envelopes: packets,
        recipient_pubs: Object.fromEntries([...room.members,...(room.audit?[room.audit]:[])].map(m=>[m.id,m.pub])),
        reply,
        uploads: payload.type === "file" ? [payload.upload] : [],
      },
    });
    assertEpoch(epoch);state.cache.set(id, { ...record, payload });
    if (state.room?.id === room.id)
      state.messages = upsertMessages(state.messages, [{ ...record, payload, pending: false }]);
    if (state.page === "chat" && state.room?.id === room.id) renderMessages();
    if (reply && state.reply?.id === reply && state.room?.id === room.id) {
      state.reply = null;
      if ($("#reply")) $("#reply").innerHTML = "";
      rememberChat();
    }
    if (state.page === "chat" && state.room?.id === room.id)
      await loadMessages().catch(err => console.warn("message-refresh", err.message));
    await refreshRooms().catch(err => console.warn("room-refresh", err.message));
    return id;
  } catch (err) {
    assertEpoch(epoch);
    if(err.code==='KEY_CHANGED'&&!options.keyRetry){await refreshRooms();assertEpoch(epoch);const fresh=state.rooms.find(r=>r.id===room.id);if(fresh)return send(payload,fresh,id,{...options,keyRetry:true,replyId:reply});}
    if(options.fromQueue){const queued=localState.outbox.find(m=>m.id===id);if(queued)state.messages=upsertMessages(state.messages,[{...queued,sender:state.user.id,pending:true,queued:true}]);}
    else state.messages = state.messages.filter((m) => m.id !== id);
    if (state.page === "chat" && state.room?.id === room.id) renderMessages();
    throw err;
  }
}
const quickReactions=["👍","❤️","🔥","🥰","👏","😁","😂"];
const reactionFlight=new Set();
function senderName(m){return m.sender===state.user?.id?"Siz":state.room?.members?.find(u=>u.id===m.sender)?.name||"Kişi";}
function hiddenMessage(m){return deletedInSession.has(m.id)||!!localState.preferences.hiddenMessages?.[m.room]?.includes(m.id);}
function eligibleMessage(id){return state.messages.find(m=>m.id===id&&!hiddenMessage(m)&&!m.callRecord&&!m.pending&&!['reaction','vote'].includes(m.payload.type));}
function validQuote(m,q){return m?.payload?.type==="text"&&typeof q==="string"&&q.length>0&&q.length<=512&&typeof m.payload.text==="string"&&m.payload.text.includes(q)?q:null;}
function renderReply(){const target=$("#reply"),m=state.reply;if(!target)return;target.innerHTML=m?`<div class="reply-banner tg-reply"><button type="button" class="reply-quote" data-action="jump-reply" data-id="${escape(m.id)}"><strong>${escape(senderName(m))} kişisine yanıt</strong><span>${escape(m.quoteText||preview(m.payload).slice(0,160))}</span></button>${button("cancel-reply","close","Yanıtı iptal et")}</div>`:"";}
function beginReply(id){if(isLocked()||state.page!=="chat")return;const m=eligibleMessage(id);if(!m)return;state.reply={...m,room:state.room.id};state.selected.clear();renderMessages();renderReply();rememberChat();$("#message-text")?.focus({preventScroll:true});}
function chooseQuote(id){const m=eligibleMessage(id);if(!m||m.payload.type!=="text")return;dialog("Alıntı seç",`<p class="hint">Yanıtlamak istediğiniz metin bölümünü seçin.</p><textarea id="quote-source" readonly rows="6">${escape(m.payload.text)}</textarea><button class="primary" id="quote-confirm">Seçilen bölümü yanıtla</button>`);const source=$("#quote-source");$("#quote-confirm").onclick=()=>{if(isLocked()||!eligibleMessage(id))return;const q=validQuote(m,source.value.slice(source.selectionStart,source.selectionEnd));if(!q){notice("1–512 karakter arasında bir bölüm seçin.");return;}modal.close();beginReply(id);if(state.reply?.id===id){state.reply.quoteText=q;renderReply();rememberChat();}};}
async function jumpReply(id){
 if(isLocked()||state.page!=="chat"||replyJumpFlight)return;
 const route=state.routeVersion,room=state.room?.id,list=$("#messages"),token={};replyJumpFlight=token;
 const original={anchor:virtualMessages?.anchor(),top:list?.scrollTop||0,room,route};
 const active=()=>!isLocked()&&state.page==="chat"&&state.routeVersion===route&&state.room?.id===room&&list?.isConnected;
 try{for(let i=0;i<=30;i++){
  if(!active())return;
  const record=state.messages.find(m=>m.id===id);if(record&&hiddenMessage(record))break;
  const row=virtualMessages?.rows.find(r=>r.id===id||r.albumIds?.includes(id));
  if(row&&virtualMessages.jump(row.id)){
   const target=list.querySelector(`[data-message="${CSS.escape(row.id)}"]`);
   if(target){const exact=row.id===id?target:target.querySelector(`[data-id="${CSS.escape(id)}"]`)||target;
    const bounds=list.getBoundingClientRect(),rect=exact.getBoundingClientRect();list.scrollTop+=rect.top-bounds.top-(bounds.height-rect.height)/2;
    exact.classList.remove("found-message");void exact.offsetWidth;exact.classList.add("found-message");setTimeout(()=>exact.classList.remove("found-message"),1800);
   }
   if(!replyReturn)replyReturn=original;const back=$("#return-reply");if(back)back.hidden=false;return;
  }
  if(!state.hasOlder||i===30)break;
  const before=state.messages.find(m=>!m.callRecord&&!m.pending)?.id;await actions("older");
  if(!active())return;if(before===state.messages.find(m=>!m.callRecord&&!m.pending)?.id)break;
 }if(active())notice("Yanıtlanan mesaj silinmiş, gizlenmiş veya daha eski geçmişte olabilir.");}
 finally{if(replyJumpFlight===token)replyJumpFlight=null;}
}
function returnReplyPosition(){const save=replyReturn;replyReturn=null;const back=$("#return-reply");if(back)back.hidden=true;if(!save||isLocked()||state.room?.id!==save.room||state.routeVersion!==save.route)return;const list=$("#messages");if(!list)return;if(save.anchor?.id&&virtualMessages?.jump(save.anchor.id))list.scrollTop+=save.anchor.delta||0;else list.scrollTop=save.top;}
async function reactToMessage(id,emoji){if(isLocked()||state.page!=="chat"||!eligibleMessage(id)||!emoji)return;const room=state.room,key=room.id+":"+id;if(reactionFlight.has(key))return;reactionFlight.add(key);try{const current=messageIndex.reactions.get(id)?.get(state.user.id);await send({type:"reaction",target:id,text:reactionValue(current,emoji)},room,null,{replyId:null});if(!isLocked()&&state.room?.id===room.id&&state.page==="chat"){const el=document.querySelector(`[data-message="${CSS.escape(id)}"] .reaction-chip[data-emoji="${CSS.escape(emoji)}"]`);if(el?.classList.contains("own-reaction"))el.animate?.([{transform:"scale(.7)"},{transform:"scale(1.25)"},{transform:"scale(1)"}],{duration:240});}}finally{reactionFlight.delete(key);}}
function messageMenu(id,rect){if(isLocked()||state.page!=="chat")return;const m=eligibleMessage(id);if(!m||modal.open||state.selected.size)return;const own=m.sender===state.user.id,active=messageIndex.reactions.get(id)?.get(state.user.id);const ops=["Yanıtla",...(m.payload.type==="text"?["Alıntıla"]:[]),"Kopyala",...(own&&m.payload.type==="text"?["Düzenle"]:[]),"İlet","Paylaş","Kaydet","Seç","Sil"];dialog("Mesaj işlemleri",`<div class="tg-reactions" aria-label="Emoji tepkileri">${quickReactions.map(e=>`<button type="button" class="${active===e?"active":""}" data-action="context-react" data-id="${escape(id)}" data-emoji="${escape(e)}" aria-label="${escape(e)}" aria-pressed="${active===e}">${e}</button>`).join("")}<button type="button" data-action="context-more" data-id="${escape(id)}" aria-label="Tüm ifadeler">⌄</button></div><div class="tg-menu">${ops.map(op=>`<button type="button" data-action="context-op" data-id="${escape(id)}" data-op="${op}" class="${op==="Sil"?"danger":""}">${({Yanıtla:"↩",Alıntıla:"❞",Kopyala:"▣",Düzenle:"✎",İlet:"↪",Paylaş:"↗",Kaydet:"☆",Seç:"✓",Sil:"⌫"})[op]} <span>${op}</span></button>`).join("")}</div>`);modal.classList.add("message-context");const vv=window.visualViewport,w=vv?.width||innerWidth,h=vv?.height||innerHeight;const mw=modal.offsetWidth,mh=modal.offsetHeight;modal.style.setProperty("--menu-x",Math.max(8,Math.min(rect.left,w-mw-8))+"px");modal.style.setProperty("--menu-y",Math.max(8,Math.min(rect.bottom+5,h-mh-8))+"px");}
function bindSelection() {
  const area=$("#messages");let start=null,longTimer=null,tapTimer=null,lastTap=null,suppressUntil=0;
  const cancelTap=()=>{clearTimeout(tapTimer);lastTap=null;};
  const reset=()=>{clearTimeout(longTimer);if(start?.node){start.node.style.removeProperty("--swipe-x");start.node.classList.remove("swiping");}start=null;};
  const toggle=id=>{if(!eligibleMessage(id))return;state.selected.has(id)?state.selected.delete(id):state.selected.add(id);renderMessages();};
  area.onpointerdown=e=>{if(e.button!==0||!e.isPrimary)return;suppressUntil=0;const node=e.target.closest("[data-message]");if(!node||!eligibleMessage(node.dataset.message))return;if(!state.selected.size&&e.target.closest("a,button,audio,video,iframe")&&!e.target.closest('[data-action="download"]'))return;reset();start={id:node.dataset.message,node,x:e.clientX,y:e.clientY,pointer:e.pointerId,mode:"wait"};longTimer=setTimeout(()=>{if(!start||start.mode!=="wait"||!area.isConnected||isLocked())return;cancelTap();start.mode="held";suppressUntil=Date.now()+900;toggle(start.id);navigator.vibrate?.(12);},420);};
  area.onpointermove=e=>{if(!start||e.pointerId!==start.pointer||start.mode==="held")return;const dx=e.clientX-start.x,dy=e.clientY-start.y;const intent=gestureIntent(dx,dy);if(start.mode==="wait"&&intent!=="wait"){clearTimeout(longTimer);cancelTap();start.mode=intent==="swipe"&&!state.selected.size?"swipe":"scroll";if(start.mode==="swipe"){try{area.setPointerCapture(e.pointerId)}catch{}}}if(start.mode==="swipe"){start.node.classList.add("swiping");start.node.style.setProperty("--swipe-x",Math.max(-92,Math.min(0,dx))+"px");}};
  area.onpointerup=e=>{if(!start||e.pointerId!==start.pointer)return;const {mode,id,x,y}=start;reset();if(mode!=="wait")suppressUntil=Date.now()+500;if(mode==="swipe"&&gestureIntent(e.clientX-x,e.clientY-y,true)==="reply"){navigator.vibrate?.(10);beginReply(id);}};
  area.onpointercancel=()=>{if(start?.mode==="swipe"||start?.mode==="held")suppressUntil=Date.now()+500;reset();};
  area.oncontextmenu=e=>{const node=e.target.closest("[data-message]");if(!node||!eligibleMessage(node.dataset.message))return;e.preventDefault();if(Date.now()<suppressUntil)return;cancelTap();reset();toggle(node.dataset.message);suppressUntil=Date.now()+500;};
  area.addEventListener("click",e=>{const node=e.target.closest("[data-message]");if(!node)return;const id=node.dataset.message;if(Date.now()<suppressUntil){e.preventDefault();e.stopPropagation();suppressUntil=0;return;}if(!eligibleMessage(id))return;if(state.selected.size){e.preventDefault();e.stopPropagation();cancelTap();toggle(id);return;}if(e.target.closest("a,button,audio,video,iframe"))return;e.preventDefault();e.stopPropagation();const now=Date.now();if(node.classList.contains("emoji")&&e.target.closest(".animated-emoji,.emoji-fallback")){cancelTap();emojiEffect(node);return;}if(lastTap?.id===id&&now-lastTap.at<280){cancelTap();reactToMessage(id,"👍").catch(error=>notice(error.message,4000,"error"));return;}cancelTap();lastTap={id,at:now};const rect=node.getBoundingClientRect();tapTimer=setTimeout(()=>{lastTap=null;if(area.isConnected&&!isLocked()&&state.page==="chat")messageMenu(id,rect);},280);},true);
  area.onkeydown=e=>{if(!["Enter"," "].includes(e.key)||e.target.closest("button,a"))return;const node=e.target.closest("[data-message]");if(!node||!eligibleMessage(node.dataset.message))return;e.preventDefault();if(state.selected.size)toggle(node.dataset.message);else messageMenu(node.dataset.message,node.getBoundingClientRect());};
}
function selectionBar() {
  const s=$("#selection");if(!s)return;const messages=state.messages.filter(m=>state.selected.has(m.id));const ops=selectionOps(messages,state.user?.id,true);s.innerHTML=messages.length?`<div class="selection-bar tg-selection"><button type="button" data-action="selection" data-op="Vazgeç" aria-label="Seçimi kapat">✕</button><strong aria-live="polite">${messages.length}</strong><div class="tg-selection-actions">${ops.map(([op,label])=>`<button type="button" data-action="selection" data-op="${op}" aria-label="${op}" title="${op}"><span>${label}</span><small>${op}</small></button>`).join("")}</div></div>`:"";
}
async function selection(op) {
  const messages=state.messages.filter(m=>state.selected.has(m.id));
  if(op==="Yanıtla"){if(messages.length===1)beginReply(messages[0].id);return;}
  if(op==="Tepki"){if(messages.length===1){state.reactionTarget=messages[0].id;emojiPicker();}}
  if(op==="Kopyala"){if(!messages.length)return;await navigator.clipboard.writeText(messages.map(m=>preview(m.payload)).join("\n"));notice("Kopyalandı.");}
  if (op === "Düzenle") {
    const m = messages[0];
    if (
      messages.length !== 1 ||
      m.sender !== state.user.id ||
      m.payload.type !== "text"
    )
      throw Error("Düzenlemek için kendi metin mesajını seç.");
    dialog(
      "Mesajı düzenle",
      `<form id="edit-message"><textarea name="text" maxlength="4000" required>${escape(m.payload.text)}</textarea><button class="primary">Kaydet</button></form>`,
    );
    $("#edit-message").onsubmit = async (e) => {
      e.preventDefault();
      try {
        const text = new FormData(e.target).get("text").trim();
        if (!text) return;
        await api("/messages/" + m.id, {
          method: "PATCH",
          body: {
            envelopes: await envelopes(state.room, { ...m.payload, text }),
            recipient_pubs: Object.fromEntries([...state.room.members,...(state.room.audit?[state.room.audit]:[])].map(peer=>[peer.id,peer.pub])),
          },
        });
        state.cache.delete(m.id);
        modal.close();
        await loadMessages();
        notice("Mesaj düzenlendi.",2000,"success");
      } catch (err) {
        notice(err.message, 4000, "error");
      }
    };
  }
  if (op === "Sil") {
    if(!messages.length)return;
    const room=state.room,epoch=access.epoch,route=state.routeVersion;
    const everyone=messages.every(m=>m.sender===state.user.id||(room.kind==="direct"&&state.directDelete));
    dialog("Mesajları sil",`<p>${messages.length} mesaj seçildi.</p><button class="secondary" id="delete-local">Yalnızca bu cihazda gizle</button>${everyone?'<button class="primary danger" id="confirm-delete">Herkesten sil</button>':'<p class="hint">Karşı tarafın mesajını herkesten silmek için sunucu desteği gerekir.</p>'}<button class="secondary" data-action="close-dialog">Vazgeç</button>`);
    const active=()=>access.valid(epoch)&&state.room?.id===room.id&&state.routeVersion===route&&state.page==="chat";
    $("#delete-local").onclick=async()=>{if(!active())return;const btn=$("#delete-local");btn.disabled=true;const old=localState.preferences.hiddenMessages?.[room.id]||[];localState.preferences.hiddenMessages??={};localState.preferences.hiddenMessages[room.id]=[...new Set([...old,...messages.map(m=>m.id)])];try{await persistLocal(true);}catch(error){localState.preferences.hiddenMessages[room.id]=old;if(active()){btn.disabled=false;notice("Silme kaydedilemedi.",4000,"error");}return;}if(!active())return;state.selected.clear();if(state.reply&&messages.some(m=>m.id===state.reply.id)){state.reply=null;renderReply();rememberChat();}modal.close();renderMessages();};
    const confirm=$("#confirm-delete");if(confirm)confirm.onclick=async()=>{if(!active())return;confirm.disabled=true;$("#delete-local").disabled=true;let done=0;try{for(const m of messages){if(!active())break;await api("/messages/"+encodeURIComponent(m.id),{method:"DELETE"});if(!active())return;removeDeletedMessage(m.id);done++;}if(active()){modal.close();state.selected.clear();renderMessages();await loadMessages();}}catch(error){if(active()){modal.close();state.selected.clear();renderMessages();notice(`${done}/${messages.length} silindi. ${error.message}`,4000,"error");}}};
    return;
  }
  if (op === "Kaydet")
    for (const m of messages)
      await api("/saved", { method: "POST", body: { id: m.id } });
  if (op === "Paylaş") {
    const files = messages.filter((m) => m.payload.type === "file");
    if (files.length) {
      for (const m of files) {
        const r = await fetch(apiRoot + "/api/uploads/" + m.payload.upload, {
          headers: { Authorization: "Bearer " + state.token },
        });
        if (!r.ok) throw Error("Paylaşılacak dosya indirilemedi.");
        const blob = await decryptFile(await r.arrayBuffer(), m.payload);
        if (window.FSNative?.beginFile)
          await nativeFile(blob, m.payload.name, m.payload.mime, "share");
        else {
          const file = new File([blob], m.payload.name, {
            type: m.payload.mime,
          });
          if (navigator.canShare?.({ files: [file] }))
            await navigator.share({ files: [file] });
          else await download(m, true);
        }
      }
      state.selected.clear();
      renderMessages();
      return;
    }
    const text = messages.map((m) => preview(m.payload)).join("\n");
    if (navigator.share) await navigator.share({ text });
    else {
      await navigator.clipboard.writeText(text);
      notice("Panoya kopyalandı.");
    }
  }
  if (op === "İlet") {
    dialog(
      "Sohbete ilet",
      state.rooms
        .map(
          (r) =>
            `<button class="row forward-target" data-target="${r.id}">${escape(name(r))}</button>`,
        )
        .join(""),
    );
    for (const b of modal.querySelectorAll(".forward-target"))
      b.onclick = async () => {
        const target = state.rooms.find((r) => r.id === b.dataset.target);
        for (const m of messages) {
          if (m.payload.type === "file") {
            const response = await fetch(
              apiRoot + "/api/uploads/" + m.payload.upload,
              { headers: { Authorization: "Bearer " + state.token } },
            );
            if (!response.ok) throw Error("İletilecek dosya indirilemedi.");
            const blob = await decryptFile(
              await response.arrayBuffer(),
              m.payload,
            );
            await uploadFile(
              new File([blob], m.payload.name, { type: m.payload.mime }),
              target,
            );
          } else {const {replyQuote,...forwardPayload}=m.payload;await send({...forwardPayload,forwarded:true},target,null,{replyId:null});}
        }
        modal.close();
      };
  }
  state.selected.clear();
  renderMessages();
}
function attach() {
  dialog(
    "Paylaş",
    `<div class="attach-grid">${[
      ["gallery", "image", "Galeri"],
      ["camera", "video", "Kamera"],
      ["document", "file", "Belge"],
      ["location", "location", "Konum"],
      ["share-contact", "user", "Kişi"],
      ["poll", "bookmark", "Anket"],
      ["event", "bell", "Etkinlik"],
    ]
      .map(([a, i, t]) => `<button data-action="${a}">${icon(i)}${t}</button>`)
      .join(
        "",
      )}</div>${window.FSNative?.recentPhotos ? '<button class="secondary" data-action="recent-photos">Son fotoğrafları göster</button><div class="recent-strip" id="recent-strip"></div>' : ""}`,
  );
}

// Keep queued media bound to the authenticated room. No auto-send on selection.
let composerFiles=[],composerRoom=null,composerGesture=null,composerMediaBusy=false;
function clearComposer(){composerGesture?.reset();composerGesture=null;composerFiles=[];composerRoom=null;composerMediaBusy=false;}
function currentComposerMode(){return composerMode({text:$('#message-text')?.value||'',files:composerFiles.length,recording:!!state.recording,active:!!voiceController?.session,busy:composerMediaBusy||voiceSending||uploadBusy});}
function syncComposer(){const b=$('#composer-action');if(!b)return;const m=currentComposerMode();if(b.dataset.mode!==m){b.dataset.mode=m;b.innerHTML=icon(m==='send'?'send':'mic');b.setAttribute('aria-label',m==='send'?'Gönder':m==='recording'?'Ses kaydediliyor':m==='busy'?'Gönderiliyor':'Basılı tutarak ses kaydet');b.classList.toggle('recording',m==='recording');b.classList.toggle('send',m==='send');}composerGesture?.changed();}
function renderComposerFiles(){const box=$('#composer-files');if(box){box.hidden=!composerFiles.length;box.replaceChildren();composerFiles.forEach((item,i)=>{const row=document.createElement('div'),name=document.createElement('span'),remove=document.createElement('button');name.textContent=item.file.name;remove.type='button';remove.textContent='×';remove.setAttribute('aria-label',item.file.name+' kaldır');remove.disabled=composerMediaBusy;remove.onclick=()=>{if(composerMediaBusy)return;composerFiles.splice(i,1);renderComposerFiles();};row.append(name,remove);box.append(row);});}syncComposer();}
function stageFiles(files,room,epoch){if(!room||!access.valid(epoch)||state.page!=='chat'||state.room?.id!==room.id)return;if(composerRoom!==room.id||composerMediaBusy)throw Error('Gönderim sürerken yeni dosya eklenemez.');const next=[...files];if(next.some(f=>!f.size||f.size>50*1048576))throw Error('Dosya boş veya 50 MB sınırını aşıyor.');if(composerFiles.length+next.length>20)throw Error('Bir seferde en fazla 20 dosya seçebilirsiniz.');composerFiles.push(...next.map(file=>({file,pendingId:null})));renderComposerFiles();}
function bindComposer(room){
 composerGesture?.reset();composerRoom=room.id;
 const b=$('#composer-action'),form=$('#compose');
 const epoch=access.epoch,valid=()=>access.valid(epoch)&&state.page==='chat'&&state.room?.id===room.id&&b.isConnected;
 composerGesture=createMicGesture({mode:()=>valid()?currentComposerMode():'busy',start:e=>{if(valid())beginRecording(e).catch(err=>{if(valid())notice(err.message,4000,'error');});},finish:endRecording,cancel:discardVoice});
 const gesture=composerGesture;
 b.onpointerdown=e=>{if(gesture.down(e)){e.preventDefault();b.setPointerCapture?.(e.pointerId);}};
 b.onpointermove=e=>{if(gesture.isRecording()&&state.voicePressed&&voiceStartY-e.clientY>55){voiceLocked=true;const session=voiceController?.session;if(session)voiceStatus({phase:'recording',elapsed:voiceController.elapsed(session),wave:session.wave});}};
 b.onpointerup=e=>gesture.up(e);b.onpointercancel=e=>gesture.abort(e);b.onlostpointercapture=e=>gesture.up(e);
 b.onclick=e=>{e.preventDefault();if(valid()&&gesture.click())submitComposer(room,epoch).catch(err=>{if(valid())notice(err.message,4000,'error');});};
 form.onsubmit=e=>{e.preventDefault();if(valid()&&currentComposerMode()==='send'){gesture.sent();submitComposer(room,epoch).catch(err=>{if(valid())notice(err.message,4000,'error');});}};
 renderComposerFiles();syncComposer();
}
async function submitComposer(room,epoch){
 const input=$('#message-text'),valid=()=>access.valid(epoch)&&state.page==='chat'&&state.room?.id===room.id&&input?.isConnected;
 if(!valid()||composerMediaBusy||currentComposerMode()!=='send')return;
 typing.stop();
 if(state.recording&&!input.value.trim()&&!composerFiles.length){await sendRecording();return;}
 // Freeze attachment intent before awaiting the network. New picks cannot sneak into this send.
 const batch=composerFiles.slice();if(batch.length){composerMediaBusy=true;renderComposerFiles();}
 try{
  const text=input.value.trim();if(text){input.value='';input.style.height='auto';syncComposer();rememberChat();try{await send({type:'text',text},room);}catch(error){if(valid()){input.value=input.value?text+'\n'+input.value:text;syncComposer();rememberChat();}throw error;}}
  for(const item of batch){if(!valid())return;const pending=await vault('pending-upload');if(!valid())return;
   try{if(item.pendingId&&pending?.id===item.pendingId&&pending.room===room.id)await resumeUpload();else await uploadFile(item.file,room);}
   catch(error){if(valid()){const saved=await vault('pending-upload');if(valid()&&saved?.room===room.id&&saved.meta?.name===item.file.name&&saved.meta?.size===item.file.size&&!pending)item.pendingId=saved.id;}throw error;}
   if(!valid())return;composerFiles=composerFiles.filter(x=>x!==item);renderComposerFiles();}}
 finally{if(valid()&&batch.length){composerMediaBusy=false;renderComposerFiles();if($('#upload-progress'))$('#upload-progress').innerHTML='';}}
}
async function chooseFiles(kind) {
  const selectedRoom=state.room,epoch=access.epoch;
  modal.close();
  const input = $("#files");
  input.multiple = kind !== "camera";
  input.accept =
    kind === "gallery" ? "image/*,video/*" : kind === "camera" ? "image/*" : "";
  if (kind === "camera") input.setAttribute("capture", "environment");
  else input.removeAttribute("capture");
  input.onchange = async () => {
    try {
      stageFiles(input.files,selectedRoom,epoch);
    } catch (err) {
      notice(err.message, 4000, "error");
    } finally {
      input.value = "";
      syncComposer();
    }
  };
  input.click();
}
let uploadBusy = false;
async function uploadFile(file, targetRoom = state.room) {
  if (uploadBusy) throw Error("Dosya yüklemesi sürüyor; tamamlanmasını bekleyin.");
  uploadBusy = true;syncComposer();
  try {
    return await createUpload(file, targetRoom);
  } finally { uploadBusy = false;syncComposer(); }
}
async function createUpload(file, targetRoom) {
  assertAccess();const epoch=access.epoch;
  if (!targetRoom || !state.rooms.some(r => r.id === targetRoom.id)) throw Error("Sohbet bulunamadı.");
  if (await vault("pending-upload"))
    throw Error(
      "Önce Veri ve Depolama bölümünden bekleyen yüklemeyi tamamla veya iptal et.",
    );
  assertEpoch(epoch);if (file.size > 50 * 1024 * 1024) throw Error("Dosya sınırı 50 MB.");
  if (!file.size) throw Error("Dosya boş.");
  const room = targetRoom,
    prepared = await prepareMedia(file,thumbnail), encrypted=prepared.encrypted;
  assertEpoch(epoch);let record = await api("/uploads", {
    method: "POST",
    body: { room: room.id, size: encrypted.data.length },
  });
  assertEpoch(epoch);await vault("pending-upload", {
    messageId: crypto.randomUUID().replaceAll("-", ""),
    id: record.id,
    room: room.id,
    bytes: encrypted.data,
    meta: {
      key: encrypted.key,
      iv: encrypted.iv,
      type: "file",
      name: file.name,
      mime: file.type || "application/octet-stream",
      size: file.size,
      thumbnail: prepared.thumbnail,
    },
  });
  assertEpoch(epoch);await continueUpload();
}
async function resumeUpload() {
  if (uploadBusy) throw Error("Dosya yüklemesi sürüyor; tamamlanmasını bekleyin.");
  uploadBusy = true;syncComposer();
  try { return await continueUpload(); } finally { uploadBusy = false;syncComposer(); }
}
async function continueUpload() {
  assertAccess();const epoch=access.epoch;
  const p = await vault("pending-upload");assertEpoch(epoch);
  if (!p) return;
  const room = state.rooms.find((r) => r.id === p.room);
  if (!room) throw Error("Bekleyen yüklemenin sohbeti bulunamadı.");
  const headers = { Authorization: "Bearer " + state.token };
  const check = await fetch(apiRoot + "/api/uploads/" + p.id, {
    method: "HEAD",
    headers,
  });
  assertEpoch(epoch);if (check.status !== 409 && !check.ok)
    throw Error("Yüklemeye devam edilemedi.");
  let offset = check.ok
    ? Number(check.headers.get("Upload-Offset"))
    : p.bytes.length;
  if (!Number.isSafeInteger(offset) || offset < 0 || offset > p.bytes.length) throw Error("Yükleme konumu geçersiz.");
  while (offset < p.bytes.length) {
    assertEpoch(epoch);const chunk = p.bytes.slice(offset, offset + 512 * 1024);
    const r = await api("/uploads/" + p.id, {
      method: "PUT",
      headers: {
        "Upload-Offset": String(offset),
        "Content-Type": "application/octet-stream",
      },
      body: chunk,
    });
    assertEpoch(epoch);if (!Number.isSafeInteger(r.offset) || r.offset !== offset + chunk.length) throw Error("Yükleme ilerlemesi doğrulanamadı; tekrar deneyin.");
    offset = r.offset;
    if ($("#upload-progress"))
      $("#upload-progress").innerHTML =
        `<div class="progress" style="width:${(offset / p.bytes.length) * 100}%"></div>`;
  }
  assertEpoch(epoch);await send({ ...p.meta, upload: p.id }, room, p.messageId);
  assertEpoch(epoch);await vault("pending-upload", null);
}
const transfers=new Map();
function transferStatus(id,text,retry=false){for(const target of document.querySelectorAll(`[data-transfer="${id}"]`)){target.textContent=text;if(retry){const button=document.createElement('button');button.dataset.action='download';button.dataset.id=id;button.textContent='Yeniden dene';target.append(button)}}}
async function fileBytes(m){
 assertAccess();
 if(transfers.has(m.id))return transfers.get(m.id);
 const token=state.token,admin=state.page==='admin-room';
 const task=(async()=>{try{transferStatus(m.id,'İndiriliyor…');const controller=new AbortController();let timer=setTimeout(()=>controller.abort(),30000);let reader;try{const response=await fetch(apiRoot+(admin?'/api/admin/uploads/':'/api/uploads/')+m.payload.upload,{headers:{Authorization:'Bearer '+token},signal:controller.signal});if(!response.ok)throw Error('Dosya indirilemedi ('+response.status+').');let bytes;if(response.body?.getReader){reader=response.body.getReader();const chunks=[];let received=0,last=0;while(true){const {done,value}=await reader.read();if(done)break;clearTimeout(timer);timer=setTimeout(()=>controller.abort(),30000);received+=value.length;if(received>50*1024*1024+16)throw Error('Dosya sınırı aşıldı.');chunks.push(value);if(Date.now()-last>100){transferStatus(m.id,`İndiriliyor · %${Math.min(100,Math.round(received/(m.payload.size+16)*100))}`);last=Date.now()}}bytes=new Uint8Array(received);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length}}else bytes=new Uint8Array(await response.arrayBuffer());if(state.token!==token)throw Error('Oturum değişti.');transferStatus(m.id,'Dosya açılıyor…');return bytes;}finally{clearTimeout(timer);reader?.releaseLock();}}catch(error){transferStatus(m.id,'İndirilemedi. ',true);throw error}finally{transfers.delete(m.id)}})();transfers.set(m.id,task);return task;
}
async function download(m, save = false) {
  if(isLocked())return;
  const p = m.payload;
  save = save || !/^(audio|image|video)\//.test(p.mime);
  state.openMediaId = m.id;
  const token=state.token,page=state.page,room=state.room?.id,epoch=access.epoch;
  let blob;try{blob=await decryptFile(await fileBytes(m),p)}catch(error){transferStatus(m.id,"Dosya açılamadı. ",true);throw error}
  transferStatus(m.id,'Hazır');
  if(!access.valid(epoch)||state.token!==token||(!save&&(state.page!==page||state.room?.id!==room)))return;
  const url = URL.createObjectURL(blob);
  if (save && window.FSNative?.beginFile) {
    URL.revokeObjectURL(url);
    await nativeFile(blob, p.name, p.mime, "save");
    return;
  }
  if (save) {
    const a = document.createElement("a");
    a.href = url;
    a.download = p.name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 10000);
    return;
  }
  if (p.mime.startsWith("audio/"))
    dialog(p.name, `<audio controls autoplay src="${url}"></audio>`);
  else if (p.mime.startsWith("image/"))
    dialog(
      p.name,
      `<img id="media-image" class="${state.settings.blur !== false ? "blurred" : ""}" src="${url}" alt="Gönderilen fotoğraf" style="width:100%"><p class="hint">Netleştirmek için fotoğrafa dokun.</p><button class="primary" data-action="save-file" data-id="${m.id}">İndir</button>`,
    );
  else if (p.mime.startsWith("video/"))
    dialog(
      p.name,
      `<video controls playsinline src="${url}" style="width:100%"></video><button class="primary" data-action="save-file" data-id="${m.id}">İndir</button>`,
    );
  else {
    URL.revokeObjectURL(url);
    return download(m, true);
  }
  modal.addEventListener("close", () => URL.revokeObjectURL(url), {
    once: true,
  });
  if ($("#media-image"))
    $("#media-image").onclick = (e) => e.target.classList.remove("blurred");
}
let voiceController=null,voiceRoom=null,voicePreviewUrl=null,voiceSending=false,voiceDuration=0;
let voiceLocked=false,voiceStartY=0;
function voiceStatus({phase,elapsed=0,wave=[],meterAvailable=false}){
 syncComposer();const box=$('#voice-status');if(!box)return;box.hidden=phase==='idle';if(box.hidden){box.innerHTML='';return}
 if(['recording','paused'].includes(phase)){
  if(!box.querySelector('.voice-wave'))box.innerHTML='<span class="record-dot"></span><strong class="voice-label"></strong><time class="voice-time"></time><div class="voice-wave" aria-label="Mikrofon ses seviyesi"></div><button type="button" data-action="voice-lock">Kilitle</button><button type="button" data-action="voice-pause">Duraklat</button><button type="button" data-action="voice-resume" hidden>Devam</button><button type="button" data-action="voice-finish">Bitir / Dinle</button><button type="button" data-action="discard-recording">Vazgeç</button>';
  box.querySelector('.voice-label').textContent=phase==='paused'?'Kayıt duraklatıldı':voiceLocked?'Kayıt kilitli':'Ses kaydediliyor';box.querySelector('.voice-time').textContent=Math.floor(elapsed/60000)+':'+String(Math.floor(elapsed/1000)%60).padStart(2,'0');box.querySelector('[data-action="voice-lock"]').hidden=voiceLocked;box.querySelector('[data-action="voice-pause"]').hidden=phase==='paused';box.querySelector('[data-action="voice-resume"]').hidden=phase!=='paused';box.querySelector('.voice-wave').innerHTML=meterAvailable&&wave.length?wave.map(v=>`<i style="height:${Math.max(2,Math.round(v*28))}px"></i>`).join(''):'<small>Ses seviyesi gösterimi kullanılamıyor</small>';
 }else box.textContent=phase==='permission'?'Mikrofon izni bekleniyor…':'Ses kaydı hazırlanıyor…';
}

function discardVoice(){voiceLocked=false;state.voicePressed=false;voiceController?.cancel();voiceController=null;state.recording=null;voiceRoom=null;if(voicePreviewUrl){URL.revokeObjectURL(voicePreviewUrl);voicePreviewUrl=null}voiceStatus({phase:'idle',elapsed:0});syncComposer()}
async function beginRecording(e){
 if(isLocked()||currentComposerMode()!=='mic'||voiceSending||state.recording||voiceController?.session)return;if(state.call)throw Error('Görüşme sırasında yeni ses kaydı başlatılamaz.');
 document.querySelectorAll('audio[data-audio]').forEach(audio=>audio.pause());
 voiceLocked=false;voiceStartY=e.clientY;state.voicePressed=true;const room=state.room?.id;voiceRoom=room;
 // The initiating pointer is already captured by the composer button.
 const controller=new VoiceRecorder({mediaDevices:navigator.mediaDevices,Recorder:globalThis.MediaRecorder,onStatus:voiceStatus,onError:error=>notice(error.message),onReady:({blob,duration,mime})=>{
  if(voiceRoom!==room||state.room?.id!==room||state.page!=='chat')return;
  state.recording=new File([blob],'ses-'+Date.now()+'.'+voiceExtension(mime),{type:mime});
  voicePreviewUrl=URL.createObjectURL(blob);voiceDuration=duration;
  const box=$('#voice-status');if(box){box.hidden=false;box.innerHTML='<strong>Ses kaydı hazır</strong><button type="button" data-action="review-recording">Dinle / Gönder</button><button type="button" data-action="discard-recording">Vazgeç</button>';}
  syncComposer();reviewRecording();
 }});voiceController=controller;await controller.start();
}
function reviewRecording(){if(state.recording&&voicePreviewUrl)dialog('Ses kaydı',`<p>${Math.ceil(voiceDuration/1000)} saniyelik kayıt hazır. Önce dinleyebilir, sonra gönderebilirsiniz.</p><audio controls src="${voicePreviewUrl}" aria-label="Ses kaydı önizlemesi"></audio><button class="primary" data-action="send-recording">Gönder</button><button class="secondary" data-action="discard-recording">Vazgeç</button>`)}
function endRecording(){state.voicePressed=false;if(!voiceLocked)voiceController?.stop()}
async function sendRecording(){
 if(voiceSending||!state.recording)return;
 if(voiceRoom!==state.room?.id||state.page!=='chat'){discardVoice();throw Error('Ses kaydının sohbeti değişti. Yeniden kayıt yapın.');}
 voiceSending=true;syncComposer();const file=state.recording;document.querySelectorAll('[data-action="send-recording"]').forEach(b=>b.disabled=true);
 try{const pending=await vault('pending-upload');if(pending&&pending.room===voiceRoom&&pending.meta.name===file.name&&pending.meta.size===file.size)await resumeUpload();else await uploadFile(file);modal.close();discardVoice()}catch(error){notice('Ses kaydı gönderilemedi. Kayıt korundu; yeniden gönderebilirsiniz.');throw error}finally{voiceSending=false;syncComposer();document.querySelectorAll('[data-action="send-recording"]').forEach(b=>b.disabled=false)}
}
document.addEventListener('visibilitychange',()=>{if(document.hidden&&voiceController?.session)discardVoice()});

function emojiPicker() {
  dialog("İfade Seç", `<div class="emoji-showcase" aria-hidden="true">🥰</div><input id="emoji-search" aria-label="Emoji ara" placeholder="Emoji ara veya yapıştır"><nav class="emoji-categories" aria-label="Emoji kategorileri"></nav><div class="emoji-grid" id="emoji-list"></div><button class="secondary emoji-more" id="emoji-more">Diğer emojiler</button>`);
  const categories=[['Tümü','✨'],['Yüzler','😀'],['Kalpler','💜'],['Hayvanlar','🐱'],['Diğer','🌟']];
  let category='Tümü',visible=72;
  const match=(e)=>category==='Tümü'||(category==='Yüzler'&&/^[\u{1F600}-\u{1F64F}]/u.test(e.emoji))||(category==='Kalpler'&&/[❤️♥💜🩷🩵💙💚💛🧡🖤🤍🤎💓💗💕💞💖💝💘]/u.test(e.emoji))||(category==='Hayvanlar'&&/^[\u{1F400}-\u{1F43F}\u{1F980}-\u{1F9AE}]/u.test(e.emoji))||(category==='Diğer'&&!/^[\u{1F600}-\u{1F64F}\u{1F400}-\u{1F43F}\u{1F980}-\u{1F9AE}]/u.test(e.emoji));
  const draw=()=>{
    const q=$('#emoji-search').value.trim();const items=emojiItems.filter(e=>match(e)&&(!q||e.emoji.includes(q)));
    $('.emoji-categories').querySelectorAll('button').forEach(b=>{b.classList.toggle('active',b.dataset.category===category);b.setAttribute('aria-pressed',b.dataset.category===category)});
    $('#emoji-list').innerHTML=items.slice(0,visible).map(e=>`<button data-action="choose-emoji" data-emoji="${escape(e.emoji)}" aria-label="${escape(e.emoji)}"><img loading="lazy" decoding="async" src="emoji/${escape(e.file)}" alt="${escape(e.emoji)}" width="36" height="36"></button>`).join('')||'<p class="hint">Eşleşen emoji bulunamadı.</p>';
    $('#emoji-more').hidden=items.length<=visible;
  };
  $('.emoji-categories').innerHTML=categories.map(([title,symbol])=>`<button data-category="${title}" title="${title}" aria-label="${title}">${symbol}</button>`).join('');
  $('.emoji-categories').onclick=e=>{const b=e.target.closest('[data-category]');if(!b)return;category=b.dataset.category;visible=72;draw()};
  $('#emoji-search').oninput=()=>{visible=72;draw()};$('#emoji-more').onclick=()=>{visible+=72;draw()};draw();
}

const liveLocations = new Map();
function locationDialog() {
  dialog(
    "Konum paylaş",
    `<form id="location-form"><p class="hint">Konum yalnızca izin verdiğinde alınır. Android’de arka plan paylaşımı sırasında görünür bir konum bildirimi gösterilir.</p><label>Paylaşım türü</label><select name="mode"><option value="once">Mevcut konum</option><option value="live">Canlı konum</option></select><label>Süre (dakika)</label><input name="minutes" type="number" min="1" max="480" list="durations" value="15"><datalist id="durations"><option value="15"><option value="60"><option value="480"></datalist><button class="primary">Konumumu paylaş</button></form>${liveLocations.size || state.nativeLive ? '<button class="secondary" data-action="stop-location">Canlı konumu durdur</button>' : ""}`,
  );
  $("#location-form").onsubmit = (e) => {
    e.preventDefault();
    const f = new FormData(e.target),
      minutes = Number(f.get("minutes")),
      live = f.get("mode") === "live";
    if (minutes < 1 || minutes > 480) {
      notice("1–480 dakika arasında bir süre gir.");
      return;
    }
    const room = state.room, locationToken = state.token;
    modal.close();
    let last = 0,
      messageId = null,
      busy = false;
    const expires = Date.now() + minutes * 60000;
    const update = async (pos) => {
      if (state.token !== locationToken || Date.now() >= expires || busy || Date.now() - last < 10000) return;
      last = Date.now();
      busy = true;
      try {
        const payload = {
          type: "location",
          text: live ? "Canlı konum" : "Konum",
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          expires,
          live,
        };
        if (!messageId) messageId = await send(payload, room);
        else {
          await api("/messages/" + messageId, {
            method: "PATCH",
            body: { envelopes: await envelopes(room, payload) },
          });
          state.cache.delete(messageId);
          if (state.room?.id === room.id && state.page === "chat")
            await loadMessages();
        }
      } catch (err) {
        notice(err.message, 4000, "error");
      } finally {
        busy = false;
      }
    };
    const fail = (err) => notice("Konum alınamadı: " + err.message);
    if (live && window.FSNative?.startLiveLocation) {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          try {
            if (isLocked()||state.token !== locationToken || Date.now() >= expires) return;
            const payload = {
              type: "location",
              text: "Canlı konum",
              lat: pos.coords.latitude,
              lng: pos.coords.longitude,
              live: true,
              expires,
            };
            const message = await send(payload, room);
            const keys = {};
            for (const peer of [
              ...new Map(
                [...room.members, ...(room.audit ? [room.audit] : [])].map(
                  (p) => [p.id, p],
                ),
              ).values(),
            ]) {
              const publicKey = await crypto.subtle.importKey(
                "jwk",
                peer.pub,
                { name: "ECDH", namedCurve: "P-256" },
                false,
                [],
              );
              const key = await crypto.subtle.deriveKey(
                { name: "ECDH", public: publicKey },
                state.identity.pair.privateKey,
                { name: "AES-GCM", length: 256 },
                true,
                ["encrypt"],
              );
              keys[peer.id] = b64(await crypto.subtle.exportKey("raw", key));
            }
            if(isLocked())return;
            window.FSNative.startLiveLocation(
              JSON.stringify({
                room: room.id,
                message,
                keys,
                expires,
                lat: payload.lat,
                lng: payload.lng,
              }),
            );
            state.nativeLive = true;
          } catch (err) {
            notice(err.message, 4000, "error");
          }
        },
        fail,
        { enableHighAccuracy: true, timeout: 20000 },
      );
      return;
    }
    if (live) {
      const watch = navigator.geolocation.watchPosition(update, fail, {
        enableHighAccuracy: true,
        maximumAge: 5000,
        timeout: 20000,
      });
      const timer = setTimeout(() => {
        navigator.geolocation.clearWatch(watch);
        liveLocations.delete(watch);
      }, minutes * 60000);
      liveLocations.set(watch, { timer, room, getMessageId: () => messageId });
    } else
      navigator.geolocation.getCurrentPosition(update, fail, {
        enableHighAccuracy: true,
        timeout: 20000,
      });
  };
}
async function stopLocations() {
  if (state.nativeLive) {
    window.FSNative?.stopLiveLocation();
    state.nativeLive = false;
  }
  for (const [watch, record] of liveLocations) {
    navigator.geolocation.clearWatch(watch);
    clearTimeout(record.timer);
    const id = record.getMessageId(),
      m = state.messages.find((m) => m.id === id);
    if (m) {
      await api("/messages/" + id, {
        method: "PATCH",
        body: {
          envelopes: await envelopes(record.room, {
            ...m.payload,
            live: false,
            text: "Canlı konum sona erdi",
            expires: Date.now(),
          }),
        },
      });
      state.cache.delete(id);
    }
  }
  liveLocations.clear();
  modal.close();
  if (state.page === "chat") await loadMessages();
}
function pollDialog() {
  dialog(
    "Anket oluştur",
    `<form id="poll-form">${field("question", "Soru")}<label>Seçenekler (her satıra bir seçenek)</label><textarea name="options" required></textarea><button class="primary">Anket gönder</button></form>`,
  );
  $("#poll-form").onsubmit = async (e) => {
    e.preventDefault();
    try {
      const b = new FormData(e.target),
        options = b
          .get("options")
          .split("\n")
          .map((x) => x.trim())
          .filter(Boolean);
      if (options.length < 2 || options.length > 10)
        throw Error("2–10 seçenek gir.");
      await send({ type: "poll", text: b.get("question"), options });
      modal.close();
    } catch (err) {
      notice(err.message, 4000, "error");
    }
  };
}
function eventDialog() {
  dialog(
    "Etkinlik oluştur",
    `<form id="event-form">${field("title", "Etkinlik adı")}${field("date", "Tarih ve saat", "datetime-local")}<button class="primary">Gönder</button></form>`,
  );
  $("#event-form").onsubmit = async (e) => {
    e.preventDefault();
    try {
    const b = new FormData(e.target);
    await send({ type: "event", text: b.get("title"), date: b.get("date") });
    modal.close();
    } catch (err) { notice(err.message, 4000, "error"); }
  };
}
function profile(peer = state.user) {
  if(isLocked())return;
  discardVoice();
  state.page = peer.id === state.user.id ? "profile" : "peer";
  shell(
    peer.id === state.user.id ? "Profilim" : escape(peer.name),
    `<div class="profile-hero"><button data-action="${peer.id === state.user.id ? "profile-photo" : "view-avatar"}">${avatar(peer, true)}</button><h2>${escape(peer.name)}</h2><button class="status" data-action="status">${escape(peer.status === "online" ? "Çevrimiçi" : peer.status === "busy" ? "Meşgul" : "Çevrimdışı")}</button><p>${escape(peer.about || "Güzel sohbetler, güvenli bağlantılar.")}</p></div>${peer.id === state.user.id ? row("edit-profile", "edit", "Profili Düzenle") + row("qr", "qr", "QR Kodum") + row("username", "user", "Kullanıcı Adı", "@" + peer.nick) + row("settings", "settings", "Ayarlar") + row("saved", "bookmark", "Kayıtlı Mesajlar") + row("media", "image", "Medya") + row("about", "info", "Hakkımda") + row("export-key", "key", "Şifreli anahtar yedeğini indir") + row("privacy-policy", "shield", "Gizlilik politikası") : row("mute-peer", "bell", (state.settings.mutedPeers || []).includes(peer.id) ? "Kişinin sesini aç" : "Kişiyi sessize al") + row("block-peer", "shield", "Kişiyi engelle") + row("contact-delete", "trash", "Kişiyi sil")}<div class="themes"><button data-action="dark" class="${state.settings.theme !== "light" ? "active" : ""}">☾ Mürdüm (Koyu)</button><button data-action="light" class="${state.settings.theme === "light" ? "active" : ""}">☀ İnci (Açık)</button></div>`,
  );
}
function settings() {
  if(isLocked())return;
  state.page = "settings";
  shell(
    "Ayarlar",
    row(
      "notifications",
      "bell",
      "Bildirimler",
      "Mesaj bildirimleri kapalı · Çağrı ve sistem ayarları",
    ) +
      row(
        "privacy",
        "shield",
        "Gizlilik ve Güvenlik",
        "Giriş kilidi, görünürlük, aranabilirlik",
      ) +
      row("blocked", "shield", "Engellenen kişiler") +
      row(
        "theme",
        "moon",
        "Tema",
        state.settings.theme === "light" ? "İnci (Açık)" : "Koyu Mor (Mürdüm)",
      ) +
      row(
        "storage",
        "file",
        "Veri ve Depolama",
        "Medya indirme ve bekleyen yüklemeler",
      ) +
      row("language", "info", "Dil", "Türkçe") +
      row(
        "app-about",
        "info",
        "FS Mesajlaşma Hakkında",
        "Sürüm 34.32 · Android",
      ) +
      row("lock", "lock", "Uygulamayı kilitle") +
      row("logout", "user", "Hesaptan çıkış"),
  );
}
async function patchSettings(p) {
  const r = await api("/me", { method: "PATCH", body: p });
  state.user = r.user;
  state.settings = r.settings;
  state.isAdmin = !!r.isAdmin;
  nativeSession();
  applyTheme();
  return r;
}
function nativeSession() {
  if(isLocked())return;
  window.FSNative?.session(
    apiRoot,
    state.token,
    state.settings.available !== false,
    false,
  );
}
function applyTheme() {
  document.body.classList.toggle("light", state.settings.theme === "light");
}
async function savedPage() {
  if(isLocked())return;
  rememberChat();state.page='saved';
  const raw=await api('/saved');if(state.page!=='saved')return;
  state.saved=await Promise.all(raw.map(decode));
  shell('Kayıtlı Mesajlar',`<div class="library-tools"><input id="saved-query" aria-label="Kayıtlı mesajlarda ara" placeholder="Metin, etiket veya dosya ara"><select id="saved-room" aria-label="Sohbete göre filtrele"><option value="">Tüm sohbetler</option>${state.rooms.map(r=>`<option value="${r.id}">${escape(name(r))}</option>`).join('')}</select></div><div id="saved-results"></div>`);
  const draw=()=>{const q=$('#saved-query').value.toLocaleLowerCase('tr'),room=$('#saved-room').value;$('#saved-results').innerHTML=state.saved.filter(m=>!hiddenMessage(m)&&(!room||m.room===room)&&[preview(m.payload),localState.tags?.[m.id]||''].join(' ').toLocaleLowerCase('tr').includes(q)).map(m=>`<div class="note"><div>${escape(preview(m.payload))}</div><small>${new Date(m.created).toLocaleDateString('tr-TR')} · ${escape(localState.tags?.[m.id]||'Etiketsiz')}</small><div class="inline-actions"><button data-action="saved-original" data-id="${m.id}">Mesaja git</button><button data-action="saved-tag" data-id="${m.id}">Etiket</button>${button('unsave','trash','Kayıttan kaldır',`data-id="${m.id}"`)}</div></div>`).join('')||empty('Kayıtlı mesaj bulunamadı','Bir mesaja basılı tutup Kaydet seçeneğini kullan.');};
  $('#saved-query').oninput=draw;$('#saved-room').onchange=draw;draw();
}
let mediaCursor='',mediaLoading=false,mediaHasMore=true,mediaEpoch=0;
async function mediaPage(){
  if(isLocked())return;
 rememberChat();mediaEpoch++;state.page='media';state.media=[];mediaCursor='';mediaLoading=false;mediaHasMore=true;
 shell('Medya',`<nav class="tabs">${['Tümü','Fotoğraflar','Videolar','Dosyalar'].map(x=>`<button data-action="media-filter" data-filter="${x}" class="${state.mediaFilter===x?'active':''}" aria-pressed="${state.mediaFilter===x}">${x}</button>`).join('')}</nav><div class="library-tools"><input id="media-query" aria-label="Dosya adıyla ara" placeholder="Yüklenen medya içinde ara"><label>Tarih<input id="media-date" type="date" aria-label="Medya tarihi"></label><button id="clear-media-date">Tarihi temizle</button></div><p id="media-status" role="status"></p><div class="gallery" id="gallery"></div><button class="secondary" data-action="media-more" id="media-more">Daha eski medya yükle</button><button class="secondary" data-action="download-all">Yüklenen / filtrelenen dosyaları indir</button>`);
 $('#media-date').value=state.mediaDate;$('#media-query').value=state.mediaQuery;
 $('#media-date').oninput=e=>{state.mediaDate=e.target.value;renderGallery()};$('#media-query').oninput=e=>{state.mediaQuery=e.target.value;renderGallery()};$('#clear-media-date').onclick=()=>{state.mediaDate='';$('#media-date').value='';renderGallery()};
 await loadMediaPage();
}
async function loadMediaPage(){
 if(mediaLoading||!mediaHasMore||state.page!=='media')return;mediaLoading=true;const epoch=mediaEpoch,target=$('#gallery'),token=state.token;$('#media-status').textContent='Medya yükleniyor…';$('#media-more').disabled=true;
 try{const raw=await api('/media'+mediaCursor),decoded=await Promise.all(raw.map(decode));if(state.page!=='media'||!target.isConnected||state.token!==token)return;state.media=upsertMessages(state.media,decoded.filter(m=>m.payload.type==='file')).sort((a,b)=>b.created-a.created);mediaHasMore=raw.length===100;if(raw.length){const last=raw.at(-1);mediaCursor='?before='+last.created+'&before_id='+encodeURIComponent(last.id)}renderGallery();}
 catch(error){if(target.isConnected){$('#media-status').textContent='Medya yüklenemedi. Daha eski medya yükle ile yeniden deneyin.';}throw error;}
 finally{if(epoch===mediaEpoch)mediaLoading=false;if(target.isConnected){$('#media-more').disabled=false;$('#media-more').hidden=!mediaHasMore;}}
}
function filteredMedia(){return state.media.filter(m=>!hiddenMessage(m)&&(!state.mediaDate||localDay(m.created)===state.mediaDate)&&(!state.mediaQuery||m.payload.name.toLocaleLowerCase('tr').includes(state.mediaQuery.toLocaleLowerCase('tr')))&&(state.mediaFilter==='Tümü'||state.mediaFilter==='Fotoğraflar'&&m.payload.mime.startsWith('image/')||state.mediaFilter==='Videolar'&&m.payload.mime.startsWith('video/')||state.mediaFilter==='Dosyalar'&&!/^(image|video)\//.test(m.payload.mime)));}
function renderGallery(){const target=$('#gallery');if(!target)return;const items=filteredMedia();target.innerHTML=items.map(m=>`<div class="media-item"><button data-action="download" data-id="${m.id}">${m.payload.mime.startsWith('image/')?`<img loading="lazy" class="thumb ${state.settings.blur!==false?'blurred':''}" data-thumb="${m.id}" alt="${escape(m.payload.name)}">`:icon('file')}<p>${escape(m.payload.name)}</p><small>${new Date(m.created).toLocaleDateString('tr-TR')}</small></button><div class="transfer-state" data-transfer="${m.id}" role="status"></div></div>`).join('')||'<p class="hint">Yüklenen medya içinde eşleşme yok. Daha eski medyayı yükleyebilirsiniz.</p>';$('#media-status').textContent=`${state.media.length} dosya yüklendi · ${items.length} eşleşme`;loadThumbnails();}
function showOutbox(){dialog('Gönderim kuyruğu',`<p class="hint">Çevrimdışıyken gönderilen metinler cihazda şifreli tutulur. İnternet gelince aynı mesaj kimliğiyle gönderilir.</p>${localState.outbox.map(m=>`<div class="note"><p>${escape(m.payload.text)}</p><small>${escape(m.error||'Bağlantı bekleniyor')}</small><button data-action="cancel-outbox" data-id="${m.id}">Kuyruktan kaldır</button></div>`).join('')||'<p>Kuyruk boş.</p>'}<button class="primary" data-action="retry-outbox">Yeniden dene</button>`);}
function chatSearch(){const room=state.room.id;dialog('Sohbette ara',`<input id="chat-query" placeholder="Mesaj veya dosya adı" aria-label="Sohbette aranacak metin"><label>Tarih<input id="chat-date" type="date"></label><button class="secondary" data-action="search-history">Daha eski geçmişte ara</button><p id="chat-search-status" role="status"></p><div id="chat-search-results"></div>`);const draw=()=>{if(!$('#chat-query')||state.room?.id!==room)return;const items=searchMessages(state.messages.filter(m=>!hiddenMessage(m)),$('#chat-query').value,$('#chat-date').value);$('#chat-search-status').textContent=`Yüklenen ${state.messages.length} mesaj · ${items.length} eşleşme`;$('#chat-search-results').innerHTML=items.slice(-100).reverse().map(m=>`<button class="row" data-action="jump-message" data-id="${m.id}">${escape(preview(m.payload).slice(0,160))}<small>${new Date(m.created).toLocaleDateString('tr-TR')}</small></button>`).join('')||'<p>Eşleşme bulunamadı.</p>';};$('#chat-query').oninput=draw;$('#chat-date').oninput=draw;draw();}
async function searchHistory(){const room=state.room,route=state.routeVersion,button=modal.querySelector('[data-action="search-history"]');if(!button||button.disabled)return;button.disabled=true;try{for(let batch=0;batch<10;batch++){const first=state.messages.filter(m=>!m.callRecord&&!m.pending).sort((a,b)=>a.created-b.created||a.id.localeCompare(b.id))[0];if(!first)break;const rows=await api(`/rooms/${room.id}/messages?before=${first.created}&before_id=${encodeURIComponent(first.id)}`);if(state.room?.id!==room.id||state.routeVersion!==route||!modal.open||!$('#chat-query'))break;state.messages=upsertMessages(state.messages,await Promise.all(rows.map(decode)));state.hasOlder=rows.length===80;renderMessages();$('#chat-query').oninput();if(rows.length<80)break;}}finally{button.disabled=false;}}
function restoreAudio(){for(const audio of document.querySelectorAll('audio[data-audio]')){const saved=localState.playback[audio.dataset.audio];audio.preload='none';if(saved?.rate)audio.playbackRate=saved.rate;if(audio._fsPlaybackBound)continue;audio._fsPlaybackBound=true;audio.addEventListener('loadedmetadata',()=>{const position=localState.playback[audio.dataset.audio];if(position?.time&&Number.isFinite(audio.duration))audio.currentTime=Math.min(position.time,Math.max(0,audio.duration-.1));});audio.addEventListener('timeupdate',()=>{if(!audio.seeking){localState.playback[audio.dataset.audio]={time:audio.currentTime,rate:audio.playbackRate};}});audio.addEventListener('pause',()=>{rememberPlayback();persistLocal()});audio.addEventListener('ended',()=>{localState.playback[audio.dataset.audio]={time:0,rate:audio.playbackRate};persistLocal()});}}

let reconnectTimer = null;
let callSignalQueue = Promise.resolve();
function queuedCallSignal(b) {
  const epoch=access.epoch;
  if(!access.valid(epoch))return Promise.resolve();
  callSignalQueue = callSignalQueue.then(() => {if(access.valid(epoch))return callSignal(b)}).catch(async err => { if(!access.valid(epoch)||!callEventMatches(state.call,b))return;console.warn("call", err.message); await endCall(); notice("Görüşme kurulamadı. Mikrofon/kamera izinlerini ve bağlantıyı kontrol edin."); });
  return callSignalQueue;
}
let pendingRoomRefresh=null,pendingMessageRefresh=null;
function scheduleRefresh(){if(!pendingRoomRefresh)pendingRoomRefresh=new Promise((resolve,reject)=>setTimeout(()=>{pendingRoomRefresh=null;refreshRooms().then(resolve,reject)},70));return pendingRoomRefresh}
function scheduleMessageRefresh(){if(!pendingMessageRefresh)pendingMessageRefresh=new Promise((resolve,reject)=>setTimeout(()=>{pendingMessageRefresh=null;loadMessages().then(resolve,reject)},70));return pendingMessageRefresh}
function removeDeletedMessage(id){
 deletedInSession.add(id);if(deletedInSession.size>20000)deletedInSession.delete(deletedInSession.values().next().value);
 if(state.openMediaId===id&&modal.open)modal.close();state.media=state.media.filter(m=>m.id!==id);state.saved=(state.saved||[]).filter(m=>m.id!==id);state.cache.delete(id);state.messages=state.messages.filter(m=>m.id!==id);state.selected.delete(id);
 if(state.reply?.id===id){state.reply=null;renderReply();rememberChat();}
 for(const room of Object.keys(localState.pages))localState.pages[room]=localState.pages[room].filter(m=>m.id!==id);
 for(const draft of Object.values(localState.drafts))if(draft.reply===id)draft.reply=null;
 for(const cache of [thumbnailUrls,audioUrls])if(cache.has(id)){URL.revokeObjectURL(cache.get(id));cache.delete(id);}
 persistLocal();
}
function updateChatPeer(){
 if(isLocked()||state.page!=="chat"||!state.room)return;
 typing.update();
 const peer=state.room.members.find(m=>m.id!==state.user.id);
 if(!peer)return;
 const status=document.querySelector('.chat-head [data-action="status"]'),photo=document.querySelector('.chat-head [data-action="peer-profile"]');
 if(status)status.textContent=peer.status==="online"?"🟢 Çevrimiçi":peer.status==="busy"?"Meşgul":"Çevrimdışı";
 if(photo)photo.innerHTML=avatar(peer);
}
function connect() {
  if(isLocked())return;
  clearTimeout(state.reconnectTimer);
  if (state.socket && [WebSocket.OPEN, WebSocket.CONNECTING].includes(state.socket.readyState)) return;
  if (state.socket && [0,1].includes(state.socket.readyState)) return;
  clearTimeout(reconnectTimer);
  state.socket?.close();
  if (!state.token) return;
  const url = new URL(apiRoot);
  url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
  url.pathname = url.pathname.replace(/\/$/, "") + "/api/socket";
  const ws = new WebSocket(url);
  state.socket = ws;
  const epoch=access.epoch;
  ws.onopen = () => {if(access.valid(epoch)&&state.socket===ws)ws.send(JSON.stringify({ token: state.token, callIds:true }));else ws.close();};
  ws.onmessage = async (e) => {
    if(!access.valid(epoch)||state.socket!==ws)return;
    try {
      const b = JSON.parse(e.data);
      if(b.type==="session-revoked"){await actions("logout");notice("Hesabına başka bir kurulumdan giriş yapıldı. Bu cihazdaki oturum kapatıldı.",5000,"info");return;}
      if(b.type===TYPING_EVENT){typing.receive(b);return;}
      if(b.type===EMOJI_EVENT){await receiveEmojiInteraction(b,epoch);return;}
      if(b.type==="read"){state.messages=state.messages.map(m=>m.room===b.room&&m.created<=b.ts?{...m,read_by:[...new Set([...(m.read_by||[]),b.from])]}:m);if(state.page==="chat"&&state.room?.id===b.room){storePage(b.room,state.messages);renderMessages();}return;}
      if (
        b.type === "message" ||
        b.type === "rooms" ||
        b.type === "read" ||
        b.type === "profile"
      ) {
        if (b.deleted&&b.id) removeDeletedMessage(b.id);
        await scheduleRefresh();
        if(!access.valid(epoch)||state.socket!==ws)return;
        if (b.type === "profile" && state.page === "chat") updateChatPeer();
        if (
          state.page === "chat" &&
          !state.rooms.some((r) => r.id === state.room?.id)
        ) {
          state.cache.clear();
          home();
          return;
        }
        if (state.page === "home") homeList();
        if (state.page === "chat" && b.room === state.room.id)
          await scheduleMessageRefresh();
      } else if (b.type === "connected") {
        presenceAuthenticated = true;state.typingEnabled=Array.isArray(b.features)&&b.features.includes(TYPING_EVENT);state.callIds=Array.isArray(b.features)&&b.features.includes("call-id-v1");state.presenceLease=Array.isArray(b.features)&&b.features.includes("presence-lease-v1");state.emojiRealtime=Array.isArray(b.features)&&b.features.includes(EMOJI_EVENT);state.directDelete=Array.isArray(b.features)&&b.features.includes("direct-delete-everyone-v1");state.messageCacheCheck=Array.isArray(b.features)&&b.features.includes("message-cache-check-v1");syncPresence(true);
        scheduleRefresh().then(()=>{
          if(!access.valid(epoch)||state.socket!==ws)return;
          if(state.page==="chat"&&state.room){
            if(!state.rooms.some(r=>r.id===state.room.id)){home();return;}
            updateChatPeer();return scheduleMessageRefresh();
          }else if(state.page==="home")homeList();
        }).catch(error=>console.warn("reconnect refresh",error.message));
        const current = await api("/calls/current");
        if(!access.valid(epoch)||state.socket!==ws)return;
        if (current?.incoming && !state.call) await queuedCallSignal(current);
        flushOutbox().catch(error=>console.warn("outbox",error.message));
      } else if (b.from !== state.user.id) await queuedCallSignal(b);
    } catch (err) {
      console.error("event", err.message);
    }
  };
  ws.onclose = () => {
    if (state.socket !== ws) return;
    state.socket = null;state.typingEnabled=false;typing.reset();state.callIds=false;state.emojiRealtime=false;state.directDelete=false;state.messageCacheCheck=false;
    presenceAuthenticated=false;state.presenceLease=false; syncPresence();
    if (state.token && !state.locked) reconnectTimer = setTimeout(connect, 2000);
  };
}
function signal(b) {
  if (state.socket?.readyState !== 1)
    throw Error("Bağlantı kesik. Yeniden bağlanmayı bekleyin.");
  const id=b.callId??state.call?.callId;
  state.socket.send(JSON.stringify(id?{...b,callId:id}:b));
}
async function startCall(video) {
  if(isLocked())return;
  if(!presenceAuthenticated)throw Error("Bağlantı kuruluyor. Biraz sonra tekrar deneyin.");
  const room = state.room;
  if (!room) throw Error("Önce bir sohbet açın.");
  if (room.kind !== "direct")
    throw Error("Bu sürümde aramalar birebir sohbetlerde kullanılabilir.");
  if (state.call) throw Error("Zaten bir görüşmedesin.");
  state.call = {
    room,
    callId:state.callIds?crypto.randomUUID().replaceAll("-",""):null,
    video,
    phase: "Aranıyor…",
    incoming: false,
    started: null,
    peer: room.members.find((x) => x.id !== state.user.id),
  };
  try { signal({ type: "call", room: room.id, video }); } catch(err) { state.call = null; throw err; }
  showCall();
}
async function callSignal(b) {
  if(isLocked())return;
  if (b.type === "call") {
    if(state.call&&b.callId&&state.call.callId===b.callId)return;
    if (state.settings.available === false) { signal({type:"call-rejected",room:b.room,callId:b.callId}); return; }
    if (state.call) {
      signal({ type: "call-rejected", room: b.room,callId:b.callId });
      return;
    }
    const room = state.rooms.find((r) => r.id === b.room);
    if (!room) return;
    state.call = {
      room,
      callId:b.callId||null,
      video: b.video,
      phase: "Gelen Arama",
      incoming: true,
      peer: room.members.find((x) => x.id === b.from),
    };
    showCall();
    return;
  }
  const call = state.call;
  if (!callEventMatches(call,b)) return;
  if (b.type === "call-rejected" || b.type === "hangup") {
    await endCall(false);
    return;
  }
  if (b.type === "answer") {
    if (!call.pc) await setupPeer();
    if (state.call !== call || !call.pc) return;
    await call.pc.setRemoteDescription(b.description);
    await flushIce(call);
    return;
  }
  if (b.type === "offer") {
    if (b.description?.sdp?.includes("m=video")) call.video = true;
    await setupPeer();
    if (state.call !== call || !call.pc) return;
    await call.pc.setRemoteDescription(b.description);
    await flushIce(call);
    if(state.call!==call)return;
    const answer = await call.pc.createAnswer();
    if(state.call!==call)return;
    await call.pc.setLocalDescription(answer);
    if(state.call!==call)return;
    signal({ type: "answer", room: call.room.id, callId:call.callId, description: answer });
    if(state.page==="call")showCall();
    return;
  }
  if (b.type === "ice") {
    if (call.pc?.remoteDescription) await call.pc.addIceCandidate(b.candidate);
    else (call.pendingIce ??= []).push(b.candidate);
  }
  if (b.type === "accepted") {
    await setupPeer();
    if (state.call !== call || !call.pc) return;
    const offer = await call.pc.createOffer();
    if(state.call!==call)return;
    await call.pc.setLocalDescription(offer);
    if(state.call!==call)return;
    signal({ type: "offer", room: call.room.id, callId:call.callId, description: offer });
  }
}
async function flushIce(c) {
  if(state.call!==c||!c.pc)return;
  const pending=c.pendingIce||[];c.pendingIce=[];
  for(const candidate of pending){if(state.call!==c)return;await c.pc.addIceCandidate(candidate);}
}
async function setupPeer() {
  const c = state.call;
  if (!c) throw Error("Arama sona erdi.");
  if (c.pc) return;
  if(c.setupPromise)return c.setupPromise;
  c.setupPromise=initializePeer(c);
  try{return await c.setupPromise}finally{c.setupPromise=null}
}
async function initializePeer(c){
  const config = await api("/config");
  if (state.call !== c) return;
  c.stream = await navigator.mediaDevices.getUserMedia({
    audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
    video: c.video
      ? { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: {ideal: 30, max: 30} }
      : false,
  });
  if (state.call !== c) { c.stream.getTracks().forEach(t => t.stop()); return; }
  c.pc = new RTCPeerConnection({ iceServers: config.iceServers });
  c.stream.getTracks().forEach((t) => {if(t.kind==="video"&&"contentHint" in t)t.contentHint="motion";c.pc.addTrack(t, c.stream)});
  window.FSNative?.activeCall(true, c.video);
  c.pc.onicecandidate = (e) => {
    if (e.candidate && state.call === c && state.socket?.readyState === 1)
      signal({ type: "ice", room: c.room.id, candidate: e.candidate.toJSON() });
  };
  c.pc.ontrack = (e) => {
    if(state.call!==c)return;
    c.remote=e.streams[0]||c.remote||new MediaStream();
    if(!c.remote.getTracks().includes(e.track))c.remote.addTrack(e.track);
    if(state.page==="call"&&c.video&&e.track.kind==="video"&&$("#remote-video")?.tagName!=="VIDEO")showCall();else attachVideo();
  };
  c.statsTimer=setInterval(async()=>{if(state.call!==c||!c.pc?.getStats)return;try{const stats=await c.pc.getStats();if(state.call!==c)return;let weak=false;stats.forEach(report=>{if(report.type==='candidate-pair'&&report.state==='succeeded'&&report.currentRoundTripTime>.5)weak=true;if(report.type==='inbound-rtp'&&report.packetsReceived>50&&report.packetsLost/(report.packetsReceived+report.packetsLost)>.08)weak=true});c.networkLabel=weak?'Ağ zayıf':c.pc.connectionState==='connected'?'Bağlantı kuruldu':'Yeniden bağlanıyor…';if($('#call-network'))$('#call-network').textContent=c.networkLabel;}catch{}},3000);
  c.pc.onconnectionstatechange = () => {
    if(state.call!==c)return;
    const status=c.pc.connectionState;
    if(status==='connected'){c.phase='Bağlandı';c.started??=Date.now();c.networkLabel='Bağlantı kuruldu';if(state.page==="call")showCall();}
    else if(status==='connecting'||status==='disconnected'){c.phase=status==='disconnected'?'Yeniden bağlanıyor…':'Bağlanıyor…';c.networkLabel=c.phase;if(state.page==="call"){const n=$("#call-network");if(n)n.textContent=c.networkLabel;}}
    else if(status==='failed'){notice('Görüşme bağlantısı kurulamadı veya kesildi. Yeniden arayabilirsiniz.',4000,'error');endCall().catch(error=>notice(error.message,4000,'error'));}
  };
  attachVideo();
}
function attachVideo() {
  if(isLocked())return;
  const c=state.call;if(!c)return;
  const mini=$("#call-mini"),remote=$("#remote-video"),local=$("#local-video");
  function attach(el,stream,muted=false){if(!el||!stream)return;if(el.srcObject!==stream)el.srcObject=stream;el.muted=muted;el.play?.().catch(()=>{});}
  if(state.page!=='call'&&!mini&&c.remote){let audio=$('#fs-background-call');if(!audio){audio=document.createElement('audio');audio.id='fs-background-call';audio.autoplay=true;app.append(audio)}attach(audio,c.remote)}
  attach(mini,c.remote);attach(remote,c.swapped?c.stream:c.remote,!!c.swapped);attach(local,c.swapped?c.remote:c.stream,!c.swapped);
}
function showCall() {
  if(isLocked())return;
  discardVoice();
  const c = state.call;
  if (!c) return;
  state.page = "call";
  typing.reset();
  let audio = {bluetooth:false};
  try { audio = JSON.parse(window.FSNative?.audioState?.() || "{}"); } catch {}
  const controls = c.incoming
    ? [
        ["reject-call", "phone", "Reddet", "red"],
        ["accept-call", "phone", "Yanıtla", "green"],
      ]
    : [
        ["mute", "mic", c.stream?.getAudioTracks().some(t=>!t.enabled)?"Mikrofon Kapalı":"Mikrofon Açık", c.stream?.getAudioTracks().some(t=>!t.enabled)?"on":""],
        ["camera-toggle", "video", c.stream?.getVideoTracks().some(t=>t.enabled)?"Kamera Açık":"Kamera Kapalı", c.stream?.getVideoTracks().some(t=>t.enabled)?"on":""],
        ...(audio.bluetooth ? [["bluetooth", "bluetooth", "Bluetooth", audio.route === "bluetooth" ? "on" : ""]] : []),
        ["speaker", "speaker", "Hoparlör", audio.route==="speaker"?"on":""],
        ["end-call", "phone", "Kapat", "red"],
      ];
  app.innerHTML = `<section class="call fs-premium ${c.video?"fs-video-call":"fs-audio-call"} ${c.incoming?"fs-incoming":""} ${c.remote&&c.video?"fs-video-live":""}">${c.remote && c.video ? '<video class="remote" id="remote-video" autoplay playsinline></video>' : '<audio id="remote-video" autoplay></audio>'}<header style="width:100%;z-index:3;background:none;border:0">${button("call-back", "back", "Sohbete dön")}<h1>${c.incoming?"Gelen Arama":"Fs Mesajlaşma"}<small>${c.video ? "Görüntülü" : "Sesli"} Arama</small></h1>${button("verification", "shield", "Arama doğrulama")}</header><div class="person">${c.remote && c.video ? "" : avatar(c.peer, true)}<h2>${escape(c.peer?.name||"Görüşme")}</h2>${c.verified?'<span class="verified-chip">✓ Doğrulandı</span>':""}<p id="call-timer" class="timer">${escape(c.phase)}</p><small id="call-network" role="status">${escape(c.networkLabel||c.phase)}</small></div>${c.video ? '<video class="local" id="local-video" autoplay muted playsinline></video>' : ""}<div class="controls">${controls.map(([a, i, l, cl]) => `<div class="control"><button data-action="${a}" class="${cl}" aria-label="${l}">${icon(i)}</button><span>${l}</span></div>`).join("")}</div>${c.incoming ? '<button class="secondary" data-action="reply-call">Mesajla Yanıtla</button>' : ""}</section>`;
  attachVideo();
  const remoteView = $("#remote-video");
  clearTimeout(state.controlsTimer);
  if(remoteView?.tagName === "VIDEO" && !c.incoming){
    applyCallControls(c);
    remoteView.onclick=()=>{Object.assign(c,callControlState(c,Date.now(),true));applyCallControls(c);};
  }
  clearInterval(state.callTimer);
  state.callTimer = setInterval(() => {
    const el = $("#call-timer");
    if (el && c.started) {
      const s = Math.floor((Date.now() - c.started) / 1000);
      el.textContent =
        String(Math.floor(s / 60)).padStart(2, "0") +
        ":" +
        String(s % 60).padStart(2, "0");
    }
  }, 1000);
  const local = $("#local-video");
  if (local) {
    let drag=null, moved=false;
    local.onclick=()=>{if(moved)return;const remote=$("#remote-video");if(remote?.tagName==="VIDEO"&&c.remote&&c.stream){c.swapped=!c.swapped;attachVideo()}};
    if(c.pipPosition){local.style.left=c.pipPosition.left;local.style.top=c.pipPosition.top;local.style.right="auto";local.style.bottom="auto";}
    local.onpointerdown = (e) => {
      moved=false;drag = {
        x: e.clientX,
        y: e.clientY,
        left: local.offsetLeft,
        top: local.offsetTop,
      };
      local.setPointerCapture(e.pointerId);
    };
    local.onpointermove = (e) => {
      if (!drag) return;
      if(Math.hypot(e.clientX-drag.x,e.clientY-drag.y)<6&&!moved)return;moved=true;
      local.style.left =
        Math.max(
          0,
          Math.min(
            app.clientWidth - local.clientWidth,
            drag.left + e.clientX - drag.x,
          ),
        ) + "px";
      local.style.top =
        Math.max(
          0,
          Math.min(
            app.clientHeight - local.clientHeight,
            drag.top + e.clientY - drag.y,
          ),
        ) + "px";
      local.style.right = "auto";
      local.style.bottom = "auto";
    };
    local.onpointerup = ()=>{drag=null;if(moved)c.pipPosition={left:local.style.left,top:local.style.top}};
    local.onpointercancel=()=>{drag=null;moved=true;};
  }
}
async function endCall(notify = true) {
  const c = state.call;
  if (!c) return;
  clearTimeout(state.controlsTimer);
  if (notify) {
    try {
      signal({ type: "hangup", room: c.room.id });
    } catch {}
  }
  state.call = null;
  if(c.pc) {c.pc.onconnectionstatechange = null;c.pc.onicecandidate = null;c.pc.ontrack = null;}
  clearInterval(c.statsTimer);
  c.stream?.getTracks().forEach((t) => t.stop());
  c.pc?.close();
  window.FSNative?.activeCall(false, false);
  clearInterval(state.callTimer);
  state.call = null;
  await openRoom(c.room.id);
}
async function verification() {
  const c = state.call;
  if (!c?.pc?.localDescription || !c.pc.remoteDescription)
    throw Error("Doğrulama için görüşmenin bağlanmasını bekle.");
  const fingerprints = [c.pc.localDescription.sdp, c.pc.remoteDescription.sdp]
    .map((s) => s.match(/a=fingerprint:sha-256 ([^\r\n]+)/)?.[1])
    .sort();
  if (fingerprints.some((x) => !x))
    throw Error("Görüşme parmak izi alınamadı.");
  const digest = new Uint8Array(
    await crypto.subtle.digest(
      "SHA-256",
      new TextEncoder().encode(fingerprints.join("|")),
    ),
  );
  const symbols = [
    "🌿",
    "🦁",
    "🚀",
    "💜",
    "🌻",
    "🦋",
    "🌙",
    "⭐",
    "🐳",
    "🍒",
    "🎈",
    "🍀",
    "🎵",
    "🔑",
    "🌈",
    "🐬",
  ];
  dialog(
    "Arama Doğrulama",
    `<p class="hint">Aşağıdaki dört emojiyi karşı tarafla sesli karşılaştırın. Tamamı aynıysa doğrulayın.</p><div class="verify-emojis">${Array.from({ length: 4 }, (_, i) => `<span>${emojiItems.length ? emojiItems[((digest[i * 2] << 8) | digest[i * 2 + 1]) % emojiItems.length].emoji : symbols[digest[i] % 16]}</span>`).join("")}</div><button class="primary" data-action="verify-call">Dördü de aynı · Doğrula</button>`,
  );
}
async function actions(a, el) {
  if(isLocked())return;
  // PIN unlock alone is not a logged-in account. Limit actions while on the sign-in form.
  if((state.page==="auth"||!state.token||!state.user)&&!["auth-toggle","privacy-policy","import-key","close-dialog"].includes(a))return;
  switch (a) {
    case 'chat-filter':state.chatFilter=el.dataset.filter;home();break;
    case 'chat-options':dialog('Sohbet seçenekleri',`<button class="row" data-action="pin-chat">${localState.preferences.pinned.includes(state.room.id)?'Sabitlemeyi kaldır':'Sohbeti sabitle'}</button><button class="row" data-action="archive-chat">${localState.preferences.archived.includes(state.room.id)?'Arşivden çıkar':'Sohbeti arşivle'}</button>`);break;
    case 'pin-chat':localState.preferences.pinned=toggleId(localState.preferences.pinned,state.room.id);await persistLocal(true);modal.close();break;
    case 'archive-chat':localState.preferences.archived=toggleId(localState.preferences.archived,state.room.id);await persistLocal(true);modal.close();home();break;
    case 'chat-search':chatSearch();break;
    case 'search-history':await searchHistory();break;
    case 'jump-message':{const id=el.dataset.id;modal.close();await jumpReply(id);break;}
    case 'outbox':showOutbox();break;
    case 'retry-outbox':await flushOutbox();showOutbox();break;
    case 'cancel-outbox':localState.outbox=localState.outbox.filter(x=>x.id!==el.dataset.id);state.messages=state.messages.filter(x=>x.id!==el.dataset.id);await persistLocal(true);showOutbox();if(state.page==='chat')renderMessages();break;
    case 'newest':jumpToLatest();break;
    case 'audio-speed':{const previous=localState.playback[el.dataset.id]||{};const speeds=[1,1.5,2];previous.rate=speeds[(speeds.indexOf(previous.rate||1)+1)%speeds.length];localState.playback[el.dataset.id]=previous;const audio=document.querySelector(`[data-audio="${el.dataset.id}"]`);if(audio)audio.playbackRate=previous.rate;el.textContent=previous.rate+'×';persistLocal();break;}
    case 'voice-lock':voiceLocked=true;voiceStatus({phase:voiceController?.session?.recorder?.state==='paused'?'paused':'recording',elapsed:voiceController?.session?voiceController.elapsed(voiceController.session):0});break;
    case 'voice-pause':voiceLocked=true;voiceController?.pause();break;
    case 'voice-resume':voiceController?.resume();break;
    case 'voice-finish':voiceController?.stop();break;
    case 'media-more':await loadMediaPage();break;
    case 'saved-original':{const record=state.saved.find(m=>m.id===el.dataset.id);if(record){await openRoom(record.room);if(!virtualMessages?.jump(record.id)){state.messages=upsertMessages(state.messages,[record]);renderMessages();virtualMessages?.jump(record.id)}}break;}
    case 'saved-tag':{const id=el.dataset.id;dialog('Etiket',`<form id="saved-tag-form">${field('tag','Etiket','text',localState.tags?.[id]||'',false)}<button class="primary">Kaydet</button></form>`);$('#saved-tag-form').onsubmit=async event=>{event.preventDefault();localState.tags??={};localState.tags[id]=new FormData(event.target).get('tag').trim().slice(0,40);await persistLocal(true);modal.close();await savedPage()};break;}

    case "export-key": {
      const packet = await vault("recovery");
      if (!packet) throw Error("Anahtar yedeği bulunamadı.");
      if (window.FSNative?.beginFile) {
        await nativeFile(
          new Blob([JSON.stringify(packet)], { type: "application/json" }),
          "FS-kisisel-anahtar-yedegi.json",
          "application/json",
          "save",
        );
        break;
      }
      const url = URL.createObjectURL(
        new Blob([JSON.stringify(packet)], { type: "application/json" }),
      );
      const link = document.createElement("a");
      link.href = url;
      link.download = "FS-kisisel-anahtar-yedegi.json";
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      break;
    }
    case "import-key":
      importKeyDialog();
      break;
    case "admin":
      modal.close();
      await adminPage();
      break;
    case "admin-room":
      await adminRoom(el.dataset.id);
      break;
    case "admin-delete":
      await adminDelete(el.dataset.kind, el.dataset.id);
      break;
    case "toggle-selection":
      if(!eligibleMessage(el.dataset.id))break;
      state.selected.has(el.dataset.id)
        ? state.selected.delete(el.dataset.id)
        : state.selected.add(el.dataset.id);
      renderMessages();
      break;
    case "close-dialog":
      modal.close();
      break;
    case "older": {
      const first = state.messages.find((m) => !m.callRecord&&!m.pending);
      if (!first) break;
      const room = state.room, route = state.routeVersion;
      const target = $("#messages"),
        height = target.scrollHeight,
        top = target.scrollTop;
      const rows = await api(
        "/rooms/" + room.id + "/messages?before=" + first.created + "&before_id=" + encodeURIComponent(first.id),
      );
      const previous = await Promise.all(rows.map(decode));
      if (state.page !== "chat" || state.room?.id !== room.id || state.routeVersion !== route || !target.isConnected) break;
      const anchor=virtualMessages?.anchor();
      state.hasOlder = rows.length === 80;
      const existing = new Set(state.messages.map((m) => m.id));
      state.messages = [
        ...previous.filter((m) => !existing.has(m.id)&&!deletedInSession.has(m.id)),
        ...state.messages,
      ];
      renderMessages();
      if(anchor)virtualMessages?.jump(anchor.id);else target.scrollTop = top + target.scrollHeight - height;
      break;
    }
    case "home":
      home();
      break;
    case "back":
      if (
        state.page === "settings" ||
        state.page === "saved" ||
        state.page === "media"
      )
        profile();
      else home();
      break;
    case "auth-toggle":
      authPage(el.dataset.register === "1");
      break;
    case "tab":
      state.tab = el.dataset.tab;
      home();
      break;
    case "open-room":
      await openRoom(el.dataset.id);
      break;
    case "new-chat":
      await newChat();
      break;
    case "start-chat":
      await startChat(el.dataset.id);
      break;
    case "contact":
      dialog(
        "Kişi",
        row("start-chat", "edit", "Sohbet başlat") +
          `<button class="row danger" data-action="delete-contact" data-id="${el.dataset.id}">Kişiyi sil</button>`,
      );
      modal.querySelector('[data-action="start-chat"]').dataset.id =
        el.dataset.id;
      break;
    case "delete-contact":
      await api("/contacts/" + el.dataset.id, { method: "DELETE" });
      modal.close();
      await homeList();
      notice("Kişi silinenler listesine taşındı.", 2000, "success");
      break;
    case "deleted": {
      const all = await api("/contacts");
      dialog(
        "Silinen kişiler",
        all
          .filter((c) => c.deleted)
          .map(
            (c) =>
              `<div class="card">${escape(c.name)}<button data-action="restore-contact" data-id="${c.id}">Geri al</button><button class="danger" data-action="purge-contact" data-id="${c.id}">Tamamen sil</button></div>`,
          )
          .join("") || '<p class="hint">Liste boş.</p>',
      );
      break;
    }
    case "restore-contact":
      await api("/contacts", { method: "POST", body: { peer: el.dataset.id } });
      modal.close();
      notice("Kişi geri alındı.", 2000, "success");
      break;
    case "purge-contact":
      await api("/contacts/" + el.dataset.id + "?permanent=1", {
        method: "DELETE",
      });
      modal.close();
      break;
    case "search":
      dialog("Sohbet ara", field("search-text", "İsim"));
      $("#search-text").oninput = (e) => {state.chatQuery=e.target.value;homeList(e.target.value).catch(error=>notice(error.message,4000,"error"))};
      break;
    case "menu":
      dialog(
        "FS Mesajlaşma",
        row("profile", "user", "Profilim") +
          row("settings", "settings", "Ayarlar") +
          row("saved", "bookmark", "Kayıtlı Mesajlar") +
          row("media", "image", "Medya") +
          row("group", "plus", "Grup oluştur") +
          (state.isAdmin ? row("admin", "shield", "Yönetim Paneli") : "") +
          row("lock", "lock", "Kilitle"),
      );
      break;
    case "profile":
      modal.close();
      profile();
      break;
    case "peer-profile":
      profile(state.room.members.find((x) => x.id !== state.user.id));
      break;
    case "settings":
      modal.close();
      settings();
      break;
    case "lock":
      modal.close();
      if (!state.call) state.socket?.close();
      showLock();
      break;
    case "logout":
      rememberChat();await persistLocal(true).catch(()=>{});
      if (state.call) await endCall().catch(() => {});
      discardVoice();
      for (const [watch, record] of liveLocations) {navigator.geolocation.clearWatch(watch);clearTimeout(record.timer)}
      liveLocations.clear();state.nativeLive=false;
      window.FSNative?.logout();
      try{await api("/logout", {method:"POST"})}catch{notice("Cihazdaki oturum kapatıldı; sunucuya ulaşılamadı.")}
      clearTimeout(localWrite);localData=null;
      presenceAuthenticated=false;presenceSent=null;approvedMaps.clear();
      state.token=null;state.user=null;state.isAdmin=false;state.room=null;state.reply=null;state.reactionTarget=null;state.keys.clear();state.contacts=[];state.selected.clear();state.settings={};
      state.messages=[];state.rooms=[];state.media=[];state.saved=[];state.cache.clear();
      for(const cache of [audioUrls,thumbnailUrls]){for(const url of cache.values())URL.revokeObjectURL(url);cache.clear()}
      await vault("session",null);state.socket?.close();state.socket=null;clearTimeout(reconnectTimer);showLock();
      break;
    case "available": {
      if(el.disabled) break;
      el.disabled=true;
      try {
        await patchSettings({ available: state.settings.available === false });
        const available=state.settings.available !== false;
        document.querySelectorAll('[data-action="available"]').forEach(button=>{button.classList.toggle("off",!available);button.setAttribute('aria-pressed',String(available));button.setAttribute('aria-label',available?'Müsaitim; değiştirmek için dokunun':'Müsait değilim; değiştirmek için dokunun')});
        notice(available ? "Müsaitim" : "Müsait değilim", 2000, available ? "success" : "error", true);
      } finally {el.disabled=false;}
      break;
    }
    case "status":
      dialog(
        "Durumun",
        `<div class="card">${["online", "offline", "busy"].map((v, i) => `<button class="row" data-action="set-status" data-value="${v}">${["Çevrimiçi", "Çevrimdışı", "Meşgul"][i]}</button>`).join("")}</div>`,
      );
      break;
    case "set-status":
      setPresencePreference(el.dataset.value);
      await syncPresence(true);
      modal.close();
      break;
    case "view-avatar": {
      const peer = state.room?.members.find((p) => p.id !== state.user.id);
      if (peer?.avatar)
        dialog(
          peer.name,
          `<img src="${escape(peer.avatar)}" alt="Profil fotoğrafı" style="width:100%">`,
        );
      break;
    }
    case "profile-photo":
      await profilePhoto();
      break;
    case "edit-profile":
      dialog(
        "Profilini düzenle",
        `<form id="profile-form">${field("name", "Ad", "text", state.user.name)}${field("about", "Hakkımda", "text", state.user.about || "", false)}<button class="primary">Kaydet</button></form>`,
      );
      $("#profile-form").onsubmit = async (e) => {
        e.preventDefault();
        const submit=e.target.querySelector("button.primary");if(submit.disabled)return;submit.disabled=true;
        try {
        await patchSettings(Object.fromEntries(new FormData(e.target)));
        modal.close();
        profile();
        notice("Profil kaydedildi.", 2000, "success");
        } catch(err) {notice("Kaydedilemedi: "+err.message,4000,"error");}
        finally {submit.disabled=false;}
      };
      break;
    case "dark":
    case "light":
      await patchSettings({ theme: a === "dark" ? "dark" : "light" });
      profile();
      notice("Tema kaydedildi.", 2000, "success");
      break;
    case "theme":
      dialog(
        "Tema",
        `<button class="row" data-action="dark">☾ Mürdüm (Koyu)</button><button class="row" data-action="light">☀ İnci (Açık)</button>`,
      );
      break;
    case "android-notifications":
      window.FSNative?.notificationSettings?.();
      break;
    case "notifications":
    case "privacy":
      dialog(
        a === "privacy" ? "Gizlilik ve Güvenlik" : "Bildirimler",
        `<form id="prefs-form"><label class="toggle">Aranabilir<input name="available" type="checkbox" ${state.settings.available !== false ? "checked" : ""}></label><label class="toggle">Medya önizlemesini bulanıklaştır<input name="blur" type="checkbox" ${state.settings.blur !== false ? "checked" : ""}></label><p class="hint">Mesaj ve kişi bildirimleri kapalıdır. Yalnız aranabilirlik açıkken gelen çağrı gösterilir. Android, sürekli arka plan bağlantısı ve görüşme için sistem bildirimi gerektirebilir.</p><button type="button" data-action="android-notifications">Android bildirim ayarları</button><button class="primary">Kaydet</button></form>`,
      );
      $("#prefs-form").onsubmit = async (e) => {
        e.preventDefault();
        const submit=e.target.querySelector("button.primary");if(submit.disabled)return;submit.disabled=true;
        try {
        const f = e.target;
        await patchSettings({
          available: f.available.checked,
          blur: f.blur.checked,
          notifications: false,
        });
        modal.close();
        notice("Ayarlar kaydedildi.", 2000, "success");
        } catch(err) {notice("Kaydedilemedi: "+err.message,4000,"error");}
        finally {submit.disabled=false;}
      };
      break;
    case "saved":
      modal.close();
      await savedPage();
      break;
    case "unsave":
      await api("/saved/" + el.dataset.id, { method: "DELETE" });
      await savedPage();
      break;
    case "media":
      modal.close();
      await mediaPage();
      break;
    case "media-filter":
      state.mediaFilter = el.dataset.filter;
      document.querySelectorAll('[data-action="media-filter"]').forEach(b=>{const selected=b.dataset.filter===state.mediaFilter;b.classList.toggle("active",selected);b.setAttribute("aria-pressed",selected);});
      renderGallery();
      break;
    case "download-all":
      for (const m of filteredMedia()) await download(m, true);
      break;
    case "attach":
      attach();
      break;
    case "recent-photos":
      window.FSNative?.recentPhotos();
      break;
    case "send-recent":
      await sendRecentPhoto(el.dataset.id);
      break;
    case "gallery":
    case "camera":
    case "document":
      await chooseFiles(a);
      break;
    case "emoji":
      state.reactionTarget=null;emojiPicker();
      break;
    case "choose-emoji":
      if (state.reactionTarget) {
        const target = state.reactionTarget;
        state.reactionTarget = null;
        modal.close();
        await reactToMessage(target,el.dataset.emoji);
        break;
      }
      $("#message-text").value += el.dataset.emoji;typing.input($("#message-text").value);syncComposer();rememberChat();
      modal.close();
      $("#message-text").focus({preventScroll:true});
      break;
    case "message-reaction": await reactToMessage(el.dataset.id,el.dataset.emoji);break;
    case "context-react": modal.close();await reactToMessage(el.dataset.id,el.dataset.emoji);break;
    case "context-more": if(!eligibleMessage(el.dataset.id))break;modal.close();state.reactionTarget=el.dataset.id;emojiPicker();break;
    case "context-op": {const id=el.dataset.id,op=el.dataset.op;modal.close();if(!eligibleMessage(id))break;if(op==="Yanıtla"){beginReply(id);break;}if(op==="Alıntıla"){chooseQuote(id);break;}state.selected=new Set([id]);if(op==="Seç")renderMessages();else await selection(op);break;}
    case "jump-reply": await jumpReply(el.dataset.id);break;
    case "return-reply": returnReplyPosition();break;
    case "selection":
      await selection(el.dataset.op);
      break;
    case "cancel-reply":
      state.reply = null;
      $("#reply").innerHTML = "";rememberChat();
      break;
    case "play-audio":
      await playAudio(el.dataset.id);
      break;
    case "download":
    case "save-file": {
      const m = [
        ...state.messages,
        ...state.media,
        ...(state.saved || []),
      ].find((x) => x.id === el.dataset.id);
      if (m) await download(m, a === "save-file");
      break;
    }
    case "review-recording":
      reviewRecording();
      break;
    case "send-recording":
      await sendRecording();
      break;
    case "discard-recording":
      discardVoice();
      modal.close();
      break;
    case "stop-location":
      await stopLocations();
      break;
    case "location":
      locationDialog();
      break;
    case "map": {
      const p = state.messages.find((m) => m.id === el.dataset.id)?.payload;
      const urls=p&&mapUrls(p.lat,p.lng);if(urls) openExternal(urls.external);break;
    }
    case "map-preview": {
      const p = state.messages.find((m) => m.id === el.dataset.id)?.payload;
      if(!p||!mapUrls(p.lat,p.lng))break;
      // Explicit permission: remote map provider receives location coordinates.
      dialog("Harita önizlemesi", `<p>Harita yüklenirken konum koordinatları OpenStreetMap ile paylaşılır.</p><button class="primary" data-action="map-consent" data-id="${escape(el.dataset.id)}">Bu haritayı göster</button><button class="secondary" data-action="map-consent-all" data-id="${escape(el.dataset.id)}">Bu cihazda haritaları her zaman göster</button>`);break;
    }
    case "map-consent":
    case "map-consent-all": {
      if(a==="map-consent-all"){try{localStorage.setItem('fs-map-preview:'+state.user?.id,'yes')}catch{}}
      approvedMaps.add(el.dataset.id);modal.close();renderMessages();break;
    }
    case "open-link": openExternal(el.dataset.url);break;
    case "poll":
      pollDialog();
      break;
    case "vote": {
      const m = state.messages.find((x) => x.id === el.dataset.id);
      await send({
        type: "vote",
        text: `${m.payload.text}: ${m.payload.options[Number(el.dataset.choice)]}`,
        poll: m.id,
        choice: Number(el.dataset.choice),
      });
      break;
    }
    case "event":
      eventDialog();
      break;
    case "invite": {
      const text = `FS Mesajlaşma'ya katıl. Kullanıcı adım: @${state.user.nick}. Davet kodu: 0032`;
      if (navigator.share) await navigator.share({ text });
      else {
        await navigator.clipboard.writeText(text);
        notice("Davet metni kopyalandı.");
      }
      break;
    }
    case "share-contact": {
      const c = await api("/contacts");
      dialog(
        "Kişi paylaş",
        c
          .filter((p) => !p.deleted)
          .map(
            (p) =>
              `<button class="row" data-action="send-contact" data-id="${p.id}" data-nick="${escape(p.nick)}" data-name="${escape(p.name)}">${escape(p.name)}</button>`,
          )
          .join(""),
      );
      break;
    }
    case "send-contact":
      await send({
        type: "contact",
        text: el.dataset.name + " · @" + el.dataset.nick,
        nick: el.dataset.nick,
      });
      modal.close();
      break;
    case "group": {
      const c = await api("/contacts");
      dialog(
        "Grup oluştur",
        `<form id="group-form">${field("title", "Grup adı")}${c
          .filter((p) => !p.deleted)
          .map(
            (p) =>
              `<label class="toggle">${escape(p.name)}<input type="checkbox" name="member" value="${p.id}"></label>`,
          )
          .join("")}<button class="primary">Oluştur</button></form>`,
      );
      $("#group-form").onsubmit = async (e) => {
        e.preventDefault();
        try {
        const f = new FormData(e.target),
          members = f.getAll("member");
        if (members.length < 2) throw Error("En az iki arkadaşını seç.");
        const r = await api("/rooms", {
          method: "POST",
          body: { title: f.get("title"), members },
        });
        modal.close();
        await refreshRooms();
        await openRoom(r.id);
        } catch (err) { notice(err.message, 4000, "error"); }
      };
      break;
    }
    case "storage":
      dialog(
        "Veri ve Depolama",
        `<p class="hint">Dosya sınırı 50 MB. Dosyalar yüklenmeden önce bu cihazda şifrelenir.</p><button class="row" data-action="resume">Kesilen yüklemeye devam et</button><button class="row danger" data-action="cancel-upload">Bekleyen yüklemeyi iptal et</button>`,
      );
      break;
    case "cancel-upload": {
      if (uploadBusy) throw Error("Yükleme sürerken iptal edilemez; tamamlanmasını bekleyin.");
      const pending = await vault("pending-upload");
      if (pending) {
        await api("/uploads/" + pending.id, { method: "DELETE" });
        await vault("pending-upload", null);
      }
      modal.close();
      notice("Bekleyen yükleme iptal edildi.");
      break;
    }
    case "resume":
      await resumeUpload();
      modal.close();
      notice("Bekleyen yükleme kontrol edildi.");
      break;
    case "language":
      dialog("Dil", "<p>Türkçe</p>");
      break;
    case "app-about":
      dialog(
        "FS Mesajlaşma",
        '<p>Sürüm 34.32</p><p class="hint">Geliştirme sürümü. Yayınlanmadı. Android cihaz testleri ve arka plan bildirim entegrasyonu tamamlanmadan üretim sürümü değildir.</p>',
      );
      break;
    case "privacy-policy":
      dialog(
        "Gizlilik politikası",
        `<div class="policy">${escape(privacyPolicy)}</div>`,
      );
      break;
    case "about":
    case "username":
      dialog(
        a === "username" ? "Kullanıcı Adı" : "Hakkımda",
        `<p>${escape(a === "username" ? "@" + state.user.nick : state.user.about)}</p>`,
      );
      break;
    case "invite-contact":
      if (window.FSNative?.inviteContact)
        window.FSNative.inviteContact(
          `FS Mesajlaşma'ya katıl. Kullanıcı adım: @${state.user.nick}. Davet kodu: 0032`,
        );
      else if (navigator.share)
        await navigator.share({
          text: `FS Mesajlaşma kullanıcı adım: @${state.user.nick}. Davet kodu: 0032`,
        });
      else notice("Rehber daveti Android uygulamasında kullanılabilir.");
      break;
    case "block-peer": {
      const peer = state.room?.members.find((m) => m.id !== state.user.id);
      if (peer) {
        await api("/blocks", { method: "POST", body: { peer: peer.id } });
        home();
        notice("Kişi engellendi.", 2000, "success");
      }
      break;
    }
    case "blocked": {
      const peers = await api("/blocks");
      dialog(
        "Engellenen kişiler",
        peers
          .map(
            (p) =>
              `<button class="row" data-action="unblock" data-id="${p.id}">${escape(p.name)} · Engeli kaldır</button>`,
          )
          .join("") || '<p class="hint">Engellenen kişi yok.</p>',
      );
      break;
    }
    case "unblock":
      await api("/blocks/" + el.dataset.id, { method: "DELETE" });
      modal.close();
      notice("Kişinin engeli kaldırıldı.",2000,"success");
      break;
    case "mute-peer": {
      const peer=state.room?.members.find(m=>m.id!==state.user.id); if(!peer)break;
      const muted=new Set(state.settings.mutedPeers||[]); if(muted.has(peer.id))muted.delete(peer.id);else muted.add(peer.id);
      await patchSettings({mutedPeers:[...muted],notifications:false}); profile(peer); notice(muted.has(peer.id)?"Kişi sessize alındı.":"Kişinin sessiz ayarı kaldırıldı.",2000,"success"); break;
    }
    case "contact-delete": {
      const peer = state.room?.members.find((m) => m.id !== state.user.id);
      if (peer) await api("/contacts/" + peer.id, { method: "DELETE" });
      home();
      break;
    }
    case "qr":
      dialog(
        "QR Kodum",
        `<canvas id="qr-canvas" aria-label="Davet QR kodu"></canvas><p>@${escape(state.user.nick)}</p><button class="primary" data-action="invite">Arkadaşına Davet Gönder</button>`,
      );
      await QRCode.toCanvas(
        $("#qr-canvas"),
        JSON.stringify({ app: "FS", nick: state.user.nick, invite: "0032" }),
        { width: 260, margin: 2, color: { dark: "#301639", light: "#ffffff" } },
      );
      break;
    case "audio-call":
      await startCall(false);
      break;
    case "video-call":
      await startCall(true);
      break;
    case "accept-call":
      if (!state.call || state.call.accepting) break;
      const acceptedCall = state.call;
      state.call.accepting = true;
      state.call.phase = "Bağlanıyor…";
      try { await setupPeer(); } catch(err) { await endCall(); throw err; }
      if (state.call !== acceptedCall) break;
      state.call.incoming = false;
      signal({ type: "accepted", room: state.call.room.id });
      showCall();
      break;
    case "reject-call":
      signal({ type: "call-rejected", room: state.call.room.id });
      await endCall(false);
      break;
    case "end-call":
      await endCall();
      break;
    case "call-back":
      await openRoom(state.call.room.id);
      break;
    case "return-call":
      showCall();
      break;
    case "mute": {
      const tracks=state.call?.stream?.getAudioTracks()||[];
      if(!tracks.length)throw Error("Görüşmenin bağlanmasını bekle.");
      const enabled=tracks.some(t=>t.enabled);tracks.forEach(t=>t.enabled=!enabled);
      el.classList.toggle("on",enabled);el.setAttribute("aria-pressed",String(enabled));el.nextElementSibling.textContent=enabled?"Mikrofon Kapalı":"Mikrofon Açık";break;
    }
    case "camera-toggle":
      if (!state.call?.pc || !state.call?.stream)
        throw Error("Görüşmenin bağlanmasını bekle.");
      if (state.call && !state.call.stream?.getVideoTracks().length) {
        const c = state.call,
          stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: "user" },
          });
        if(state.call!==c){stream.getTracks().forEach(t=>t.stop());break;}
        for (const track of stream.getVideoTracks()) {
          c.stream.addTrack(track);
          c.pc.addTrack(track, c.stream);
        }
        c.video = true;
        window.FSNative?.activeCall(true, true);
        const description = await c.pc.createOffer();
        if(state.call!==c)break;
        await c.pc.setLocalDescription(description);
        if(state.call!==c)break;
        signal({ type: "offer", room: c.room.id, callId:c.callId, description });
        showCall();
        break;
      }
      {const tracks=state.call.stream.getVideoTracks();const enabled=tracks.some(t=>t.enabled);tracks.forEach(t=>t.enabled=!enabled);el.classList.toggle("on",!enabled);el.setAttribute("aria-pressed",String(!enabled));el.nextElementSibling.textContent=enabled?"Kamera Kapalı":"Kamera Açık";}
      break;
    case "speaker":
    case "bluetooth":
      if (window.FSNative?.audioRoute) {window.FSNative.audioRoute(a);setTimeout(()=>{if(state.page!=="call"||!el.isConnected)return;try{const route=JSON.parse(window.FSNative.audioState?.()||"{}").route;document.querySelectorAll('[data-action="speaker"],[data-action="bluetooth"]').forEach(b=>b.classList.toggle("on",b.dataset.action===route))}catch{}},350);}
      else notice("Ses çıkışını cihazın ses menüsünden seç.");
      break;
    case "verification":
      await verification();
      break;
    case "verify-call":
      state.call.verified = true;
      modal.close();
      notice("Görüşme emojilerini doğruladın.");if(state.page==="call")showCall();
      break;
    case "reply-call": {
      const room = state.call.room;
      await endCall();
      await openRoom(room.id);
      $("#message-text").value = "Şu an yanıtlayamıyorum, sana yazacağım.";syncComposer();rememberChat();
      break;
    }

  }
}
document.addEventListener("click", async (e) => {
  if(isLocked())return;
  const el = e.target.closest("[data-action]");
  if (!el) return;
  if(el.dataset.action==="open-link"){e.preventDefault();if(state.selected.size)return;}
  try {
    await actions(el.dataset.action, el);
  } catch (err) {
    if (err.name !== "AbortError") notice(err.message, 4000, "error");
  }
});
modal.addEventListener("click", (e) => {
  if (e.target === modal) modal.close();
});
$("#notice").onclick = () => ($("#notice").style.display = "none");

function linkText(text){return urlParts(text).map(p=>p.url?`<a class="message-link" href="${escape(p.url)}" data-action="open-link" data-url="${escape(p.url)}" target="_blank" rel="noopener noreferrer">${escape(p.text)}</a>`:escape(p.text)).join('');}
function openExternal(value){let u;try{u=new URL(value)}catch{return}if(!['http:','https:'].includes(u.protocol)||u.username||u.password)return;window.open(u.href,'_blank','noopener,noreferrer');}
const approvedMaps=new Set();
function locationCard(m){const p=m.payload,urls=mapUrls(p.lat,p.lng);if(!urls)return 'Geçersiz konum';let allowed=approvedMaps.has(m.id);try{allowed||=localStorage.getItem('fs-map-preview:'+state.user?.id)==='yes'}catch{};
return `<div class="location-card"><strong>📍 ${escape(p.text||'Konum')}</strong>${allowed?`<iframe class="location-map" title="Konum haritası" src="${escape(urls.embed)}" loading="lazy" referrerpolicy="no-referrer" sandbox="allow-scripts allow-same-origin"></iframe><small>© OpenStreetMap contributors</small>`:`<button class="location-map-placeholder" data-action="map-preview" data-id="${escape(m.id)}">🗺️ Haritayı göster</button>`}<button class="location-open" data-action="map" data-id="${escape(m.id)}">Haritada aç ↗</button></div>`;}
function applyCallControls(c){const el=$('.call .controls');if(!el||state.call!==c||state.page!=='call')return;clearTimeout(state.controlsTimer);Object.assign(c,callControlState(c,Date.now()));el.classList.toggle('hidden-controls',!!c.controlsHidden);el.inert=!!c.controlsHidden;el.setAttribute('aria-hidden',String(!!c.controlsHidden));if(!c.controlsHidden)state.controlsTimer=setTimeout(()=>{if(state.call===c&&state.page==='call'){c.controlsHidden=true;applyCallControls(c)}},Math.max(0,c.controlsUntil-Date.now()));}
let viewportFrame=0, previousChatHeight=0, previousMessageHeight=0, viewportArea=null, viewportObserver=null;
function syncChatViewport(){
 const area=$('#messages');
 if(state.page!=='chat'||!area){viewportObserver?.disconnect();viewportArea=null;app.style.removeProperty('--chat-viewport-height');app.style.removeProperty('--chat-viewport-top');previousChatHeight=previousMessageHeight=0;app.classList.remove('chat-compact-viewport');return;}
 const v=window.visualViewport;const bottom=nearLatest(area);
 // Fixed positioning is relative to the layout viewport; offsetTop is the visible viewport's displacement within it.
 const height=Math.max(1,Math.floor(v?.height>0?v.height:window.innerHeight));const top=Math.max(0,v?.offsetTop||0);
 if(viewportArea!==area){viewportObserver?.disconnect();viewportArea=area;previousChatHeight=previousMessageHeight=0;if(typeof ResizeObserver==='function'){viewportObserver??=new ResizeObserver(scheduleChatViewport);viewportObserver.observe(area);}}
 app.style.setProperty('--chat-viewport-height',height+'px');app.style.setProperty('--chat-viewport-top',top+'px');app.classList.toggle('chat-compact-viewport',height<420);
 const messageHeight=area.clientHeight;
 if(previousChatHeight!==height||previousMessageHeight!==messageHeight){previousChatHeight=height;previousMessageHeight=messageHeight;if(bottom)area.scrollTop=area.scrollHeight;virtualMessages?.draw(!!bottom);}
 placeChatPip();updateLatestButton();
}
function scheduleChatViewport(){if(viewportFrame)return;viewportFrame=requestAnimationFrame(()=>{viewportFrame=0;syncChatViewport()});}
function pipBounds(){const area=$('#messages');if(!area)return null;const a=area.getBoundingClientRect(),b=app.getBoundingClientRect();return {left:a.left-b.left+4,top:a.top-b.top+4,width:Math.max(0,a.width-8),height:Math.max(0,a.height-8)};}
function placeChatPip(){const el=$('#call-mini'),c=state.call,b=pipBounds();if(!el||!c||!b)return;el.style.maxWidth=Math.max(0,b.width)+'px';el.style.maxHeight=Math.max(0,b.height)+'px';const pos=pipPosition(b,{width:el.offsetWidth,height:el.offsetHeight},c.chatPipRatio||{x:1,y:0});el.style.left=pos.left+'px';el.style.top=pos.top+'px';el.style.right='auto';el.style.bottom='auto';}
function bindChatPip(){const el=$('#call-mini'),c=state.call;if(!el||!c)return;let drag=null;el.onpointerdown=e=>{if(e.button!==0)return;drag={id:e.pointerId,x:e.clientX,y:e.clientY,left:el.offsetLeft,top:el.offsetTop,moved:false};el.setPointerCapture(e.pointerId);};el.onpointermove=e=>{if(!drag||drag.id!==e.pointerId)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(!drag.moved&&Math.hypot(dx,dy)<6)return;drag.moved=true;const b=pipBounds();if(!b)return;const x=Math.max(0,b.width-el.offsetWidth),y=Math.max(0,b.height-el.offsetHeight);c.chatPipRatio={x:x?clamp((drag.left+dx-b.left)/x,0,1):c.chatPipRatio?.x??1,y:y?clamp((drag.top+dy-b.top)/y,0,1):c.chatPipRatio?.y??0};placeChatPip();};el.onpointerup=e=>{if(!drag||drag.id!==e.pointerId)return;const moved=drag.moved;drag=null;if(!moved)showCall();};el.onpointercancel=el.onlostpointercapture=()=>{drag=null;};el.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();showCall();}};placeChatPip();}
window.visualViewport?.addEventListener('resize',scheduleChatViewport);window.visualViewport?.addEventListener('scroll',scheduleChatViewport);window.addEventListener('resize',scheduleChatViewport);document.addEventListener('focusin',scheduleChatViewport);document.addEventListener('focusout',scheduleChatViewport);
// Publish lifecycle via existing authenticated /me PATCH. Server-side expiry is additionally required for process kill/network loss.
document.addEventListener('visibilitychange',()=>{if(document.hidden)typing.reset()});window.addEventListener('pagehide',()=>typing.reset());window.addEventListener('offline',()=>typing.reset());
let presenceAuthenticated=false,presenceSent=null,presenceWriting=false,presenceQueued=null;
function presencePreference(){try{return localStorage.getItem('fs-presence:'+state.user?.id)||'online'}catch{return 'online'}}
function setPresencePreference(value){try{localStorage.setItem('fs-presence:'+state.user?.id,value)}catch{}}
async function syncPresence(force=false,leaving=false){
 if(!state.token||!state.user)return;
 const token=state.token,foreground=!leaving&&!document.hidden&&!state.locked&&state.page!=='auth'&&state.page!=='setup';
 if(foreground&&!presenceAuthenticated&&!presenceSent)return;
 const wanted=effectiveStatus(foreground,presenceAuthenticated&&navigator.onLine!==false,presencePreference());
 if(presenceWriting){presenceQueued={force,leaving};return;}
 if(!force&&presenceSent?.token===token&&presenceSent?.status===wanted)return;
 if(!apiRoot||navigator.onLine===false)return;
 presenceWriting=true;
 try{const res=await fetch(apiRoot+'/api/me',{method:'PATCH',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({status:wanted}),keepalive:true});if(!res.ok)throw Error('Durum güncellenemedi');if(state.token===token){presenceSent={token,status:wanted};if(state.user)state.user.status=wanted;}}catch{if(force&&!leaving&&!document.hidden)notice('Durum sunucuya iletilemedi. Bağlantı geldiğinde yeniden denenecek.');}finally{presenceWriting=false;if(presenceQueued){const next=presenceQueued;presenceQueued=null;queueMicrotask(()=>syncPresence(next.force,next.leaving))}}
}
document.addEventListener('visibilitychange',()=>{if(document.hidden)clearEmojiEffect();else{connect();scheduleChatViewport()}syncPresence();});window.addEventListener('pagehide',()=>syncPresence(true,true));window.addEventListener('online',()=>syncPresence());window.addEventListener('offline',()=>{presenceSent=null;});setInterval(()=>{if(!document.hidden&&state.token&&!state.locked){syncPresence(state.presenceLease===true);}},15000);

async function boot() {
  emojiItems = await fetch("emojis.json").then((r) => r.json());
  emojiIndex = buildEmojiIndex(emojiItems);
  state.identity = await identity();
  const session = await vault("session");
  if (session) {
    state.token = session.token;
    state.user = session.user;
  }
  const pinRecord=await vault("pin");
  if(!pinRecord && session){app.textContent="Kilit kaydı eksik. Güvenlik nedeniyle oturum açılmadı.";return;}
  bootReady=true;
  if (!pinRecord) {
    state.page = "setup";
    app.innerHTML = `<section class="lock"><div class="brand">Fs</div><h1>Hesap Kilidi Oluştur</h1><p class="hint">Bu cihaza en az 6 rakamlı bir PIN belirle. PIN’i hesap makinesine yazıp = tuşuna bas. Mevcut hesabın varsa ardından telefon numaran ve hesap şifrenle giriş yap; yeniden üye olman gerekmez.</p><form id="pin-form">${field("pin", "Hesap makinesi PIN’i", "password")}${field("confirm-pin", "PIN tekrar", "password")}<button class="primary">Şifre oluştur</button><div class="error" role="alert"></div></form></section>`;
    for(const input of app.querySelectorAll('#pin-form input')){input.inputMode="numeric";input.autocomplete="new-password";}
    $("#pin-form").onsubmit = async (e) => {
      e.preventDefault();
      const submit=e.target.querySelector("button.primary");if(submit.disabled)return;submit.disabled=true;
      try {
        const f = new FormData(e.target);
        if (f.get("pin") !== f.get("confirm-pin"))
          throw Error("Şifreler aynı olmalı.");
        if(state.page!=="setup"||!isLocked()||await vault("pin"))return;
        await setPin(f.get("pin"));
        showLock();
      } catch (err) {
        e.target.querySelector(".error").textContent = err.message;
      } finally {submit.disabled=false;}
    };
  } else showLock();
}
// A pending calculator check cannot complete after the app is hidden or a native window is opened.
function cancelPendingEntry(){if(bootReady&&(state.page==="lock"||state.page==="auth"))showLock();}
document.addEventListener("visibilitychange",()=>{if(document.hidden&&state.page==="lock")cancelPendingEntry();});
window.addEventListener("pagehide",cancelPendingEntry);
window.addEventListener("popstate",()=>{if(bootReady&&state.page!=="setup")showLock()});
window.addEventListener("pageshow",e=>{if(e.persisted&&bootReady&&state.page!=="setup")showLock()});
boot().catch((err) => {
  app.textContent = "Başlatılamadı: " + err.message;
});
window.FSApp = {
  back() {
    if(isLocked()||state.page==="lock"||state.page==="setup"){
      if(state.page==="lock"){const popup=app.querySelector(".calc-popup");if(popup)popup.remove();else if(calculatorView)showLock();}
      return;
    }
    if (modal.open) modal.close();
    else if (state.page === "call")
      actions("call-back").catch((err) => notice(err.message,4000,"error"));
    else if (state.page === "chat" && state.selected.size){state.selected.clear();renderMessages();}
    else if (state.page === "chat") home();
    else if (state.page === "home") showLock();
    else if (state.page === "auth") showLock();
    else if (state.page === "setup") return;
    else home();
  },
};

async function profilePhoto() {
  const input = $("#files");
  input.accept = "image/jpeg,image/png,image/webp";
  input.multiple = false;
  input.removeAttribute("capture");
  input.onchange = async () => {
    try {
      const file = input.files[0];
      if (!file) return;
      if (
        !/^image\/(jpeg|png|webp)$/.test(file.type) ||
        file.size > 10 * 1048576
      )
        throw Error("10 MB altında bir fotoğraf seç.");
      const bitmap = await createImageBitmap(file);
      const canvas = document.createElement("canvas");
      canvas.width = canvas.height = 256;
      const ctx = canvas.getContext("2d");
      const side = Math.min(bitmap.width, bitmap.height);
      ctx.drawImage(
        bitmap,
        (bitmap.width - side) / 2,
        (bitmap.height - side) / 2,
        side,
        side,
        0,
        0,
        256,
        256,
      );
      bitmap.close();
      await patchSettings({ avatar: canvas.toDataURL("image/jpeg", 0.85) });
      profile();
      notice("Profil fotoğrafı kaydedildi.", 2000, "success");
    } catch (err) {
      notice(err.message, 4000, "error");
    } finally {
      input.multiple = true;
      input.value = "";
    }
  };
  input.click();
}

function importKeyDialog() {
  dialog(
    "Kişisel anahtar yedeği",
    `<form id="key-form"><label>Şifreli anahtar dosyası</label><input id="key-file" type="file" accept="application/json" required>${field("key-password", "Yedek oluşturulurken kullanılan hesap şifresi", "password")}<button class="primary">İçe aktar</button><p class="error"></p></form>`,
  );
  $("#key-form").onsubmit = async (e) => {
    e.preventDefault();
    try {
      const file = $("#key-file").files[0];
      if (file.size > 20000) throw Error("Geçersiz anahtar dosyası.");
      const packet = JSON.parse(await file.text());
      state.identity = await restoreRecovery(
        packet,
        new FormData(e.target).get("key-password"),
      );
      state.keys.clear();
      modal.close();
      notice("Anahtar içe aktarıldı. Şimdi giriş yapabilirsin.",3000,"success");
    } catch (err) {
      e.target.querySelector(".error").textContent =
        "Dosya veya yedek şifresi doğrulanamadı.";
    }
  };
}

function callLabel(c) {
  const seconds =
    c.connected && c.ended
      ? Math.max(0, Math.floor((c.ended - c.connected) / 1000))
      : 0;
  return `${c.video ? "Görüntülü" : "Sesli"} arama · ${c.status === "missed" ? "Cevapsız" : c.status === "rejected" ? "Reddedildi" : c.status === "ringing" ? "Aranıyor" : seconds ? Math.floor(seconds / 60) + ":" + String(seconds % 60).padStart(2, "0") : "Sona erdi"}`;
}

async function nativeFile(blob, name, mime, action) {
  if(isLocked())return;
  const id = window.FSNative.beginFile(name, mime, action);
  if (!id) throw Error("Dosya işlemi başlatılamadı.");
  try {
    for (let offset = 0; offset < blob.size; offset += 49152) {
      const bytes = new Uint8Array(
        await blob.slice(offset, offset + 49152).arrayBuffer(),
      );
      if (!window.FSNative.appendFile(id, b64(bytes)))
        throw Error("Dosya yazılamadı.");
    }
    window.FSNative.finishFile(id);
  } catch (err) {
    window.FSNative.cancelFile(id);
    throw err;
  }
}

async function adminPage() {
  if(isLocked())return;
  state.page = "admin";
  const [users, rooms] = await Promise.all([
    api("/admin/inventory/users"),
    api("/admin/inventory/rooms"),
  ]);
  state.adminRooms = rooms;
  shell(
    "Yönetim Paneli",
    `<p class="security-note">Yönetici erişimi gizlilik politikasında açıklanır. İçerikler yönetici cihazında çözülür; sunucuda açık metin tutulmaz.</p><h3>Sohbetler (${rooms.length})</h3>${rooms.map((r) => `<div class="card"><button class="row" data-action="admin-room" data-id="${r.id}">${escape(r.title || r.members.map((u) => u.name).join(" · "))}</button><button class="danger" data-action="admin-delete" data-kind="rooms" data-id="${r.id}">Sohbeti sil</button></div>`).join("")}<h3>Kullanıcılar (${users.length})</h3>${users.map((u) => `<div class="card">${escape(u.name)} · @${escape(u.nick)}<p class="hint">${escape(u.phone)}</p>${u.id !== state.user.id ? `<button class="danger" data-action="admin-delete" data-kind="users" data-id="${u.id}">Kullanıcıyı sil</button>` : ""}</div>`).join("")}`,
  );
}
async function adminRoom(id) {
  if(isLocked())return;
  state.page = "admin-room";
  const room = state.adminRooms.find((r) => r.id === id);
  if (!room) throw Error("Sohbet bulunamadı.");
  if (!state.rooms.some((r) => r.id === id)) state.rooms.push(room);
  state.adminMessages = await Promise.all(
    (await api("/admin/rooms/" + id + "/messages")).map(decode),
  );
  state.media = state.adminMessages.filter((m) => m.payload.type === "file");
  shell(
    "Sohbet Denetimi",
    state.adminMessages
      .map(
        (m) =>
          `<div class="card"><p class="hint">${escape(room.members.find((u) => u.id === m.sender)?.name || m.sender)} · ${new Date(m.created).toLocaleString("tr-TR")}</p><p>${escape(preview(m.payload))}</p>${m.payload.type === "file" ? `<button class="secondary" data-action="download" data-id="${m.id}">Dosyayı aç</button>` : ""}<button class="danger" data-action="admin-delete" data-kind="messages" data-id="${m.id}">Sil</button></div>`,
      )
      .join("") || empty("Mesaj yok", "Bu sohbette kayıt bulunmuyor."),
  );
}
async function adminDelete(kind, id) {
  dialog(
    "Kalıcı silme",
    `<p>Seçilen kayıt kalıcı silinecek. Bu işlem geri alınamaz.</p><button id="admin-confirm" class="primary">Kalıcı sil</button>`,
  );
  $("#admin-confirm").onclick = async () => {
    try {
      await api("/admin/" + kind + "/" + id, { method: "DELETE" });
      modal.close();
      await adminPage();
    } catch (err) {
      notice(err.message, 4000, "error");
    }
  };
}

async function thumbnail(file) {
  if (!/^image\/(jpeg|png|webp)$/.test(file.type)) return undefined;
  try {
    const bitmap = await createImageBitmap(file);
    const size = Math.min(1, 160 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(bitmap.width * size));
    canvas.height = Math.max(1, Math.round(bitmap.height * size));
    canvas
      .getContext("2d")
      .drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    bitmap.close();
    const blob = await new Promise((r) => canvas.toBlob(r, "image/jpeg", 0.55));
    if (!blob || blob.size > 16000) return undefined;
    const encrypted = await encryptFile(blob);
    return {
      data: b64(encrypted.data),
      key: encrypted.key,
      iv: encrypted.iv,
      mime: "image/jpeg",
    };
  } catch {
    return undefined;
  }
}
const thumbnailUrls = new Map();
let thumbnailObserver=null;
function loadThumbnails() {
  thumbnailObserver?.disconnect();
  const indexed=new Map([...state.messages,...state.media].map(m=>[m.id,m]));
  if(typeof IntersectionObserver==="function")thumbnailObserver=new IntersectionObserver(entries=>{for(const e of entries)if(e.isIntersecting){thumbnailObserver.unobserve(e.target);e.target._fsShowThumb?.();}},{rootMargin:"80px"});
  for (const img of document.querySelectorAll("[data-thumb]")) {
    const m = indexed.get(img.dataset.thumb);
    const meta = m?.payload.thumbnail;
    if (!meta) {
      img.removeAttribute("data-thumb");
      continue;
    }
    const show = async () => {
      if (!img.isConnected) return;
      try {
        let url = thumbnailUrls.get(m.id);
        if (!url) {
          const blob = await decryptFile(unb64(meta.data), meta);
          url = URL.createObjectURL(blob);
          thumbnailUrls.set(m.id, url);
          while (thumbnailUrls.size > 40) {
            const oldest = thumbnailUrls.keys().next().value;
            URL.revokeObjectURL(thumbnailUrls.get(oldest));
            thumbnailUrls.delete(oldest);
          }
        }
        if(!img.isConnected)return;
        img.src = url;img.removeAttribute("data-thumb");
      } catch {
        img.alt = "Önizleme açılamadı";
      }
    };
    img._fsShowThumb=show;
    if(thumbnailObserver)thumbnailObserver.observe(img);else show();
  }
}

function keyedMessages(target, markup) {
  const template = document.createElement("template");
  template.innerHTML = markup;
  const key = (node) =>
    node.dataset.key || node.dataset.message || node.dataset.action || "day:" + node.dataset.day;
  const old = new Map([...target.children].map((node) => [key(node), node]));
  let cursor = target.firstElementChild;
  for (const fresh of [...template.content.children]) {
    const id = key(fresh),
      existing = old.get(id),
      signature = fresh.outerHTML;
    let node;
    if (existing && existing._fsMarkup === signature) node = existing;
    else {
      node = fresh;
      node._fsMarkup = signature;
      if (existing) {
        for(const audio of existing.querySelectorAll("audio[data-audio]")){const replacement=node.querySelector(`audio[data-audio="${audio.dataset.audio}"]`);if(replacement)replacement.replaceWith(audio);}
        existing.replaceWith(node);
        if (cursor === existing) cursor = node;
      }
    }
    old.delete(id);
    if (node !== cursor) target.insertBefore(node, cursor);
    cursor = node.nextElementSibling;
  }
  for (const node of old.values()) node.remove();
}
const audioUrls = new Map();
async function playAudio(id) {
  if(isLocked())return;
  const m = state.messages.find((m) => m.id === id);
  if (!m) return;
  let url = audioUrls.get(id);
  if (!url) {
    const blob = await decryptFile(await fileBytes(m), m.payload);
    transferStatus(m.id,'Hazır');
    url = URL.createObjectURL(blob);
    audioUrls.set(id, url);
  }
  const audio = document.querySelector(`[data-audio="${id}"]`);
  if(!audio?.isConnected)return;
  audio.src = url;
  restoreAudio();
  await audio.play();
  while(audioUrls.size>32){const oldest=audioUrls.keys().next().value;if(oldest===id)break;URL.revokeObjectURL(audioUrls.get(oldest));audioUrls.delete(oldest);}
}
document.addEventListener('play',event=>{const audio=event.target;if(audio?.matches?.('audio[data-audio]'))document.querySelectorAll('audio[data-audio]').forEach(other=>{if(other!==audio)other.pause()})},true);
function emojiEffect(target){if(isLocked()||state.page!=="chat"||state.selected.size)return;const m=eligibleMessage(target.dataset.message);if(!m||m.payload.type!=="text"||!isSingleEmoji(m.payload.text))return;animateEmoji(target,m.payload.text,{reducedMotion:!!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches});sendEmojiInteraction(m).catch(error=>console.warn("emoji relay",error.message));}
async function sendEmojiInteraction(m){
 const room=state.room,epoch=access.epoch,ws=state.socket,route=state.routeVersion;if(!state.emojiRealtime||ws?.readyState!==1||!room||document.hidden||Date.now()-lastEmojiTap<100)return;lastEmojiTap=Date.now();
 const payload={type:EMOJI_EVENT,id:crypto.randomUUID().replaceAll("-",""),target:m.id,emoji:m.payload.text};if(!validInteraction(payload))return;const packets=Object.create(null);
 await Promise.all(room.members.filter(x=>x.id!==state.user.id).map(async peer=>{packets[peer.id]=await seal(await keyFor(peer),payload,room.id);}));
 if(!access.valid(epoch)||state.routeVersion!==route||state.room?.id!==room.id||state.page!=="chat"||document.hidden||state.socket!==ws||ws.readyState!==1)return;
 ws.send(JSON.stringify({type:EMOJI_EVENT,id:payload.id,room:room.id,target:m.id,envelopes:packets}));
}
async function receiveEmojiInteraction(b,epoch){
 const room=state.room,route=state.routeVersion;if(!state.emojiRealtime||!access.valid(epoch)||state.page!=="chat"||document.hidden||room?.id!==b.room||b.from===state.user?.id||!b.envelope)return;
 const peer=room.members.find(m=>m.id===b.from);if(!peer)return;
 const payload=await open(await keyFor(peer),b.envelope,room.id);if(!access.valid(epoch)||state.routeVersion!==route||state.room?.id!==room.id||state.page!=="chat"||document.hidden||state.selected.size)return;
 if(payload.id!==b.id||payload.target!==b.target||!matchesInteraction(payload,eligibleMessage(b.target),room.id)||!emojiWindow.accept(b.from+"-"+b.id,b.ts))return;
 const node=document.querySelector(`[data-message="${CSS.escape(b.target)}"]`),host=$(".fs-chat");if(!host)return;
 const rect=node?.getBoundingClientRect(),bounds=$("#messages")?.getBoundingClientRect(),visible=rect&&bounds&&rect.bottom>bounds.top&&rect.top<bounds.bottom;
 animateEmoji(visible?node:host,payload.emoji,{reducedMotion:!!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches,center:!visible,assetPath:emojiAsset(emojiIndex,payload.emoji)});
}
document.addEventListener('error',event=>{const image=event.target;if(image?.classList?.contains('animated-emoji')){const fallback=document.createElement('span');fallback.className='emoji-fallback';fallback.textContent=image.alt;image.replaceWith(fallback)}},true);

window.FSApp.resume = async () => {
  if (isLocked() || !state.token) return;
  const epoch=access.epoch;
  connect();syncPresence();
  try {
    await refreshRooms();
    const current = await api("/calls/current");
    if(!access.valid(epoch))return;
    if (current?.incoming && !state.call) {
      await queuedCallSignal(current);
      return;
    }
    const room = window.FSNative?.pendingMessage();
    if (room && state.rooms.some((r) => r.id === room)) await openRoom(room);
  } catch (err) {
    notice(err.message, 4000, "error");
  }
};

let recentPhotos = [];
window.addEventListener("fs-recent-photos", (e) => {
  if(isLocked())return;
  recentPhotos = Array.isArray(e.detail) ? e.detail : [];
  const strip = $("#recent-strip");
  if (strip)
    strip.innerHTML =
      recentPhotos
        .map(
          (p) =>
            `<button data-action="send-recent" data-id="${escape(p.id)}" aria-label="${escape(p.name)}"><img src="${escape(p.thumb)}" alt="${escape(p.name)}"></button>`,
        )
        .join("") ||
      '<p class="hint">Fotoğraf yok veya erişim izni verilmedi.</p>';
});
async function sendRecentPhoto(id) {
  if(isLocked())return;
  const p = recentPhotos.find((p) => p.id === id), room=state.room, epoch=access.epoch;
  if (!p) return;
  if (p.size > 50 * 1048576) throw Error("Dosya sınırı 50 MB.");
  const chunks = [];
  for (let offset = 0; offset < p.size; offset += 49152) {
    assertEpoch(epoch);if(state.room?.id!==room?.id)return;
    const part = window.FSNative.photoChunk(
      id,
      offset,
      Math.min(49152, p.size - offset),
    );
    if (!part) throw Error("Fotoğraf okunamadı. Galeriden tekrar seç.");
    chunks.push(unb64(part));
    if (offset % (49152 * 4) === 0) await new Promise((r) => setTimeout(r, 0));
  }
  modal.close();
  stageFiles([new File(chunks, p.name, { type: p.mime || "image/jpeg" })],room,epoch);
}

window.addEventListener("fs-audio-devices", () => { if(state.page === "call" && state.call) showCall(); });
window.addEventListener("fs-audio-route", (e) => {
  for (const name of ["speaker", "bluetooth"])
    document
      .querySelector(`.call [data-action="${name}"]`)
      ?.classList.toggle("on", e.detail === name);
});
