import {calculate} from './calculator.js';
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function formatCalculation(value){
 const s=String(value);if(/[eE]/.test(s))return s.replace('.',',');
 const [integer,decimal]=s.split('.');return integer.replace(/\B(?=(\d{3})+(?!\d))/g,'.')+(decimal!==undefined?','+decimal:'');
}
export function mountCalculator(root,{checkPin=async()=>false,onUnlock=async()=>{},windowAction=()=>{},initial=null,floating=false}={}){
 let input='',done=false,scientific=false,radians=false,inverse=false,lastExpression='',busy=false,typedPin='';
 let history=[];try{const h=JSON.parse(localStorage.getItem('fs-calculator-history')||'[]');if(Array.isArray(h))history=h.slice(0,30)}catch{}
 const svg=b=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${b}</svg>`;
 const back=svg('<path d="M9 5H21V19H9L3 12Z"/><path d="m12 9 6 6m0-6-6 6"/>');
 root.innerHTML=`<section class="android-calculator"><header class="calc-toolbar"><button id="calc-compact" aria-label="Küçük pencere">${svg('<path d="m3 3 7 7M10 4v6H4m17 11-7-7m0 6v-6h6"/>')}</button><div class="calc-tools"><button id="calc-science" aria-label="Bilimsel hesap makinesi" aria-expanded="false"><span class="science-symbol">√π<br>e＝</span></button><button id="calc-tools" aria-label="Hesap makinesi araçları">${svg('<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>')}</button><button id="calc-menu" aria-label="Diğer seçenekler">${svg('<circle cx="12" cy="5" r="1" fill="currentColor"/><circle cx="12" cy="12" r="1" fill="currentColor"/><circle cx="12" cy="19" r="1" fill="currentColor"/>')}</button></div></header><div class="calc-display"><div id="calc-expression"></div><output class="display" aria-live="polite"></output><div id="calc-preview"></div><small id="calc-error" role="status"></small></div><div class="scientific-pad" hidden></div><div class="keypad"></div></section>`;
 const $=s=>root.querySelector(s),section=$('.android-calculator');
 const snapshot=()=>JSON.stringify({input:!floating&&typedPin?"":input,done:!floating&&typedPin?false:done,scientific,radians,inverse,lastExpression});
 function restore(value){typedPin="";try{const v=typeof value==='string'?JSON.parse(value):value;if(!v||typeof v.input!=='string'||v.input.length>500||!/^[\d.eπ+−×÷%^!(),a-z-]*$/.test(v.input))return;input=v.input;done=!!v.done;scientific=!!v.scientific;radians=!!v.radians;inverse=!!v.inverse;lastExpression=typeof v.lastExpression==='string'?v.lastExpression.slice(0,500):'';keys();draw()}catch{}}
 function keys(){
  const basic=['AC','%','⌫','÷','7','8','9','×','4','5','6','−','1','2','3','+','00','0',',','='];
  const full=['sin','cos','tan','rad','deg','log','ln','(',')','inv','!','AC','%','⌫','÷','^','7','8','9','×','√','4','5','6','−','π','1','2','3','+','e','00','0',',','='];
  $('.keypad').innerHTML=(scientific?full:basic).map(k=>`<button data-calc="${k}" aria-label="${k==='⌫'?'Son rakamı sil':k}" class="${['AC','%','⌫','÷','×','−','+'].includes(k)?'calc-operator ':''}${k==='='?'calc-equals ':''}${['sin','cos','tan','rad','deg','log','ln','(',')','inv','!','^','√','π','e'].includes(k)?'calc-function ':''}${(k==='rad'&&radians||k==='deg'&&!radians||k==='inv'&&inverse)?'calc-selected':''}">${k==='⌫'?back:inverse&&['sin','cos','tan'].includes(k)?k+'⁻¹':k}</button>`).join('');
  section.classList.toggle('calc-scientific',scientific);$('#calc-science').setAttribute('aria-expanded',String(scientific));$('#calc-science .science-symbol').innerHTML=scientific?'+−<br>×＝':'√π<br>e＝';
  // Retained as a semantic visibility marker for accessibility/tests; keys share one grid.
  $('.scientific-pad').hidden=!scientific;
 }
 function result(){const missing=(input.match(/\(/g)||[]).length-(input.match(/\)/g)||[]).length;return calculate(input+')'.repeat(Math.max(0,missing)),{radians})}
 function draw(){
  $('.display').textContent=done?formatCalculation(input):input.replaceAll('.',',');
  $('#calc-expression').textContent=done?lastExpression.replaceAll('.',','):'';
  $('#calc-preview').textContent='';section.classList.toggle('calc-editing',!!input&&!done);
  if(input&&!done){try{const n=result();if(/[+−×÷%^!()a-zπ√]/.test(input))$('#calc-preview').textContent=formatCalculation(n)}catch{}}
  $('#calc-error').textContent='';
 }
 function popup(title,items){
  root.querySelector('.calc-popup')?.remove();const box=document.createElement('div');box.className='calc-popup';box.setAttribute('role','dialog');box.setAttribute('aria-label',title);
  for(const [label,action] of items){const b=document.createElement('button');b.className='row';b.textContent=label;b.onclick=()=>{box.remove();action()};box.append(b)}
  const close=document.createElement('button');close.textContent='Geri';close.className='calc-popup-close';close.onclick=()=>box.remove();box.append(close);section.append(box);
 }
 function showHistory(){popup('Hesaplama geçmişi',history.map(h=>[h.expression.replaceAll('.',',')+' = '+formatCalculation(h.result),()=>{typedPin="";input=String(h.result);lastExpression=h.expression;done=true;draw()}]).concat([['Geçmişi temizle',()=>{history=[];localStorage.removeItem('fs-calculator-history')}]]))}
 function windowMenu(){popup('Pencere seçenekleri',[['Tam ekran',()=>windowAction('fullscreen',snapshot())],['Küçült',()=>windowAction('minimize',snapshot())],['Kapat',()=>windowAction('close',snapshot())]])}
 $('#calc-science').onclick=()=>{scientific=!scientific;keys();draw()};
 $('#calc-compact').onclick=()=>windowAction('float',snapshot());
 $('#calc-tools').onclick=()=>popup('Hesap makinesi araçları',[['Hesaplama geçmişi',showHistory],['Bilimsel hesap makinesi',()=>$('#calc-science').click()],['Pencere seçenekleri',windowMenu]]);
 $('#calc-menu').onclick=()=>floating?windowMenu():popup('Hesap makinesi',[['Hesaplama geçmişi',showHistory],['Küçük pencere',()=>windowAction('float',snapshot())]]);
 section.onclick=async event=>{
  const b=event.target.closest('[data-calc]');if(!b||busy||!event.isTrusted)return;let k=b.dataset.calc;
  try{
   if(k==='AC')typedPin='';
   else if(k==='⌫')typedPin=typedPin===input?typedPin.slice(0,-1):'';
   else if(k!=='='){if(event.isTrusted&&/^\d+$/.test(k)&&(done||typedPin===input)){typedPin=(done?'':typedPin)+k;}else typedPin='';}
   if(k==='rad'||k==='deg'){radians=k==='rad';keys();draw();return}
   if(k==='inv'){inverse=!inverse;keys();return}
   if(k==='AC'){input='';done=false;lastExpression=''}
   else if(k==='⌫'){input=input.slice(0,-1);done=false}
   else if(k==='='){
    busy=true;try{const pin=typedPin;if(!floating&&event.isTrusted&&!done&&pin===input&&/^\d{6,}$/.test(pin)&&await checkPin(pin,true)){input='';lastExpression='';typedPin='';await onUnlock();return}
     typedPin='';const value=result();lastExpression=input;input=String(value);done=true;history.unshift({expression:lastExpression,result:value});history=history.slice(0,30);try{localStorage.setItem('fs-calculator-history',JSON.stringify(history))}catch{}
    }finally{busy=false}
   }else{
    const op=['+','−','×','÷','^','%','!'].includes(k);if(done&&!op)input='';done=false;
    if(input.length>=500)throw Error('İşlem çok uzun.');
    if(k===','){const part=input.split(/[+−×÷^()]/).at(-1);if(part.includes('.'))return;input+=(part?'':'0')+'.'}
    else if(['sin','cos','tan','log','ln','√'].includes(k)){if(/[\d)πe!]$/.test(input))input+='×';input+=(k==='√'?'√':inverse&&['sin','cos','tan'].includes(k)?'a'+k:k)+'('}
    else {if(['π','e','('].includes(k)&&/[\d)πe!]$/.test(input))input+='×';if(k===')'&&(input.match(/\(/g)||[]).length<=(input.match(/\)/g)||[]).length)return;input+=k}
   }
   draw();
  }catch(err){busy=false;typedPin='';input='';done=false;lastExpression='';draw();$('#calc-error').textContent=err.message}
 };
 keys();draw();if(initial)restore(initial);return {snapshot,restore};
}
