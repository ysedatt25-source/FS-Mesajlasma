export function clamp(value,min,max){return Math.max(min,Math.min(Math.max(min,max),value));}
export function pipPosition(bounds,size,ratio={x:1,y:0}){
 const maxX=Math.max(0,bounds.width-size.width),maxY=Math.max(0,bounds.height-size.height);
 return {left:bounds.left+clamp(ratio.x,0,1)*maxX,top:bounds.top+clamp(ratio.y,0,1)*maxY};
}
export function urlParts(value){
 const raw=String(value??'');const chunks=[];let end=0;
 for(const match of raw.matchAll(/(?:https?:\/\/|www\.)[^\s<>"'\u0000-\u001f]+/gi)){
  let text=match[0].replace(/[.,;:!?]+$/,'');
  for(const [open,close] of [['(',')'],['[',']'],['{','}']])while(text.endsWith(close)&&text.split(close).length>text.split(open).length)text=text.slice(0,-1);
  let url;try{url=new URL(/^www\./i.test(text)?'https://'+text:text);if(!['https:','http:'].includes(url.protocol)||url.username||url.password||!url.hostname)continue;}catch{continue;}
  chunks.push({text:raw.slice(end,match.index)},{text,url:url.href});end=match.index+text.length;
 }
 chunks.push({text:raw.slice(end)});return chunks;
}
export function mapUrls(lat,lng){
 if(!Number.isFinite(lat)||!Number.isFinite(lng)||Math.abs(lat)>90||Math.abs(lng)>180)return null;
 const q=new URLSearchParams({mlat:String(lat),mlon:String(lng)});
 const displayLat=clamp(lat,-85,85),d=.008,dx=Math.min(.12,d/Math.max(.08,Math.cos(displayLat*Math.PI/180)));
 const bbox=[clamp(lng-dx,-180,180),clamp(displayLat-d,-85.051,85.051),clamp(lng+dx,-180,180),clamp(displayLat+d,-85.051,85.051)].join(',');
 const frame=new URLSearchParams({bbox,layer:'mapnik',marker:`${lat},${lng}`});
 return {external:'https://www.openstreetmap.org/?'+q+'#map=16/'+lat+'/'+lng,embed:'https://www.openstreetmap.org/export/embed.html?'+frame};
}
export function effectiveStatus(foreground,connected,preferred='online'){return foreground&&connected?(['busy','offline'].includes(preferred)?preferred:'online'):'offline';}
export function callControlState(c,now,tap=false){
 let controlsHidden=!!c.controlsHidden,controlsUntil=c.controlsUntil??now+10000;
 if(!controlsHidden&&now>=controlsUntil)controlsHidden=true;
 if(tap){controlsHidden=!controlsHidden;controlsUntil=controlsHidden?0:now+10000;}
 return {controlsHidden,controlsUntil};
}

// Match events to a single call instance; legacy servers omit callId.
export function callEventMatches(call,event){
 return !!(call&&event&&(!event.room||event.room===call.room?.id)&&(!call.callId||event.callId===call.callId));
}
