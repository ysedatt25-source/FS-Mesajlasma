// The gesture is authorized only once, at pointer-down, and never on click.
export function composerMode({text='',files=0,recording=false,active=false,busy=false}={}){
 if(active)return 'recording';
 if(busy)return 'busy';
 if(String(text).trim()||files||recording)return 'send';
 return 'mic';
}
export function createMicGesture({mode,start,finish,cancel,hold=420,cooldown=350,now=()=>performance.now(),schedule=setTimeout,unschedule=clearTimeout}){
 let pointer=null,timer=null,started=false,lastSend=-Infinity,suppress=false;
 const stopTimer=()=>{if(timer!==null){unschedule(timer);timer=null;}};
 function clear(abort=false){stopTimer();const was=started;pointer=null;started=false;if(was){if(abort)cancel();else finish();}return was;}
 return {
  down(e){if(pointer!==null||!e.isPrimary||e.button!==0)return false; suppress=false;
   if(mode()!=='mic')return false;
   suppress=true; if(now()-lastSend<cooldown)return true;
   pointer=e.pointerId;const id=pointer;timer=schedule(()=>{timer=null;if(pointer!==id||mode()!=='mic')return;started=true;start(e);},hold);return true;},
  up(e){if(pointer===e.pointerId)clear(false);},
  abort(e){if(pointer===e.pointerId)clear(true);},
  reset(){clear(true);suppress=false;},
  changed(){if(pointer!==null&&!started&&mode()!=='mic'){stopTimer();pointer=null;}},
  click(){if(suppress){suppress=false;return false;}if(mode()!=='send')return false;lastSend=now();return true;},
  sent(){lastSend=now();},
  isRecording(){return started;}
 };
}
