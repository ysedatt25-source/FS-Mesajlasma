// The bundled animated WebP artwork stays in place. Effects are a separate,
// noninteractive layer; unsupported Unicode sequences retain their exact text.
export function isSingleEmoji(text){
 if(typeof text!=='string'||!text)return false;
 return /^(?:\p{Regional_Indicator}{2}|[0-9#*]\uFE0F?\u20E3|\p{Extended_Pictographic}[\uFE0F\p{Emoji_Modifier}\u{E0020}-\u{E007F}]*(?:\u200D\p{Extended_Pictographic}[\uFE0F\p{Emoji_Modifier}\u{E0020}-\u{E007F}]*)*)$/u.test(text);
}
export function emojiKey(value){return typeof value==='string'?value.normalize('NFC').replace(/\uFE0F/g,''):'';}
export function buildEmojiIndex(items){const index=new Map();for(const item of items||[]){if(isSingleEmoji(item.emoji)&&/^[a-f0-9_-]+\.webp$/i.test(item.file)){const key=emojiKey(item.emoji);if(!index.has(key))index.set(key,item.file)}}return index;}
export function emojiAsset(index,value){return isSingleEmoji(value)?index.get(emojiKey(value))||null:null;}
const families=[
 {match:/[😘😚😙😗💋]/u,kind:'kiss',symbols:['💋','💕','✨']},
 {match:/[😛😜😝🤪]/u,kind:'tongue',symbols:['😛','😜','✦']},
 {match:/[😎🕶]/u,kind:'cool',symbols:['🕶️','✨','⭐']},
 {match:/[🤔🤨🧐😐]/u,kind:'think',symbols:['❔','💭','✧']},
 {match:/[🤭🙈🙊]/u,kind:'shy',symbols:['💕','🙈','✨']},
 {match:/[🤤😋]/u,kind:'yum',symbols:['💧','😋','✨']},
 {match:/[💩]/u,kind:'poop',symbols:['💩','💨','✧']},
 {match:/[🍌]/u,kind:'banana',symbols:['🍌','✨','🍌']},
 {match:/[😴💤]/u,kind:'sleep',symbols:['💤','🌙','✧']},
 {match:/[🤮🤢]/u,kind:'sick',symbols:['💚','💧','✧']},
 {match:/[❤♥💖💗💓💕💞💘💝💟🩷🩵🧡💛💚💙💜🤎🖤🤍🫶😍🥰😘😻]/u,kind:'love',symbols:['❤','💕','✨']},
 {match:/[😂🤣😹]/u,kind:'laugh',symbols:['💧','✨','💧']},
 {match:/[😢😭🥲😿]/u,kind:'rain',symbols:['💧','💦','💧']},
 {match:/[🔥💥🌋]/u,kind:'fire',symbols:['🔥','✨','🟠']},
 {match:/[🎉🎊🎈🎆🎇🥳🎂🍾🥂]/u,kind:'celebrate',symbols:['🎊','✨','🎉']},
 {match:/[🦋]/u,kind:'flutter',symbols:['🦋','✨','🦋']},
 {match:/[❄☃⛄🧊🥶]/u,kind:'snow',symbols:['❄','✧','❄']},
 {match:/[⚡🌩⛈]/u,kind:'lightning',symbols:['⚡','✦','⚡']},
 {match:/[👍👎👏🙌🤝✋🤚👋✌🤟🤘💪🤞👌]/u,kind:'gesture',symbols:['✦','✨','✧']},
 {match:/[💸💵💰🤑💲]/u,kind:'money',symbols:['💸','💰','✨']},
 {match:/[💔]/u,kind:'broken',symbols:['💔','✧','💔']},
 {match:/[😡🤬😠]/u,kind:'anger',symbols:['💢','♨','💢']},
 {match:/[😱🤯😨👻💀]/u,kind:'shock',symbols:['✧','💥','✦']},
 {match:/[⭐🌟✨🤩🏆🥇]/u,kind:'star',symbols:['⭐','✨','✦']},
 {match:/[⚽🏀🏐🎾🏈⚾]/u,kind:'sport',symbols:['✦','✨','✧']},
];
export function effectPlan(value){if(!isSingleEmoji(value))return null;const family=families.find(x=>x.match.test(value));return family?{kind:family.kind,symbols:family.symbols}:{kind:'spark',symbols:['✧',value,'✦']};}
export function particlePlan(kind,i,count=12){const a=2*Math.PI*i/count,r=95+(i%4)*34;let x=Math.cos(a)*r,y=Math.sin(a)*r;
 if(['love','fire','flutter','kiss','sleep'].includes(kind)){x=Math.cos(a)*r*.7;y=-70-(i%5)*38;}
 if(['rain','snow','money'].includes(kind)){x=(i%6-2.5)*34;y=65+(i%4)*40;}
 return {x:Math.round(x),y:Math.round(y),delay:(i%4)*65,size:19+(i%3)*8};}
let active=null;
export function clearEmojiEffect(){if(active){active.dispose();active=null;}}
export function animateEmoji(target,value,{reducedMotion=false,schedule=setTimeout,fetchAsset=globalThis.fetch,center=false,assetPath=null}={}){
 const plan=effectPlan(value),host=target?.closest?.('.fs-chat');if(reducedMotion||!plan||!target?.isConnected||!host?.isConnected)return false;
 clearEmojiEffect();const doc=target.ownerDocument,layer=doc.createElement('div');layer.className='emoji-interactive-layer';layer.dataset.effect=plan.kind;layer.setAttribute('aria-hidden','true');
 const bounds=host.getBoundingClientRect(),rect=center?bounds:(target.querySelector('.animated-emoji,.emoji-fallback')||target).getBoundingClientRect();
 layer.style.setProperty('--effect-x',Math.max(32,Math.min(bounds.width-32,rect.left+rect.width/2-bounds.left))+'px');layer.style.setProperty('--effect-y',Math.max(40,Math.min(bounds.height-40,rect.top+rect.height/2-bounds.top))+'px');
 for(let i=0;i<12;i++){const p=particlePlan(plan.kind,i),node=doc.createElement('span');node.className='emoji-particle';node.textContent=plan.symbols[i%plan.symbols.length];for(const [key,v] of Object.entries({'--dx':p.x+'px','--dy':p.y+'px','--delay':p.delay+'ms','--size':p.size+'px'}))node.style.setProperty(key,v);layer.append(node);}
 host.append(layer);let url=null,disposed=false;const token={dispose(){if(disposed)return;disposed=true;layer.remove();if(url)URL.revokeObjectURL(url);}};active=token;
 // Replay the actual frame animation with a fresh local blob URL. No network
 // service is contacted: the path is validated and stays in bundled assets.
 const original=center?null:target.querySelector('.animated-emoji'),path=assetPath?'emoji/'+assetPath:original?.getAttribute('src');
 if(path&&/^emoji\/[a-f0-9_-]+\.webp$/i.test(path)&&typeof fetchAsset==='function'){
  Promise.resolve().then(()=>fetchAsset(path)).then(r=>{if(!r.ok)throw Error('Emoji asset');return r.blob()}).then(blob=>{if(disposed||!host.isConnected||active!==token)return;url=URL.createObjectURL(blob);const replay=doc.createElement('img');replay.className='emoji-replay';replay.alt='';replay.src=url;layer.append(replay);}).catch(()=>{});
 }
 schedule(()=>{token.dispose();if(active===token)active=null;},2200);return true;
}
