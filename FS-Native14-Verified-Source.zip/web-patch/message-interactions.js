export function gestureIntent(dx,dy,release=false){
 const x=Math.abs(dx),y=Math.abs(dy);
 if(release)return dx<=-58&&x>y*1.25?'reply':'cancel';
 if(x<12&&y<12)return 'wait';
 if(dx<0&&x>y*1.25)return 'swipe';
 return 'scroll';
}
export function reactionValue(current,chosen){return current===chosen?'':chosen;}
export function selectionOps(messages,self,localDelete=false){
 const one=messages.length===1,own=messages.length>0&&messages.every(m=>m.sender===self);
 return [...(one?[["Yanıtla","↩"],["Tepki","☺"]]:[]),["Kopyala","▣"],...(one&&own&&messages[0].payload.type==='text'?[["Düzenle","✎"]]:[]),["İlet","↪"],["Paylaş","↗"],["Kaydet","☆"],...(messages.length&&(own||localDelete)?[["Sil","⌫"]]:[])];
}
