// HTTP acknowledgements, realtime refreshes and optimistic records share one ID.
export function mergeMessagePage(previous, fetched, room) {
  const serverIds = new Set(fetched.map(m => m.id));
  const oldest = fetched.filter(m => !m.callRecord)[0];
  const records = new Map();
  for (const m of previous) {
    if (m.room !== room || m.callRecord || serverIds.has(m.id)) continue;
    const before = oldest && (m.created < oldest.created || (m.created === oldest.created && m.id < oldest.id));
    if (m.pending || before) records.set(m.id, m);
  }
  for (const m of fetched) records.set(m.id, {...m, pending:false});
  return [...records.values()].sort((a,b) => a.created - b.created || a.id.localeCompare(b.id));
}
export function upsertMessage(previous, incoming) {
  const records = new Map(previous.map(m => [m.id,m]));
  for (const m of incoming) records.set(m.id,m);
  return [...records.values()].sort((a,b) => a.created - b.created || a.id.localeCompare(b.id));
}

/** Reconcile only previously acknowledged messages absent from the latest server page.
 * Pending sends and call records are not message existence candidates.
 * Fail closed on malformed replies: never treat a protocol error as deletion.
 */
export async function missingCachedMessages(previous, fetched, room, check, stillCurrent=()=>true) {
  const seen = new Set(fetched.map(m=>m.id));
  const ids = [...new Set(previous.filter(m=>m.room===room&&!m.pending&&!m.queued&&!m.callRecord&&!seen.has(m.id)&&/^[A-Za-z0-9_-]{10,64}$/.test(m.id)).map(m=>m.id))];
  const missing=[];
  for(let i=0;i<ids.length;i+=200){
    if(!stillCurrent())return [];
    const chunk=ids.slice(i,i+200), allowed=new Set(chunk);
    const response=await check(chunk);
    if(!stillCurrent())return [];
    if(!Array.isArray(response?.existing)||response.existing.some(id=>!allowed.has(id)))throw Error('Mesaj eşitleme yanıtı geçersiz.');
    const existing=new Set(response.existing);
    missing.push(...chunk.filter(id=>!existing.has(id)));
  }
  return missing;
}
