import {isSingleEmoji,emojiKey} from './emoji-effects.js';
export const EMOJI_EVENT='emoji-interaction-v1';
export const MAX_EVENT_AGE=8000;
export const validId=s=>typeof s==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(s);
export function validInteraction(p){return p?.type===EMOJI_EVENT&&validId(p.id)&&validId(p.target)&&isSingleEmoji(p.emoji)&&p.emoji.length<=64;}
export function matchesInteraction(p,m,room){return validInteraction(p)&&m?.id===p.target&&m.room===room&&!m.pending&&m.payload?.type==='text'&&emojiKey(m.payload.text)===emojiKey(p.emoji);}
export function createInteractionWindow({now=Date.now,limit=512}={}){
 const seen=new Map();return {accept(id,ts){const t=now();if(!validId(id)||!Number.isFinite(ts)||ts>t+3000||t-ts>MAX_EVENT_AGE )return false;for(const [k,v] of seen)if(t-v>MAX_EVENT_AGE)seen.delete(k);if(seen.has(id))return false;seen.set(id,t);while(seen.size>limit)seen.delete(seen.keys().next().value);return true;},clear(){seen.clear();}};
}
