export const TYPING_EVENT='typing-v1';
export function createTypingStatus({context,send,render,clock=()=>Date.now(),delay=setTimeout,cancel=clearTimeout}){
 let outgoing=null,stopTimer=null,viewTimer=null,incoming=new Map();
 const key=(room,user)=>room+'\0'+user;
 function stop(){cancel(stopTimer);stopTimer=null;if(outgoing){const old=outgoing;outgoing=null;send({type:TYPING_EVENT,room:old.room,active:false});}}
 function update(){cancel(viewTimer);viewTimer=null;const c=context(),now=clock();let next=Infinity;const names=[];
  for(const [id,e] of incoming){if(e.until<=now||!c?.enabled||e.room!==c.room||!c.members.has(e.user)){incoming.delete(id);continue;}names.push(c.members.get(e.user));next=Math.min(next,e.until);}
  render(c?.enabled?names:[]);if(next<Infinity)viewTimer=delay(update,Math.max(1,next-now));
 }
 function input(text){const c=context();if(!c||!c.enabled||!String(text).trim()){stop();return;}const now=clock();if(outgoing?.room!==c.room)stop();if(!outgoing||now-outgoing.at>=2000){if(send({type:TYPING_EVENT,room:c.room,active:true}))outgoing={room:c.room,at:now};}cancel(stopTimer);stopTimer=delay(stop,3000);}
 function receive(e){const c=context();if(!c||!c.enabled||e?.type!==TYPING_EVENT||e.room!==c.room||!c.members.has(e.from)||typeof e.active!=='boolean')return false;const id=key(e.room,e.from);if(e.active)incoming.set(id,{room:e.room,user:e.from,until:clock()+5500});else incoming.delete(id);update();return true;}
 function reset(){stop();incoming.clear();update();}
 return {input,receive,stop,reset,update};
}
