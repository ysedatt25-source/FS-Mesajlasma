export function nearLatest(target,threshold=32){return Math.max(0,target.scrollHeight-target.scrollTop-target.clientHeight)<=threshold;}
export function visibleRange(offsets,top,height,overscan=5){
 const n=offsets.length-1;
 const at=y=>{let lo=0,hi=n;while(lo<hi){const mid=(lo+hi)>>1;if(offsets[mid+1]<y)lo=mid+1;else hi=mid}return lo};
 return {start:Math.max(0,at(top)-overscan),end:Math.min(n,at(top+height)+overscan+1)};
}
// Heights are measured after paint; only a viewport window is attached to the DOM.
export class VirtualMessages {
 constructor(target,patch,after){this.target=target;this.patch=patch;this.after=after;this.rows=[];this.heights=new Map();this.frame=null;this.onScroll=()=>{if(this.frame===null)this.frame=requestAnimationFrame(()=>{this.frame=null;this.draw()})};target.addEventListener('scroll',this.onScroll,{passive:true});this.observer=typeof ResizeObserver==='function'?new ResizeObserver(()=>this.measure()):null}
 offsets(){const a=[0];for(const row of this.rows)a.push(a.at(-1)+(this.heights.get(row.id)||100));return a}
 anchor(){const a=this.offsets(),range=visibleRange(a,this.target.scrollTop,0,0);return {id:this.rows[range.start]?.id,delta:this.target.scrollTop-a[range.start]}}
 set(rows,{bottom=false,anchor=null}={}){this.rows=rows;const ids=new Set(rows.map(r=>r.id));for(const key of this.heights.keys())if(!ids.has(key))this.heights.delete(key);let a=this.offsets(),top=this.target.scrollTop;if(bottom)top=Math.max(0,a.at(-1)-(this.target.clientHeight||800));else if(anchor){const i=rows.findIndex(r=>r.id===anchor.id);if(i>=0)top=a[i]+anchor.delta}this.draw(bottom,top);}
 draw(bottom=false,requestedTop=null){const t=this.target;if(!t.isConnected)return;const a=this.offsets();const height=t.clientHeight||800;const top=requestedTop??(bottom?Math.max(0,a.at(-1)-height):t.scrollTop);const range=this.rows.length<=80?{start:0,end:this.rows.length}:visibleRange(a,top,height);this.patch(t,`<div class="virtual-spacer" data-key="virtual-top" style="height:${a[range.start]}px"></div>`+this.rows.slice(range.start,range.end).map(r=>`<div class="message-row" data-key="${r.id}" data-row-id="${r.id}">${typeof r.html==='function'?r.html():r.html}</div>`).join('')+`<div class="virtual-spacer" data-key="virtual-bottom" style="height:${a.at(-1)-a[range.end]}px"></div>`);if(bottom)t.scrollTop=t.scrollHeight;else if(requestedTop!==null)t.scrollTop=requestedTop;this.observer?.disconnect();for(const node of t.querySelectorAll('[data-row-id]'))this.observer?.observe(node);this.after?.();}

 measure(){const bottom=nearLatest(this.target);const anchor=this.anchor();let changed=false;for(const node of this.target.querySelectorAll('[data-row-id]')){const h=node.getBoundingClientRect().height;if(h>0&&Math.abs((this.heights.get(node.dataset.rowId)||100)-h)>1){this.heights.set(node.dataset.rowId,h);changed=true}}if(changed){if(bottom){this.draw(true);return;}const a=this.offsets(),i=this.rows.findIndex(r=>r.id===anchor.id);if(i>=0)this.target.scrollTop=a[i]+anchor.delta;this.onScroll()}}
 jump(id){const i=this.rows.findIndex(r=>r.id===id);if(i<0)return false;this.target.scrollTop=this.offsets()[i];this.draw();return true}
 destroy(){this.target.removeEventListener('scroll',this.onScroll);this.observer?.disconnect();if(this.frame!==null)cancelAnimationFrame(this.frame)}
}
