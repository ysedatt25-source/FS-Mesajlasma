// Album export is local only. The grouping rules remain the chat renderer's rules.
export function albumMembers(rows, anchor, messages, eligible) {
  const row=rows.find(r=>r.id===anchor && r.albumIds?.length>1);
  if(!row)return [];
  const byId=new Map(messages.map(m=>[m.id,m]));
  const members=[...new Set(row.albumIds)].map(id=>byId.get(id));
  // Refuse stale or partially acknowledged albums rather than silently omit photos.
  if(members.length!==row.albumIds.length||members.some(m=>!m||!eligible(m)||m.payload?.type!=='file'||typeof m.payload.mime!=='string'||!m.payload.mime.startsWith('image/')))return [];
  return members;
}
export function photoName(name,index){
  const clean=String(name||'fotoğraf').normalize('NFC').replace(/[\\/:*?"<>|\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/gu,'_').replace(/^\.+|[. ]+$/gu,'').trim()||'fotoğraf';
  const ext=clean.match(/\.[a-zA-Z0-9]{1,10}$/)?.[0]||'';
  return `${String(index+1).padStart(3,'0')}-${Array.from(clean.slice(0,clean.length-ext.length)).slice(0,80).join('')}${ext}`;
}
const abort=()=>new DOMException('Albüm indirme iptal edildi.','AbortError');
// At most one decrypted photo in memory in Android. Every completed save is acknowledged.
export async function exportPhotos(members,{active,read,sink,progress=()=>{},eligible=()=>true,onSaved=async()=>{}}){
  const result={saved:0,failed:0,cancelled:false,total:members.length};
  try{
    if(!active())throw abort();
    await sink.open(active);
    for(let i=0;i<members.length;i++){
      if(!active())throw abort();
      const m=members[i];
      try{
        if(!eligible(m))throw Error('Fotoğraf artık mevcut değil.');
        const blob=await read(m);
        if(!active())throw abort();
        if(!eligible(m)||blob.size!==m.payload.size)throw Error('Fotoğraf doğrulanamadı.');
        await sink.write(photoName(m.payload.name,i),m.payload.mime,blob,()=>active()&&eligible(m));
        result.saved++;
        await onSaved(m);
      }catch(e){if(!active()||e.name==='AbortError')throw abort();result.failed++;}
      progress({...result});
    }
    if(!active())throw abort();
    await sink.complete(active);
  }catch(e){result.cancelled=e.name==='AbortError'||!active();if(!result.cancelled)throw e;}
  finally{await sink.close();}
  return result;
}
export function nativeAlbumSink(bridge,{sleep=ms=>new Promise(r=>setTimeout(r,ms)),encode,timeout=300000}={}){
  let id='';
  return {
    async open(active){id=bridge.beginPhotoAlbum();if(!id)throw Error('Klasör seçimi başlatılamadı.');const start=Date.now();while(active()&&Date.now()-start<timeout){const s=bridge.photoAlbumState(id);if(s==='ready')return;if(s==='cancelled')throw abort();if(s!=='waiting')throw Error('Klasör açılamadı.');await sleep(150);}throw abort();},
    async write(name,mime,blob,active){if(!active())throw abort();if(!bridge.beginAlbumPhoto(id,name,mime,blob.size))throw Error('Fotoğraf oluşturulamadı.');try{for(let offset=0;offset<blob.size;offset+=49152){const chunk=new Uint8Array(await blob.slice(offset,offset+49152).arrayBuffer());if(!active())throw abort();if(!bridge.appendAlbumPhoto(id,encode(chunk)))throw Error('Fotoğraf yazılamadı.');}if(!active())throw abort();if(!bridge.finishAlbumPhoto(id))throw Error('Fotoğraf kaydedilemedi.');}catch(e){bridge.abortAlbumPhoto(id);throw e;}},
    async complete(){},
    async close(){if(id){bridge.endPhotoAlbum(id);id='';}}
  };
}
// Browser fallback: one explicit ZIP download, not many popup-triggered downloads.
const table=Uint32Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0});
export function crc32(bytes){let crc=0xffffffff;for(const b of bytes)crc=table[(crc^b)&255]^(crc>>>8);return (crc^0xffffffff)>>>0;}
export function browserAlbumSink(onReady,{maxBytes=128*1024*1024}={}){
  let entries=[],size=0;
  return {
    async open(){},
    async write(name,mime,blob,active){if(size+blob.size>maxBytes)throw Error('Tarayıcı albüm sınırı aşıldı.');const bytes=new Uint8Array(await blob.arrayBuffer());if(!active())throw abort();entries.push({name:new TextEncoder().encode(name),bytes,crc:crc32(bytes)});size+=bytes.length;},
    async complete(active){if(!active())throw abort();if(!entries.length)return;const chunks=[],central=[];let offset=0,centralSize=0;const header=n=>{const b=new Uint8Array(n);return [b,new DataView(b.buffer)]};for(const {name,bytes,crc} of entries){const [l,v]=header(30);v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint16(12,33,true);v.setUint32(14,crc,true);v.setUint32(18,bytes.length,true);v.setUint32(22,bytes.length,true);v.setUint16(26,name.length,true);const [c,d]=header(46);d.setUint32(0,0x02014b50,true);d.setUint16(4,20,true);d.setUint16(6,20,true);d.setUint16(8,0x800,true);d.setUint16(14,33,true);d.setUint32(16,crc,true);d.setUint32(20,bytes.length,true);d.setUint32(24,bytes.length,true);d.setUint16(28,name.length,true);d.setUint32(42,offset,true);chunks.push(l,name,bytes);central.push(c,name);offset+=l.length+name.length+bytes.length;centralSize+=c.length+name.length;}const [end,e]=header(22);e.setUint32(0,0x06054b50,true);e.setUint16(8,entries.length,true);e.setUint16(10,entries.length,true);e.setUint32(12,centralSize,true);e.setUint32(16,offset,true);if(!active())throw abort();onReady(new Blob([...chunks,...central,end],{type:'application/zip'}));},
    async close(){entries=[];size=0;}
  };
}
