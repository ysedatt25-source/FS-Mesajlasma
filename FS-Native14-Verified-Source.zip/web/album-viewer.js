// Keep only the current decrypted photo in memory. A generation check prevents
// a late download from replacing another photo or reopening a closed viewer.
export function swipeStep(dx,dy){return Math.abs(dx)>=45&&Math.abs(dx)>Math.abs(dy)*1.5?(dx<0?1:-1):0;}
export function createAlbumViewer(members,{active,eligible,read,render,blur=true,makeURL=blob=>URL.createObjectURL(blob),revokeURL=url=>URL.revokeObjectURL(url)}){
  const photos=[...members];let index=-1,revision=0,closed=false,url=null,phase='idle',revealed=!blur;
  const clear=()=>{if(url){revokeURL(url);url=null;}};
  const current=()=>photos[index];
  const valid=()=>!closed&&active()&&!!current()&&eligible(current());
  const paint=()=>{if(valid())render({index,total:photos.length,photo:current(),url,phase,revealed});};
  async function select(next){
    if(closed||!active()||!Number.isInteger(next)||next<0||next>=photos.length)return false;
    if(next===index&&valid()){if(phase==='loading')return false;if(phase==='ready')return true;}
    const ticket=++revision;clear();index=next;revealed=!blur;phase='loading';
    const photo=current();if(!eligible(photo)){close();return false;}
    paint();
    try{const blob=await read(photo);if(ticket!==revision||!valid())return false;url=makeURL(blob);phase='ready';paint();return true;}
    catch(error){if(ticket===revision&&valid()){phase='error';paint();}return false;}
  }
  function close(){closed=true;revision++;clear();}
  return {select,step:delta=>select(index+delta),retry:()=>select(index),reveal(){if(valid()&&phase==='ready'){revealed=true;paint();}},imageError(){if(valid()&&phase==='ready'){clear();phase='error';paint();}},close,get current(){return current();},get ready(){return valid()&&phase==='ready';}};
}

// Short-lived ciphertext only. Every cache hit requires fresh server permission;
// this is never used for view-once media or across viewer/account sessions.
export function createPhotoCipherCache({read,authorize,valid,enabled,limit=16*1024*1024,count=3}){
 const entries=new Map();let size=0,closed=false;
 const check=m=>{if(closed||!valid(m))throw new DOMException('Fotoğraf işlemi iptal edildi.','AbortError');};
 const remove=k=>{const item=entries.get(k);if(item){size-=item.byteLength;entries.delete(k);}};
 async function load(m){check(m);if(!enabled(m))return read(m);const p=m.payload,k=JSON.stringify([m.id,m.room,p.upload,p.size,p.key,p.iv]);const hit=entries.get(k);
  if(hit){try{await authorize(m);check(m);if(entries.get(k)===hit){entries.delete(k);entries.set(k,hit);return hit;}}catch(e){remove(k);throw e;}}
  const bytes=await read(m);check(m);if(bytes instanceof Uint8Array&&bytes.byteLength===p.size+16&&bytes.byteLength<=limit){remove(k);while(entries.size>=count||size+bytes.byteLength>limit)remove(entries.keys().next().value);entries.set(k,bytes);size+=bytes.byteLength;}return bytes;
 }
 return {load,close(){closed=true;entries.clear();size=0;}};
}
