// History arrays are replaced, not mutated, by app.js. Weak keys avoid retaining
// old decrypted histories after room changes or lock.
export function createRecordLookup(){
 const indexes=new WeakMap();
 function index(rows){let result=indexes.get(rows);if(!result){result=new Map();for(const row of rows)result.set(row.id,row);indexes.set(rows,result);}return result;}
 return (id,...lists)=>{for(let i=lists.length-1;i>=0;i--){const row=index(lists[i]).get(id);if(row!==undefined)return row;}return undefined;};
}
// Each neighboring pair is evaluated once, preserving all boundary rules.
export function bubbleGroups(rows,firstUnread,joined){
 let before=false;return rows.map((row,i)=>{const after=i+1<rows.length&&joined(row,rows[i+1],i+1===firstUnread);const group=before?(after?'middle':'end'):(after?'start':'single');before=after;return group;});
}
// Catalog and identity are independent, but both must finish before boot is
// allowed to reveal the PIN setup or calculator. No fallback for legacy catalog.
export async function prepareBoot(loadCatalog,loadIdentity){
 const [catalog,identity]=await Promise.all([Promise.resolve().then(loadCatalog),Promise.resolve().then(loadIdentity)]);return {catalog,identity};
}
