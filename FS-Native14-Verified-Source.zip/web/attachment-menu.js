// Attachment choices and locally validated sharing payloads.
export const ATTACHMENTS = Object.freeze([
 ['gallery','image','Galeri','Fotoğraf ve video'], ['camera','camera','Kamera','Fotoğraf çek'],
 ['document','file','Belge','Dosya seç'], ['share-contact','user','Kişi','Kullanıcı adı paylaş'],
 ['location','location','Konum','Mevcut konum'], ['live-location','live-location','Canlı konum','Süreli paylaşım'],
 ['poll','poll','Anket','Seçenekli soru'], ['event','calendar','Etkinlik','Tarih ve saat']
].map(Object.freeze));
export function attachmentMarkup(icon, recent) {
 return `<section class="attachment-panel"><div class="attachment-handle" aria-hidden="true"></div>${recent?'<section class="attachment-recent"><div class="attachment-recent-head"><strong>Son fotoğraflar</strong><button type="button" class="secondary" data-action="recent-photos">Göster</button></div><div id="recent-strip" class="recent-strip" aria-live="polite"><p class="hint">Son fotoğrafları görmek için Göster’e dokun.</p></div><button type="button" class="primary recent-confirm" data-action="confirm-recent" hidden>Seçilenleri ekle</button></section>':''}<div class="attach-grid">${ATTACHMENTS.map(([action,glyph,label,hint])=>`<button type="button" data-action="${action}" class="attach-tile" aria-label="${label}: ${hint}"><span class="attach-symbol">${icon(glyph)}</span><strong>${label}</strong></button>`).join('')}</div><small class="attachment-limit">Dosya başına en fazla 50 MB · En fazla 20 dosya</small></section>`;
}
export function makePoll(question, lines) {
 const text=String(question??'').trim(),options=String(lines??'').split('\n').map(s=>s.trim()).filter(Boolean);
 if(!text||text.length>300)throw Error('Anket sorusu 1–300 karakter olmalı.');
 if(options.length<2||options.length>10||options.some(s=>s.length>200))throw Error('2–10 seçenek gir; her seçenek en fazla 200 karakter olsun.');
 if(new Set(options.map(s=>s.toLocaleLowerCase('tr-TR'))).size!==options.length)throw Error('Anket seçenekleri birbirinden farklı olmalı.');
 return {type:'poll',text,options};
}
export function makeEvent(title,date) {
 const text=String(title??'').trim(),value=String(date??'');
 if(!text||text.length>300)throw Error('Etkinlik adı 1–300 karakter olmalı.');
 if(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value)||!Number.isFinite(Date.parse(value)))throw Error('Geçerli tarih ve saat seç.');
 return {type:'event',text,date:value};
}
export function attachmentContext(state,access) {
 const room=state.room,epoch=access.epoch,route=state.routeVersion,token=state.token;
 const valid=()=>!!room&&access.valid(epoch)&&state.page==='chat'&&state.room?.id===room.id&&state.routeVersion===route&&state.token===token;
 return {room,epoch,valid};
}
export function recentItems(items) {
 return Array.isArray(items)?items.slice(0,12).filter(p=>p&&typeof p.id==='string'&&p.id.length<=100&&typeof p.name==='string'&&p.name.length<=256&&Number.isSafeInteger(p.size)&&p.size>0&&typeof p.thumb==='string'&&p.thumb.length<=100000&&/^data:image\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/.test(p.thumb)):[];
}
