import {mountCalculator} from './calculator-ui.js';
const view=mountCalculator(document.querySelector('#app'),{floating:true,windowAction:(action,value)=>window.FSCalculator?.windowAction(action,value)});
window.FSCalculatorView={restore:value=>view.restore(value)};
