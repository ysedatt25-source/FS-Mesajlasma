// Recursive descent; no eval or executable user input.
export function calculate(source, {radians=false}={}) {
 const input=String(source).replaceAll('×','*').replaceAll('÷','/').replaceAll('−','-').replaceAll('π','pi').replaceAll('√','sqrt').replace(/\s/g,'');
 const tokens=input.match(/(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?|pi|asin|acos|atan|sin|cos|tan|sqrt|cbrt|abs|exp|log|ln|e|[()+\-*/%^!]/g)||[];
 if(!input || tokens.join('')!==input)throw Error('Geçersiz işlem');
 let i=0;const val=x=>({value:x,percent:false});
 function primary(){const t=tokens[i++];let v;
  if(t==='('){v=sum().value;if(tokens[i++]!==')')throw Error('Parantezi kapatın');}
  else if(t==='pi')v=Math.PI;else if(t==='e')v=Math.E;
  else if(/^(sin|cos|tan|asin|acos|atan|sqrt|cbrt|abs|exp|log|ln)$/.test(t||'')){
   if(tokens[i++]!=='(')throw Error('Fonksiyon parantezi eksik');const a=sum().value;if(tokens[i++]!==')')throw Error('Parantezi kapatın');
   const angle=radians?a:a*Math.PI/180;const inv=x=>radians?x:x*180/Math.PI;
   const f={sin:()=>Math.sin(angle),cos:()=>Math.cos(angle),tan:()=>Math.abs(Math.cos(angle))<1e-14?NaN:Math.tan(angle),asin:()=>inv(Math.asin(a)),acos:()=>inv(Math.acos(a)),atan:()=>inv(Math.atan(a)),sqrt:()=>Math.sqrt(a),cbrt:()=>Math.cbrt(a),abs:()=>Math.abs(a),exp:()=>Math.exp(a),log:()=>Math.log10(a),ln:()=>Math.log(a)};v=f[t]();
  }else if(t && /^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(t))v=Number(t);else throw Error('İşlem eksik');
  let n=val(v);while(['%','!'].includes(tokens[i])){if(tokens[i++]==='%')n={value:n.value/100,percent:true};else{if(!Number.isInteger(n.value)||n.value<0||n.value>170)throw Error('Faktöriyel için 0–170 arası tam sayı girin');let f=1;for(let k=2;k<=n.value;k++)f*=k;n=val(f)}}return n;
 }
 function power(){let a=primary();if(tokens[i]==='^'){i++;a=val(a.value**unary().value)}return a}
 function unary(){if(tokens[i]==='+'){i++;return unary()}if(tokens[i]==='-'){i++;const a=unary();return {...a,value:-a.value}}return power()}
 function product(){let a=unary();while(['*','/'].includes(tokens[i])){const op=tokens[i++],b=unary();a=val(op==='*'?a.value*b.value:a.value/b.value)}return a}
 function sum(){let a=product();while(['+','-'].includes(tokens[i])){const op=tokens[i++],b=product(),n=b.percent?a.value*b.value:b.value;a=val(op==='+'?a.value+n:a.value-n)}return a}
 const result=sum().value;if(i!==tokens.length||!Number.isFinite(result))throw Error('İşlem yapılamadı');return Number(result.toPrecision(12));
}
