export function clamp(value,min,max){return Math.max(min,Math.min(Math.max(min,max),value));}
export function pipPosition(bounds,size,ratio={x:1,y:0}){
 const maxX=Math.max(0,bounds.width-size.width),maxY=Math.max(0,bounds.height-size.height);
 return {left:bounds.left+clamp(ratio.x,0,1)*maxX,top:bounds.top+clamp(ratio.y,0,1)*maxY};
}
// Position and size are independent of viewport pixels, including keyboard changes.
export function pipGeometry(bounds,preferred=128,ratio={x:1,y:0}){
 const width=Math.max(0,bounds.width),height=Math.max(0,bounds.height);
 const target=clamp(Number.isFinite(preferred)?preferred:128,72,240);
 const h=Math.min(target,height,width/0.75),w=h*.75;
 return {width:w,height:h,...pipPosition(bounds,{width:w,height:h},ratio)};
}
export function pipRatio(bounds,size,left,top,previous={x:1,y:0}){
 const x=bounds.width-size.width,y=bounds.height-size.height;
 return {x:x>0?clamp((left-bounds.left)/x,0,1):previous.x,y:y>0?clamp((top-bounds.top)/y,0,1):previous.y};
}
export function layoutFloatingVideo(el,bounds,c,positionKey,sizeKey,defaultSize){
 if(!el||!bounds)return null;
 const g=pipGeometry(bounds,c[sizeKey]??defaultSize,c[positionKey]??{x:1,y:0});
 Object.assign(el.style,{width:g.width+'px',height:g.height+'px',maxWidth:bounds.width+'px',maxHeight:bounds.height+'px',left:g.left+'px',top:g.top+'px',right:'auto',bottom:'auto'});
 el.style.visibility=g.height<1?'hidden':'';
 const grip=el.parentElement?.querySelector('[data-pip-resize="'+el.id+'"]');
 if(grip){grip.hidden=g.width<36||g.height<40;grip.style.left=(g.left+g.width-30)+'px';grip.style.top=(g.top+g.height-30)+'px';}
 return g;
}
// One finger moves the preview; two fingers resize it. A separate accessible button
// cycles size. A cancelled or multi-pointer gesture never activates the preview.
export function bindFloatingVideo(el,c,{bounds,place,positionKey,sizeKey,defaultSize=128,onTap}){
 const points=new Map();let drag=null,pinch=null,acted=false;
 const point=e=>({x:e.clientX,y:e.clientY});
 const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
 const resize=value=>{c[sizeKey]=clamp(value,72,240);place();};
 const size=()=>({width:el.offsetWidth,height:el.offsetHeight});
 const position=(left,top)=>{const b=bounds();if(b){c[positionKey]=pipRatio(b,size(),left,top,c[positionKey]);place();}};
 const startDrag=p=>({x:p.x,y:p.y,left:el.offsetLeft,top:el.offsetTop});
 const grip=document.createElement('button');grip.type='button';grip.className='pip-resize';grip.dataset.pipResize=el.id;grip.setAttribute('aria-label','Küçük görüntü boyutunu değiştir');grip.title='Görüntü boyutunu değiştir';grip.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 4h6v6M20 4l-6 6M10 20H4v-6M4 20l6-6"/></svg>';el.after(grip);
 grip.onclick=e=>{e.stopPropagation();const h=c[sizeKey]??defaultSize;resize(h<150?180:h<210?240:96);};
 el.onpointerdown=e=>{if(e.button!==0||points.has(e.pointerId)||points.size>=2)return;e.stopPropagation();const p=point(e);if(!points.size){acted=false;drag=startDrag(p);pinch=null;}points.set(e.pointerId,p);try{el.setPointerCapture(e.pointerId);}catch{}if(points.size===2){const [a,b]=points.values();pinch={distance:Math.max(1,distance(a,b)),height:el.offsetHeight,centerX:el.offsetLeft+el.offsetWidth/2,centerY:el.offsetTop+el.offsetHeight/2};acted=true;}};
 el.onpointermove=e=>{if(!points.has(e.pointerId))return;points.set(e.pointerId,point(e));if(points.size===2&&pinch){const [a,b]=points.values();resize(pinch.height*distance(a,b)/pinch.distance);position(pinch.centerX-el.offsetWidth/2,pinch.centerY-el.offsetHeight/2);return;}if(!drag)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(!acted&&Math.hypot(dx,dy)<6)return;acted=true;position(drag.left+dx,drag.top+dy);};
 const finish=(e,cancelled)=>{if(!points.has(e.pointerId))return;points.delete(e.pointerId);if(cancelled)acted=true;if(points.size){drag=startDrag([...points.values()][0]);pinch=null;acted=true;return;}const tap=!acted&&!cancelled;drag=pinch=null;if(tap)onTap();};
 el.onpointerup=e=>finish(e,false);el.onpointercancel=el.onlostpointercapture=e=>finish(e,true);
 el.onclick=e=>{e.stopPropagation();if(e.detail===0)onTap();};
 el.onkeydown=e=>{if(['Enter',' '].includes(e.key)){e.preventDefault();onTap();}else if(['+','=','-'].includes(e.key)){e.preventDefault();resize((c[sizeKey]??defaultSize)+(e.key==='-'?-24:24));}else if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();position(el.offsetLeft+(e.key==='ArrowLeft'?-24:e.key==='ArrowRight'?24:0),el.offsetTop+(e.key==='ArrowUp'?-24:e.key==='ArrowDown'?24:0));}};
 place();
}
export function urlParts(value){
 const raw=String(value??'');const chunks=[];let end=0;
 for(const match of raw.matchAll(/(?:https?:\/\/|www\.)[^\s<>"'\u0000-\u001f]+/gi)){
  let text=match[0].replace(/[.,;:!?]+$/,'');
  for(const [open,close] of [['(',')'],['[',']'],['{','}']])while(text.endsWith(close)&&text.split(close).length>text.split(open).length)text=text.slice(0,-1);
  let url;try{url=new URL(/^www\./i.test(text)?'https://'+text:text);if(!['https:','http:'].includes(url.protocol)||url.username||url.password||!url.hostname||url.hostname==='appassets.androidplatform.net'||url.href.length>8192)continue;}catch{continue;}
  chunks.push({text:raw.slice(end,match.index)},{text,url:url.href});end=match.index+text.length;
 }
 chunks.push({text:raw.slice(end)});return chunks;
}
export function mapUrls(lat,lng){
 if(!Number.isFinite(lat)||!Number.isFinite(lng)||Math.abs(lat)>90||Math.abs(lng)>180)return null;
 const q=new URLSearchParams({mlat:String(lat),mlon:String(lng)});
 const displayLat=clamp(lat,-85,85),d=.008,dx=Math.min(.12,d/Math.max(.08,Math.cos(displayLat*Math.PI/180)));
 const bbox=[clamp(lng-dx,-180,180),clamp(displayLat-d,-85.051,85.051),clamp(lng+dx,-180,180),clamp(displayLat+d,-85.051,85.051)].join(',');
 const frame=new URLSearchParams({bbox,layer:'mapnik',marker:`${lat},${lng}`});
 return {external:'https://www.openstreetmap.org/?'+q+'#map=16/'+lat+'/'+lng,embed:'https://www.openstreetmap.org/export/embed.html?'+frame};
}
export function effectiveStatus(foreground,connected,preferred='online'){return foreground&&connected?(['busy','offline'].includes(preferred)?preferred:'online'):'offline';}
export function callControlState(c,now,tap=false){
 let controlsHidden=!!c.controlsHidden,controlsUntil=c.controlsUntil??now+10000;
 if(!controlsHidden&&now>=controlsUntil)controlsHidden=true;
 if(tap){controlsHidden=!controlsHidden;controlsUntil=controlsHidden?0:now+10000;}
 return {controlsHidden,controlsUntil};
}

// Match events to a single call instance; legacy servers omit callId.
export function callEventMatches(call,event){
 return !!(call&&event&&(!event.room||event.room===call.room?.id)&&(!call.callId||event.callId===call.callId));
}

// A presentation receipt can be upgraded, but a delayed snapshot must not downgrade it.
export function applyAlertReceipt(call,status){
 const labels={alerted:"Çalıyor… (zil bildirimi)",silent:"Çağrı ulaştı (sessiz)",displayed:"Çağrı ulaştı (ses doğrulanmadı)"};
 if(!call?.offerer||call.started||call.pc||call.alertAccepted||!Object.hasOwn(labels,status))return false;
 if(call.alertStatus&&call.alertStatus!=="displayed")return false;
 call.alertStatus=status;call.phase=labels[status];return true;
}

// Current invitation reconciliation is deliberately limited to unaccepted incoming calls.
export function currentCallAction(call,current){
 const ringing=!!(current?.incoming&&current.ringing!==false);
 if(!call)return ringing?'open':'none';
 if(!call.incoming||call.accepting)return 'none';
 return ringing&&callEventMatches(call,current)?'none':'close';
}

// A bounded, image-only map preview. No remote document receives the native bridge.
export function mapPreview(lat,lng){
 if(!mapUrls(lat,lng)||Math.abs(lat)>85.05112878)return null;
 const z=15,n=2**z,rad=lat*Math.PI/180;
 const px=((lng+180)/360*n)*256,py=clamp((1-Math.asinh(Math.tan(rad))/Math.PI)/2*n*256,0,n*256-0.001);
 const x0=Math.floor((px-128)/256),y0=Math.floor((py-128)/256),tiles=[];
 for(let row=0;row<2;row++)for(let col=0;col<2;col++){const x=((x0+col)%n+n)%n,y=y0+row;if(y>=0&&y<n)tiles.push({col,row,url:`https://tile.openstreetmap.org/${z}/${x}/${y}.png`});}
 return {x:px-x0*256,y:py-y0*256,tiles};
}
export function liveLocationLabel(p,now=Date.now()){
 if(p?.live===true)return Number.isFinite(p.expires)&&p.expires>now?'Canlı konum':'Canlı konum sona erdi';
 return p?.text==='Canlı konum sona erdi'?'Canlı konum sona erdi':'Konum';
}
