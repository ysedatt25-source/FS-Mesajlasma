// Ephemeral peer-to-peer call controls. Nothing is written into chat history.
export const CALL_REACTIONS=Object.freeze(['❤️','👍','😂','👏','🎉','😍','😮','😢']);
const MODES=['off','camera','screen'];
export const CALL_CHANNEL='fs-call-extras-v1';
export function decodeCallExtra(raw){
 if(typeof raw!=='string'||raw.length>160)return null;
 try{const b=JSON.parse(raw);if(!b||typeof b!=='object')return null;
 if(b.type==='media'&&MODES.includes(b.mode))return {type:'media',mode:b.mode};
 if(b.type==='reaction'&&CALL_REACTIONS.includes(b.emoji))return {type:'reaction',emoji:b.emoji};}catch{}return null;
}
export function createCallExtras({pc,stream,initialVideo,valid,mediaDevices,videoConstraints,onChange=()=>{},onReaction=()=>{},clock=()=>Date.now()}){
 let mode=initialVideo?'camera':'off',remote=mode,channel=null,closed=false,busy=false,peerReady=false,lastSent=-Infinity,lastReceived=-Infinity;
 let facing=stream.getVideoTracks()[0]?.getSettings?.().facingMode==='environment'?'environment':'user';
 const alive=()=>!closed&&valid();
 const transport=()=>alive()&&channel?.readyState==='open';
 const ready=()=>transport()&&peerReady;
 const slot=()=>pc.getTransceivers().find(t=>t.receiver?.track?.kind==='video'&&['sendrecv','sendonly'].includes(t.currentDirection));
 const notify=()=>{if(alive())onChange();};
 const send=b=>{if(!transport()||channel.bufferedAmount>8192)return false;try{channel.send(JSON.stringify(b));return true;}catch{return false;}};
 function bind(ch){if(!alive()||channel||ch.label!==CALL_CHANNEL){ch.close();return;}channel=ch;
  ch.onopen=()=>{if(alive()){send({type:'media',mode});notify();}};
  ch.onclose=()=>{peerReady=false;mediaDevices?.cancelDisplay?.();if(alive()){if(mode==='screen'){stream.getVideoTracks().forEach(t=>{t.stop();stream.removeTrack(t);});mode='off';void slot()?.sender.replaceTrack(null).catch(()=>{});}notify();}};
  ch.onmessage=e=>{if(!transport())return;const b=decodeCallExtra(e.data);if(!b)return;
   if(b.type==='media'){const first=!peerReady;peerReady=true;if(first)send({type:'media',mode});if(first||remote!==b.mode){remote=b.mode;notify();}}else if(peerReady&&clock()-lastReceived>=700){lastReceived=clock();onReaction(b.emoji);}};
  if(ch.readyState==='open')ch.onopen();
 }
 async function setMode(next){
  if(!alive()||busy||!MODES.includes(next))throw Error('Görüntü değiştirilemiyor.');
  if(next===mode)return;
  const tx=slot();if(next!=='off'&&(!tx||!ready()))throw Error('Bu özellik için iki cihazda da güncel sürüm ve bağlı görüşme gerekiyor.');
  if(next==='screen'&&typeof mediaDevices?.getDisplayMedia!=='function')throw Error('Bu cihazda ekran paylaşımı desteklenmiyor.');
  busy=true;let captured=null,track=null,committed=false;
  try{
   if(next!=='off'){
    captured=next==='screen'?await mediaDevices.getDisplayMedia({video:true,audio:false}):await mediaDevices.getUserMedia({video:videoConstraints(),audio:false});
    track=captured.getVideoTracks()[0];if(!ready()||!track||track.readyState==='ended')throw Error('Görüntü alınamadı.');
    try{track.contentHint=next==='screen'?'text':'detail';}catch{}
   }
   // Turning off must stop capture even if replaceTrack fails.
   const previous=stream.getVideoTracks();
   if(next==='off')previous.forEach(t=>{t.stop();stream.removeTrack(t);});
   try{if(tx)await tx.sender.replaceTrack(track);}catch(err){if(next==='off'&&alive()){mode='off';send({type:'media',mode});notify();}throw err;}
   if(!alive()||(!ready()&&next!=='off')){if(alive()){previous.forEach(t=>{t.stop();stream.removeTrack(t);});mode='off';void tx?.sender.replaceTrack(null).catch(()=>{});notify();}throw Error('Görüşme bağlantısı değişti.');}
   previous.forEach(t=>{t.stop();stream.removeTrack(t);});
   if(track?.readyState==='ended'){mode='off';void tx.sender.replaceTrack(null).catch(()=>{});send({type:'media',mode});notify();throw Error('Görüntü yakalama sona erdi.');}
   if(track){attachTrack(track,tx);if(next==='camera')facing=track.getSettings?.().facingMode==='environment'?'environment':'user';}
   committed=true;mode=next;send({type:'media',mode});notify();
  }finally{if(captured)for(const t of captured.getTracks())if(!committed||t!==track)t.stop();busy=false;}
 }
 function attachTrack(track,tx){stream.addTrack(track);track.addEventListener('ended',()=>{if(alive()&&stream.getVideoTracks().includes(track)){stream.removeTrack(track);mode='off';void tx.sender.replaceTrack(null).catch(()=>{});send({type:'media',mode});notify();}},{once:true});}
 // Replace the existing video sender only; preserve microphone, SDP and call ID.
 // Mobile cameras may be mutually exclusive: release the old camera only after
 // a device-busy failure, then try to restore it if switching cannot succeed.
 async function switchCamera(){
  if(!ready()||busy||mode!=='camera')throw Error('Kamera değiştirmek için bağlı görüşme gerekiyor.');
  const tx=slot(),old=stream.getVideoTracks()[0];if(!tx||!old)throw Error('Kamera bulunamadı.');
  const original=facing,next=facing==='user'?'environment':'user';let released=false,committed=false,captured=null;
  busy=true;
  const release=()=>{stream.removeTrack(old);old.stop();released=true;};
  async function acquire(target){
   const base=videoConstraints();const constraints={...(typeof base==='object'&&base?base:{}),facingMode:{exact:target}};
   const media=await mediaDevices.getUserMedia({video:constraints,audio:false});const track=media.getVideoTracks()[0];
   if(!ready()||!track||track===old||track.readyState==='ended'){for(const t of media.getTracks())if(t!==old)t.stop();throw Error('Kamera görüntüsü alınamadı.');}
   captured=media;try{track.contentHint='detail';}catch{}return track;
  }
  async function install(track,target){
   await tx.sender.replaceTrack(track);if(!ready()||track.readyState==='ended')throw Error('Görüşme bağlantısı değişti.');
   if(!released)release();attachTrack(track,tx);facing=target;committed=true;notify();
  }
  function cleanup(){if(captured)for(const t of captured.getTracks())if(!committed||!stream.getVideoTracks().includes(t))t.stop();captured=null;}
  try{
   let track;try{track=await acquire(next);}catch(e){if(!ready()||!['NotReadableError','AbortError'].includes(e?.name))throw e;release();track=await acquire(next);}
   await install(track,next);
  }catch(error){
   cleanup();if(released&&ready()){
    try{const restored=await acquire(original);await install(restored,original);}catch{if(alive()){mode='off';void tx.sender.replaceTrack(null).catch(()=>{});send({type:'media',mode});notify();}}
   }else if(released&&alive()){mode='off';void tx.sender.replaceTrack(null).catch(()=>{});send({type:'media',mode});notify();}else if(!released&&alive()&&old.readyState==='live'&&tx.sender.track!==old){try{await tx.sender.replaceTrack(old);}catch{release();mode='off';void tx.sender.replaceTrack(null).catch(()=>{});send({type:'media',mode});notify();}}
   throw Error('Kamera değiştirilemedi. '+(mode==='off'?'Kamerayı tekrar açabilirsiniz.':'Mevcut görüşme korunuyor.'));
  }finally{cleanup();busy=false;}
 }
 return {bind,switchCamera,get canSwitchCamera(){return !!(ready()&&mode==='camera'&&slot()&&!busy);},get facing(){return facing;},legacyCamera(enabled){if(!ready()&&mode!=='screen')mode=enabled?'camera':'off';},get mode(){return mode;},get remote(){return remote;},get ready(){return !!ready();},get canVideo(){return !!(ready()&&slot());},get canShare(){return !!(ready()&&slot()&&typeof mediaDevices?.getDisplayMedia==='function');},setMode,
  react(emoji){if(!ready()||!CALL_REACTIONS.includes(emoji)||clock()-lastSent<700||!send({type:'reaction',emoji}))return false;lastSent=clock();onReaction(emoji);return true;},
  close(){closed=true;mediaDevices?.cancelDisplay?.();if(channel){channel.onopen=channel.onclose=channel.onmessage=null;channel.close();}stream.getVideoTracks().forEach(t=>t.stop());}};
}
