// History cards reflect server state, never infer a completed call from its age.
export function callHistoryInfo(c,self){
 const outgoing=c.caller===self,video=c.video===true||c.video===1;
 const status=['missed','rejected','ringing','ended','accepted','connected','disconnected','device_changed'].includes(c.status)?c.status:'ended';
 const elapsed=Number.isFinite(c.connected)&&Number.isFinite(c.ended)&&c.connected>0?Math.max(0,Math.floor((c.ended-c.connected)/1000)):0;
 const title=status==='missed'?'Cevapsız Arama':status==='rejected'?'Reddedilen Arama':`${outgoing?'Giden':'Gelen'} ${video?'Görüntülü ':''}Arama`;
 const detail=status==='ringing'?'Aranıyor':status==='missed'?'Cevapsız':status==='rejected'?'Reddedildi':status==='device_changed'?'Cihaz değişti':status==='disconnected'?'Bağlantı kesildi':elapsed?`${Math.floor(elapsed/60)}:${String(elapsed%60).padStart(2,'0')}`:'Sona erdi';
 return {outgoing,video,status,elapsed,title,detail,failed:['missed','rejected','disconnected','device_changed'].includes(status)};
}
export function sameCallHistoryKind(a,b){return !!a&&!!b&&a.outgoing===b.outgoing&&a.video===b.video&&a.status===b.status;}
