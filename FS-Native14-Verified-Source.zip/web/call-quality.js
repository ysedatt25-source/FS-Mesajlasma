// Prefer camera detail. These are ideals, never mandatory constraints or a fixed cap.
export function videoCaptureConstraints(){
  return {facingMode:'user',width:{ideal:3840},height:{ideal:2160},frameRate:{ideal:30}};
}
function finite(v){return typeof v==='number'&&Number.isFinite(v);}
function video(r){return (r.kind||r.mediaType)==='video';}
function lossDelta(now,previous){
  if(!previous||!finite(now.packetsLost)||!finite(previous.packetsLost))return null;
  const lost=now.packetsLost-previous.packetsLost;
  const received=finite(now.packetsReceived)&&finite(previous.packetsReceived)?now.packetsReceived-previous.packetsReceived:null;
  if(lost<0||received===null||received<0||lost+received<30)return null;
  return lost/(lost+received);
}
export function readCallStats(stats,previous=new Map()){
  const reports=new Map();stats.forEach(r=>reports.set(r.id,r));
  const pairs=[...reports.values()].filter(r=>r.type==='candidate-pair'&&r.state==='succeeded');
  const outgoing=[...reports.values()].filter(r=>r.type==='outbound-rtp'&&video(r)&&r.active!==false);
  const videoTransports=new Set(outgoing.map(r=>r.transportId).filter(Boolean));
  const selected=[...reports.values()].filter(r=>r.type==='transport'&&r.selectedCandidatePairId&&(!videoTransports.size||videoTransports.has(r.id))).map(r=>reports.get(r.selectedCandidatePairId)).filter(r=>r?.state==='succeeded');
  const nominated=pairs.filter(r=>r.nominated===true);
  const activePairs=selected.length?selected:!videoTransports.size&&nominated.length===1?nominated:[];
  const rates=activePairs.map(p=>p.availableOutgoingBitrate).filter(v=>finite(v)&&v>0);
  const delays=activePairs.map(p=>p.currentRoundTripTime).filter(v=>finite(v)&&v>=0);
  const bandwidth=rates.length?Math.min(...rates):null;
  const rtt=delays.length?Math.max(...delays):null;
  let sendLoss=null,receiveLoss=null,remoteSize=null;
  let cpuLimited=false,bandwidthLimited=false,framePressure=false,outgoingFps=null,sourceFps=null,localSize=null,sendBitrate=null,receiveFps=null;
  // Only active outbound video participates. Camera rate is measured rather
  // than assuming every camera can provide 30 FPS in every lighting condition.
  for(const r of outgoing){
    if(r.qualityLimitationReason==='cpu')cpuLimited=true;
    if(r.qualityLimitationReason==='bandwidth')bandwidthLimited=true;
    const source=reports.get(r.mediaSourceId), fps=r.framesPerSecond, capture=source?.framesPerSecond;
    if(finite(r.frameWidth)&&finite(r.frameHeight)&&r.frameWidth>0&&r.frameHeight>0){if(!localSize||r.frameWidth*r.frameHeight>localSize.width*localSize.height)localSize={width:r.frameWidth,height:r.frameHeight};}
    const prev=previous.get(r.id);if(prev&&finite(r.timestamp)&&finite(prev.timestamp)&&r.timestamp>prev.timestamp&&finite(r.bytesSent)&&finite(prev.bytesSent)&&r.bytesSent>=prev.bytesSent){const bps=(r.bytesSent-prev.bytesSent)*8000/(r.timestamp-prev.timestamp);sendBitrate=(sendBitrate??0)+bps;}
    if(finite(fps)&&fps>=0)outgoingFps=Math.min(outgoingFps??fps,fps);
    if(finite(capture)&&capture>0)sourceFps=Math.max(sourceFps??capture,capture);
    // Slow cameras, muted tracks, and missing counters are not evidence of encoder overload.
    if(finite(fps)&&finite(capture)&&capture>=15&&fps>=0&&fps<capture*.55&&
      (r.qualityLimitationReason==='cpu'||r.qualityLimitationReason==='bandwidth'))framePressure=true;
  }
  const next=new Map();
  for(const r of reports.values()){
    if(r.type==='remote-inbound-rtp'&&video(r)){
      // RTCP fractionLost refers to the most recent reporting interval.
      const f=finite(r.fractionLost)&&r.fractionLost>=0&&r.fractionLost<=1?r.fractionLost:lossDelta(r,previous.get(r.id));
      if(f!==null)sendLoss=Math.max(sendLoss??0,f);
    }
    if(r.type==='inbound-rtp'){
      const f=lossDelta(r,previous.get(r.id));if(f!==null)receiveLoss=Math.max(receiveLoss??0,f);
      if(video(r)&&r.framesDecoded>0&&finite(r.frameWidth)&&finite(r.frameHeight)&&r.frameWidth>0&&r.frameHeight>0){
        if(!remoteSize||r.frameWidth*r.frameHeight>remoteSize.width*remoteSize.height)remoteSize={width:r.frameWidth,height:r.frameHeight};
        if(finite(r.framesPerSecond)&&r.framesPerSecond>=0)receiveFps=Math.max(receiveFps??0,r.framesPerSecond);
      }
    }
    if(r.type==='remote-inbound-rtp'||r.type==='inbound-rtp')next.set(r.id,{packetsReceived:r.packetsReceived,packetsLost:r.packetsLost});
    if(r.type==='outbound-rtp'&&video(r)&&r.active!==false)next.set(r.id,{bytesSent:r.bytesSent,timestamp:r.timestamp});
  }
  return {bandwidth,rtt,sendLoss,receiveLoss,remoteSize,cpuLimited,bandwidthLimited,framePressure,outgoingFps,sourceFps,localSize,sendBitrate,receiveFps,next};
}
// Let WebRTC's congestion controller choose the actual bitrate. No competing
// fixed bitrate ceilings, artificial resolution caps or repeated renegotiations.
export function createCallQuality(){
  let mode='maintain-resolution',bad=0,good=0,flowBad=0,previous=new Map(),busy=false,connection=null;
  const applied=new WeakMap();
  return {async sample(pc,isCurrent=()=>true){
    if(busy||!isCurrent()||!pc?.getStats)return null;
    busy=true;
    try{
      const samplingState=pc.connectionState;
      const stats=await pc.getStats();if(!isCurrent())return null;
      if(samplingState!==pc.connectionState){previous=new Map();bad=good=flowBad=0;connection=pc.connectionState;return null;}
      const connected=pc.connectionState==='connected';
      if(connection!==pc.connectionState){previous=new Map();bad=good=flowBad=0;connection=pc.connectionState;}
      const m=readCallStats(stats,previous);previous=m.next;
      const videoActive=(pc.getSenders?.()||[]).some(s=>s.track?.kind==='video'&&s.track.enabled!==false&&s.track.readyState!=='ended');
      const severe=(m.bandwidth!==null&&m.bandwidth<700000)||(m.sendLoss!==null&&m.sendLoss>=.12)||
        (m.rtt!==null&&m.rtt>.75&&m.sendLoss!==null&&m.sendLoss>=.04)||m.cpuLimited||m.framePressure;
      const healthy=!m.cpuLimited&&!m.bandwidthLimited&&!m.framePressure&&
        (m.bandwidth===null||m.bandwidth>=1500000)&&(m.sendLoss===null||m.sendLoss<.03)&&(m.rtt===null||m.rtt<.45)&&
        (m.bandwidth!==null||m.sendLoss!==null||m.rtt!==null);
      if(connected&&videoActive){
        bad=severe?Math.min(4,bad+1):0;good=healthy?Math.min(3,good+1):0;
        flowBad=m.framePressure?Math.min(4,flowBad+1):0;
        if(flowBad>=3)mode='maintain-framerate';
        else if(bad>=2&&mode!=='maintain-framerate')mode='balanced';
        if(good>=3)mode='maintain-resolution';
      }else{bad=good=flowBad=0;previous=new Map();}
      for(const sender of pc.getSenders?.()||[]){
        if(!isCurrent())return null;
        if(sender.track?.kind!=='video'||sender.track.enabled===false||sender.track.readyState==='ended'||!sender.getParameters||!sender.setParameters)continue;
        try{
          if(applied.get(sender)?.unsupported===mode&&applied.get(sender)?.track===sender.track)continue;
          const params=sender.getParameters();if(!params.encodings?.length)continue;
          if(params.degradationPreference!==mode){params.degradationPreference=mode;await sender.setParameters(params);}
          applied.set(sender,{track:sender.track});
        }catch(error){
          // Older Android WebViews may not implement this hint. Preserve the
          // native congestion controller, and retry only negotiation-state errors.
          if(error?.name!=='InvalidStateError'&&error?.name!=='InvalidModificationError')applied.set(sender,{unsupported:mode,track:sender.track});
        }
      }
      if(!isCurrent())return null;
      const weak=mode!=='maintain-resolution'||(m.rtt!==null&&m.rtt>.5)||(m.receiveLoss!==null&&m.receiveLoss>.08)||severe;
      const label=pc.connectionState==='connected'?'Bağlantı kuruldu':pc.connectionState==='disconnected'?'Yeniden bağlanıyor…':'Bağlanıyor…';
      return {mode,label,weak,remoteSize:connected?m.remoteSize:null,metrics:connected?{localSize:videoActive?m.localSize:null,remoteSize:m.remoteSize,sendFps:videoActive?m.outgoingFps:null,receiveFps:m.receiveFps,sendBitrate:videoActive?m.sendBitrate:null,rtt:m.rtt,sendLoss:m.sendLoss,receiveLoss:m.receiveLoss}:null};
    }finally{busy=false;}
  }};
}
export function preferVideoDetail(track){
  if(track?.kind==='video'&&'contentHint' in track){try{track.contentHint='detail';}catch{}}
}
