// Recover the existing peer connection; never reopen the mic or camera.
export const RECOVERY_GRACE_MS=3000;
export const RECOVERY_LIMIT_MS=60000;
export const RECOVERY_RETRY_MS=7000;
export const RECOVERY_MAX_ATTEMPTS=8;
// Only an authenticated, current signaling socket may carry a call event.
export class CallSignalUnavailable extends Error {}
export function audioCaptureConstraints(){return {echoCancellation:true,noiseSuppression:true,autoGainControl:true,channelCount:{ideal:1},sampleRate:{ideal:48000}};}
export function preferSpeech(track){if(track?.kind==='audio'&&'contentHint' in track){try{track.contentHint='speech';}catch{}}}
// Best-effort audio RTP priority. Only supported parameter fields are changed;
// never rewrite SDP or cap audio/video bitrate. Retry after negotiation if needed.
export function createAudioPriority(){
 const applied=new WeakMap();let busy=false;
 return async function prioritize(pc,valid=()=>true){
  if(busy||!valid()||pc?.connectionState!=='connected'||pc.signalingState!=='stable')return;
  busy=true;
  try{for(const sender of pc.getSenders?.()||[]){
   if(!valid())return;
   const track=sender.track;if(track?.kind!=='audio'||track.readyState==='ended'||!sender.getParameters||!sender.setParameters)continue;
   if(applied.get(sender)===track)continue;
   try{
    const p=sender.getParameters();if(!p.encodings?.length)continue;
    let changed=false;
    for(const e of p.encodings){for(const field of ['priority','networkPriority'])if(typeof e[field]==='string'&&e[field]!=='high'){e[field]='high';changed=true;}}
    if(changed)await sender.setParameters(p);
    if(valid()&&sender.track===track)applied.set(sender,track);
   }catch(error){if(!['InvalidStateError','InvalidModificationError','OperationError'].includes(error?.name))applied.set(sender,track);}
  }}finally{busy=false;}
 };
}
export function createIceRecovery({pc,offerer,send,valid,canSignal=()=>true,clock=()=>Date.now(),onExpired=()=>{}}){
 let since=null,last=-Infinity,attempts=0,busy=false,closed=false,requested=false,expired=false,waiting=false;
 const alive=()=>!closed&&valid();
 const healthy=()=>pc.connectionState==='connected'&&!['failed','disconnected','checking'].includes(pc.iceConnectionState);
 const unhealthy=()=>['failed','disconnected'].includes(pc.connectionState)||['failed','disconnected'].includes(pc.iceConnectionState);
 const reset=()=>{since=null;attempts=0;last=-Infinity;requested=false;expired=false;};
 async function tick(){
  if(!alive()||busy)return;
  // The initial SDP offer can be lost while the signaling socket reconnects.
  // Retry the same offer, without restarting ICE before an answer exists.
  const initial=offerer&&pc.signalingState==='have-local-offer'&&pc.localDescription?.type==='offer'&&!pc.remoteDescription;
  if(healthy()&&!requested&&(!waiting||since===null)){reset();return;}
  if(expired)return;
  if(!unhealthy()&&!requested&&!initial&&since===null)return;
  const now=clock();since??=now;
  if(now-since>=RECOVERY_LIMIT_MS){
   // A lost restart answer must not terminate a call whose media still works.
   if(healthy()){reset();return;}
   expired=true;onExpired();return;
  }
  if(now-since<RECOVERY_GRACE_MS||!canSignal()||now-last<RECOVERY_RETRY_MS||attempts>=RECOVERY_MAX_ATTEMPTS)return;
  if(!pc.localDescription||(!pc.remoteDescription&&!initial))return;
  busy=true;
  try{
   if(initial){send('offer',{description:pc.localDescription});last=now;attempts++;return;}
   if(!offerer){send('restart-request',{});last=now;attempts++;requested=false;return;}
   if(pc.signalingState==='have-local-offer'&&waiting){send('offer',{description:pc.localDescription});last=now;attempts++;return;}
   if(!alive()||pc.signalingState!=='stable')return;
   const offer=await pc.createOffer({iceRestart:true});if(!alive())return;
   await pc.setLocalDescription(offer);if(!alive())return;
   waiting=true;requested=false;
   if(!canSignal())return; // Preserve the generated offer for the next authenticated socket.
   send('offer',{description:pc.localDescription||offer});last=now;attempts++;
  }catch{ /* signaling and ICE operations may fail transiently; retry within the window */ }finally{busy=false;}
 }
 return {tick,request(){if(alive()&&offerer&&!expired){requested=true;since??=clock();}},
  wake(){if(!alive()||expired)return; if(unhealthy()||requested||waiting||(offerer&&pc.signalingState==='have-local-offer'&&!pc.remoteDescription)){since??=clock();last=-Infinity;}return tick();},
  answered(){waiting=false;},close(){closed=true;}};
}
// Retransmitted SDP can contain candidates gathered after its first delivery.
// Ignore only trickled candidate lines when recognizing the same offer.
export function sameOffer(a,b){const clean=d=>String(d?.sdp||'').split(/\r?\n/).filter(x=>!/^a=(candidate:|end-of-candidates$)/.test(x)).join('\n');return !!(a?.sdp&&b?.sdp&&a.type===b.type&&clean(a)===clean(b));}
export function iceUfrags(description){return new Set([...String(description?.sdp||'').matchAll(/^a=ice-ufrag:([^\r\n]+)\r?$/gm)].map(m=>m[1].trim()));}
export function isRestartOffer(previous,next){const a=iceUfrags(previous),b=iceUfrags(next);return a.size>0&&b.size>0&&[...b].some(x=>!a.has(x));}
export function candidateMatches(description,candidate){const fragments=iceUfrags(description);const fragment=candidate?.usernameFragment||String(candidate?.candidate||'').match(/(?:^|\s)ufrag\s+(\S+)/)?.[1];return !fragment||!fragments.size||fragments.has(fragment);}
// A candidate from the next ICE generation can arrive ahead of its SDP.
// Repeated trickle delivery must not exhaust the bounded queue. A transient
// InvalidStateError can occur while remote SDP is being applied; retry on drain.
export function queueIce(pending,candidate){
 if(!candidate||pending.length>=128)return;
 const key=c=>JSON.stringify([c.candidate,c.sdpMid??null,c.sdpMLineIndex??null,c.usernameFragment??null]);
 const id=key(candidate);if(!pending.some(c=>key(c)===id))pending.push(candidate);
}
export async function acceptIce(pc,pending,candidate){
 if(!candidate)return;
 if(!pc.remoteDescription||!candidateMatches(pc.remoteDescription,candidate)){queueIce(pending,candidate);return;}
 try{await pc.addIceCandidate(candidate);}catch(e){if(e?.name==='InvalidStateError')queueIce(pending,candidate);else if(e?.name!=='OperationError')throw e;}
}
export async function drainIce(pc,pending,valid=()=>true){for(const c of pending.splice(0)){if(!valid())return;if(candidateMatches(pc.remoteDescription,c))await acceptIce(pc,pending,c);}}

// When signaling was offline, a repeated SDP can be the only delivery of ICE
// candidates gathered since the first description. Do not renegotiate the SDP.
export async function replaySdpCandidates(pc,description,valid=()=>true){
 const previous=pc.remoteDescription;
 if(!valid()||!sameOffer(previous,description))return 0;
 const read=d=>{let index=-1,mid=null,ufrag=null;const rows=[];for(const line of String(d.sdp).split(/\r?\n/)){
  if(line.startsWith('m=')){index++;mid=null;ufrag=null;}
  else if(line.startsWith('a=mid:'))mid=line.slice(6).trim();
  else if(line.startsWith('a=ice-ufrag:'))ufrag=line.slice(12).trim();
  else if(index>=0&&line.startsWith('a=candidate:'))rows.push({candidate:line.slice(2),sdpMid:mid,sdpMLineIndex:index,...(ufrag?{usernameFragment:ufrag}:{})});
 }return rows;};
 const key=c=>`${c.sdpMLineIndex}:${c.candidate}`;
 const seen=new Set(read(previous).map(key));let count=0;
 for(const candidate of read(description)){
  if(!valid()||!sameOffer(pc.remoteDescription,description))break;
  const k=key(candidate);if(seen.has(k))continue;seen.add(k);
  if(!candidateMatches(pc.remoteDescription,candidate))continue;
  try{await pc.addIceCandidate(candidate);count++;}catch(error){if(error?.name!=='OperationError'&&error?.name!=='InvalidStateError')throw error;}
 }
 return count;
}
