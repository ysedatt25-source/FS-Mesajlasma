// Device-local, allowlisted ringtone selection. Native notifications own Android
// ringing; browser playback is used only without the native ringtone bridge.
export const RINGTONES=Object.freeze([
 ['system','Telefonun varsayılanı'],['classic','Klasik'],['crystal','Kristal'],
 ['soft','Yumuşak'],['pulse','Nabız'],['aurora','Aurora']
].map(([id,label])=>Object.freeze({id,label})));
export const RINGTONE_PREVIEW_MS=30000;
export const CUSTOM_RINGTONES=Object.freeze([{id:'sura_derinlere',label:'Sura İskenderli – Derinlere İniyorum'},{id:'sezen_tukenecegiz',label:'Sezen Aksu – Tükeneceğiz'}].map(Object.freeze));
export function validRingtone(id){return RINGTONES.some(t=>t.id===id)||CUSTOM_RINGTONES.some(t=>t.id===id);}
export function normalizeRingtone(id){return validRingtone(id)?id:'system';}
export function ringtonePath(id){id=normalizeRingtone(id);return `ringtones/${CUSTOM_RINGTONES.some(t=>t.id===id)||id==='system'?'classic':id}.wav`;}
export function ringtoneLabel(id){return [...RINGTONES,...CUSTOM_RINGTONES].find(t=>t.id===normalizeRingtone(id)).label;}
export function createRingtones({native=()=>null,storage=()=>null,makeAudio=src=>new window.Audio(src),schedule=setTimeout,cancel=clearTimeout}={}){
 const key='fs-call-ringtone-v1',muteKey='fs-call-muted-v1';let audio=null,timer=null,mode=null,epoch=0;
 const bridge=()=>{const n=native();return typeof n?.getCallRingtone==='function'&&typeof n?.setCallRingtone==='function'?n:null;};
 function selected(){try{const n=bridge();return normalizeRingtone(n?n.getCallRingtone():storage()?.getItem(key));}catch{return 'system';}}
 function save(id){if(!validRingtone(id))return false;try{const n=bridge();if(n)return n.setCallRingtone(id)===true;if(CUSTOM_RINGTONES.some(t=>t.id===id))return false;const s=storage();if(!s)return false;s.setItem(key,id);return s.getItem(key)===id;}catch{return false;}}
 function muted(){try{const n=native();return n?typeof n.getCallMuted==='function'&&n.getCallMuted()===true:storage()?.getItem(muteKey)==='true';}catch{return false;}}
 function saveMuted(value){if(typeof value!=='boolean')return false;try{const n=native();let saved=false;if(n){saved=typeof n.setCallMuted==='function'&&n.setCallMuted(value)===true;}else{const s=storage();if(!s)return false;s.setItem(muteKey,String(value));saved=s.getItem(muteKey)===String(value);}if(saved&&value)stop();return saved;}catch{return false;}}
 function stop(){epoch++;if(timer!==null){cancel(timer);timer=null;}if(audio){audio.pause();try{audio.currentTime=0}catch{}audio=null;}if(mode==='native-preview'){try{bridge()?.stopCallRingtonePreview?.()}catch{}}mode=null;}
 async function play(id,{preview=false,onError=()=>{}}={}){
  stop();if(!validRingtone(id))return false;const e=epoch;const n=bridge();
  try{
   if(!preview&&native())return true;
   if(n){mode='native-preview';if(typeof n.previewCallRingtone!=='function')throw Error('Zil sesi önizlenemedi.');n.previewCallRingtone(id);}
   else{if(CUSTOM_RINGTONES.some(t=>t.id===id))throw Error('Önce ses dosyası seçin.');mode=preview?'preview':'incoming';const a=makeAudio(ringtonePath(id));audio=a;a.loop=true;a.volume=.75;await a.play();if(e!==epoch){a.pause();return false;}}
   if(e===epoch)timer=schedule(()=>{if(e===epoch)stop()},preview?RINGTONE_PREVIEW_MS:45000);return e===epoch;
  }catch(error){if(e===epoch){stop();onError(error);}return false;}
 }
 return {selected,save,muted,saveMuted,stop,preview:(id,onError)=>play(id,{preview:true,onError}),incoming:()=>{if(muted()){stop();return Promise.resolve(true);}return play(selected());}};
}
