// FS v2: a short, manually compared DTLS authentication code, not Telegram's DH protocol.
const SHA256_FP=/^(?:[0-9a-f]{2}:){31}[0-9a-f]{2}$/i;
function fingerprint(sdp){
  const lines=sdp.split(/\r?\n/).filter(s=>/^a=fingerprint:/i.test(s));
  const values=[];
  for(const line of lines){const m=/^a=fingerprint:sha-256 (.+)$/i.exec(line);if(!m||!SHA256_FP.test(m[1]))return null;values.push(m[1].toUpperCase());}
  const unique=[...new Set(values)];return unique.length===1?unique[0]:null;
}
export function callVerificationSnapshot(pc,callId){
  if(pc?.connectionState!=="connected"||pc.signalingState!=="stable"||!/^[a-f0-9]{32}$/i.test(callId??""))return null;
  if(pc.iceConnectionState&&!['connected','completed'].includes(pc.iceConnectionState))return null;
  const local=pc.currentLocalDescription?.sdp??pc.localDescription?.sdp;
  const remote=pc.currentRemoteDescription?.sdp??pc.remoteDescription?.sdp;
  if(typeof local!=="string"||typeof remote!=="string")return null;
  const a=fingerprint(local),b=fingerprint(remote);
  if(!a||!b||a===b)return null;
  return {pc,callId,local,remote,localFingerprint:a,remoteFingerprint:b,material:['FS-CALL-SAS-v2',callId,...[a,b].sort()].join('|')};
}
export function sameCallVerification(a,b){return !!a&&!!b&&a.pc===b.pc&&a.callId===b.callId&&a.local===b.local&&a.remote===b.remote&&a.material===b.material;}
export async function verificationDigest(snapshot,subtle=globalThis.crypto.subtle){
  if(!snapshot?.material)throw Error("Missing certificate fingerprints");
  return new Uint8Array(await subtle.digest("SHA-256",new TextEncoder().encode(snapshot.material)));
}
// Never show a verified code based only on signaling. Check the certificate
// IDs of every reported active DTLS transport against the negotiated SDP.
export async function verifyCallTransport(snapshot){
  if(!snapshot||!sameCallVerification(snapshot,callVerificationSnapshot(snapshot.pc,snapshot.callId)))return false;
  try{
    const stats=await snapshot.pc.getStats();
    if(!sameCallVerification(snapshot,callVerificationSnapshot(snapshot.pc,snapshot.callId)))return false;
    const transports=[...stats.values()].filter(x=>x.type==='transport');
    const cert=id=>{const x=stats.get(id);return x?.type==='certificate'&&x.fingerprintAlgorithm?.toLowerCase()==='sha-256'&&SHA256_FP.test(x.fingerprint)?x.fingerprint.toUpperCase():null;};
    return transports.length>0&&transports.every(t=>t.dtlsState==='connected'&&cert(t.localCertificateId)===snapshot.localFingerprint&&cert(t.remoteCertificateId)===snapshot.remoteFingerprint);
  }catch{return false;}
}
