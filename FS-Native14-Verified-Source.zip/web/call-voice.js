import {VOICE_PROFILES} from './voice-transform-dsp.js';
export const VOICE_MODES=Object.freeze([{id:'normal',label:'Normal ses'},{id:'female',label:'Kadın sesi'},{id:'male',label:'Erkek sesi'}].map(Object.freeze));
export const validVoiceMode=m=>VOICE_MODES.some(x=>x.id===m);
export const voiceLabel=m=>VOICE_MODES.find(x=>x.id===m)?.label??'Normal ses';
const key=user=>`fs-call-voice-v1:${user}`;
export function selectedVoice(user,storage){try{const value=user&&storage.getItem(key(user));return validVoiceMode(value)?value:'normal';}catch{return 'normal';}}
export function saveVoice(user,mode,storage){if(!user||!validVoiceMode(mode))return false;try{storage.setItem(key(user),mode);return true;}catch{return false;}}
// Keep capture AEC/NS/AGC in the browser. Extra filtering belongs only to
// the transformed path; never apply another automatic gain stage to normal voice.
export function createVoiceFilters(context,mode){
 const profile=VOICE_PROFILES[mode];
 const highpass=context.createBiquadFilter();highpass.type='highpass';highpass.frequency.value=75;if(highpass.Q)highpass.Q.value=.707;
 const shelf=context.createBiquadFilter();shelf.type='highshelf';shelf.frequency.value=1700;shelf.gain.value=profile.shelf;
 const warmth=context.createBiquadFilter();warmth.type='lowshelf';warmth.frequency.value=350;warmth.gain.value=profile.warmth;
 const limiter=context.createDynamicsCompressor();limiter.threshold.value=-12;limiter.knee.value=12;limiter.ratio.value=4;limiter.attack.value=.003;limiter.release.value=.12;
 return {highpass,shelf,warmth,limiter};
}
const stop=stream=>stream?.getTracks().forEach(t=>t.stop());
function timeout(p,ms=5000){let timer;return Promise.race([p,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Ses motoru başlatılamadı.')),ms)})]).finally(()=>clearTimeout(timer));}
// Owns the input stream. On failure it stops capture, never returns raw audio
// for a requested transformed mode. Normal mode is an exact bypass.
export async function createOutgoingVoice(raw,mode,{Context=globalThis.AudioContext||globalThis.webkitAudioContext,Worklet=globalThis.AudioWorkletNode,Stream=globalThis.MediaStream,onFailure=()=>{}}={}){
  let context,source,node,highpass,shelf,warmth,limiter,destination,output,closed=false,failed=false,rawTrack;
  const close=()=>{if(closed)return;closed=true;try{rawTrack?.removeEventListener('ended',fail);}catch{}if(node)node.onprocessorerror=null;for(const n of [source,node,highpass,shelf,warmth,limiter])try{n?.disconnect()}catch{}stop(output);stop(raw);if(context&&context.state!=='closed')try{Promise.resolve(context.close()).catch(()=>{})}catch{};};
  function fail(){if(closed||failed)return;failed=true;output?.getAudioTracks().forEach(t=>{t.enabled=false;t.stop()});close();onFailure();}
  try{
    if(!validVoiceMode(mode))throw Error('Geçersiz ses modu.');
    rawTrack=raw.getAudioTracks()[0];if(!rawTrack||rawTrack.readyState==='ended')throw Error('Mikrofon açılamadı.');
    if(mode==='normal')return {stream:raw,mode,close};
    if(!Context||!Worklet||!Stream)throw Error('Bu cihazda ses dönüştürme desteklenmiyor.');
    context=new Context({latencyHint:'interactive'});
    if(!context.audioWorklet)throw Error('Bu cihazda ses dönüştürme desteklenmiyor.');
    await timeout(context.audioWorklet.addModule(new URL('./voice-transform-worklet.js',import.meta.url).href));
    source=context.createMediaStreamSource(new Stream([rawTrack]));
    node=new Worklet(context,'fs-voice-transform',{numberOfInputs:1,numberOfOutputs:1,outputChannelCount:[1],channelCount:1,channelCountMode:'explicit',processorOptions:{mode}});
    ({highpass,shelf,warmth,limiter}=createVoiceFilters(context,mode));
    destination=context.createMediaStreamDestination();destination.channelCount=1;
    source.connect(highpass).connect(node).connect(shelf).connect(warmth).connect(limiter).connect(destination);
    output=new Stream([...destination.stream.getAudioTracks(),...raw.getVideoTracks()]);
    node.onprocessorerror=fail;rawTrack.addEventListener('ended',fail,{once:true});
    await timeout(context.resume());if(closed||context.state!=='running'||rawTrack.readyState==='ended')throw Error('Ses dönüştürme başlatılamadı.');
    return {stream:output,mode,close};
  }catch(error){close();throw error;}
}
