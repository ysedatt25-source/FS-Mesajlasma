// Local workspace preferences; no server-side room modifications.
export const FOLDER_LIMIT=12;
export const BUILTIN_FILTERS=Object.freeze(['Tümü','Okunmamış','Gruplar','Arşiv']);
const validId=id=>typeof id==='string'&&/^[a-zA-Z0-9_-]{1,100}$/.test(id);
const folderName=s=>typeof s==='string'?s.normalize('NFC').trim().replace(/\s+/gu,' '):'';
const key=s=>folderName(s).toLocaleLowerCase('tr-TR');
const validName=s=>s.length>0&&Array.from(s).length<=32&&!/[\p{Cc}\p{Cf}]/u.test(s);
export function normalizeFolders(input){
 const output=[],ids=new Set(),names=new Set(BUILTIN_FILTERS.map(key));
 for(const f of Array.isArray(input)?input:[]){
  if(!f||!validId(f.id)||ids.has(f.id))continue;
  const name=folderName(f.name),k=key(name);
  if(!validName(name)||names.has(k))continue;
  const roomIds=[...new Set((Array.isArray(f.roomIds)?f.roomIds:[]).filter(validId))];
  ids.add(f.id);names.add(k);output.push({id:f.id,name,roomIds});
  if(output.length>=FOLDER_LIMIT)break;
 }
 return output;
}
export function folderFilter(id){return 'folder:'+id;}
export function resolveFolderFilter(filter,folders){
 if(BUILTIN_FILTERS.includes(filter))return filter;
 return normalizeFolders(folders).some(f=>folderFilter(f.id)===filter)?filter:'Tümü';
}
export function filterFolderRooms(rooms,folders,filter){
 const f=normalizeFolders(folders).find(f=>folderFilter(f.id)===filter);
 if(!f)return rooms;
 const members=new Set(f.roomIds);return rooms.filter(r=>members.has(r.id));
}
export function saveFolder(input,{id,name,roomIds}){
 const folders=normalizeFolders(input),label=folderName(name),k=key(label);
 if(!validId(id))throw Error('Geçersiz klasör kimliği.');
 if(!validName(label))throw Error('Klasör adı 1–32 karakter olmalıdır.');
 if(BUILTIN_FILTERS.some(f=>key(f)===k)||folders.some(f=>f.id!==id&&key(f.name)===k))throw Error('Bu klasör adı zaten kullanılıyor.');
 const index=folders.findIndex(f=>f.id===id);
 if(index<0&&folders.length>=FOLDER_LIMIT)throw Error('En fazla 12 klasör oluşturabilirsin.');
 const f={id,name:label,roomIds:[...new Set((Array.isArray(roomIds)?roomIds:[]).filter(validId))]};
 if(index<0)folders.push(f);else folders[index]=f;
 return folders;
}
export function removeFolder(input,id){return normalizeFolders(input).filter(f=>f.id!==id);}
// Preserve membership of rooms not loaded by the current workspace cache.
export function mergeFolderMembers(previous,visible,checked){
 const ids=new Set(visible.filter(validId));return [...new Set([...previous.filter(id=>validId(id)&&!ids.has(id)),...checked.filter(id=>ids.has(id))])];
}
export function folderFiltersMarkup(input,selected,escape){
 const folders=normalizeFolders(input),active=resolveFolderFilter(selected,folders);
 const tab=(id,label)=>`<button type="button" data-action="chat-filter" data-filter="${escape(id)}" class="${active===id?'active':''}" aria-pressed="${active===id}">${escape(label)}</button>`;
 return BUILTIN_FILTERS.map(f=>tab(f,f)).join('')+folders.map(f=>tab(folderFilter(f.id),f.name)).join('')+'<button type="button" data-action="manage-folders" aria-label="Sohbet klasörlerini yönet" class="folder-manage">＋</button>';
}
export function folderManagerMarkup(input,escape){
 const folders=normalizeFolders(input);
 return `<p class="hint">Klasörler bu cihazdaki sohbet düzenini değiştirir; mesajları silmez.</p><div class="folder-manager">${folders.map(f=>`<div class="folder-row"><button type="button" class="folder-edit" data-action="edit-folder" data-id="${escape(f.id)}"><strong>${escape(f.name)}</strong><small>${f.roomIds.length} sohbet</small></button><button type="button" class="danger" data-action="confirm-remove-folder" data-id="${escape(f.id)}" aria-label="${escape(f.name)} klasörünü sil">Sil</button></div>`).join('')||'<p class="hint">Henüz özel klasör yok.</p>'}</div><button type="button" class="primary" data-action="new-folder" ${folders.length>=FOLDER_LIMIT?'disabled':''}>Yeni klasör</button>`;
}
export function folderEditorMarkup(folder,rooms,roomName,escape){
 const selected=new Set(folder?.roomIds||[]);
 return `<form id="folder-form"><label for="folder-name">Klasör adı</label><input id="folder-name" name="folderName" maxlength="64" value="${escape(folder?.name||'')}" required autocomplete="off"><p class="hint">Bu klasörde görmek istediğin sohbetleri seç.</p><div class="folder-room-list">${rooms.map(r=>`<label class="folder-room"><input type="checkbox" name="room" value="${escape(r.id)}" ${selected.has(r.id)?'checked':''}><span>${escape(roomName(r))}</span></label>`).join('')||'<p class="hint">Seçilebilecek sohbet yok.</p>'}</div><p class="error" id="folder-error" role="alert"></p><button class="primary" type="submit">Kaydet</button><button class="secondary" type="button" data-action="manage-folders">Vazgeç</button></form>`;
}
