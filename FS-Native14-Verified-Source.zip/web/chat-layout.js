// Group only adjacent, ordinary messages from one sender on the same day.
// Compute against the full visible sequence, not the current virtual DOM window.
export function chatMessageJoined(previous, current, { unreadBoundary = false, singleEmoji = () => false } = {}) {
  if (!previous || !current || unreadBoundary || !previous.sender || previous.sender !== current.sender) return false;
  if (previous.callRecord || current.callRecord || previous.album || current.album) return false;
  if (previous.room && current.room && previous.room !== current.room) return false;
  if (previous.reply || current.reply || previous.payload?.effect || current.payload?.effect) return false;
  if (previous.payload?.type !== 'text' || current.payload?.type !== 'text') return false;
  if (typeof previous.payload.text !== 'string' || typeof current.payload.text !== 'string') return false;
  if (singleEmoji(previous.payload.text) || singleEmoji(current.payload.text)) return false;
  if (!Number.isFinite(previous.created) || !Number.isFinite(current.created)) return false;
  const elapsed = current.created - previous.created;
  return elapsed >= 0 && elapsed <= 120000 && new Date(previous.created).toDateString() === new Date(current.created).toDateString();
}

// A one-shot compositor animation of the actual new bubble; no text clones,
// timers, persisted flags or interference with the bubble's reply-swipe transform.
export function animateComposerSend(list,id,origin){
  if(!list?.isConnected||!origin||!Number.isFinite(origin.x)||!Number.isFinite(origin.y)||window.matchMedia?.('(prefers-reduced-motion: reduce)').matches)return false;
  const row=list.querySelector(`[data-row-id="${CSS.escape(id)}"] > .tg-message-line`);
  const bubble=row?.querySelector('.message.mine.fs-text-bubble');
  if(!bubble||!row.animate||row.dataset.composerAnimated||(list.classList.contains('selection-active')||list.classList.contains('selection-gesture')))return false;
  const r=bubble.getBoundingClientRect(),bounds=list.getBoundingClientRect();
  if(r.bottom<bounds.top||r.top>bounds.bottom)return false;
  const dy=Math.max(0,Math.min(96,origin.y-r.bottom)),dx=Math.max(-24,Math.min(24,origin.x-r.left));
  row.dataset.composerAnimated='1';
  row.animate([{opacity:.4,transform:`translate(${dx}px,${dy}px) scale(.97)`},{opacity:1,transform:'translate(0,0) scale(1)'}],{duration:180,easing:'cubic-bezier(.2,.7,.2,1)'});
  return true;
}
