// Cache unread timestamps per immutable message array. A read-marker advance
// is a binary search, not a complete history scan on every scroll frame.
export function createUnreadCounter(){
 const cache=new WeakMap();
 return (messages,{room,self,hiddenRevision,deletedRevision,isHidden,read=0})=>{
  let entry=cache.get(messages);
  if(!entry||entry.room!==room||entry.self!==self||entry.hiddenRevision!==hiddenRevision||entry.deletedRevision!==deletedRevision){
   const times=[];
   for(const m of messages){if(m.sender===self||m.callRecord||m.pending||['reaction','vote'].includes(m.payload?.type)||isHidden(m))continue;if(Number.isFinite(m.created))times.push(m.created);}
   times.sort((a,b)=>a-b);
   entry={room,self,hiddenRevision,deletedRevision,times};cache.set(messages,entry);
  }
  const times=entry.times;let lo=0,hi=times.length;
  while(lo<hi){const mid=(lo+hi)>>>1;if(times[mid]<=read)lo=mid+1;else hi=mid;}
  return times.length-lo;
 };
}
export function lastReadableMessage(messages){
 for(let i=messages.length-1;i>=0;i--){const m=messages[i];if(!m.callRecord&&!m.pending)return m;}
 return undefined;
}
