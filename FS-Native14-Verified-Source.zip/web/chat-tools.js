import {vault,peerKey,seal,open} from './crypto.js';
// Per-account local records are encrypted with the account's own device identity.
export class LocalChats {
 constructor(user,identity,storage=vault){this.user=user;this.identity=identity;this.storage=storage;this.queue=Promise.resolve();this.key=peerKey(identity.pair.privateKey,identity.pub)}
 scope(name){return `local-v2:${this.user}:${name}`}
 async get(name,fallback=null){await this.queue;const packet=await this.storage(this.scope(name));if(!packet)return fallback;try{return await open(await this.key,packet,this.scope(name))}catch{return fallback}}
 put(name,value){const scope=this.scope(name);const task=this.queue.catch(()=>{}).then(async()=>this.storage(scope,await seal(await this.key,value,scope)));this.queue=task.catch(()=>{});return task}
}
// Counts only explicit delivered-but-unread records. Older servers or messages still
// awaiting decryption cannot provide a trustworthy exact count; show a dot instead.
export function roomUnreadState(room,preferences={},user){
 const raw=room.unread_delivered_count, count=Number.isSafeInteger(raw)&&raw>=0?raw:0;
 const last=room.last,hidden=(preferences.hiddenMessages?.[room.id]||[]).includes(last?.id);
 const row=last?.receipts_v2?.find(r=>r.user===user);
 const pending=!!(last&&!hidden&&last.sender!==user&&!['reaction','vote','locked'].includes(last.payload?.type)&&!row?.read_at&&last.created>(preferences.read?.[room.id]||0));
 return {count,pending:pending&&count===0};
}
export function chatList(rooms,preferences={},filter='Tümü',query='',user){
 const fold=value=>String(value??'').normalize('NFC').trim().replace(/\s+/gu,' ').toLocaleLowerCase('tr-TR');
 const pinned=new Set(preferences.pinned||[]),archived=new Set(preferences.archived||[]),q=fold(query);
 return rooms.filter(r=>{
  if(r.hidden_from_home||(filter==='Arşiv'?!archived.has(r.id):archived.has(r.id))||(filter==='Gruplar'&&r.kind!=='group'))return false;
  if(filter==='Okunmamış'){const unread=roomUnreadState(r,preferences,user);if(!unread.count&&!unread.pending)return false;}
  const peers=(r.members||[]).filter(m=>m.id!==user);
  return !q||[r.title,peers.map(m=>m.name).join(', '),...peers.map(m=>m.nick)].some(v=>fold(v).includes(q));
 }).sort((a,b)=>Number(pinned.has(b.id))-Number(pinned.has(a.id))||(b.last?.created||b.created)-(a.last?.created||a.created));
}
export function buildMessageIndex(messages){
 const byId=new Map(),votes=new Map(),reactions=new Map();
 for(const m of messages){byId.set(m.id,m);const p=m.payload;if(p.type==='vote'){if(!votes.has(p.poll))votes.set(p.poll,new Map());votes.get(p.poll).set(m.sender,p.choice)}if(p.type==='reaction'){if(!reactions.has(p.target))reactions.set(p.target,new Map());reactions.get(p.target).set(m.sender,p.text)}}
 return {byId,votes,reactions};
}
export const localDay=t=>{const d=new Date(t);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
export function searchMessages(messages,query='',date=''){const q=query.trim().toLocaleLowerCase('tr');return messages.filter(m=>!['reaction','vote'].includes(m.payload.type)&&(!date||localDay(m.created)===date)&&(!q||[m.payload.text,m.payload.name,m.payload.date].filter(Boolean).join(' ').toLocaleLowerCase('tr').includes(q)))}
export const toggleId=(list=[],id)=>list.includes(id)?list.filter(x=>x!==id):[...list,id];
