export const SERVER_REQUIRED = 'Mesajlaşma sunucusu henüz bağlanmamış. Sunucu ayarından çalışan FS Mesajlaşma sunucusunun HTTPS adresini ekleyin.';
export function serverRoot(value) {
  if (!value) return '';
  const url = new URL(value);
  if (url.hostname === 'appassets.androidplatform.net') throw Error(SERVER_REQUIRED);
  if (url.username || url.password || url.search || url.hash) throw Error('Sunucu adresine kullanıcı bilgisi, sorgu veya bağlantı anahtarı eklemeyin.');
  if (url.protocol !== 'https:' && !(url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname))) throw Error('Güvenli HTTPS adresi girin.');
  const path = url.pathname.replace(/\/+$/, '').replace(/\/api$/, '');
  return url.origin + path;
}
export async function fetchServer(root, path, options = {}, fetcher = fetch) {
  if (!root) throw Error(SERVER_REQUIRED);
  // Preserve cancellation from the caller (PIN lock, offline, or transfer deadline).
  // A lost response may follow a committed PUT: preserve its retry classification.
  const parent = options.signal;
  const controller = new AbortController();
  const cancelled = () => new DOMException('İşlem iptal edildi.', 'AbortError');
  if (parent?.aborted) throw cancelled();
  const abort = () => controller.abort();
  parent?.addEventListener('abort', abort, {once: true});
  let timedOut = false;
  const timer = setTimeout(() => {timedOut = true; controller.abort();}, 20000);
  const timeout = () => Object.assign(Error('Sunucu yanıt vermedi. İnternet bağlantınızı ve sunucu adresini kontrol edip tekrar deneyin.'), {code: 'NETWORK'});
  try {
    const response = await fetcher(root + path, {...options, signal: controller.signal});
    if (parent?.aborted || timedOut) {
      // A response arriving after cancellation must not retain its unread body.
      try { Promise.resolve(response.body?.cancel()).catch(() => {}); } catch {}
      throw parent?.aborted ? cancelled() : timeout();
    }
    return response;
  } catch (error) {
    if (parent?.aborted) throw cancelled();
    if (timedOut) throw timeout();
    if (error?.name === 'AbortError') throw error;
    throw Object.assign(Error('Sunucuya bağlanılamadı. İnternet bağlantısını ve sunucu adresini kontrol edin.', {cause: error}), {code: 'NETWORK'});
  } finally {
    clearTimeout(timer);
    parent?.removeEventListener('abort', abort);
  }
}
export async function verifyServer(root, fetcher = fetch) {
  const response = await fetchServer(root, '/health', {}, fetcher);
  let status;
  try { status = await response.json(); } catch {}
  if (!response.ok || status?.service !== 'fs-mesajlasma' || status?.ok !== true)
    throw Error('Bu adreste çalışan FS Mesajlaşma API sunucusu bulunamadı. GitHub indirme veya statik site adresi kullanmayın.');
  return root;
}
