const enc = new TextEncoder(),
  dec = new TextDecoder();
export function b64(bytes) {
  let s = "";
  for (const b of new Uint8Array(bytes)) s += String.fromCharCode(b);
  return btoa(s);
}
export function unb64(s) {
  return Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
}
export async function database() {
  return new Promise((ok, no) => {
    const r = indexedDB.open("fs-private-v1", 1);
    r.onupgradeneeded = () => r.result.createObjectStore("vault");
    r.onsuccess = () => ok(r.result);
    r.onerror = () => no(r.error);
  });
}
export async function vault(key, value) {
  const db = await database();
  return new Promise((ok, no) => {
    const t = db.transaction(
        "vault",
        value === undefined ? "readonly" : "readwrite",
      ),
      s = t.objectStore("vault");
    const r = value === undefined ? s.get(key) : s.put(value, key);
    t.oncomplete = () => {
      db.close();
      ok(r.result);
    };
    t.onerror = () => {
      db.close();
      no(t.error);
    };
  });
}
export async function identity() {
  let pair = await vault("identity");
  if (!pair) {
    const generated = await crypto.subtle.generateKey(
      { name: "ECDH", namedCurve: "P-256" },
      true,
      ["deriveKey"],
    );
    const raw = await crypto.subtle.exportKey("jwk", generated.privateKey);
    await vault("identity-export", raw);
    pair = {
      publicKey: generated.publicKey,
      privateKey: await crypto.subtle.importKey(
        "jwk",
        raw,
        { name: "ECDH", namedCurve: "P-256" },
        false,
        ["deriveKey"],
      ),
    };
    await vault("identity", pair);
  }
  return { pair, pub: await crypto.subtle.exportKey("jwk", pair.publicKey) };
}
async function recoveryKey(password, salt, iterations=310000) {
  const base = await crypto.subtle.importKey(
    "raw",
    enc.encode(password),
    "PBKDF2",
    false,
    ["deriveKey"],
  );
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt, iterations, hash: "SHA-256" },
    base,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"],
  );
}
export async function prepareRecovery(password) {
  const raw = await vault("identity-export");
  if (!raw) return;
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const packet = {
    version: 1,
    salt: b64(salt),
    ...(await seal(
      await recoveryKey(password, salt),
      raw,
      "FS key recovery v1",
    )),
  };
  await vault("recovery", packet);
  await vault("identity-export", null);
}
// Legacy v1 backups are readable; new exports always use account-bound v2.
const recoveryAAD = version => `FS key recovery v${version}`;
function recoveryBytes(value, length, max=length) {
  if(typeof value!=="string" || value.length>28000 || !/^[A-Za-z0-9+/]+={0,2}$/.test(value))throw Error("Geçersiz anahtar yedeği.");
  const bytes=unb64(value);if(bytes.length<length||bytes.length>max)throw Error("Geçersiz anahtar yedeği.");return bytes;
}
export function sameIdentity(a,b){return !!a&&!!b&&a.kty===b.kty&&a.crv===b.crv&&a.x===b.x&&a.y===b.y;}
async function recoveryRaw(packet,password){
  if(!packet||![1,2].includes(packet.version)||typeof password!=="string"||password.length>256||!password.length)throw Error("Geçersiz anahtar yedeği.");
  recoveryBytes(packet.iv,12);recoveryBytes(packet.data,17,12000);
  const salt=recoveryBytes(packet.salt,16);
  const payload=await open(await recoveryKey(password,salt,packet.version===2?600000:310000),packet,recoveryAAD(packet.version));
  const raw=packet.version===2?payload?.privateKey:payload;
  const account=packet.version===2?payload?.account:null;
  if(!raw||raw.kty!=="EC"||raw.crv!=="P-256"||typeof raw.d!=="string"||(packet.version===2&&(typeof account!=="string"||!account||account.length>128)))throw Error("Geçersiz anahtar yedeği.");
  return {raw,account};
}
async function recoveryIdentity(raw){
  const privateKey=await crypto.subtle.importKey("jwk",raw,{name:"ECDH",namedCurve:"P-256"},false,["deriveKey"]);
  const publicKey=await crypto.subtle.importKey("jwk",{kty:raw.kty,crv:raw.crv,x:raw.x,y:raw.y,ext:true,key_ops:[]},{name:"ECDH",namedCurve:"P-256"},true,[]);
  return {pair:{privateKey,publicKey},pub:await crypto.subtle.exportKey("jwk",publicKey)};
}
export async function inspectRecovery(packet,password){
  const {raw,account}=await recoveryRaw(packet,password);
  return {...await recoveryIdentity(raw),account,packet:structuredClone(packet)};
}
export async function createRecoveryExport(source,oldPassword,newPassword,account,expectedPub){
  if(typeof newPassword!=="string"||newPassword.length<16||newPassword.length>256)throw Error("Kurtarma parolası 16–256 karakter olmalı.");
  if(source?.version===1&&oldPassword===newPassword)throw Error("Hesap şifresinden farklı bir kurtarma parolası seç.");
  const {raw,account:bound}=await recoveryRaw(source,oldPassword);
  if(!account||(bound&&bound!==account)||!sameIdentity((await recoveryIdentity(raw)).pub,expectedPub))throw Error("Yedek bu hesabın geçerli anahtarına ait değil.");
  const salt=crypto.getRandomValues(new Uint8Array(16));
  return {version:2,salt:b64(salt),...await seal(await recoveryKey(newPassword,salt,600000),{account,privateKey:raw},recoveryAAD(2))};
}
// Only a successful matching login can call this; persist key and session atomically.
export async function commitRecovery(candidate,session,valid=()=>true){
  if(!session?.token||!session.user?.id||!sameIdentity(candidate.pub,session.user.pub)||(candidate.account&&candidate.account!==session.user.id))throw Error("Anahtar yedeği bu hesaba ait değil.");
  const db=await database();
  if(!valid()){db.close();throw new DOMException("İşlem iptal edildi","AbortError");}
  return new Promise((ok,no)=>{
    const t=db.transaction("vault","readwrite"),store=t.objectStore("vault");
    t.oncomplete=()=>{db.close();ok();};t.onabort=t.onerror=()=>{db.close();no(t.error||Error("Anahtar kaydedilemedi."));};
    store.put(candidate.pair,"identity");store.put(candidate.packet,"recovery");store.put(null,"identity-export");store.put(session,"session");
  });
}
// Legacy helper for local migration/tests. The application never calls this on import.
export async function restoreRecovery(packet,password){
  const candidate=await inspectRecovery(packet,password);
  await vault("identity",candidate.pair);await vault("recovery",packet);await vault("identity-export",null);
  return {pair:candidate.pair,pub:candidate.pub};
}
export async function peerKey(privateKey, pub) {
  const p = await crypto.subtle.importKey(
    "jwk",
    pub,
    { name: "ECDH", namedCurve: "P-256" },
    false,
    [],
  );
  return crypto.subtle.deriveKey(
    { name: "ECDH", public: p },
    privateKey,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"],
  );
}
export async function seal(key, value, aad) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const data = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv, additionalData: enc.encode(aad) },
    key,
    enc.encode(JSON.stringify(value)),
  );
  return { iv: b64(iv), data: b64(data) };
}
export async function open(key, e, aad) {
  return JSON.parse(
    dec.decode(
      await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: unb64(e.iv), additionalData: enc.encode(aad) },
        key,
        unb64(e.data),
      ),
    ),
  );
}
export async function pinHash(pin, salt) {
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(pin),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  return b64(
    await crypto.subtle.deriveBits(
      {
        name: "PBKDF2",
        hash: "SHA-256",
        salt: unb64(salt),
        iterations: 210000,
      },
      key,
      256,
    ),
  );
}
export async function setPin(pin) {
  if (!/^\d{6,}$/.test(pin)) throw Error("Şifre en az 6 rakam olmalı.");
  const salt = b64(crypto.getRandomValues(new Uint8Array(16)));
  await vault("pin", { salt, hash: await pinHash(pin, salt) });
}
export async function checkPin(pin) {
  const record = await vault("pin");
  if (!record) return false;
  const limit = (await vault("pin-lock")) || { failures: 0, until: 0 };
  if (Date.now() < limit.until)
    throw Error("Çok fazla deneme. Bir dakika bekleyin.");
  const valid = (await pinHash(pin, record.salt)) === record.hash;
  if (valid) await vault("pin-lock", { failures: 0, until: 0 });
  else if (/^\d{6,}$/.test(pin)) {
    limit.failures++;
    if (limit.failures >= 5) {
      limit.until = Date.now() + 60000;
      limit.failures = 0;
    }
    await vault("pin-lock", limit);
    throw Error("Şifre yanlış. Tekrar girin.");
  }
  return valid;
}
export async function encryptFile(file) {
  const raw = crypto.getRandomValues(new Uint8Array(32)),
    iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await crypto.subtle.importKey("raw", raw, "AES-GCM", false, [
    "encrypt",
  ]);
  return {
    data: new Uint8Array(
      await crypto.subtle.encrypt(
        { name: "AES-GCM", iv },
        key,
        await file.arrayBuffer(),
      ),
    ),
    key: b64(raw),
    iv: b64(iv),
  };
}
export async function decryptFile(bytes, meta) {
  const key = await crypto.subtle.importKey(
    "raw",
    unb64(meta.key),
    "AES-GCM",
    false,
    ["decrypt"],
  );
  return new Blob(
    [
      await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: unb64(meta.iv) },
        key,
        bytes,
      ),
    ],
    { type: meta.mime },
  );
}
export { calculate } from "./calculator.js";
