import {receiptBatch} from './message-details.js';
// Sequential keyset traversal. Never acknowledge encrypted content that could not
// be authenticated/decrypted, or report read while a conversation is not visible.
export async function syncDelivery({fetchPage,decode,ack,valid,self,cursor=null,maxPages=5}){
 let after=cursor?.after||0,afterId=cursor?.afterId||'',count=0;
 for(let page=0;page<maxPages&&valid();page++){
  const rows=await fetchPage(after,afterId);if(!valid())break;
  if(!Array.isArray(rows)||rows.length>40)throw Error('Teslim sayfası geçersiz.');
  if(!rows.length)return {count,next:null};
  const rooms=new Map();
  for(const row of rows){if(!valid())return {count,next:null};const m=await decode(row);if(!valid())return {count,next:null};if(receiptBatch([m],self,new Set()).delivered.length){if(!rooms.has(m.room))rooms.set(m.room,[]);rooms.get(m.room).push(m.id);}}
  for(const [room,ids] of rooms){if(!valid())return {count,next:null};await ack(room,ids);count+=ids.length;}
  const last=rows.at(-1);if(last.created<after||(last.created===after&&last.id<=afterId))throw Error('Teslim sayfası ilerlemedi.');after=last.created;afterId=last.id;
  if(rows.length<40)return {count,next:null};
 }
 return {count,next:valid()?{after,afterId}:null};
}
