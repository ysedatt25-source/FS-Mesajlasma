// A single retry timer per foreground session. Never access files or unlock the app.
export function retryableDownload(error){
 if(!error||error.name==='AbortError')return false;
 return error.code==='NETWORK'||error.code==='DOWNLOAD_TIMEOUT'||error.code==='TRANSFER_TIMEOUT'||error.name==='TypeError'||error instanceof TypeError||[408,425,429,500,502,503,504].includes(error.status);
}
export function createDownloadRecovery({eligible,run,onError=()=>{},schedule=setTimeout,cancel=clearTimeout,delays=[2000,5000,15000,30000,60000]}={}){
 let timer=null,flight=null,attempt=0,generation=0,wake=false;
 function clear(){if(timer!==null){cancel(timer);timer=null;}}
 function stop(){generation++;clear();attempt=0;wake=false;}
 function retry(){if(!eligible()||timer!==null)return;const g=generation;timer=schedule(()=>{timer=null;if(g===generation)kick();},delays[Math.min(attempt++,delays.length-1)]);}
 function kick(){if(!eligible())return Promise.resolve();if(flight){wake=true;return flight;}clear();const g=generation;
  const p=Promise.resolve().then(()=>eligible()&&g===generation?run():false).then(pending=>{if(g!==generation)return;if(pending)retry();else attempt=0;},error=>{if(g!==generation)return;onError(error);if(retryableDownload(error))retry();});flight=p;
  p.finally(()=>{if(flight!==p)return;flight=null;if(wake){wake=false;if(eligible()&&(g!==generation||timer===null)){clear();void kick();}}}).catch(()=>{});return p;
 }
 return {kick,retry,stop};
}
