import {peerKey,seal,open} from './crypto.js';
import {queueCommit} from './durable-uploads.js';
export const DOWNLOAD_CHUNK=1024*1024;
const MAX_BYTES=200*1024*1024,MAX_FILES=20,MAX_FILE=50*1024*1024;
const abort=()=>new DOMException('Oturum değişti.','AbortError');
const validId=x=>typeof x==='string'&&/^[a-zA-Z0-9_-]{8,128}$/.test(x);
// Every offset update and corresponding ciphertext chunk commit atomically.
// Metadata (including the file decryption key) is encrypted under the local account key.
export class DurableDownloads {
 constructor({user,identity,read,commit=queueCommit,valid=()=>true,namespace="downloads-v1"}){
  if(!user||!identity?.pub?.x||!identity?.pub?.y)throw Error('İndirme oturumu hazır değil.');
  if(!["downloads-v1","ratchet-downloads-v1"].includes(namespace))throw Error("Geçersiz indirme alanı.");
  this.scope=`${namespace}:${user}:${identity.pub.x}:${identity.pub.y}`;this.key=peerKey(identity.pair.privateKey,identity.pub);this.read=read;this.commit=commit;this.valid=valid;
 }
 active(){if(!this.valid())throw abort();}
 async list(){this.active();const packet=await this.read(this.scope);this.active();if(!packet)return [];const items=await open(await this.key,packet,this.scope);this.active();if(!Array.isArray(items))throw Error('İndirme kuyruğu bozuk.');return items;}
 part(job,offset){return `${this.scope}:${job.id}:${offset}`;}
 async write(items,puts=[],deletes=[]){const packet=await seal(await this.key,items,this.scope);this.active();await this.commit([[this.scope,packet],...puts],deletes);}
 async enqueue(m){return (await this.enqueueBatch([m]))[0];}
 async enqueueBatch(messages){
  const jobs=await this.list(),added=[],result=[];
  for(const m of messages){const p=m?.payload;
   if(!validId(m?.id)||!validId(m.room)||!validId(p?.upload)||p.type!=='file'||!Number.isSafeInteger(p.size)||p.size<1||p.size>MAX_FILE||typeof p.key!=='string'||typeof p.iv!=='string'||typeof p.name!=='string'||typeof p.mime!=='string')throw Error('İndirme bilgisi geçersiz.');
   const existing=[...jobs,...added].find(j=>j.id===m.id);
   if(existing){if(existing.room!==m.room||existing.upload!==p.upload||existing.total!==p.size+16||existing.meta.key!==p.key||existing.meta.iv!==p.iv)throw Error('Dosya değişti. Eski indirme kaydını kaldırın.');result.push(existing);continue;}
   const job={id:m.id,room:m.room,upload:p.upload,total:p.size+16,offset:0,meta:{name:p.name,mime:p.mime,size:p.size,key:p.key,iv:p.iv}};added.push(job);result.push(job);
  }
  const all=[...jobs,...added];if(all.length>MAX_FILES||all.reduce((n,j)=>n+j.total,0)>MAX_BYTES){const e=Error('İndirme kuyruğu sınırı: 20 dosya, toplam 200 MB.');e.code='QUEUE_LIMIT';throw e;}
  if(added.length)await this.write(all);return result;
 }
 async fetch(job,request,progress=()=>{}){
  // Re-read the committed offset instead of trusting an old caller snapshot.
  const saved=(await this.list()).find(j=>j.id===job.id);
  if(!saved||saved.upload!==job.upload||saved.total!==job.total||saved.room!==job.room||saved.meta.key!==job.meta.key||saved.meta.iv!==job.meta.iv)throw Error('İndirme kaydı değişti.');
  job=saved;let offset=job.offset;if(!Number.isSafeInteger(offset)||offset<0||offset>job.total||(offset!==job.total&&offset%DOWNLOAD_CHUNK))throw Error('İndirme konumu geçersiz.');
  while(offset<job.total){this.active();const end=Math.min(job.total,offset+DOWNLOAD_CHUNK),bytes=await request(job,offset,end);this.active();
   if(!(bytes instanceof Uint8Array)||bytes.length!==end-offset)throw Error('Dosya parçası doğrulanamadı.');
   const items=await this.list(),stored=items.find(j=>j.id===job.id);if(!stored||stored.offset!==offset||stored.upload!==job.upload)throw Error('İndirme kaydı değişti.');
   await this.write(items.map(j=>j.id===job.id?{...j,offset:end}:j),[[this.part(job,offset),bytes]]);offset=end;this.active();progress(offset,job.total);
  }
  return {...job,offset};
 }
 async bytes(job){this.active();const items=await this.list();const stored=items.find(j=>j.id===job.id);if(stored?.offset!==job.total||stored?.upload!==job.upload)throw Error('İndirme henüz tamamlanmadı.');
  const all=new Uint8Array(job.total);for(let i=0;i<job.total;i+=DOWNLOAD_CHUNK){const part=await this.read(this.part(job,i));this.active();if(!(part instanceof Uint8Array)||part.length!==Math.min(DOWNLOAD_CHUNK,job.total-i))throw Error('Saklanan indirme eksik veya bozuk.');all.set(part,i);}return all;
 }
 async remove(id){const items=await this.list(),job=items.find(j=>j.id===id);if(!job)return false;const deletes=[];for(let i=0;i<job.offset;i+=DOWNLOAD_CHUNK)deletes.push(this.part(job,i));await this.write(items.filter(j=>j.id!==id),[],deletes);return true;}
}
export async function fetchRange(fetcher,url,token,offset,end,total,signal){
 const response=await fetcher(url,{headers:{Authorization:'Bearer '+token,Range:`bytes=${offset}-${end-1}`},signal,redirect:'error',cache:'no-store'});
 if(response.status!==206){const e=Error(`Dosya parçası alınamadı (${response.status}).`);e.status=response.status;throw e;}
 if(response.headers.get('Content-Range')!==`bytes ${offset}-${end-1}/${total}`||Number(response.headers.get('Content-Length'))!==end-offset)throw Error('Sunucudan geçersiz dosya parçası geldi.');
 const bytes=new Uint8Array(await response.arrayBuffer());if(bytes.length!==end-offset)throw Error('Dosya parçası eksik.');return bytes;
}
