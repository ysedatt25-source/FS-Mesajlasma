import {database,peerKey,seal,open} from './crypto.js';
export const MAX_QUEUE_FILES=20,MAX_QUEUE_BYTES=200*1024*1024;
const MAX_FILE=50*1024*1024;
const aborted=()=>new DOMException('Oturum değişti.','AbortError');
const assertActive=valid=>{if(!valid())throw aborted()};
const id=()=>crypto.randomUUID().replaceAll('-','');
// One indexedDB transaction commits the encrypted manifest and all ciphertext bodies.
// No plaintext file data, names or file keys are persisted in the queue.
export async function queueCommit(puts,deletes=[]){
 const db=await database();
 return new Promise((resolve,reject)=>{let t;try{t=db.transaction('vault','readwrite');const s=t.objectStore('vault');for(const [key,value] of puts)s.put(value,key);for(const key of deletes)s.delete(key);t.oncomplete=()=>{db.close();resolve()};t.onabort=()=>{db.close();reject(t.error||Error('Dosya kuyruğu kaydedilemedi.'))};t.onerror=()=>{};}catch(error){try{t?.abort()}catch{}db.close();reject(error)}});
}
export class DurableUploads{
 constructor({user,identity,read,commit=queueCommit,valid=()=>true}){
  if(!user||!identity?.pub?.x||!identity?.pub?.y)throw Error('Dosya kuyruğu oturumu bulunamadı.');
  this.scope=`uploads-v1:${user}:${identity.pub.x}:${identity.pub.y}`;this.read=read;this.commit=commit;this.valid=valid;this.key=peerKey(identity.pair.privateKey,identity.pub);
 }
 async list(){assertActive(this.valid);const packet=await this.read(this.scope);assertActive(this.valid);if(!packet)return [];const items=await open(await this.key,packet,this.scope);assertActive(this.valid);if(!Array.isArray(items))throw Error('Dosya kuyruğu okunamadı.');return items;}
 bodyKey(job){return `${this.scope}:${job.id}`;}
 async enqueue(files,room,prepare,replyId=null){
  const items=await this.list(),next=[...files];
  if(!next.length)return [];
  if(items.length+next.length>MAX_QUEUE_FILES||next.some(f=>!Number.isSafeInteger(f.size)||f.size<1||f.size>MAX_FILE)||items.reduce((n,j)=>n+j.meta.size,0)+next.reduce((n,f)=>n+f.size,0)>MAX_QUEUE_BYTES)throw Error('Dosya kuyruğu sınırı: 20 dosya, toplam 200 MB, dosya başına 50 MB.');
  const jobs=[],puts=[];
  for(const file of next){assertActive(this.valid);const prepared=await prepare(file);assertActive(this.valid);const {encrypted,thumbnail}=prepared;
   if(encrypted.data.length!==file.size+16)throw Error('Şifreli dosya boyutu doğrulanamadı.');
   const job={id:id(),messageId:id(),room,replyId:jobs.length?null:replyId,meta:{key:encrypted.key,iv:encrypted.iv,type:'file',name:file.name,mime:file.type||'application/octet-stream',size:file.size,thumbnail}};
   jobs.push(job);puts.push([this.bodyKey(job),encrypted.data]);
  }
  const packet=await seal(await this.key,[...items,...jobs],this.scope);assertActive(this.valid);await this.commit([[this.scope,packet],...puts]);return jobs;
 }
 async body(job){assertActive(this.valid);const bytes=await this.read(this.bodyKey(job));assertActive(this.valid);if(!(bytes instanceof Uint8Array)||bytes.length!==job.meta.size+16)throw Error('Saklanan dosya eksik veya bozuk.');return bytes;}
 async remove(job){const items=await this.list();if(!items.some(x=>x.id===job.id))return;const packet=await seal(await this.key,items.filter(x=>x.id!==job.id),this.scope);assertActive(this.valid);await this.commit([[this.scope,packet]],[this.bodyKey(job)]);}
}
