// The bundled animated WebP artwork stays in place. Effects are a separate,
// noninteractive layer; unsupported Unicode sequences retain their exact text.
export function isSingleEmoji(text){
 if(typeof text!=='string'||!text)return false;
 return /^(?:\p{Regional_Indicator}{2}|\p{Emoji_Modifier}|[0-9#*]\uFE0F?\u20E3|\p{Extended_Pictographic}[\uFE0F\p{Emoji_Modifier}\u{E0020}-\u{E007F}]*(?:\u200D\p{Extended_Pictographic}[\uFE0F\p{Emoji_Modifier}\u{E0020}-\u{E007F}]*)*)$/u.test(text);
}
export function emojiKey(value){return typeof value==='string'?value.normalize('NFC').replace(/\uFE0F/g,''):'';}
// Categories are mutually exclusive; variation selectors are presentation only.
const heartGlyph=/[❤♥💜🩷🩵💙💚💛🧡🖤🤍🤎💓💗💕💞💖💝💘💔💟]/u;
export function emojiCategory(value){
 const key=emojiKey(value);
 if(heartGlyph.test(key))return 'Kalpler';
 if(/^[\u{1F600}-\u{1F64F}\u{1F910}-\u{1F92F}\u{1F970}-\u{1F976}\u{1F978}-\u{1F97A}\u{1FAE0}-\u{1FAE9}]/u.test(key))return 'Yüzler';
 if(/^[\u{1F400}-\u{1F43F}\u{1F980}-\u{1F9AE}]/u.test(key))return 'Hayvanlar';
 return 'Diğer';
}
const emojiTerms={'kalp':heartGlyph,'gül':/[😀😃😄😁😆😂🤣😊🙂☺🌹]/u,'ateş':/[🔥💥]/u,'öpücük':/[😘😚😙😗💋]/u,'ağla':/[😢😭🥲]/u,'el':/[👍👎👏🙌🤝✋🤚👋✌🤟🤘💪🤞👌]/u,'kelebek':/🦋/u,'kutlama':/[🎉🎊🎈🎆🎇🥳🎂]/u};
export function emojiMatches(value,query){
 const q=String(query??'').trim();if(!q)return true;
 const keyword=q.toLocaleLowerCase('tr-TR');
 if(keyword==='hayvan')return emojiCategory(value)==='Hayvanlar';
 if(keyword==='yüz')return emojiCategory(value)==='Yüzler';
 const key=emojiKey(q);return !!(key&&emojiKey(value).includes(key))||!!(Object.hasOwn(emojiTerms,keyword)&&emojiTerms[keyword].test(value));
}
export function buildEmojiIndex(items){const index=new Map();for(const item of items||[]){if(isSingleEmoji(item.emoji)&&/^[a-f0-9_-]+\.webp$/i.test(item.file)){const key=emojiKey(item.emoji);if(!index.has(key))index.set(key,item.file)}}return index;}
// Legacy path and order stay frozen for compatibility with previous APKs.
export function emojiFilePath(file){if(typeof file!=='string'||!(/^[a-f0-9_-]+\.webp$/i.test(file)))return null;return (file.startsWith('e-')?'emoji-extra/':'emoji/')+file;}
export function mergeEmojiCatalog(legacy,extension){const result=[],seen=new Set();for(const items of [legacy,extension]){if(!Array.isArray(items))continue;for(const item of items){if(!item||!isSingleEmoji(item.emoji)||!emojiFilePath(item.file))continue;const key=emojiKey(item.emoji);if(!seen.has(key)){seen.add(key);result.push(item)}}}return result;}
export function emojiAsset(index,value){return isSingleEmoji(value)?index.get(emojiKey(value))||null:null;}
const families=[
 {match:/[😘😚😙😗💋]/u,kind:'kiss',symbols:['💋','💕','✨']},
 {match:/[😛😜😝🤪]/u,kind:'tongue',symbols:['😛','😜','✦']},
 {match:/[😎🕶]/u,kind:'cool',symbols:['🕶️','✨','⭐']},
 {match:/[🤔🤨🧐😐]/u,kind:'think',symbols:['❔','💭','✧']},
 {match:/[🤭🙈🙊]/u,kind:'shy',symbols:['💕','🙈','✨']},
 {match:/[🤤😋]/u,kind:'yum',symbols:['💧','😋','✨']},
 {match:/[💩]/u,kind:'poop',symbols:['💩','💨','✧']},
 {match:/[🍌]/u,kind:'banana',symbols:['🍌','✨','🍌']},
 {match:/[😴💤]/u,kind:'sleep',symbols:['💤','🌙','✧']},
 {match:/[🤮🤢]/u,kind:'sick',symbols:['💚','💧','✧']},
 {match:/[❤♥💖💗💓💕💞💘💝💟🩷🩵🧡💛💚💙💜🤎🖤🤍🫶😍🥰😘😻]/u,kind:'love',symbols:['❤','💕','✨']},
 {match:/[😂🤣😹]/u,kind:'laugh',symbols:['💧','✨','💧']},
 {match:/[😢😭🥲😿]/u,kind:'rain',symbols:['💧','💦','💧']},
 {match:/[🔥💥🌋]/u,kind:'fire',symbols:['🔥','✨','🟠']},
 {match:/[🎉🎊🎈🎆🎇🥳🎂🍾🥂]/u,kind:'celebrate',symbols:['🎊','✨','🎉']},
 {match:/[🦋]/u,kind:'flutter',symbols:['🦋','✨','🦋']},
 {match:/[❄☃⛄🧊🥶]/u,kind:'snow',symbols:['❄','✧','❄']},
 {match:/[⚡🌩⛈]/u,kind:'lightning',symbols:['⚡','✦','⚡']},
 {match:/[👍👎👏🙌🤝✋🤚👋✌🤟🤘💪🤞👌]/u,kind:'gesture',symbols:['✦','✨','✧']},
 {match:/[💸💵💰🤑💲]/u,kind:'money',symbols:['💸','💰','✨']},
 {match:/[💔]/u,kind:'broken',symbols:['💔','✧','💔']},
 {match:/[😡🤬😠]/u,kind:'anger',symbols:['💢','♨','💢']},
 {match:/[😱🤯😨👻💀]/u,kind:'shock',symbols:['✧','💥','✦']},
 {match:/[⭐🌟✨🤩🏆🥇]/u,kind:'star',symbols:['⭐','✨','✦']},
 {match:/[⚽🏀🏐🎾🏈⚾]/u,kind:'sport',symbols:['✦','✨','✧']},
];
// Semantic choreography is independent of the WebP replay and deterministic
// for the exact Unicode sequence, so sender/recipient derive the same plan.
const extraFamilies=[
 {match:/[🌸🌺🌻🌷🌹💐🪷🌼]/u,kind:'bloom',symbols:['🌸','✿','✨']},
 {match:/[🌧☔🌂💧💦🌊]/u,kind:'water',symbols:['💧','💦','◦']},
 {match:/[☀🌞🌈🌅🌄]/u,kind:'sun',symbols:['✦','☀️','✨']},
 {match:/[🌙🌛🌜🪐🌌☄]/u,kind:'orbit',symbols:['✦','✧','⋆']},
 {match:/[🎵🎶🎸🎹🎤🎧🎷🥁🎺🎻]/u,kind:'music',symbols:['♪','♫','♬']},
 {match:/[🚀🛸✈🛫🛩]/u,kind:'launch',symbols:['✦','💨','⋆']},
 {match:/[🎯🏹]/u,kind:'target',symbols:['◎','✦','◦']},
 {match:/[🎁🎀]/u,kind:'gift',symbols:['🎀','✨','✦']},
 {match:/[🍕🍔🍟🌮🍰🍩🍦🍫🍿🍪]/u,kind:'food',symbols:['✧','✨','◦']},
 {match:/[🐶🐱🐈🐕🐾🐻🦊🐼]/u,kind:'paw',symbols:['🐾','✧','⋆']},
 {match:/[🐝🐞🪲🦟🪰]/u,kind:'buzz',symbols:['✧','◦','⋆']},
 {match:/[💡🔦🕯]/u,kind:'glow',symbols:['✦','✧','⋆']},
 {match:/[🏁🏎🚗🚕🚙🏍🚲]/u,kind:'drive',symbols:['💨','✧','◦']},
 {match:/[😊😀😃😄😁🙂☺😇]/u,kind:'smile',symbols:['✦','✨','✧']},
 {match:/[😉]/u,kind:'wink',symbols:['✦','✨','✧']},
 {match:/[🤗🫂]/u,kind:'hug',symbols:['💕','✨','✧']},
 {match:/[😞😔😟🙁☹]/u,kind:'sad',symbols:['💧','◦','✧']},
 {match:/[😵🥴😵‍💫]/u,kind:'dizzy',symbols:['✦','⋆','✧']},
];
const motionByKind={kiss:'kiss',tongue:'wiggle',cool:'glow',think:'orbit',shy:'bloom',yum:'bounce',poop:'bounce',banana:'wiggle',sleep:'float',sick:'fall',love:'heart',laugh:'bounce',rain:'fall',fire:'flame',celebrate:'confetti',flutter:'flutter',snow:'snow',lightning:'flash',gesture:'pulse',money:'fall',broken:'split',anger:'shake',shock:'flash',star:'glow',sport:'bounce',bloom:'bloom',water:'wave',sun:'glow',orbit:'orbit',music:'float',launch:'launch',target:'pulse',gift:'confetti',food:'bounce',paw:'bounce',buzz:'flutter',glow:'glow',drive:'dash',smile:'bloom',wink:'flash',hug:'heart',sad:'fall',dizzy:'orbit'};
function hashEmoji(value){let h=2166136261;for(const cp of emojiKey(value)){h=Math.imul(h^cp.codePointAt(0),16777619);}return h>>>0;}
export function effectPlan(value){
 if(!isSingleEmoji(value))return null;
 const key=emojiKey(value),seed=hashEmoji(value),flag=/^\p{Regional_Indicator}{2}$/u.test(key)||/^[🏴][\u{E0020}-\u{E007F}]+$/u.test(key),number=/^[0-9#*]\u20e3$/u.test(key);
 // A compound glyph is never substituted with an unrelated animal/face.
 const compound=key.includes('\u200d');
 const family=!flag&&!number&&!compound?[...families,...extraFamilies].find(x=>x.match.test(value)):null;
 const kind=family?.kind||'spark',motion=flag?'flag':number?'pulse':compound?'orbit':motionByKind[kind]||['glow','orbit','pulse','bloom'][seed%4];
 let symbols=family?[...family.symbols]:['✧',value,'✦'];
 // Keep the sender's exact complexion, heart color and original glyph.
 if(kind==='kiss'||kind==='tongue'||kind==='gesture'||kind==='love'||kind==='sport'||kind==='bloom'||kind==='food'||kind==='wink'||kind==='smile'||kind==='paw'||flag||number||compound)symbols=[value,...symbols.filter(x=>x!==value&&x!=='❤'&&x!=='💕').slice(0,2)];
 return {kind,motion,symbols,seed};
}
export function particlePlan(kind,i,count=12,seed=0,motion=motionByKind[kind]||'glow'){
 const jitter=((seed>>>((i%4)*8))&255)/255, a=2*Math.PI*i/count+seed%17*.012,r=82+(i%4)*27+jitter*14;let x=Math.cos(a)*r,y=Math.sin(a)*r;
 if(['heart','flame','flutter','kiss','float','launch'].includes(motion)){x=Math.cos(a)*r*.72;y=-66-(i%5)*32-jitter*10;}
 if(['fall','snow','flag'].includes(motion)){x=(i%6-2.5)*30;y=62+(i%4)*35;}
 if(motion==='kiss'){x=(i%2?1:-1)*(40+(i%6)*24);y=-42-(i%5)*29;}
 if(motion==='wiggle'&&kind==='tongue'){x=(i%2?1:-1)*(45+(i%5)*25);y=(i%4-1.5)*48;}
 if(motion==='confetti'){x=Math.cos(a)*r;y=68+(i%4)*24;}
 if(motion==='split'){x=(i%2?1:-1)*(54+(i%6)*16);y=20+(i%4)*25;}
 if(motion==='dash'){x=(i%2?1:-1)*(70+(i%4)*22);y=(i%5-2)*12;}
 if(motion==='pulse'){x*=.7;y*=.7;}
 if(motion==='launch'){x*=.4;y*=1.12;}
 const mx=motion==='confetti'?x*.65:motion==='fall'||motion==='snow'||motion==='flag'?x*.45:motion==='bounce'?x*.5:x*.55;
 const my=motion==='confetti'?-95-(i%3)*18:motion==='bounce'?-70-(i%3)*15:motion==='orbit'?x*.7:y*.6;
 return {x:Math.round(x),y:Math.round(y),mx:Math.round(mx),my:Math.round(my),delay:(i%4)*65,size:18+(i%3)*8,spin:Math.round((i%2?1:-1)*(30+jitter*120)),duration:1180+(i%4)*95+seed%90};
}
// Extension assets were generated by a generic mesh warp. Until individually
// authored replacements are verified, preserve their exact Unicode as static text.
const authoredCharacters=new Set(['e-1f431.webp','e-1f436.webp','e-1f56f.webp','e-1f618.webp','e-1f60a.webp','e-1f609.webp','e-1f602.webp','e-1f622.webp','e-1f621.webp','e-1f60d.webp','e-1f634.webp','e-1f62e.webp','e-2764.webp','e-1f525.webp','e-1f98b.webp','e-1f44b.webp','e-2b50.webp','e-1f338.webp','e-1f601.webp','e-1f61b.webp','e-1f914.webp','e-1f60e.webp','e-1f41d.webp','e-1f44d.webp','e-1f631.webp','e-1f494.webp','e-1f41f.webp','e-1f44f.webp','e-1f388.webp','e-1f614.webp','e-1f62d.webp','e-1f680.webp','e-1f3b5.webp','e-1f60f.webp','e-1f64f.webp','e-1f308.webp']);
// Frozen catalog matches the official Noto authored animation collection.
const verifiedNotoFiles=new Set(["00a9.webp","00ae.webp","1f192.webp","1f193.webp","1f195.webp","1f197.webp","1f198.webp","1f199.webp","1f300.webp","1f304.webp","1f305.webp","1f307.webp","1f308.webp","1f30a.webp","1f30b.webp","1f30c.webp","1f30d.webp","1f30e.webp","1f30f.webp","1f31a.webp","1f31b.webp","1f31c.webp","1f31d.webp","1f31e.webp","1f31f.webp","1f321.webp","1f327.webp","1f329.webp","1f32a.webp","1f32c.webp","1f32d.webp","1f32e.webp","1f32f.webp","1f331.webp","1f332.webp","1f335.webp","1f337.webp","1f338.webp","1f339.webp","1f33c.webp","1f33d.webp","1f33f.webp","1f340.webp","1f341.webp","1f342.webp","1f343.webp","1f344.webp","1f345.webp","1f347.webp","1f348.webp","1f349.webp","1f34a.webp","1f34b.webp","1f34d.webp","1f34e.webp","1f350.webp","1f352.webp","1f353.webp","1f354.webp","1f355.webp","1f357.webp","1f35c.webp","1f35d.webp","1f35e.webp","1f361.webp","1f362.webp","1f366.webp","1f368.webp","1f369.webp","1f36a.webp","1f373.webp","1f375.webp","1f377.webp","1f379.webp","1f37b.webp","1f37c.webp","1f37d.webp","1f37e.webp","1f37f.webp","1f381.webp","1f382.webp","1f386.webp","1f388.webp","1f389.webp","1f38a.webp","1f393.webp","1f39e.webp","1f39f.webp","1f3a0.webp","1f3a1.webp","1f3a2.webp","1f3a3.webp","1f3ac.webp","1f3ad.webp","1f3af.webp","1f3b0.webp","1f3b1.webp","1f3b2.webp","1f3b3.webp","1f3b6.webp","1f3b7.webp","1f3b8.webp","1f3ba.webp","1f3bb.webp","1f3be.webp","1f3bf.webp","1f3c0.webp","1f3c1.webp","1f3c6.webp","1f3c9.webp","1f3cd.webp","1f3ce.webp","1f3cf.webp","1f3d1.webp","1f3d2.webp","1f3d3.webp","1f3d5.webp","1f3da.webp","1f3de.webp","1f3e0.webp","1f3f3.webp","1f3f4.webp","1f3f8.webp","1f400.webp","1f402.webp","1f405.webp","1f407.webp","1f409.webp","1f40a.webp","1f40c.webp","1f40d.webp","1f40e.webp","1f410.webp","1f412.webp","1f413.webp","1f415.webp","1f415_200d_1f9ba.webp","1f416.webp","1f419.webp","1f41b.webp","1f41c.webp","1f41d.webp","1f41e.webp","1f41f.webp","1f421.webp","1f422.webp","1f423.webp","1f424.webp","1f425.webp","1f426.webp","1f426_200d_1f525.webp","1f426_200d_2b1b.webp","1f427.webp","1f429.webp","1f42c.webp","1f42e.webp","1f433.webp","1f438.webp","1f43a.webp","1f43b.webp","1f43c.webp","1f43e.webp","1f43f.webp","1f440.webp","1f441.webp","1f442.webp","1f442_1f3fb.webp","1f442_1f3fc.webp","1f442_1f3fd.webp","1f442_1f3fe.webp","1f442_1f3ff.webp","1f443.webp","1f443_1f3fb.webp","1f443_1f3fc.webp","1f443_1f3fd.webp","1f443_1f3fe.webp","1f443_1f3ff.webp","1f446.webp","1f446_1f3fb.webp","1f446_1f3fc.webp","1f446_1f3fd.webp","1f446_1f3fe.webp","1f446_1f3ff.webp","1f447.webp","1f447_1f3fb.webp","1f447_1f3fc.webp","1f447_1f3fd.webp","1f447_1f3fe.webp","1f447_1f3ff.webp","1f448.webp","1f448_1f3fb.webp","1f448_1f3fc.webp","1f448_1f3fd.webp","1f448_1f3fe.webp","1f448_1f3ff.webp","1f449.webp","1f449_1f3fb.webp","1f449_1f3fc.webp","1f449_1f3fd.webp","1f449_1f3fe.webp","1f449_1f3ff.webp","1f44a.webp","1f44a_1f3fb.webp","1f44a_1f3fc.webp","1f44a_1f3fd.webp","1f44a_1f3fe.webp","1f44a_1f3ff.webp","1f44b.webp","1f44b_1f3fb.webp","1f44b_1f3fc.webp","1f44b_1f3fd.webp","1f44b_1f3fe.webp","1f44b_1f3ff.webp","1f44c.webp","1f44c_1f3fb.webp","1f44c_1f3fc.webp","1f44c_1f3fd.webp","1f44c_1f3fe.webp","1f44c_1f3ff.webp","1f44d.webp","1f44d_1f3fb.webp","1f44d_1f3fc.webp","1f44d_1f3fd.webp","1f44d_1f3fe.webp","1f44d_1f3ff.webp","1f44e.webp","1f44e_1f3fb.webp","1f44e_1f3fc.webp","1f44e_1f3fd.webp","1f44e_1f3fe.webp","1f44e_1f3ff.webp","1f44f.webp","1f44f_1f3fb.webp","1f44f_1f3fc.webp","1f44f_1f3fd.webp","1f44f_1f3fe.webp","1f44f_1f3ff.webp","1f450.webp","1f450_1f3fb.webp","1f450_1f3fc.webp","1f450_1f3fd.webp","1f450_1f3fe.webp","1f450_1f3ff.webp","1f451.webp","1f45f.webp","1f460.webp","1f463.webp","1f479.webp","1f47b.webp","1f47d.webp","1f47e.webp","1f47f.webp","1f480.webp","1f483.webp","1f483_1f3fb.webp","1f483_1f3fc.webp","1f483_1f3fd.webp","1f483_1f3fe.webp","1f483_1f3ff.webp","1f485.webp","1f485_1f3fb.webp","1f485_1f3fc.webp","1f485_1f3fd.webp","1f485_1f3fe.webp","1f485_1f3ff.webp","1f48b.webp","1f48c.webp","1f48d.webp","1f48e.webp","1f490.webp","1f493.webp","1f494.webp","1f495.webp","1f496.webp","1f497.webp","1f498.webp","1f499.webp","1f49a.webp","1f49b.webp","1f49c.webp","1f49d.webp","1f49e.webp","1f49f.webp","1f4a1.webp","1f4a3.webp","1f4a5.webp","1f4a7.webp","1f4a9.webp","1f4aa.webp","1f4aa_1f3fb.webp","1f4aa_1f3fc.webp","1f4aa_1f3fd.webp","1f4aa_1f3fe.webp","1f4aa_1f3ff.webp","1f4ac.webp","1f4af.webp","1f4b8.webp","1f4bb.webp","1f4bf.webp","1f4c8.webp","1f4c9.webp","1f4ca.webp","1f4da.webp","1f4df.webp","1f4e3.webp","1f4e6.webp","1f4f4.webp","1f4f7.webp","1f4f8.webp","1f4fa.webp","1f50b.webp","1f50c.webp","1f50e.webp","1f512.webp","1f514.webp","1f525.webp","1f52e.webp","1f54a.webp","1f573.webp","1f577.webp","1f587.webp","1f590.webp","1f590_1f3fb.webp","1f590_1f3fc.webp","1f590_1f3fd.webp","1f590_1f3fe.webp","1f590_1f3ff.webp","1f595.webp","1f595_1f3fb.webp","1f595_1f3fc.webp","1f595_1f3fd.webp","1f595_1f3fe.webp","1f595_1f3ff.webp","1f596.webp","1f596_1f3fb.webp","1f596_1f3fc.webp","1f596_1f3fd.webp","1f596_1f3fe.webp","1f596_1f3ff.webp","1f5a4.webp","1f5a8.webp","1f5d1.webp","1f5e3.webp","1f5ef.webp","1f5f3.webp","1f5ff.webp","1f600.webp","1f601.webp","1f602.webp","1f603.webp","1f604.webp","1f605.webp","1f606.webp","1f607.webp","1f608.webp","1f609.webp","1f60a.webp","1f60b.webp","1f60c.webp","1f60d.webp","1f60e.webp","1f60f.webp","1f610.webp","1f611.webp","1f612.webp","1f613.webp","1f614.webp","1f615.webp","1f616.webp","1f617.webp","1f618.webp","1f619.webp","1f61a.webp","1f61b.webp","1f61c.webp","1f61d.webp","1f61e.webp","1f61f.webp","1f620.webp","1f621.webp","1f622.webp","1f623.webp","1f624.webp","1f625.webp","1f626.webp","1f627.webp","1f628.webp","1f629.webp","1f62a.webp","1f62b.webp","1f62c.webp","1f62d.webp","1f62e.webp","1f62e_200d_1f4a8.webp","1f62f.webp","1f630.webp","1f631.webp","1f632.webp","1f633.webp","1f634.webp","1f635.webp","1f635_200d_1f4ab.webp","1f636.webp","1f636_200d_1f32b.webp","1f637.webp","1f638.webp","1f639.webp","1f63a.webp","1f63b.webp","1f63c.webp","1f63d.webp","1f63e.webp","1f63f.webp","1f640.webp","1f641.webp","1f642.webp","1f642_200d_2194.webp","1f642_200d_2195.webp","1f643.webp","1f644.webp","1f648.webp","1f649.webp","1f64a.webp","1f64c.webp","1f64c_1f3fb.webp","1f64c_1f3fc.webp","1f64c_1f3fd.webp","1f64c_1f3fe.webp","1f64c_1f3ff.webp","1f64f.webp","1f64f_1f3fb.webp","1f64f_1f3fc.webp","1f64f_1f3fd.webp","1f64f_1f3fe.webp","1f64f_1f3ff.webp","1f680.webp","1f682.webp","1f68c.webp","1f695.webp","1f697.webp","1f69a.webp","1f69c.webp","1f6a6.webp","1f6a7.webp","1f6a8.webp","1f6a9.webp","1f6ae.webp","1f6b2.webp","1f6ce.webp","1f6d1.webp","1f6d2.webp","1f6d8.webp","1f6df.webp","1f6e0.webp","1f6eb.webp","1f6ec.webp","1f6f6.webp","1f6f8.webp","1f6f9.webp","1f6fc.webp","1f90c.webp","1f90c_1f3fb.webp","1f90c_1f3fc.webp","1f90c_1f3fd.webp","1f90c_1f3fe.webp","1f90c_1f3ff.webp","1f90d.webp","1f90e.webp","1f90f.webp","1f90f_1f3fb.webp","1f90f_1f3fc.webp","1f90f_1f3fd.webp","1f90f_1f3fe.webp","1f90f_1f3ff.webp","1f910.webp","1f911.webp","1f912.webp","1f913.webp","1f914.webp","1f915.webp","1f916.webp","1f917.webp","1f918.webp","1f918_1f3fb.webp","1f918_1f3fc.webp","1f918_1f3fd.webp","1f918_1f3fe.webp","1f918_1f3ff.webp","1f919.webp","1f919_1f3fb.webp","1f919_1f3fc.webp","1f919_1f3fd.webp","1f919_1f3fe.webp","1f919_1f3ff.webp","1f91a.webp","1f91a_1f3fb.webp","1f91a_1f3fc.webp","1f91a_1f3fd.webp","1f91a_1f3fe.webp","1f91a_1f3ff.webp","1f91b.webp","1f91b_1f3fb.webp","1f91b_1f3fc.webp","1f91b_1f3fd.webp","1f91b_1f3fe.webp","1f91b_1f3ff.webp","1f91c.webp","1f91c_1f3fb.webp","1f91c_1f3fc.webp","1f91c_1f3fd.webp","1f91c_1f3fe.webp","1f91c_1f3ff.webp","1f91d.webp","1f91d_1f3fb.webp","1f91d_1f3fc.webp","1f91d_1f3fd.webp","1f91d_1f3fe.webp","1f91d_1f3ff.webp","1f91e.webp","1f91e_1f3fb.webp","1f91e_1f3fc.webp","1f91e_1f3fd.webp","1f91e_1f3fe.webp","1f91e_1f3ff.webp","1f91f.webp","1f91f_1f3fb.webp","1f91f_1f3fc.webp","1f91f_1f3fd.webp","1f91f_1f3fe.webp","1f91f_1f3ff.webp","1f920.webp","1f921.webp","1f922.webp","1f923.webp","1f924.webp","1f925.webp","1f927.webp","1f928.webp","1f929.webp","1f92a.webp","1f92b.webp","1f92c.webp","1f92d.webp","1f92e.webp","1f92f.webp","1f932.webp","1f932_1f3fb.webp","1f932_1f3fc.webp","1f932_1f3fd.webp","1f932_1f3fe.webp","1f932_1f3ff.webp","1f933.webp","1f933_1f3fb.webp","1f933_1f3fc.webp","1f933_1f3fd.webp","1f933_1f3fe.webp","1f933_1f3ff.webp","1f940.webp","1f941.webp","1f942.webp","1f947.webp","1f948.webp","1f949.webp","1f94b.webp","1f94d.webp","1f94e.webp","1f94f.webp","1f951.webp","1f952.webp","1f953.webp","1f954.webp","1f955.webp","1f957.webp","1f95d.webp","1f95e.webp","1f962.webp","1f966.webp","1f967.webp","1f968.webp","1f96c.webp","1f96d.webp","1f970.webp","1f971.webp","1f972.webp","1f973.webp","1f974.webp","1f975.webp","1f976.webp","1f978.webp","1f979.webp","1f97a.webp","1f980.webp","1f981.webp","1f982.webp","1f984.webp","1f985.webp","1f987.webp","1f988.webp","1f989.webp","1f98a.webp","1f98b.webp","1f98d.webp","1f98e.webp","1f994.webp","1f995.webp","1f996.webp","1f997.webp","1f998.webp","1f99a.webp","1f99d.webp","1f99e.webp","1f99f.webp","1f9a0.webp","1f9a5.webp","1f9a6.webp","1f9a7.webp","1f9a9.webp","1f9ad.webp","1f9ae.webp","1f9b4.webp","1f9b5.webp","1f9b5_1f3fb.webp","1f9b5_1f3fc.webp","1f9b5_1f3fd.webp","1f9b5_1f3fe.webp","1f9b5_1f3ff.webp","1f9b6.webp","1f9b6_1f3fb.webp","1f9b6_1f3fc.webp","1f9b6_1f3fd.webp","1f9b6_1f3fe.webp","1f9b6_1f3ff.webp","1f9bb.webp","1f9bb_1f3fb.webp","1f9bb_1f3fc.webp","1f9bb_1f3fd.webp","1f9bb_1f3fe.webp","1f9bb_1f3ff.webp","1f9be.webp","1f9bf.webp","1f9c0.webp","1f9c2.webp","1f9c3.webp","1f9c4.webp","1f9c5.webp","1f9c9.webp","1f9cb.webp","1f9d0.webp","1f9e0.webp","1f9e1.webp","1f9e6.webp","1f9f9.webp","1fa70.webp","1fa75.webp","1fa76.webp","1fa77.webp","1fa78.webp","1fa7a.webp","1fa81.webp","1fa82.webp","1fa83.webp","1fa84.webp","1fa85.webp","1fa87.webp","1fa89.webp","1fa8a.webp","1fa8e.webp","1fa8f.webp","1fa90.webp","1fa94.webp","1fa95.webp","1fa99.webp","1faa4.webp","1faa8.webp","1faa9.webp","1faab.webp","1faad.webp","1fab0.webp","1fab1.webp","1fab3.webp","1fab7.webp","1fabb.webp","1fabc.webp","1fabe.webp","1fabf.webp","1fac0.webp","1fac2.webp","1fac6.webp","1fac8.webp","1facd.webp","1facf.webp","1fad0.webp","1fad1.webp","1fad6.webp","1fad7.webp","1fad8.webp","1fada.webp","1fadb.webp","1fadc.webp","1fadf.webp","1fae0.webp","1fae1.webp","1fae2.webp","1fae3.webp","1fae4.webp","1fae5.webp","1fae6.webp","1fae7.webp","1fae8.webp","1fae9.webp","1faea.webp","1faef.webp","1faf0.webp","1faf0_1f3fb.webp","1faf0_1f3fc.webp","1faf0_1f3fd.webp","1faf0_1f3fe.webp","1faf0_1f3ff.webp","1faf1.webp","1faf1_1f3fb.webp","1faf1_1f3fb_200d_1faf2_1f3fc.webp","1faf1_1f3fb_200d_1faf2_1f3fd.webp","1faf1_1f3fb_200d_1faf2_1f3fe.webp","1faf1_1f3fb_200d_1faf2_1f3ff.webp","1faf1_1f3fc.webp","1faf1_1f3fc_200d_1faf2_1f3fb.webp","1faf1_1f3fc_200d_1faf2_1f3fd.webp","1faf1_1f3fc_200d_1faf2_1f3fe.webp","1faf1_1f3fc_200d_1faf2_1f3ff.webp","1faf1_1f3fd.webp","1faf1_1f3fd_200d_1faf2_1f3fb.webp","1faf1_1f3fd_200d_1faf2_1f3fc.webp","1faf1_1f3fd_200d_1faf2_1f3fe.webp","1faf1_1f3fd_200d_1faf2_1f3ff.webp","1faf1_1f3fe.webp","1faf1_1f3fe_200d_1faf2_1f3fb.webp","1faf1_1f3fe_200d_1faf2_1f3fc.webp","1faf1_1f3fe_200d_1faf2_1f3fd.webp","1faf1_1f3fe_200d_1faf2_1f3ff.webp","1faf1_1f3ff.webp","1faf1_1f3ff_200d_1faf2_1f3fb.webp","1faf1_1f3ff_200d_1faf2_1f3fc.webp","1faf1_1f3ff_200d_1faf2_1f3fd.webp","1faf1_1f3ff_200d_1faf2_1f3fe.webp","1faf2.webp","1faf2_1f3fb.webp","1faf2_1f3fc.webp","1faf2_1f3fd.webp","1faf2_1f3fe.webp","1faf2_1f3ff.webp","1faf3.webp","1faf3_1f3fb.webp","1faf3_1f3fc.webp","1faf3_1f3fd.webp","1faf3_1f3fe.webp","1faf3_1f3ff.webp","1faf4.webp","1faf4_1f3fb.webp","1faf4_1f3fc.webp","1faf4_1f3fd.webp","1faf4_1f3fe.webp","1faf4_1f3ff.webp","1faf5.webp","1faf5_1f3fb.webp","1faf5_1f3fc.webp","1faf5_1f3fd.webp","1faf5_1f3fe.webp","1faf5_1f3ff.webp","1faf6.webp","1faf6_1f3fb.webp","1faf6_1f3fc.webp","1faf6_1f3fd.webp","1faf6_1f3fe.webp","1faf6_1f3ff.webp","1faf7.webp","1faf7_1f3fb.webp","1faf7_1f3fc.webp","1faf7_1f3fd.webp","1faf7_1f3fe.webp","1faf7_1f3ff.webp","1faf8.webp","1faf8_1f3fb.webp","1faf8_1f3fc.webp","1faf8_1f3fd.webp","1faf8_1f3fe.webp","1faf8_1f3ff.webp","203c.webp","2049.webp","2122.webp","231b.webp","23f0.webp","23f3.webp","2601.webp","2602.webp","2603.webp","2604.webp","2615.webp","261d.webp","261d_1f3fb.webp","261d_1f3fc.webp","261d_1f3fd.webp","261d_1f3fe.webp","261d_1f3ff.webp","2622.webp","2623.webp","262e.webp","262f.webp","2639.webp","263a.webp","2648.webp","2649.webp","264a.webp","264b.webp","264c.webp","264d.webp","264e.webp","264f.webp","2650.webp","2651.webp","2652.webp","2653.webp","265f.webp","2660.webp","2665.webp","2668.webp","267e.webp","2693.webp","2696.webp","2699.webp","26a0.webp","26a1.webp","26bd.webp","26be.webp","26c4.webp","26c5.webp","26ce.webp","26d3.webp","26d3_200d_1f4a5.webp","26f3.webp","26f5.webp","26f8.webp","26fd.webp","2702.webp","2705.webp","2708.webp","270a.webp","270a_1f3fb.webp","270a_1f3fc.webp","270a_1f3fd.webp","270a_1f3fe.webp","270a_1f3ff.webp","270b.webp","270b_1f3fb.webp","270b_1f3fc.webp","270b_1f3fd.webp","270b_1f3fe.webp","270b_1f3ff.webp","270c.webp","270c_1f3fb.webp","270c_1f3fc.webp","270c_1f3fd.webp","270c_1f3fe.webp","270c_1f3ff.webp","270d.webp","270d_1f3fb.webp","270d_1f3fc.webp","270d_1f3fd.webp","270d_1f3fe.webp","270d_1f3ff.webp","270f.webp","2728.webp","2744.webp","274c.webp","2753.webp","2757.webp","2763.webp","2764.webp","2764_200d_1f525.webp","2764_200d_1fa79.webp","2795.webp","2b50.webp"]);
export function characterAssetPath(file){if(verifiedNotoFiles.has(file))return 'emoji/'+file;const authored=typeof file==='string'&&!file.startsWith('e-')?'e-'+file:file;if(authoredCharacters.has(authored))return 'emoji-character/'+authored;return null;}
// Cache only successful, bounded artwork responses; never cache failed requests.
const replayCache=new Map();
const replayCacheLimit=8;
export async function replayArtwork(path,fetchAsset,signal){
 const cached=replayCache.get(path);
 if(cached&&cached.fetchAsset===fetchAsset){replayCache.delete(path);replayCache.set(path,cached);return cached.blob;}
 const response=await fetchAsset(path,{signal});
 if(!response.ok)throw Error('Emoji asset');
 const blob=await response.blob();
 if(!signal?.aborted&&blob.size<=512*1024){replayCache.delete(path);replayCache.set(path,{blob,fetchAsset});while(replayCache.size>replayCacheLimit)replayCache.delete(replayCache.keys().next().value);}
 return blob;
}
let active=null;
export function clearEmojiEffect(){if(active){active.dispose();active=null;}}
export function animateEmoji(target,value,{reducedMotion=false,schedule=setTimeout,fetchAsset=globalThis.fetch,center=false,assetPath=null}={}){
 const host=target?.closest?.('.fs-chat');
 if(reducedMotion||!isSingleEmoji(value)||!target?.isConnected||!host?.isConnected)return false;
 clearEmojiEffect();
 const original=center?null:target.querySelector('.animated-emoji');
 const path=assetPath?characterAssetPath(assetPath):original?.getAttribute('src');
 if(!path||!/^(?:emoji|emoji-character)\/[a-f0-9_-]+\.webp$/i.test(path)||typeof fetchAsset!=='function')return false;
 let url=null,disposed=false,layer=null;
 const controller=new AbortController();
 const token={dispose(){if(disposed)return;disposed=true;controller.abort();layer?.remove();if(url)URL.revokeObjectURL(url);}};active=token;
 Promise.resolve().then(()=>disposed?Promise.reject(Error('Effect closed')):replayArtwork(path,fetchAsset,controller.signal)).then(blob=>{
  if(disposed||!host.isConnected||!target.isConnected||active!==token)return;
  url=URL.createObjectURL(blob);const doc=target.ownerDocument;layer=doc.createElement('div');layer.className='emoji-interactive-layer character-replay';layer.setAttribute('aria-hidden','true');
  const bounds=host.getBoundingClientRect(),rect=center?bounds:(original||target).getBoundingClientRect();
  layer.style.setProperty('--effect-x',Math.max(23,Math.min(bounds.width-23,rect.left+rect.width/2-bounds.left))+'px');
  layer.style.setProperty('--effect-y',Math.max(23,Math.min(bounds.height-23,rect.top+rect.height/2-bounds.top))+'px');
  const replay=doc.createElement('img');replay.className='emoji-replay';replay.alt='';replay.src=url;layer.append(replay);host.append(layer);
 }).catch(()=>{token.dispose();if(active===token)active=null;});
 schedule(()=>{token.dispose();if(active===token)active=null;},2200);return true;
}
