// The bundled animated WebP artwork stays in place. Effects are a separate,
// noninteractive layer; unsupported Unicode sequences retain their exact text.
export function isSingleEmoji(text){
 if(typeof text!=='string'||!text)return false;
 return /^(?:\p{Regional_Indicator}{2}|\p{Emoji_Modifier}|[0-9#*]\uFE0F?\u20E3|\p{Extended_Pictographic}[\uFE0F\p{Emoji_Modifier}\u{E0020}-\u{E007F}]*(?:\u200D\p{Extended_Pictographic}[\uFE0F\p{Emoji_Modifier}\u{E0020}-\u{E007F}]*)*)$/u.test(text);
}
export function emojiKey(value){return typeof value==='string'?value.normalize('NFC').replace(/\uFE0F/g,''):'';}
// Categories are mutually exclusive; variation selectors are presentation only.
const heartGlyph=/[❤♥💜🩷🩵💙💚💛🧡🖤🤍🤎💓💗💕💞💖💝💘💔💟]/u;
export function emojiCategory(value){
 const key=emojiKey(value);
 if(heartGlyph.test(key))return 'Kalpler';
 if(/^[\u{1F600}-\u{1F64F}\u{1F910}-\u{1F92F}\u{1F970}-\u{1F976}\u{1F978}-\u{1F97A}\u{1FAE0}-\u{1FAE9}]/u.test(key))return 'Yüzler';
 if(/^[\u{1F400}-\u{1F43F}\u{1F980}-\u{1F9AE}]/u.test(key))return 'Hayvanlar';
 return 'Diğer';
}
const emojiTerms={'kalp':heartGlyph,'gül':/[😀😃😄😁😆😂🤣😊🙂☺🌹]/u,'ateş':/[🔥💥]/u,'öpücük':/[😘😚😙😗💋]/u,'ağla':/[😢😭🥲]/u,'el':/[👍👎👏🙌🤝✋🤚👋✌🤟🤘💪🤞👌]/u,'kelebek':/🦋/u,'kutlama':/[🎉🎊🎈🎆🎇🥳🎂]/u};
export function emojiMatches(value,query){
 const q=String(query??'').trim();if(!q)return true;
 const keyword=q.toLocaleLowerCase('tr-TR');
 if(keyword==='hayvan')return emojiCategory(value)==='Hayvanlar';
 if(keyword==='yüz')return emojiCategory(value)==='Yüzler';
 const key=emojiKey(q);return !!(key&&emojiKey(value).includes(key))||!!(Object.hasOwn(emojiTerms,keyword)&&emojiTerms[keyword].test(value));
}
export function buildEmojiIndex(items){const index=new Map();for(const item of items||[]){if(isSingleEmoji(item.emoji)&&/^[a-f0-9_-]+\.webp$/i.test(item.file)){const key=emojiKey(item.emoji);if(!index.has(key))index.set(key,item.file)}}return index;}
// Legacy path and order stay frozen for compatibility with previous APKs.
export function emojiFilePath(file){if(typeof file!=='string'||!(/^[a-f0-9_-]+\.webp$/i.test(file)))return null;return (file.startsWith('e-')?'emoji-extra/':'emoji/')+file;}
export function mergeEmojiCatalog(legacy,extension){const result=[],seen=new Set();for(const items of [legacy,extension]){if(!Array.isArray(items))continue;for(const item of items){if(!item||!isSingleEmoji(item.emoji)||!emojiFilePath(item.file))continue;const key=emojiKey(item.emoji);if(!seen.has(key)){seen.add(key);result.push(item)}}}return result;}
export function emojiAsset(index,value){return isSingleEmoji(value)?index.get(emojiKey(value))||null:null;}
const families=[
 {match:/[😘😚😙😗💋]/u,kind:'kiss',symbols:['💋','💕','✨']},
 {match:/[😛😜😝🤪]/u,kind:'tongue',symbols:['😛','😜','✦']},
 {match:/[😎🕶]/u,kind:'cool',symbols:['🕶️','✨','⭐']},
 {match:/[🤔🤨🧐😐]/u,kind:'think',symbols:['❔','💭','✧']},
 {match:/[🤭🙈🙊]/u,kind:'shy',symbols:['💕','🙈','✨']},
 {match:/[🤤😋]/u,kind:'yum',symbols:['💧','😋','✨']},
 {match:/[💩]/u,kind:'poop',symbols:['💩','💨','✧']},
 {match:/[🍌]/u,kind:'banana',symbols:['🍌','✨','🍌']},
 {match:/[😴💤]/u,kind:'sleep',symbols:['💤','🌙','✧']},
 {match:/[🤮🤢]/u,kind:'sick',symbols:['💚','💧','✧']},
 {match:/[❤♥💖💗💓💕💞💘💝💟🩷🩵🧡💛💚💙💜🤎🖤🤍🫶😍🥰😘😻]/u,kind:'love',symbols:['❤','💕','✨']},
 {match:/[😂🤣😹]/u,kind:'laugh',symbols:['💧','✨','💧']},
 {match:/[😢😭🥲😿]/u,kind:'rain',symbols:['💧','💦','💧']},
 {match:/[🔥💥🌋]/u,kind:'fire',symbols:['🔥','✨','🟠']},
 {match:/[🎉🎊🎈🎆🎇🥳🎂🍾🥂]/u,kind:'celebrate',symbols:['🎊','✨','🎉']},
 {match:/[🦋]/u,kind:'flutter',symbols:['🦋','✨','🦋']},
 {match:/[❄☃⛄🧊🥶]/u,kind:'snow',symbols:['❄','✧','❄']},
 {match:/[⚡🌩⛈]/u,kind:'lightning',symbols:['⚡','✦','⚡']},
 {match:/[👍👎👏🙌🤝✋🤚👋✌🤟🤘💪🤞👌]/u,kind:'gesture',symbols:['✦','✨','✧']},
 {match:/[💸💵💰🤑💲]/u,kind:'money',symbols:['💸','💰','✨']},
 {match:/[💔]/u,kind:'broken',symbols:['💔','✧','💔']},
 {match:/[😡🤬😠]/u,kind:'anger',symbols:['💢','♨','💢']},
 {match:/[😱🤯😨👻💀]/u,kind:'shock',symbols:['✧','💥','✦']},
 {match:/[⭐🌟✨🤩🏆🥇]/u,kind:'star',symbols:['⭐','✨','✦']},
 {match:/[⚽🏀🏐🎾🏈⚾]/u,kind:'sport',symbols:['✦','✨','✧']},
];
// Semantic choreography is independent of the WebP replay and deterministic
// for the exact Unicode sequence, so sender/recipient derive the same plan.
const extraFamilies=[
 {match:/[🌸🌺🌻🌷🌹💐🪷🌼]/u,kind:'bloom',symbols:['🌸','✿','✨']},
 {match:/[🌧☔🌂💧💦🌊]/u,kind:'water',symbols:['💧','💦','◦']},
 {match:/[☀🌞🌈🌅🌄]/u,kind:'sun',symbols:['✦','☀️','✨']},
 {match:/[🌙🌛🌜🪐🌌☄]/u,kind:'orbit',symbols:['✦','✧','⋆']},
 {match:/[🎵🎶🎸🎹🎤🎧🎷🥁🎺🎻]/u,kind:'music',symbols:['♪','♫','♬']},
 {match:/[🚀🛸✈🛫🛩]/u,kind:'launch',symbols:['✦','💨','⋆']},
 {match:/[🎯🏹]/u,kind:'target',symbols:['◎','✦','◦']},
 {match:/[🎁🎀]/u,kind:'gift',symbols:['🎀','✨','✦']},
 {match:/[🍕🍔🍟🌮🍰🍩🍦🍫🍿🍪]/u,kind:'food',symbols:['✧','✨','◦']},
 {match:/[🐶🐱🐈🐕🐾🐻🦊🐼]/u,kind:'paw',symbols:['🐾','✧','⋆']},
 {match:/[🐝🐞🪲🦟🪰]/u,kind:'buzz',symbols:['✧','◦','⋆']},
 {match:/[💡🔦🕯]/u,kind:'glow',symbols:['✦','✧','⋆']},
 {match:/[🏁🏎🚗🚕🚙🏍🚲]/u,kind:'drive',symbols:['💨','✧','◦']},
 {match:/[😊😀😃😄😁🙂☺😇]/u,kind:'smile',symbols:['✦','✨','✧']},
 {match:/[😉]/u,kind:'wink',symbols:['✦','✨','✧']},
 {match:/[🤗🫂]/u,kind:'hug',symbols:['💕','✨','✧']},
 {match:/[😞😔😟🙁☹]/u,kind:'sad',symbols:['💧','◦','✧']},
 {match:/[😵🥴😵‍💫]/u,kind:'dizzy',symbols:['✦','⋆','✧']},
];
const motionByKind={kiss:'kiss',tongue:'wiggle',cool:'glow',think:'orbit',shy:'bloom',yum:'bounce',poop:'bounce',banana:'wiggle',sleep:'float',sick:'fall',love:'heart',laugh:'bounce',rain:'fall',fire:'flame',celebrate:'confetti',flutter:'flutter',snow:'snow',lightning:'flash',gesture:'pulse',money:'fall',broken:'split',anger:'shake',shock:'flash',star:'glow',sport:'bounce',bloom:'bloom',water:'wave',sun:'glow',orbit:'orbit',music:'float',launch:'launch',target:'pulse',gift:'confetti',food:'bounce',paw:'bounce',buzz:'flutter',glow:'glow',drive:'dash',smile:'bloom',wink:'flash',hug:'heart',sad:'fall',dizzy:'orbit'};
function hashEmoji(value){let h=2166136261;for(const cp of emojiKey(value)){h=Math.imul(h^cp.codePointAt(0),16777619);}return h>>>0;}
export function effectPlan(value){
 if(!isSingleEmoji(value))return null;
 const key=emojiKey(value),seed=hashEmoji(value),flag=/^\p{Regional_Indicator}{2}$/u.test(key)||/^[🏴][\u{E0020}-\u{E007F}]+$/u.test(key),number=/^[0-9#*]\u20e3$/u.test(key);
 // A compound glyph is never substituted with an unrelated animal/face.
 const compound=key.includes('\u200d');
 const family=!flag&&!number&&!compound?[...families,...extraFamilies].find(x=>x.match.test(value)):null;
 const kind=family?.kind||'spark',motion=flag?'flag':number?'pulse':compound?'orbit':motionByKind[kind]||['glow','orbit','pulse','bloom'][seed%4];
 let symbols=family?[...family.symbols]:['✧',value,'✦'];
 // Keep the sender's exact complexion, heart color and original glyph.
 if(kind==='kiss'||kind==='tongue'||kind==='gesture'||kind==='love'||kind==='sport'||kind==='bloom'||kind==='food'||kind==='wink'||kind==='smile'||kind==='paw'||flag||number||compound)symbols=[value,...symbols.filter(x=>x!==value&&x!=='❤'&&x!=='💕').slice(0,2)];
 return {kind,motion,symbols,seed};
}
export function particlePlan(kind,i,count=12,seed=0,motion=motionByKind[kind]||'glow'){
 const jitter=((seed>>>((i%4)*8))&255)/255, a=2*Math.PI*i/count+seed%17*.012,r=82+(i%4)*27+jitter*14;let x=Math.cos(a)*r,y=Math.sin(a)*r;
 if(['heart','flame','flutter','kiss','float','launch'].includes(motion)){x=Math.cos(a)*r*.72;y=-66-(i%5)*32-jitter*10;}
 if(['fall','snow','flag'].includes(motion)){x=(i%6-2.5)*30;y=62+(i%4)*35;}
 if(motion==='kiss'){x=(i%2?1:-1)*(40+(i%6)*24);y=-42-(i%5)*29;}
 if(motion==='wiggle'&&kind==='tongue'){x=(i%2?1:-1)*(45+(i%5)*25);y=(i%4-1.5)*48;}
 if(motion==='confetti'){x=Math.cos(a)*r;y=68+(i%4)*24;}
 if(motion==='split'){x=(i%2?1:-1)*(54+(i%6)*16);y=20+(i%4)*25;}
 if(motion==='dash'){x=(i%2?1:-1)*(70+(i%4)*22);y=(i%5-2)*12;}
 if(motion==='pulse'){x*=.7;y*=.7;}
 if(motion==='launch'){x*=.4;y*=1.12;}
 const mx=motion==='confetti'?x*.65:motion==='fall'||motion==='snow'||motion==='flag'?x*.45:motion==='bounce'?x*.5:x*.55;
 const my=motion==='confetti'?-95-(i%3)*18:motion==='bounce'?-70-(i%3)*15:motion==='orbit'?x*.7:y*.6;
 return {x:Math.round(x),y:Math.round(y),mx:Math.round(mx),my:Math.round(my),delay:(i%4)*65,size:18+(i%3)*8,spin:Math.round((i%2?1:-1)*(30+jitter*120)),duration:1180+(i%4)*95+seed%90};
}
// Extension assets were generated by a generic mesh warp. Until individually
// authored replacements are verified, preserve their exact Unicode as static text.
const authoredCharacters=new Set(['e-1f431.webp','e-1f436.webp','e-1f56f.webp','e-1f618.webp','e-1f60a.webp','e-1f609.webp','e-1f602.webp','e-1f622.webp','e-1f621.webp','e-1f60d.webp','e-1f634.webp','e-1f62e.webp','e-2764.webp','e-1f525.webp','e-1f98b.webp','e-1f44b.webp','e-2b50.webp','e-1f338.webp','e-1f601.webp','e-1f61b.webp','e-1f914.webp','e-1f60e.webp','e-1f41d.webp','e-1f44d.webp','e-1f631.webp','e-1f494.webp','e-1f41f.webp','e-1f44f.webp','e-1f388.webp','e-1f614.webp','e-1f62d.webp','e-1f680.webp','e-1f3b5.webp','e-1f60f.webp','e-1f64f.webp','e-1f308.webp']);
export function characterAssetPath(file){const authored=typeof file==='string'&&!file.startsWith('e-')?'e-'+file:file;if(authoredCharacters.has(authored))return 'emoji-character/'+authored;return null;}
// Cache only successful, bounded artwork responses; never cache failed requests.
const replayCache=new Map();
const replayCacheLimit=8;
export async function replayArtwork(path,fetchAsset,signal){
 const cached=replayCache.get(path);
 if(cached&&cached.fetchAsset===fetchAsset){replayCache.delete(path);replayCache.set(path,cached);return cached.blob;}
 const response=await fetchAsset(path,{signal});
 if(!response.ok)throw Error('Emoji asset');
 const blob=await response.blob();
 if(!signal?.aborted&&blob.size<=512*1024){replayCache.delete(path);replayCache.set(path,{blob,fetchAsset});while(replayCache.size>replayCacheLimit)replayCache.delete(replayCache.keys().next().value);}
 return blob;
}
let active=null;
export function clearEmojiEffect(){if(active){active.dispose();active=null;}}
export function animateEmoji(target,value,{reducedMotion=false,schedule=setTimeout,fetchAsset=globalThis.fetch,center=false,assetPath=null}={}){
 const host=target?.closest?.('.fs-chat');
 if(reducedMotion||!isSingleEmoji(value)||!target?.isConnected||!host?.isConnected)return false;
 clearEmojiEffect();
 const original=center?null:target.querySelector('.animated-emoji');
 const path=assetPath?characterAssetPath(assetPath):original?.getAttribute('src');
 if(!path||!/^emoji-character\/[a-f0-9_-]+\.webp$/i.test(path)||typeof fetchAsset!=='function')return false;
 let url=null,disposed=false,layer=null;
 const controller=new AbortController();
 const token={dispose(){if(disposed)return;disposed=true;controller.abort();layer?.remove();if(url)URL.revokeObjectURL(url);}};active=token;
 Promise.resolve().then(()=>disposed?Promise.reject(Error('Effect closed')):replayArtwork(path,fetchAsset,controller.signal)).then(blob=>{
  if(disposed||!host.isConnected||!target.isConnected||active!==token)return;
  url=URL.createObjectURL(blob);const doc=target.ownerDocument;layer=doc.createElement('div');layer.className='emoji-interactive-layer character-replay';layer.setAttribute('aria-hidden','true');
  const bounds=host.getBoundingClientRect(),rect=center?bounds:(original||target).getBoundingClientRect();
  layer.style.setProperty('--effect-x',Math.max(23,Math.min(bounds.width-23,rect.left+rect.width/2-bounds.left))+'px');
  layer.style.setProperty('--effect-y',Math.max(23,Math.min(bounds.height-23,rect.top+rect.height/2-bounds.top))+'px');
  const replay=doc.createElement('img');replay.className='emoji-replay';replay.alt='';replay.src=url;layer.append(replay);host.append(layer);
 }).catch(()=>{token.dispose();if(active===token)active=null;});
 schedule(()=>{token.dispose();if(active===token)active=null;},2200);return true;
}
