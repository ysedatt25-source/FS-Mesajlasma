import {emojiAsset} from './emoji-effects.js';
export const GREETINGS=Object.freeze(['👋','🙌','🤗','😊','✌️','🤝','😄','🫶']);
// Keep the choice stable during rerenders; avoid consecutive repeats on navigation.
export function createGreetingPicker(random=Math.random){
 let previous=null,route=null;
 return (nextRoute,index)=>{
  if(previous!==null&&route===nextRoute)return previous;
  const available=GREETINGS.filter(g=>emojiAsset(index,g));
  const pool=available.length?available:GREETINGS;
  const alternatives=pool.filter(g=>g!==previous);
  const choices=alternatives.length?alternatives:pool;
  previous=choices[Math.min(choices.length-1,Math.max(0,Math.floor(random()*choices.length)))];
  route=nextRoute;return previous;
 };
}
