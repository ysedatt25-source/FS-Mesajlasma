import {createCallQuality} from './call-quality.js';
import {createAudioPriority,createIceRecovery,isRestartOffer,acceptIce,drainIce,sameOffer} from './call-recovery.js';
// A four-person mesh uses one capture stream and one WebRTC connection per
// accepted peer. No media is sent via the signaling service.
export class GroupMesh{
 constructor({self,stream,iceServers,send,valid,change,failed,canSignal=()=>true,createPC=c=>new RTCPeerConnection(c),createStream=()=>new MediaStream()}){
  Object.assign(this,{self,stream,iceServers,send,valid,change,failed,canSignal,createPC,createStream});this.peers=new Map();this.allowed=new Set();this.early=new Map();this.closed=false;
 }
 active(){return !this.closed&&this.valid();}
 get(id){return this.peers.get(id);}
 ensure(id){
  if(!this.active()||!this.allowed.has(id))return null;
  if(this.peers.has(id))return this.peers.get(id);
  const pc=this.createPC({iceServers:this.iceServers}),p={pc,remote:null,candidates:[],offered:false};this.peers.set(id,p);
  const active=()=>this.active()&&this.peers.get(id)===p;
  this.stream.getTracks().forEach(t=>pc.addTrack(t,this.stream));
  pc.onicecandidate=e=>{if(e.candidate&&active())try{this.send(id,'ice',{candidate:e.candidate.toJSON()})}catch{}};
  pc.ontrack=e=>{if(!active())return;p.remote=e.streams?.[0]||p.remote||this.createStream();if(!p.remote.getTracks().includes(e.track))p.remote.addTrack(e.track);this.change();};
  p.recovery=createIceRecovery({pc,offerer:this.self<id,valid:active,canSignal:this.canSignal,send:(kind,payload)=>this.send(id,kind,payload),onExpired:()=>{if(active()){p.recoveryExpired=true;this.change();this.failed(id);}}});
  const quality=createCallQuality(),prioritizeAudio=createAudioPriority();p.timer=setInterval(async()=>{if(!active())return;void p.recovery.tick();try{await prioritizeAudio(pc,active);const q=await quality.sample(pc,active);if(q&&active()&&p.networkLabel!==q.label){p.networkLabel=q.label;this.change();}}catch{}},3000);p.timer.unref?.();
  pc.onconnectionstatechange=()=>{if(active()){if(pc.connectionState==='connected')p.recoveryExpired=false;this.change();void p.recovery.tick();}};
  pc.oniceconnectionstatechange=()=>{if(active())void p.recovery.tick();};
  return p;
 }
 async update(ids){
  if(!this.active())return;
  this.allowed=new Set(ids.filter(id=>id!==this.self));
  for(const id of this.peers.keys())if(!this.allowed.has(id))this.drop(id);
  for(const id of this.allowed){const p=this.ensure(id);if(!p)continue;const valid=()=>this.active()&&this.peers.get(id)===p;
   if(this.self<id&&!p.offered){p.offered=true;const offer=await p.pc.createOffer();if(!valid())return;await p.pc.setLocalDescription(offer);if(!valid())return;this.send(id,'offer',{description:offer});}
   const early=this.early.get(id)||[];this.early.delete(id);for(const b of early){if(!valid())return;await this.handle(b);}
  }
  if(this.active())this.change();
 }
 async handle(b){
  if(!this.active()||b.from===this.self||b.to!==this.self)return;
  const id=b.from;
  // A directed signal may arrive just before the membership snapshot. Buffer
  // only a bounded number; authentication and joined membership are server checked.
  if(!this.allowed.has(id)){if(this.early.size>=4&&!this.early.has(id))return;const q=this.early.get(id)||[];if(q.length<128)q.push(b);this.early.set(id,q);return;}
  const p=this.ensure(id);if(!p)return;const pc=p.pc,valid=()=>this.active()&&this.peers.get(id)===p;
  if(b.kind==='restart-request'){p.recovery.request();return;}
  if(b.kind==='offer'){
   if(id>=this.self)return;
   if(pc.remoteDescription&&!isRestartOffer(pc.remoteDescription,b.description)){if(sameOffer(pc.remoteDescription,b.description)&&pc.localDescription?.type==='answer')this.send(id,'answer',{description:pc.localDescription});return;}
   if(pc.signalingState&&pc.signalingState!=='stable')return;
   await pc.setRemoteDescription(b.description);if(!valid())return;
   await this.flush(p,valid);if(!valid())return;
   const answer=await pc.createAnswer();if(!valid())return;await pc.setLocalDescription(answer);if(!valid())return;this.send(id,'answer',{description:answer});
  }else if(b.kind==='answer'){
   if(this.self>=id||!p.offered||(pc.signalingState?pc.signalingState!=='have-local-offer':!!pc.remoteDescription))return;
   await pc.setRemoteDescription(b.description);p.recovery.answered();if(valid())await this.flush(p,valid);
  }else if(b.kind==='ice'){
   await acceptIce(pc,p.candidates,b.candidate);
  }
 }
 wake(){if(this.active())for(const p of this.peers.values())void p.recovery.wake();}
 async flush(p,valid){await drainIce(p.pc,p.candidates,valid);}
 drop(id){const p=this.peers.get(id);if(!p)return;this.peers.delete(id);clearInterval(p.timer);p.recovery.close();p.pc.ontrack=null;p.pc.onicecandidate=null;p.pc.onconnectionstatechange=null;p.pc.oniceconnectionstatechange=null;p.pc.close();p.candidates=[];}
 close(){this.closed=true;for(const id of this.peers.keys())this.drop(id);this.early.clear();this.allowed.clear();}
}
