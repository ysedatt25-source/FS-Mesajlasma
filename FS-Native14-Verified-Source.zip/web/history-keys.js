// Account/server-scoped, local-only historical keys. Never used for sending.
import {database,inspectRecovery,sameIdentity,peerKey,open} from './crypto.js';
import {validatePayload} from './payload.js';
const MAX=8;
function scope(root,account){
 if(typeof root!=='string'||!root||typeof account!=='string'||!account)throw Error('Oturum hazır değil.');
 return 'history-keys:'+JSON.stringify([root,account]);
}
function check(valid){if(!valid())throw new DOMException('Oturum değişti.','AbortError');}
export async function historyKeys(root,account){
 const name=scope(root,account),db=await database();return new Promise((resolve,reject)=>{
  const t=db.transaction('vault','readonly'),r=t.objectStore('vault').get(name);
  t.oncomplete=()=>{db.close();resolve(Array.isArray(r.result)?r.result.slice(0,MAX):[])};
  t.onerror=t.onabort=()=>{db.close();reject(t.error||Error('Anahtar okunamadı.'))};
 });
}
export async function addHistoryKey({root,account,packet,password,activePub,valid=()=>true}){
 check(valid);const name=scope(root,account),c=await inspectRecovery(packet,password);check(valid);
 // An unbound legacy file cannot establish account ownership after rotation.
 if(c.account!==account)throw Error('Bu işlem için ilgili hesaba bağlı v2 anahtar yedeği gerekli.');
 if(sameIdentity(c.pub,activePub))return {added:false,current:true};
 const db=await database();try{check(valid)}catch(e){db.close();throw e;}
 return new Promise((resolve,reject)=>{
  const t=db.transaction('vault','readwrite'),s=t.objectStore('vault'),r=s.get(name);let result,error;
  t.oncomplete=()=>{db.close();resolve(result)};
  t.onerror=t.onabort=()=>{db.close();reject(error||t.error||Error('Anahtar kaydedilemedi.'))};
  r.onsuccess=()=>{try{
   check(valid);const list=Array.isArray(r.result)?r.result:[];
   if(list.some(x=>sameIdentity(x.pub,c.pub))){result={added:false,current:false};return;}
   if(list.length>=MAX)throw Error('Geçmiş anahtar sınırı dolu. Mevcut anahtarlar silinmedi.');
   // Store only a nonextractable CryptoKey and public identifier, not the password or raw JWK.
   s.put([...list,{pair:c.pair,pub:c.pub}],name);result={added:true,current:false};
  }catch(e){error=e;t.abort();}};
 });
}
export async function openHistorical({keys,senderPub,ownLegacy,packet,room,valid=()=>true}){
 for(const k of keys.slice(0,MAX)){
  check(valid);
  try{
   const payload=validatePayload(await open(await peerKey(k.pair.privateKey,ownLegacy?k.pub:senderPub),packet,room));
   check(valid);return payload;
  }catch(e){check(valid);}
 }
 throw Error('Geçmiş mesaj bu cihazdaki anahtarlarla açılamadı.');
}
