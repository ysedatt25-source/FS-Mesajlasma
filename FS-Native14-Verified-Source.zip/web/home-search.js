// Local authenticated search. Never send arbitrary search terms to the server.
export const searchTerm=value=>String(value??'').trim().replace(/\s+/gu,' ').slice(0,100);
const fold=value=>String(value??'').trim().replace(/\s+/gu,' ').normalize('NFC').toLocaleLowerCase('tr-TR');
const match=(q,...values)=>!q||values.some(v=>fold(v).includes(q));
export function recentSearches(values=[]){
 const seen=new Set(),out=[];
 for(const value of Array.isArray(values)?values:[]){if(typeof value!=='string')continue;const text=searchTerm(value),key=fold(text);if(!key||seen.has(key))continue;seen.add(key);out.push(text);if(out.length===12)break;}
 return out;
}
export function rememberSearch(values,value){return recentSearches([searchTerm(value),...recentSearches(values)]);}
export function homeSearch({rooms=[],contacts=[],saved=[],user,preferences={},tags={},query='',category='all',hidden=()=>false,presenceStale=false}={}){
 const q=fold(searchTerm(query)),out=[];if(!q||!user)return out;
 const accessible=new Map(rooms.filter(r=>r&&r.id&&!r.hidden_from_home&&r.members?.some(m=>m.id===user)).map(r=>[r.id,r]));
 const archived=new Set(preferences.archived||[]),pinned=new Set(preferences.pinned||[]);
 const label=r=>r.title||r.members.filter(m=>m.id!==user).map(m=>m.name).join(', ')||'Sohbet';
 const ordered=[...accessible.values()].sort((a,b)=>Number(pinned.has(b.id))-Number(pinned.has(a.id))||((b.last?.created||b.created||0)-(a.last?.created||a.created||0)));
 if(category==='all'||category==='rooms'||category==='groups')for(const r of ordered){const group=r.kind==='group';if(category==='groups'&&!group)continue;const peer=group?null:r.members.find(m=>m.id!==user);if(match(q,label(r),peer?.nick))out.push({kind:group?'group':'room',id:r.id,label:label(r),detail:[archived.has(r.id)?'Arşiv':'',group?'Grup':peer?.nick?'@'+peer.nick:''].filter(Boolean).join(' · '),person:peer});}
 if(category==='all'||category==='people'){
  const unique=new Map(contacts.filter(c=>c?.id&&c.id!==user&&!c.deleted).map(c=>[c.id,c]));
  for(const c of unique.values())if(match(q,c.name,c.nick)){const room=ordered.find(r=>r.kind!=='group'&&r.members.some(m=>m.id===c.id));out.push({kind:'person',id:c.id,room:room?.id,label:c.name||c.nick,detail:[c.nick?'@'+c.nick:'',presenceStale?'Durum doğrulanamadı':c.status==='online'?'Çevrimiçi':c.status==='busy'?'Meşgul':c.status==='offline'?'Çevrimdışı':'Durum doğrulanamadı'].filter(Boolean).join(' · '),person:c});}
 }
 if(category==='all'||category==='saved')for(const m of saved){const p=m?.payload,r=accessible.get(m?.room);if(!r||!p||!m.id||m.pending||hidden(m)||p.viewOnce||['reaction','vote','locked','call'].includes(p.type))continue;const text=p.text||p.name||p.type;if(match(q,text,p.name,tags[m.id]))out.push({kind:'saved',id:m.id,room:r.id,label:text,detail:label(r),record:m});}
 // Cap rendering; narrower queries and filters remain available.
 return out.slice(0,120);
}
