import { icon } from './icons.js';
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const text = (s, fallback) => typeof s === 'string' && s.trim() ? s.trim() : fallback;
const hangupIcon = '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 15v-3a15 15 0 0 1 18 0v3a1 1 0 0 1-1 1l-4-1v-3a12 12 0 0 0-8 0v3l-4 1a1 1 0 0 1-1-1Z"/></svg>';
// Caller details come only from the authenticated room membership already in state.
export function incomingCallDetails(call) {
  const caller = call.group ? call.room?.members?.find(m=>m.id===call.host) : call.peer;
  return {caller, name:text(caller?.name,'Arayan kişi'), group:call.group?text(call.room?.title,'Grup görüşmesi'):null,
    type:`Gelen ${call.video?'görüntülü':'sesli'} ${call.group?'grup araması':'arama'}`};
}
// avatar is the existing application renderer (which escapes the image URL and initials).
export function incomingCallMarkup(call, avatar) {
  const d=incomingCallDetails(call), busy=!!call.accepting;
  return `<section class="call fs-incoming-screen" aria-labelledby="incoming-caller" aria-describedby="incoming-type">
    <div class="incoming-heading" id="incoming-type">${icon(call.video?'video':'phone')}<span>${esc(d.type)}</span></div>
    <div class="incoming-person">
      <div class="incoming-photo">${avatar(d.caller,true)}</div>
      <h1 id="incoming-caller" dir="auto">${esc(d.name)}</h1>
      ${d.group?`<p class="incoming-group" dir="auto">${esc(d.group)}</p>`:''}
      <p class="incoming-status" role="status" aria-live="polite">${busy?'Bağlanıyor…':'Arama geliyor…'}</p>
    </div>
    <div class="incoming-bottom">
      <div class="incoming-actions">
        <button type="button" class="incoming-action incoming-reject" data-action="reject-call" aria-label="Reddet"><span class="incoming-circle">${hangupIcon}</span><span>Reddet</span></button>
        <button type="button" class="incoming-action incoming-accept" data-action="accept-call" aria-label="${busy?'Bağlanıyor':'Kabul et'}" ${busy?'disabled aria-busy="true"':''}><span class="incoming-circle">${icon(call.video?'video':'phone')}</span><span>${busy?'Bağlanıyor…':'Kabul et'}</span></button>
      </div>
      <button type="button" class="incoming-reply" data-action="reply-call" ${busy?'disabled':''}>${icon('send')}<span>Mesajla yanıtla</span></button>
    </div>
  </section>`;
}
