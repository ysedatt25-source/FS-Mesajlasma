import {validVoiceMode,createOutgoingVoice,createVoiceFilters} from './call-voice.js';
import {VOICE_PROFILES} from './voice-transform-dsp.js';
const stop=s=>s?.getTracks().forEach(t=>t.stop());
function timed(p,ms=5000){let timer;return Promise.race([p,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Ses motoru yanıt vermedi.')),ms)})]).finally(()=>clearTimeout(timer));}
// One stable outgoing track for the entire call, including all group peers.
// Normal path bypasses the pitch/EQ/compressor; only capture and WebAudio routing remain.
export async function createLiveCallVoice(raw,initial,{Context=globalThis.AudioContext||globalThis.webkitAudioContext,Worklet=globalThis.AudioWorkletNode,Stream=globalThis.MediaStream,onFailure=()=>{}}={}){
 if(!validVoiceMode(initial)){stop(raw);throw Error('Geçersiz ses modu.');}
 const input=raw.getAudioTracks()[0];if(!input||input.readyState==='ended'){stop(raw);throw Error('Mikrofon açılamadı.');}
 let ctx,source,node,normal,converted,highpass,shelf,warmth,limiter,dest,stream,output,closed=false,ready=false,pending=null,sequence=0,mode=initial,muted=false,busy=false;
 const sync=()=>{if(output)output.enabled=!closed&&!busy&&!muted;};
 const dispose=()=>{if(node){node.onprocessorerror=null;node.port.onmessage=null;}input.removeEventListener('ended',fail);if(pending){pending.reject(Error('Görüşme sona erdi.'));pending=null;}for(const n of [source,node,normal,converted,highpass,shelf,warmth,limiter])try{n?.disconnect()}catch{}if(output){output.enabled=false;output.stop();}if(ctx&&ctx.state!=='closed')try{Promise.resolve(ctx.close()).catch(()=>{})}catch{};};
 const close=()=>{if(closed)return;closed=true;dispose();stop(raw);};
 function fail(){if(closed)return;close();if(ready)onFailure();}
 function gates(next){normal.gain.value=next==='normal'?1:0;converted.gain.value=next==='normal'?0:1;}
 async function switchMode(next){
  if(closed)throw Error('Görüşme sona erdi.');if(!validVoiceMode(next))throw Error('Geçersiz ses modu.');if(busy)throw Error('Ses değişimi sürüyor.');if(next===mode)return mode;
  busy=true;sync();normal.gain.value=0;converted.gain.value=0;
  try{
   if(ctx.state!=='running')await timed(ctx.resume());
   const id=++sequence;await timed(new Promise((resolve,reject)=>{pending={id,resolve,reject};node.port.postMessage({id,mode:next});}));
   if(closed||ctx.state!=='running'||input.readyState==='ended')throw Error('Ses değiştirilemedi.');
   const profile=VOICE_PROFILES[next];shelf.gain.value=profile.shelf;warmth.gain.value=profile.warmth;gates(next);
   // Let the new audio graph settle before permitting output again.
   await new Promise(resolve=>setTimeout(resolve,80));if(closed||ctx.state!=='running'||input.readyState==='ended')throw Error('Ses değiştirilemedi.');
   mode=next;busy=false;sync();return mode;
  }catch(e){fail();throw e;}finally{pending=null;}
 }
 try{
  if(!Context||!Worklet||!Stream)throw Error('Bu cihazda canlı ses değişimi desteklenmiyor.');
  ctx=new Context({latencyHint:'interactive'});if(!ctx.audioWorklet)throw Error('Ses motoru desteklenmiyor.');
  await timed(ctx.audioWorklet.addModule(new URL('./voice-transform-worklet.js',import.meta.url).href));
  source=ctx.createMediaStreamSource(new Stream([input]));node=new Worklet(ctx,'fs-voice-transform',{numberOfInputs:1,numberOfOutputs:1,outputChannelCount:[1],channelCount:1,channelCountMode:'explicit',processorOptions:{mode:initial}});
  normal=ctx.createGain();converted=ctx.createGain();normal.gain.value=converted.gain.value=0;
  ({highpass,shelf,warmth,limiter}=createVoiceFilters(ctx,initial));
  dest=ctx.createMediaStreamDestination();dest.channelCount=1;output=dest.stream.getAudioTracks()[0];output.enabled=false;
  source.connect(normal).connect(dest);source.connect(highpass).connect(node).connect(shelf).connect(warmth).connect(limiter).connect(converted).connect(dest);
  stream=new Stream([output,...raw.getVideoTracks()]);
  node.port.onmessage=e=>{if(pending&&e.data?.id===pending.id){if(e.data.ok)pending.resolve();else pending.reject(Error('Ses motoru modu kabul etmedi.'));}};
  node.onprocessorerror=fail;input.addEventListener('ended',fail,{once:true});
  await timed(ctx.resume());if(closed||ctx.state!=='running'||input.readyState==='ended')throw Error('Ses motoru başlatılamadı.');
  gates(initial);ready=true;sync();
  return {stream,get mode(){return mode;},get muted(){return muted;},get busy(){return busy;},switchMode,setMuted(value){muted=!!value;sync();},close};
 }catch(error){
  // A normal-only call remains usable on old WebViews, but a requested
  // transformed mode is NEVER downgraded to the real microphone voice.
  if(initial==='normal'&&!closed&&input.readyState!=='ended'){
   dispose();const fallback=await createOutgoingVoice(raw,'normal',{Context,Worklet,Stream,onFailure});
   return {...fallback,get muted(){return !input.enabled;},busy:false,setMuted(value){input.enabled=!value;},async switchMode(next){if(next!=='normal')throw Error('Bu cihazda görüşme sırasında ses değişimi desteklenmiyor.');return 'normal';}};
  }close();throw error;
 }
}
