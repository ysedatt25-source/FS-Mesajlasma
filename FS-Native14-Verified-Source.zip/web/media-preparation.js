import {encryptFile} from './crypto.js';
let worker=null,serial=0,queue=Promise.resolve();const pending=new Map();
// Only the worker owning an operation may resolve, reject or terminate it.
// Late events from a replaced worker must not interfere with a new upload.
function failWorker(owner,message){
 if(worker!==owner)return;
 worker=null;owner.terminate();
 for(const [id,p] of pending){if(p.owner!==owner)continue;pending.delete(id);clearTimeout(p.timer);p.reject(Error(message));}
}
function getWorker(){
 if(worker)return worker;
 const owner=new Worker(new URL('./media-worker.js',import.meta.url),{type:'module'});worker=owner;
 owner.onmessage=({data})=>{const p=pending.get(data?.id);if(worker!==owner||p?.owner!==owner)return;pending.delete(data.id);clearTimeout(p.timer);data.error?p.reject(Error(data.error)):p.resolve(data.result);};
 owner.onerror=()=>failWorker(owner,'Medya hazırlama işlemi kesildi.');
 owner.onmessageerror=()=>failWorker(owner,'Medya hazırlama yanıtı okunamadı.');
 return owner;
}
function inWorker(file){return new Promise((resolve,reject)=>{
 const id=++serial;
 try{const owner=getWorker();const timer=setTimeout(()=>failWorker(owner,'Dosya hazırlama zaman aşımına uğradı.'),120000);pending.set(id,{owner,resolve,reject,timer});owner.postMessage({id,file});}
 catch(error){const p=pending.get(id);if(p){clearTimeout(p.timer);pending.delete(id);failWorker(p.owner,'Medya hazırlama işlemi başlatılamadı.');}reject(error);}
});}
export function prepareMedia(file,fallbackThumbnail){const task=queue.catch(()=>{}).then(async()=>{if(typeof Worker==='function'){try{return await inWorker(file)}catch{}}return {encrypted:await encryptFile(file),thumbnail:await fallbackThumbnail(file)}});queue=task.catch(()=>{});return task;}
