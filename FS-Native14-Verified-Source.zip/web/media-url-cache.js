// A bounded LRU object URL cache. A pending decrypt has exactly one owner.
// Clear/delete invalidate in-flight work before a URL can be allocated.
export class MediaUrlCache {
 constructor({count,bytes,create=blob=>URL.createObjectURL(blob),revoke=url=>URL.revokeObjectURL(url)}){if(!Number.isSafeInteger(count)||count<1||!Number.isSafeInteger(bytes)||bytes<1)throw Error("Geçersiz medya önbellek sınırı.");this.count=count;this.budget=bytes;this.create=create;this.revoke=revoke;this.entries=new Map();this.pending=new Map();this.bytes=0;}
 has(id){return this.entries.has(id)}
 get(id){const item=this.entries.get(id);if(!item)return;this.entries.delete(id);this.entries.set(id,item);return item.url;}
 delete(id){this.pending.delete(id);const item=this.entries.get(id);if(!item)return;this.entries.delete(id);this.bytes-=item.size;this.revoke(item.url);}
 clear(){this.pending.clear();for(const id of this.entries.keys())this.delete(id);}
 async load(id,make,valid=()=>true){
  const abort=()=>new DOMException('Medya işlemi iptal edildi.','AbortError');
  if(!valid())throw abort();const hit=this.get(id);if(hit)return hit;
  if(this.pending.has(id)){const url=await this.pending.get(id);if(!valid()||this.entries.get(id)?.url!==url)throw abort();return url;}
  const task=Promise.resolve().then(async()=>{if(!valid()||this.pending.get(id)!==task)throw abort();const blob=await make();if(!valid()||this.pending.get(id)!==task)throw abort();if(!Number.isSafeInteger(blob.size)||blob.size<0||blob.size>this.budget)throw Error('Medya önbellek sınırını aşıyor.');while(this.entries.size>=this.count||this.bytes+blob.size>this.budget)this.delete(this.entries.keys().next().value);const url=this.create(blob);this.entries.set(id,{url,size:blob.size});this.bytes+=blob.size;return url;});
  this.pending.set(id,task);try{return await task;}finally{if(this.pending.get(id)===task)this.pending.delete(id);}
 }
}
// The authenticated message declares the exact encrypted length. Copy each chunk
// once, rather than keeping a full chunk list and then allocating a second copy.
export async function readExactBytes(reader,size,{progress=()=>{},valid=()=>true}={}){
 if(!Number.isSafeInteger(size)||size<16||size>50*1024*1024+16)throw Error('Dosya boyutu geçersiz.');
 const bytes=new Uint8Array(size);let offset=0;
 while(true){if(!valid())throw new DOMException('Dosya işlemi iptal edildi.','AbortError');const {done,value}=await reader.read();if(!valid())throw new DOMException('Dosya işlemi iptal edildi.','AbortError');if(done)break;if(value.length>size-offset)throw Error('Dosya boyutu doğrulanamadı.');bytes.set(value,offset);offset+=value.length;progress(offset);}
 if(offset!==size)throw Error('Dosya boyutu doğrulanamadı.');return bytes;
}
