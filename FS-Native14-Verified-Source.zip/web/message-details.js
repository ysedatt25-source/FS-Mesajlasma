// Explicit acknowledgements are independent of server acceptance and legacy room cursors.
export function mergeReceipts(a=[],b=[]){
 const result=new Map();
 for(const r of [...(Array.isArray(a)?a:[]),...(Array.isArray(b)?b:[])]){
  if(!r||typeof r.user!=='string'||!Number.isFinite(r.delivered)||r.delivered<=0)continue;
  const old=result.get(r.user);const delivered=old?Math.min(old.delivered,r.delivered):r.delivered;
  const reads=[old?.read_at,Number.isFinite(r.read_at)&&r.read_at>=r.delivered?r.read_at:null].filter(Number.isFinite);
  result.set(r.user,{user:r.user,delivered,read_at:reads.length?Math.min(...reads):null});
 }
 return [...result.values()];
}
export function receiptStatus(message,peers){
 const items=Array.isArray(message.album)&&message.album.length?message.album:[message];
 if(items.some(m=>m.queued))return {state:'queued',mark:'Kuyrukta',label:'Gönderim kuyruğunda'};
 if(items.some(m=>m.pending))return {state:'pending',mark:'◷',label:'Gönderiliyor'};
 const rows=items.map(m=>new Map(mergeReceipts(m.receipts_v2).map(r=>[r.user,r]))),ids=[...new Set((Array.isArray(peers)?peers:[]).filter(id=>typeof id==='string'&&id))];
 const count=ids.filter(id=>rows.every(row=>row.has(id))).length;
 const read=ids.filter(id=>rows.every(row=>row.get(id)?.read_at!=null)).length;
 if(ids.length&&read===ids.length)return {state:'read',mark:'✓✓',label:`Okundu (${read}/${ids.length})`,read:true};
 if(ids.length&&count===ids.length)return {state:'delivered',mark:'✓',label:`Teslim edildi (${count}/${ids.length})`,read:false};
 return {state:'accepted',mark:'✓',label:`Sunucu kabul etti${count||read?` · Teslim ${count}/${ids.length}, okundu ${read}/${ids.length}`:''}`};
}
export function receiptBatch(messages,self,visible){
 const delivered=[],read=[];
 for(const m of messages){
  if(m.sender===self||m.pending||m.queued||m.callRecord||!m.envelope||!m.payload||['locked','reaction','vote'].includes(m.payload.type))continue;
  const own=(m.receipts_v2||[]).find(r=>r.user===self);
  if(!own)delivered.push(m.id);
  if(visible.has(m.id)&&!own?.read_at)read.push(m.id);
 }
 return {delivered,read};
}
