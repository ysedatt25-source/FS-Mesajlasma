// Preserve the three legacy wire effects so older clients can still read text.
export const MESSAGE_EFFECTS=Object.freeze([
 {id:'heart',base:'heart',glyph:'❤️',label:'Kalpler'},
 {id:'sparkle',base:'sparkle',glyph:'✨',label:'Parıltı'},
 {id:'celebrate',base:'celebrate',glyph:'🎉',label:'Kutlama'},
 {id:'fireworks',base:'celebrate',glyph:'🎆',label:'Havai fişek'},
 {id:'fire',base:'sparkle',glyph:'🔥',label:'Ateş'},
 {id:'kiss',base:'heart',glyph:'💋',label:'Öpücük'},
].map(Object.freeze));
export function effectFields(id){const e=MESSAGE_EFFECTS.find(x=>x.id===id);return e?{effect:e.base,...(e.id!==e.base?{effectVariant:e.id}:{})}:{};}
export function messageEffect(base,variant){return MESSAGE_EFFECTS.find(x=>x.id===variant&&x.base===base)||MESSAGE_EFFECTS.find(x=>x.id===base&&x.base===base)||null;}
export function validEffectVariant(base,variant){return MESSAGE_EFFECTS.some(x=>x.id===variant&&x.base===base&&x.id!==x.base);}
export function createEffectHistory(limit=512){const seen=new Set();return {accept(key){if(seen.has(key))return false;seen.add(key);if(seen.size>limit)seen.delete(seen.values().next().value);return true;},clear(){seen.clear();}};}
// A dedicated layer, independent of the interactive single-emoji scene.
export function drawMessageEffect(node,effect,{schedule=setTimeout}={}){
 if(!node?.isConnected||!effect)return false;
 const doc=node.ownerDocument,host=node.closest('.fs-chat')||node;
 host.querySelectorAll('.send-effect-overlay').forEach(x=>x.remove());
 const fx=doc.createElement('span');fx.className='send-effect-overlay';fx.dataset.effect=effect.id;fx.setAttribute('aria-hidden','true');
 const rect=node.getBoundingClientRect(),bounds=host.getBoundingClientRect();
 const x=Math.max(0,Math.min(bounds.width,rect.left+rect.width/2-bounds.left)),y=Math.max(0,Math.min(bounds.height,rect.top+rect.height/2-bounds.top));
 fx.style.setProperty('--send-fx-x',`${x}px`);fx.style.setProperty('--send-fx-y',`${y}px`);
 const spread=Math.max(.25,Math.min(1,bounds.width/340,bounds.height/400));
 const glyphs={heart:['❤️','💗','💕'],sparkle:['✨','✦','✧'],celebrate:['🎉','🎊','✨'],fireworks:['🎆','✦','⋆'],fire:['🔥','🟠','✦'],kiss:['💋','💕','✨']}[effect.id];
 for(let i=0;i<12;i++){const p=doc.createElement('span'),a=i*Math.PI/6,r=(48+i%4*22)*spread;let dx=Math.cos(a)*r,dy=Math.sin(a)*r;if(['heart','fire','kiss'].includes(effect.id))dy=-Math.abs(dy)-24*spread;if(effect.id==='celebrate')dy=Math.abs(dy)+18*spread;p.className='send-effect-particle';p.textContent=glyphs[i%3];p.style.setProperty('--fx-dx',`${Math.round(dx)}px`);p.style.setProperty('--fx-dy',`${Math.round(dy)}px`);p.style.setProperty('--fx-delay',`${i%3*45}ms`);fx.append(p);}
 host.append(fx);schedule(()=>fx.remove(),1150);return true;
}
