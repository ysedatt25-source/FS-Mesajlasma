import {isViewOnce} from "./view-once.js";
export function gestureIntent(dx,dy,release=false){
 const x=Math.abs(dx),y=Math.abs(dy);
 if(release)return dx<=-58&&x>y*1.25?'reply':'cancel';
 if(x<12&&y<12)return 'wait';
 if(dx<0&&x>y*1.25)return 'swipe';
 return 'scroll';
}
// Keep the activation threshold and visual feedback in one place.
export function replySwipeFeedback(dx,dy){
 const distance=Math.max(0,-dx),armed=gestureIntent(dx,dy,true)==='reply';
 return {offset:-Math.min(82,distance),progress:Math.min(1,distance/58),armed};
}
// Variation selectors change presentation, not the reaction identity.
export function reactionKey(value){return typeof value==='string'?value.normalize('NFC').replace(/\uFE0F/g,''):'';}
export function sameReaction(a,b){return !!reactionKey(a)&&reactionKey(a)===reactionKey(b);}
export function reactionValue(current,chosen){return sameReaction(current,chosen)?'':chosen;}
export function isReactionDoubleTap(first,next){return !!first&&first.id===next.id&&first.room===next.room&&first.route===next.route&&first.user===next.user&&next.at>=first.at&&next.at-first.at<=280&&Math.hypot(next.x-first.x,next.y-first.y)<=28;}
export function reactionChoices(quick,active){return active&&!quick.some(x=>sameReaction(x,active))?[...quick.slice(0,-1),active]:quick;}

// Recompute from the gesture's initial snapshot, never toggle on every pointermove.
// Reversing direction restores the original state of rows left behind.
export function selectionRange(order,baseline,anchor,target,adding){
 const result=new Set(baseline),a=order.indexOf(anchor),b=order.indexOf(target);
 if(a<0||b<0)return result;
 for(let i=Math.min(a,b);i<=Math.max(a,b);i++)adding?result.add(order[i]):result.delete(order[i]);
 return result;
}
export function messageHasDetails(m,self){return !!m&&!m.callRecord&&!m.pending&&((m.sender===self&&!m.queued)||m.history_count>0);}
export function selectionOps(messages,self,localDelete=false){
 if(messages.some(m=>m.callRecord))return [["Kopyala","▣"],...(localDelete?[["Sil","⌫"]]:[])];
 const one=messages.length===1,own=messages.length>0&&messages.every(m=>m.sender===self);
 const restricted=messages.some(isViewOnce);
 return [...(one?[["Yanıtla","↩"],["Tepki","☺"]]:[]),["Kopyala","▣"],...(one&&own&&messages[0].payload.type==='text'?[["Düzenle","✎"]]:[]),...(!restricted?[["İlet","↪"],["Paylaş","↗"],["Kaydet","☆"]]:[]),...(one&&messageHasDetails(messages[0],self)?[["Bilgi","ⓘ"]]:[]),...(messages.length&&(own||localDelete)?[["Sil","⌫"]]:[])];
}

// A proportional edge velocity, bounded to avoid sudden jumps on short screens.
export function selectionEdgeStep(y,top,bottom){
 if(![y,top,bottom].every(Number.isFinite)||bottom<=top)return 0;
 const band=Math.min(48,(bottom-top)/3);
 const delta=y<top+band?y-(top+band):y>bottom-band?y-(bottom-band):0;
 return delta?Math.sign(delta)*Math.min(22,Math.ceil(Math.abs(delta)/3)):0;
}

// Use layout-viewport coordinates, including visualViewport offsets when the keyboard or zoom is active.
export function messageMenuPlacement(anchor,viewport,width,height){
 const margin=8,gap=7,left=viewport.left+margin,top=viewport.top+margin,right=viewport.left+viewport.width-margin,bottom=viewport.top+viewport.height-margin;
 const w=Math.max(0,Math.min(width,right-left)),h=Math.max(0,Math.min(height,bottom-top));
 const below=Math.max(0,bottom-anchor.bottom-gap),above=Math.max(0,anchor.top-top-gap);
 let side=below>=h?'below':above>=h?'above':below>=above?'below':'above';
 const space=side==='below'?below:above;
 // If neither side has room for a useful menu, allow an overlay, always within the viewport.
 const fit=space>=Math.min(h,160)?Math.min(h,space):h;
 if(space<Math.min(h,160))side='overlay';
 const x=Math.max(left,Math.min(anchor.own?anchor.right-w:anchor.left,right-w));
 const y=Math.max(top,Math.min(side==='above'?anchor.top-gap-fit:anchor.bottom+gap,bottom-fit));
 return {x,y,width:w,height:fit,side};
}
export function messageContextOps(m,self){
 if(!m||m.pending||['reaction','vote'].includes(m.payload.type))return [];
 if(m.callRecord)return ['Kopyala','Seç','Sil'];
 const text=m.payload.type==='text',own=m.sender===self;
 return ['Yanıtla',...(text?['Alıntıla']:[]),'Kopyala',...(own&&text?['Düzenle']:[]),...(!isViewOnce(m)?['İlet','Paylaş','Kaydet',...(m.payload.type==='file'&&m.payload.mime?.startsWith('image/')?['İndir']:[])]:[]),...(messageHasDetails(m,self)?['Bilgi']:[]),...(!isViewOnce(m)?['Sabitle']:[]),'Seç','Sil'];
}

// Show only explicit, valid receipts for current peers. Never infer a read from a send or a legacy cursor.
export function contextReceipt(m,self,members){
 if(!m||m.sender!==self||m.callRecord||m.pending||m.queued)return null;
 const peers=[...new Set((Array.isArray(members)?members:[]).map(x=>x?.id).filter(x=>typeof x==='string'&&x&&x!==self))];
 if(!peers.length)return null;
 const rows=new Map();
 for(const r of Array.isArray(m.receipts_v2)?m.receipts_v2:[]){
  if(!peers.includes(r?.user)||!Number.isFinite(r.delivered)||r.delivered<=0)continue;
  const old=rows.get(r.user),delivered=old?Math.min(old.delivered,r.delivered):r.delivered;
  const times=[old?.read,Number.isFinite(r.read_at)&&r.read_at>=r.delivered?r.read_at:null].filter(Number.isFinite);
  rows.set(r.user,{delivered,read:times.length?Math.min(...times):null});
 }
 const records=[...rows.values()],read=records.filter(r=>r.read!==null);
 if(read.length===peers.length)return {label:'Okundu',mark:'✓✓',at:Math.max(...read.map(r=>r.read)),read:true};
 if(records.length===peers.length)return {label:'Teslim edildi',mark:'✓✓',at:Math.max(...records.map(r=>r.delivered)),read:false};
 return {label:records.length?`Teslim ${records.length}/${peers.length}`:'Gönderildi',mark:'✓',at:null,read:false};
}
