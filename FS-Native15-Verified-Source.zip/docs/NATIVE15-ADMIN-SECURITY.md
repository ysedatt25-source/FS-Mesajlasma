# Native15 yönetim ve veri koruma durumu

Mevcut paket ve APK imzalama anahtarı korunur. Sürüm kodu 15'tir; Native14 üzerine yükseltme için hazırlanır. Yeni APK imzalama anahtarı veya kullanıcı şifreleme anahtarı oluşturulmaz.

Yönetim paneli Ayarlar > Yönetim Paneli yolundadır; yalnız mevcut yönetici rolüne sahip hesap görebilir. API her istekte aynı yetkiyi ayrıca doğrular. Kullanıcı/sohbet araması ve ayrı sayfalama, kayıt sayıları, bekleyen dosya silme durumu, yönetici anahtarının yerel cihazla karşılaştırılması ve geçmiş mesaj sayfaları eklenmiştir. Yönetici verileri normal sohbet önbelleğine yazılmaz. Parolalar, parola özetleri ve özel anahtarlar yönetim envanterine dahil edilmez.

Yönetici silmesinde mesaj zarfları, geçmiş sürümler, oturumlar ve ilişkili kayıtlar SQL işlemiyle kaldırılır. Sohbet/kullanıcı kademeli silmesi dosya kuyruğunu artık ortadan kaldırmaz. Disk erişim hatası varsa kuyruk kalır; başlangıçta ve periyodik bakımda tekrar denenir. Tamamlanmamış silme panelde gösterilir. SQLite WAL dosyası için silmeden sonra kesme kontrolü denenir; başarı sonucu API yanıtında bildirilir. Bunun SSD hücresi veya sağlayıcı snapshot silme garantisi olduğu iddia edilmez.

Yönetici açık anahtarı ilk güvenilen kullanımda cihazda SHA256 parmak iziyle sabitlenir. Sonraki sessiz anahtar/kimlik değişimi veya yönetici zarfının kaldırılması gönderimi durdurur. Özel anahtar sunucuya gönderilmez; var olan cihaz anahtarları değiştirilmez. İlk bağlantının bağımsız kimlik doğrulaması ve cihazlar arasında parmak izi karşılaştırması halen gereklidir. Bu TOFU kontrolü tek başına kötü niyetli bir sağlayıcının tüm aktif saldırılarını önlemez.

Kapsam sınırları: mevcut mesaj ve medya şifrelemesi kullanılır; tüm hesap/bağlantı üst verileri şifrelenmiş değildir. Yönetici zarfı veya kurtarma anahtarı bulunmayan eski içerik geriye dönük açılamaz. Deneysel ratchet kanalları ve tek görüntülemelik medya mevcut kısıtlarını korur. Hikâyelerde yöneticiye otomatik yeni alıcı eklenmemiştir. Dolayısıyla yöneticinin istisnasız bütün içerikleri açabildiği veya yönetici dışındaki herkesin bütün üst verilere erişiminin engellendiği söylenemez.

Sağlayıcının eski yedekleri, logları, snapshotları ve kullanıcıların dışa kaydettiği kopyaları uygulama API'si silemez. Kriptografik silme, koruyan anahtarların bütün kopyalarının yok edilebildiği durumlarda değerlendirilebilir; eski kurtarılabilir açık metin veya anahtar kopyalarını yok etmez. Kaynaklar: OWASP Cryptographic Storage / Key Management Cheat Sheets; NIST SP 800-88 Rev.2.

Canlı geçiş ayrı onay gerektirir. Mevcut /data birimi korunur; yeni erasure_files tablosu eklemelidir. Önceki sunucu komutu geri dönüş için saklanır. Gerçek kullanıcı kayıtları testlere kopyalanmaz. Bu dosya canlı geçiş veya nihai fiziksel cihaz kabulü yapıldığı anlamına gelmez.
