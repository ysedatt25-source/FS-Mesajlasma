"""Bounded administrator-only inventory; never returns passwords or private keys."""
from aiohttp import web


def install(app, authorize, public_user, audit_user):
    async def overview(request):
        authorize(request)
        s=app['store']
        counts={table:s.one(f'SELECT count(*) n FROM {table}')['n']
                for table in ('users','rooms','messages','uploads','stories')}
        pending=s.one('SELECT count(*) n FROM erasure_files')['n']+s.one('SELECT count(*) n FROM deleted_upload_queue')['n']
        size=s.one('SELECT COALESCE(sum(size),0) n FROM uploads')['n']
        admin=audit_user(s)
        return web.json_response({'counts':counts,'encryptedMediaBytes':size,
            'pendingFileDeletions':pending,'admin':admin,
            'protection':{'content':'client-encrypted','plaintextPrivateKeysOnServer':False,
                'metadataEncrypted':False,'providerSnapshotsVerified':False,
                'retroactiveAdminAccess':False}})

    async def inventory(request):
        authorize(request)
        s=app['store'];kind=request.match_info['kind']
        offset=int(request.query.get('offset','0'));limit=int(request.query.get('limit','50'))
        query=request.query.get('q','').strip()
        if not 0<=offset<=10000000 or not 1<=limit<=100 or len(query)>100:raise ValueError()
        # Literal substring search: '%' and '_' are not wildcard instructions.
        term='%'+query.replace('!', '!!').replace('%','!%').replace('_','!_')+'%'
        if kind=='users':
            where=" WHERE (LOWER(nick) LIKE LOWER(?) ESCAPE '!' OR LOWER(name) LIKE LOWER(?) ESCAPE '!' OR phone LIKE ? ESCAPE '!')"
            args=(term,term,term)
            total=s.one('SELECT count(*) n FROM users'+where,args)['n']
            rows=s.all('SELECT * FROM users'+where+' ORDER BY created DESC,id DESC LIMIT ? OFFSET ?',(*args,limit,offset))
            items=[{**public_user(r,s),'phone':r['phone'],'created':r['created']} for r in rows]
        else:
            where=" WHERE LOWER(title) LIKE LOWER(?) ESCAPE '!'";args=(term,)
            total=s.one('SELECT count(*) n FROM rooms'+where,args)['n']
            items=s.all('SELECT * FROM rooms'+where+' ORDER BY created DESC,id DESC LIMIT ? OFFSET ?',(*args,limit,offset))
            admin=audit_user(s)
            for room in items:
                room['members']=[public_user(r,s) for r in s.all('SELECT u.* FROM users u JOIN members m ON m.user=u.id WHERE m.room=? ORDER BY u.id',(room['id'],))]
                room['audit']=admin
        return web.json_response({'items':items,'total':total,'nextOffset':offset+len(items) if offset+len(items)<total else None})

    app.router.add_get('/api/admin/overview',overview)
    app.router.add_get('/api/admin/console/{kind:users|rooms}',inventory)
