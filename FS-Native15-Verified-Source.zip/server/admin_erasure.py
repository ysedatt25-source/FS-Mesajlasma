"""Crash-recoverable deletion of ciphertext files after SQL cascades.

This is application deletion, not a claim about provider snapshots or SSD erasure.
The queue deliberately has no foreign key to a row being deleted.
"""
import re


def queue_files(store, identifiers):
    for ident in set(identifiers):
        if not isinstance(ident, str) or not re.fullmatch(r'[A-Za-z0-9_-]{16,64}', ident):
            raise ValueError('Invalid encrypted file identifier')
        store.db.execute('INSERT OR IGNORE INTO erasure_files VALUES(?)', (ident,))


def drain_files(store, limit=100):
    for row in store.all('SELECT id FROM erasure_files ORDER BY id LIMIT ?', (limit,)):
        ident = row['id']
        # Never let corrupt queue state escape the dedicated data directory.
        if not re.fullmatch(r'[A-Za-z0-9_-]{16,64}', ident):
            continue
        try:
            (store.dir / ident).unlink(missing_ok=True)
        except OSError:
            continue
        store.run('DELETE FROM erasure_files WHERE id=?', (ident,))


def checkpoint(store):
    """Best effort WAL truncation, without interrupting concurrent readers."""
    if hasattr(store.db, 'connection'):
        return False
    try:
        row = store.db.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()
        return row[0] == 0
    except Exception:
        # Deletion remains committed and the persistent file queue can retry.
        return False
