"""Private administrator alias. Credentials are deployment secrets, never APK data."""
import asyncio,base64,hashlib,hmac,os,re,secrets
from aiohttp import web

def enabled():
    return bool(os.environ.get('FS_ADMIN_LOGIN_EMAIL') or os.environ.get('FS_ADMIN_LOGIN_HASH'))

def permitted(request,user,admin):
    if not admin or admin['id']!=user:return False
    if not enabled():return True
    token=request.headers.get('Authorization','')[7:]
    digest=hashlib.sha256(token.encode()).hexdigest()
    return bool(request.app['store'].one('SELECT 1 FROM admin_sessions WHERE token=?',(digest,)))

async def login(request,b,*,device_public_key,public_key_matches,audit_user,public_user,now,rate):
    rate(request,'admin-login',5)
    s=request.app['store'];email=os.environ.get('FS_ADMIN_LOGIN_EMAIL','').strip().lower()
    encoded=os.environ.get('FS_ADMIN_LOGIN_HASH','');parts=encoded.split('$')
    valid=len(parts)==3 and parts[0]=='scrypt-v1'
    try:
        salt=base64.b64decode(parts[1],validate=True) if valid else b'invalid-admin-salt'
        expected=base64.b64decode(parts[2],validate=True) if valid else bytes(64)
        valid=valid and len(salt)==32 and len(expected)==64
    except (ValueError,IndexError):salt=b'invalid-admin-salt';expected=bytes(64);valid=False
    password=b.get('password','')
    hashed=await asyncio.to_thread(hashlib.scrypt,password.encode(),salt=salt,n=16384,r=8,p=1)
    if not valid or not email or not hmac.compare_digest(b['login'].strip().lower(),email) or not hmac.compare_digest(hashed,expected):
        raise web.HTTPUnauthorized(text='Giriş bilgileri yanlış.')
    admin=audit_user(s)
    if not admin:raise web.HTTPUnauthorized(text='Giriş bilgileri yanlış.')
    user=admin['id'];pub=device_public_key(b.get('pub'))
    if not public_key_matches(pub,admin['pub']):
        # An alias password must never rotate the administrator's decryption key.
        raise web.HTTPConflict(text='Bu cihazın anahtarı eşleşmiyor. Mevcut anahtar yedeğinizi içe aktarın.')
    if 'recovery_account' in b and b['recovery_account']!=user:raise web.HTTPConflict(text='Anahtar yedeği bu hesapla eşleşmiyor.')
    token=secrets.token_urlsafe(32);digest=hashlib.sha256(token.encode()).hexdigest()
    from database import transaction
    with transaction(s.db):
        s.db.execute('INSERT INTO sessions VALUES(?,?,?)',(digest,user,now()+3600000))
        s.db.execute('INSERT INTO admin_sessions VALUES(?)',(digest,))
    row=s.one('SELECT * FROM users WHERE id=?',(user,))
    import json
    return web.json_response({'token':token,'deviceChanged':False,'user':public_user(row,s),
        'settings':{**json.loads(row['settings']),'notifications':False},'isAdmin':True,'adminEntry':True})
