import test from 'node:test';import assert from 'node:assert/strict';import {Window} from 'happy-dom';
import {adminDashboard} from '../web/admin-console.js';
const escape=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
test('admin dashboard escapes record and search values and separates privileged self deletion',()=>{
 const w=new Window(),evil='<img src=x onerror="alert(1)">',admin={id:'admin',name:'Admin',nick:'owner',phone:'1'};
 const summary={admin,counts:{users:2,rooms:1},pendingFileDeletions:3};const users={items:[admin,{id:'peer',name:evil,nick:evil,phone:evil}],total:2,nextOffset:null};
 const rooms={items:[{id:'r',title:evil,members:[]}],total:1,nextOffset:null};
 w.document.body.innerHTML=adminDashboard(summary,users,rooms,escape,evil);
 assert.equal(w.document.querySelector('img'),null);assert.equal(w.document.querySelector('#admin-query').value,evil);
 assert.equal(w.document.querySelectorAll('[data-kind="users"]').length,1);assert.match(w.document.body.textContent,/Bekleyen dosya silme: 3/);
 assert.match(w.document.body.textContent,/tamamı şifreli değildir/);w.happyDOM.abort();
});
test('independent user and room pagination retains the other offset',()=>{
 const w=new Window(),summary={counts:{},admin:{id:'a'}};w.document.body.innerHTML=adminDashboard(summary,{items:[],total:150,nextOffset:100},{items:[],total:200,nextOffset:150},escape,'q',50,100);
 const pages=[...w.document.querySelectorAll('[data-action="admin-page"]')];
 assert.deepEqual(pages.map(x=>[x.dataset.usersOffset,x.dataset.roomsOffset]),[['50','50'],['50','150'],['0','100'],['100','100']]);w.happyDOM.abort();
});
