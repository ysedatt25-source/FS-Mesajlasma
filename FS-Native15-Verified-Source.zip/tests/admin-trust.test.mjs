import test from 'node:test';
import assert from 'node:assert/strict';
import {assertAdminTrust,adminFingerprint} from '../web/admin-trust.js';
const admin={id:'admin',pub:{kty:'EC',crv:'P-256',x:'A'.repeat(43),y:'B'.repeat(43)}};
function store(){const data=new Map();return {data,read:async k=>data.get(k),write:async(k,v)=>data.set(k,v)}}
test('first-use administrator pin is persistent and stable across equivalent public JWK metadata',async()=>{
 const s=store(),first=await assertAdminTrust('https://api.invalid',admin,s);
 assert.equal(first.length,64);assert.equal(await assertAdminTrust('https://api.invalid',{...admin,pub:{...admin.pub,ext:true,key_ops:[]}},s),first);assert.equal(s.data.size,1);
 assert.equal(JSON.stringify([...s.data]).includes('privateKey'),false);
});
test('changed identity, changed key and removed administrator fail closed without replacing pin',async()=>{
 const s=store();await assertAdminTrust('origin',admin,s);const saved=JSON.stringify([...s.data]);
 for(const changed of [null,{...admin,id:'attacker'},{...admin,pub:{...admin.pub,x:'C'.repeat(43)}}])await assert.rejects(assertAdminTrust('origin',changed,s));
 assert.equal(JSON.stringify([...s.data]),saved);
});
test('parallel first-use attempts cannot race to replace a pin',async()=>{
 const s=store();const r=await Promise.allSettled([assertAdminTrust('race',admin,s),assertAdminTrust('race',{...admin,id:'other'},s)]);
 assert.deepEqual(r.map(x=>x.status),['fulfilled','rejected']);
});
test('pins are scoped to the API server and lock cancels first-use writes',async()=>{
 const s=store();await assertAdminTrust('a',admin,s);await assertAdminTrust('b',{...admin,id:'other'},s);assert.equal(s.data.size,2);
 await assert.rejects(assertAdminTrust('locked',admin,{...s,valid:()=>false}),{name:'AbortError'});assert.equal(s.data.size,2);
});
test('private or malformed public key input is rejected',async()=>{
 await assert.rejects(adminFingerprint({...admin,pub:{...admin.pub,d:'private'}}));await assert.rejects(adminFingerprint({...admin,pub:{...admin.pub,x:'bad'}}));
});
