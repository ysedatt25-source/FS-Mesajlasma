"""Real isolated API and disk deletion; no live data or provider calls."""
import json
from pathlib import Path
from unittest.mock import patch
import unittest
import test_server as base
from aiohttp.test_utils import TestClient,TestServer
from app import create_app,expire_messages

class AdminConsoleTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=base.APITest.asyncSetUp
    asyncTearDown=base.APITest.asyncTearDown
    register=base.APITest.register
    h=base.APITest.h
    env=base.APITest.env
    def promote(self):
        self.app['store'].run("INSERT INTO app_config VALUES('admin',?)",(self.c['user']['id'],))
    async def upload_message(self,mid='erasure_message_123456'):
        r=await self.client.post('/api/uploads',headers=self.h(self.a),json={'room':self.room,'size':6})
        ident=(await r.json())['id']
        self.assertEqual((await self.client.put('/api/uploads/'+ident,headers={**self.h(self.a),'Upload-Offset':'0'},data=b'cipher')).status,200)
        r=await self.client.post('/api/rooms/'+self.room+'/messages',headers=self.h(self.a),json={'id':mid,'envelopes':{**self.env(),self.c['user']['id']:base.ENVELOPE},'uploads':[ident]})
        self.assertEqual(r.status,201,await r.text());return ident
    async def test_inventory_is_admin_only_bounded_search_and_no_credentials(self):
        for path in ['/api/admin/overview','/api/admin/console/users','/api/admin/console/rooms']:
            self.assertEqual((await self.client.get(path)).status,401)
            self.assertEqual((await self.client.get(path,headers=self.h(self.a))).status,403)
        self.promote()
        r=await self.client.get('/api/admin/console/users?limit=1',headers=self.h(self.c));body=await r.json()
        self.assertEqual(body['total'],3);self.assertEqual(len(body['items']),1);self.assertEqual(body['nextOffset'],1)
        for user in body['items']:self.assertFalse(set(user)&{'password','salt','token','settings'})
        r=await self.client.get('/api/admin/console/users?q=ALICE',headers=self.h(self.c));self.assertEqual((await r.json())['items'][0]['nick'],'alice')
        for query in ['limit=101','offset=-1','q='+'x'*101]:self.assertEqual((await self.client.get('/api/admin/console/users?'+query,headers=self.h(self.c))).status,400)
        # Wildcards are literal, not an instruction to retrieve every account.
        self.assertEqual((await(await self.client.get('/api/admin/console/users?q=%25',headers=self.h(self.c))).json())['total'],0)
        report=await(await self.client.get('/api/admin/overview',headers=self.h(self.c))).json()
        self.assertFalse(report['protection']['metadataEncrypted']);self.assertFalse(report['protection']['providerSnapshotsVerified'])
    async def test_room_file_erasure_survives_sql_cascade_disk_failure_and_restart(self):
        self.promote();ident=await self.upload_message();store=self.app['store'];target=Path(self.tmp.name)/ident
        original=Path.unlink
        def fail(path,*a,**kw):
            if path==target:raise OSError('simulated disk failure')
            return original(path,*a,**kw)
        with patch.object(Path,'unlink',fail):
            r=await self.client.delete('/api/admin/rooms/'+self.room,headers=self.h(self.c));self.assertEqual(r.status,200,await r.text());self.assertEqual((await r.json())['pendingFileDeletions'],1)
            self.assertTrue(target.exists());self.assertIsNone(store.one('SELECT 1 FROM uploads WHERE id=?',(ident,)))
            self.assertTrue(store.one('SELECT 1 FROM erasure_files WHERE id=?',(ident,)))
            self.assertEqual((await self.client.get('/api/admin/uploads/'+ident,headers=self.h(self.c))).status,404)
        await self.client.close();self.app=create_app(self.tmp.name);self.client=TestClient(TestServer(self.app));await self.client.start_server()
        self.assertFalse(target.exists());self.assertIsNone(self.app['store'].one('SELECT 1 FROM erasure_files'))
    async def test_user_deletion_removes_message_revisions_uploads_and_auth(self):
        self.promote();ident=await self.upload_message();store=self.app['store'];mid='erasure_message_123456'
        store.run('INSERT INTO message_revisions VALUES(?,?,?,?,?)',(mid,1,1,json.dumps(self.env()),'{}'))
        r=await self.client.delete('/api/admin/users/'+self.a['user']['id'],headers=self.h(self.c));self.assertEqual(r.status,200,await r.text())
        self.assertFalse((Path(self.tmp.name)/ident).exists());self.assertIsNone(store.one('SELECT 1 FROM messages WHERE id=?',(mid,)));self.assertIsNone(store.one('SELECT 1 FROM message_revisions WHERE message=?',(mid,)))
        self.assertEqual((await self.client.get('/api/me',headers=self.h(self.a))).status,401)
        self.assertTrue(store.one('SELECT 1 FROM users WHERE id=?',(self.b['user']['id'],)))
        self.assertEqual(store.db.execute('PRAGMA foreign_key_check').fetchall(),[])
    async def test_message_pagination_has_no_same_timestamp_gaps(self):
        self.promote();store=self.app['store'];env=json.dumps({**self.env(),self.c['user']['id']:base.ENVELOPE})
        with __import__('app').transaction(store.db):
            store.db.executemany('INSERT INTO messages(id,room,sender,envelopes,created) VALUES(?,?,?,?,?)',[(f'page_message_{i:04}',self.room,self.a['user']['id'],env,1234) for i in range(205)])
        path='/api/admin/rooms/'+self.room+'/messages';first=await(await self.client.get(path,headers=self.h(self.c))).json();tail=first[-1]
        second=await(await self.client.get(path,params={'before':tail['created'],'before_id':tail['id']},headers=self.h(self.c))).json()
        self.assertEqual(len(first),200);self.assertEqual(len(second),5);self.assertEqual(len({x['id'] for x in first+second}),205)
    async def test_self_deletion_and_path_traversal_are_rejected(self):
        self.promote();r=await self.client.delete('/api/admin/users/'+self.c['user']['id'],headers=self.h(self.c));self.assertEqual(r.status,400)
        from admin_erasure import queue_files
        with self.assertRaises(ValueError):queue_files(self.app['store'],['../fs.sqlite'])
    async def test_deleting_room_ends_only_its_active_call(self):
        self.promote();s=self.app['store'];a,b=self.a['user']['id'],self.b['user']['id']
        s.calls[a]={'id':'call_erasure_123456','room':self.room,'peer':b}
        s.calls[b]={'id':'call_erasure_123456','room':self.room,'peer':a}
        s.calls['unrelated']={'id':'other_call_123456','room':'unrelated_room'}
        r=await self.client.delete('/api/admin/rooms/'+self.room,headers=self.h(self.c));self.assertEqual(r.status,200,await r.text())
        self.assertEqual(set(s.calls),{'unrelated'})

if __name__=='__main__':unittest.main()
