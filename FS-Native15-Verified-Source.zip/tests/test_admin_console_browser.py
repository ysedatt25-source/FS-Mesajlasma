"""Actual Chromium layout for the new administrator inventory."""
import json,os,pathlib,unittest
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]

class AdminConsoleLayout(unittest.TestCase):
    def test_narrow_and_wide_inventory_without_overflow(self):
        source=(ROOT/'web/admin-console.js').read_text().replace('export function','function')
        style=(ROOT/'web/style.css').read_text()
        with sync_playwright() as p:
            options={'headless':True,'args':['--no-sandbox']}
            if os.environ.get('FS_CHROMIUM'):options['executable_path']=os.environ['FS_CHROMIUM']
            browser=p.chromium.launch(**options)
            try:
                page=browser.new_page()
                for width in (280,320,412,1280):
                    page.set_viewport_size({'width':width,'height':800})
                    page.set_content('<style>'+style+'</style><main id="host" style="padding:12px;box-sizing:border-box;width:100%"></main>')
                    page.add_script_tag(content=source)
                    result=page.evaluate('''()=>{
                      const escape=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
                      const users={items:[{id:'peer',name:'Çok uzun kullanıcı adı '.repeat(6),nick:'k'.repeat(64),phone:'+905001234567'}],total:100,nextOffset:50};
                      const rooms={items:[{id:'room',title:'Sohbet '.repeat(30),members:[]}],total:100,nextOffset:50};
                      document.querySelector('#host').innerHTML=adminDashboard({admin:{id:'admin'},counts:{users:100,rooms:100},pendingFileDeletions:1},users,rooms,escape);
                      return {width:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth,buttons:[...document.querySelectorAll('button')].map(b=>({x:b.getBoundingClientRect().x,right:b.getBoundingClientRect().right}))};
                    }''')
                    self.assertLessEqual(result['scroll'],result['width']+1,result)
                    for button in result['buttons']:
                        self.assertGreaterEqual(button['x'],-1);self.assertLessEqual(button['right'],width+1)
            finally:browser.close()

if __name__=='__main__':unittest.main()
