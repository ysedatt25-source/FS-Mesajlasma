import base64,hashlib,os,unittest
from unittest.mock import patch
import test_server as base

class PrivateAdminLogin(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=base.APITest.asyncSetUp
    asyncTearDown=base.APITest.asyncTearDown
    register=base.APITest.register
    h=base.APITest.h
    async def test_private_alias_is_separate_from_phone_login_and_does_not_rotate_keys(self):
        s=self.app['store'];s.run("INSERT INTO app_config VALUES('admin',?)",(self.c['user']['id'],))
        salt=os.urandom(32);password='isolated-admin-pass-123';encoded='scrypt-v1$'+base64.b64encode(salt).decode()+'$'+base64.b64encode(hashlib.scrypt(password.encode(),salt=salt,n=16384,r=8,p=1)).decode()
        initial=dict(s.one('SELECT * FROM users WHERE id=?',(self.c['user']['id'],)))
        with patch.dict(os.environ,{'FS_ADMIN_LOGIN_EMAIL':'admin@example.test','FS_ADMIN_LOGIN_HASH':encoded}):
            b={'login':'admin@example.test','password':password,'pub':base.PUB}
            r=await self.client.post('/api/session',json=b);self.assertEqual(r.status,200,await r.text());admin=await r.json();self.assertTrue(admin['adminEntry'])
            self.assertEqual((await self.client.get('/api/admin/overview',headers=self.h(admin))).status,200)
            me=await(await self.client.get('/api/me',headers=self.h(admin))).json();self.assertTrue(me['isAdmin'])
            # A normal existing session for the same account is not a private admin session.
            self.assertEqual((await self.client.get('/api/admin/overview',headers=self.h(self.c))).status,403)
            normal=await(await self.client.post('/api/session',json={'login':'+905003333333','password':'test-password-123','pub':base.PUB})).json();self.assertFalse(normal['isAdmin'])
            self.assertEqual((await self.client.get('/api/admin/overview',headers=self.h(normal))).status,403)
            for change,code in [({'login':'other@example.test'},401),({'password':'incorrect-pass'},401),({'pub':base.NEW_PUB,'new_device':True},409)]:
                r=await self.client.post('/api/session',json={**b,**change});self.assertEqual(r.status,code,await r.text())
            self.assertEqual(dict(s.one('SELECT * FROM users WHERE id=?',(self.c['user']['id'],))),initial)
            await self.client.post('/api/logout',headers=self.h(admin));self.assertEqual((await self.client.get('/api/admin/overview',headers=self.h(admin))).status,401)
            self.assertIsNone(s.one('SELECT 1 FROM admin_sessions'))
    async def test_disabled_or_unprovisioned_alias_never_promotes_an_account(self):
        r=await self.client.post('/api/session',json={'login':'admin@example.test','password':'test-password-123','pub':base.PUB});self.assertEqual(r.status,401)
        self.assertIsNone(self.app['store'].one("SELECT 1 FROM app_config WHERE key='admin'"))

if __name__=='__main__':unittest.main()
