"""Provision only the Android client config, never a service-account key.
Run from CI using masked environment variables; does not connect to Firebase.
"""
import base64, binascii, hashlib, json, os, pathlib, re, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'server'))
from fcm_config import validate_project
PACKAGE='com.fs.mesajlasma'

def client_configuration(project, encoded):
    validate_project(project)
    try:
        if not isinstance(encoded,str) or not 0<len(encoded)<=131072:raise ValueError()
        raw=base64.b64decode(encoded,validate=True)
        obj=json.loads(raw)
        if not isinstance(obj,dict) or any(k in obj for k in ['private_key','client_email','type']):raise ValueError()
        info=obj['project_info'];number=info['project_number']
        if info['project_id']!=project or not isinstance(number,str) or not re.fullmatch(r'[0-9]{5,20}',number):raise ValueError()
        matches=[c for c in obj['client'] if c['client_info']['android_client_info']['package_name']==PACKAGE]
        if len(matches)!=1:raise ValueError()
        c=matches[0]
        if not re.fullmatch(r'1:'+number+r':android:[0-9a-fA-F]+',c['client_info']['mobilesdk_app_id']):raise ValueError()
        if not any(isinstance(k.get('current_key'),str) and k['current_key'].strip() for k in c['api_key']):raise ValueError()
        return obj
    except (ValueError,TypeError,KeyError,AttributeError,binascii.Error):
        raise ValueError('Invalid Android Firebase configuration or project/package mismatch') from None

def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def main():
    try:obj=client_configuration(os.environ.get('FS_FCM_PROJECT'),os.environ.get('FS_GOOGLE_SERVICES_JSON_B64'))
    except ValueError as e:sys.exit(str(e))
    # Avoid placing the generated file under the APK web asset tree.
    dest=ROOT/'android/app/src/push/google-services.json'
    if dest.exists():sys.exit('Remove the existing local push client config before provisioning')
    dest.parent.mkdir(parents=True,exist_ok=True)
    fd=os.open(dest,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as f:json.dump(obj,f)
    files={}
    for directory in ('web','server','android/app/src/main','android/app/src/push'):
        for p in sorted((ROOT/directory).rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts and p.name!='google-services.json':files[p.relative_to(ROOT).as_posix()]=digest(p)
    for name in ('android/build.gradle','android/settings.gradle','android/app/build.gradle','android/gradle.properties'):
        files[name]=digest(ROOT/name)
    out=ROOT/'build/push-metadata/build-info.json';out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps({'version':'34.32','versionCode':15,'package':PACKAGE,'transport':'fcm','sources':files},sort_keys=True))
    print('Android Firebase configuration matches requested project and package; live delivery not tested.')
if __name__=='__main__':main()
