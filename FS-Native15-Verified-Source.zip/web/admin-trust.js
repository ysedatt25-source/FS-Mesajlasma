// Trust on first use, scoped to the API origin. Existing pins never rotate
// automatically. This cannot authenticate a compromised first connection.
const flights=new Map();
export async function adminFingerprint(admin,subtle=crypto.subtle){
 const p=admin?.pub;
 if(typeof admin?.id!=='string'||!admin.id||p?.kty!=='EC'||p.crv!=='P-256'||!/^[A-Za-z0-9_-]{43}$/.test(p.x||'')||!/^[A-Za-z0-9_-]{43}$/.test(p.y||'')||'d' in p)throw Error('Yönetici açık anahtarı geçersiz.');
 const material=JSON.stringify(['FS-ADMIN-KEY-v1',admin.id,p.crv,p.x,p.y]);
 return [...new Uint8Array(await subtle.digest('SHA-256',new TextEncoder().encode(material)))].map(x=>x.toString(16).padStart(2,'0')).join('');
}
export async function assertAdminTrust(root,admin,{read,write,valid=()=>true}){
 const check=()=>{if(!valid())throw new DOMException('Oturum değişti','AbortError');};
 const previous=flights.get(root)||Promise.resolve();
 const task=previous.catch(()=>{}).then(async()=>{
  check();const key='admin-trust-v1:'+root,stored=await read(key);check();
  if(!admin){if(stored)throw Error('Kayıtlı yönetici anahtarı sunucuda bulunmuyor. Gönderim güvenlik için durduruldu.');return null;}
  const fingerprint=await adminFingerprint(admin);check();
  if(stored&&(stored.id!==admin.id||stored.fingerprint!==fingerprint))throw Error('Yönetici güvenlik anahtarı değişti. Doğrulamadan mesaj gönderilemez.');
  if(!stored){await write(key,{id:admin.id,fingerprint});check();}
  return fingerprint;
 });
 flights.set(root,task);
 try{return await task;}finally{if(flights.get(root)===task)flights.delete(root);}
}
