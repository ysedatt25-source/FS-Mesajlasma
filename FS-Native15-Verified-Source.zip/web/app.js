import {createGreetingPicker} from "./greeting-picker.js";
import {adminDashboard} from './admin-console.js';
import {assertAdminTrust,adminFingerprint} from './admin-trust.js';
import {mountStories} from "./stories.js";
import {homeSearch,searchTerm,recentSearches,rememberSearch} from "./home-search.js";
import {callHistoryInfo,sameCallHistoryKind} from "./call-history-card.js";
import {createOutgoingRingback} from './outgoing-ringback.js';
import {CUSTOM_RINGTONES} from './call-ringtones.js';
import {BoundedCache,estimateRecordBytes,reconnectDelay,foregroundInterval} from "./resource-budget.js";
import {createRecordLookup,bubbleGroups,prepareBoot} from "./app-performance.js";
import {normalizeFolders,folderFilter,resolveFolderFilter,filterFolderRooms,saveFolder,removeFolder,mergeFolderMembers,folderFiltersMarkup,folderManagerMarkup,folderEditorMarkup} from "./chat-folders.js";
import {createUnreadCounter,lastReadableMessage} from "./chat-performance.js";
import {chatMessageJoined,animateComposerSend} from "./chat-layout.js";
import {isViewOnce,viewOnceMime,canSendViewOnce,onceStatus,createOnceViewer} from "./view-once.js";
import {uploadChunks,transferDeadline,createTransferRecovery,transferRetryable,abortTransfer,fetchVerifiedRange} from "./transfer-resilience.js";
import {bindVoicePlayer,syncVoicePlayer,nextVoiceRate,voiceDurationHint,audioDuration} from "./voice-player.js";
import {videoPlayerMarkup,mountVideoPlayer} from "./video-player.js";
import {mediaKind,mountMediaEditor} from "./media-editor.js";
import {attachmentMarkup,makePoll,makeEvent,attachmentContext,recentItems} from "./attachment-menu.js";
import {nativeScreenDevices} from "./native-screen-share.js";
import {CALL_CHANNEL,CALL_REACTIONS,createCallExtras} from "./call-extras.js";
import {callVerificationSnapshot,sameCallVerification,verificationDigest,verifyCallTransport} from "./call-verification.js";
import {createRefreshBatch,frameBatch} from "./refresh-batch.js";
import {createInlineTransport,mountInlineTransport} from "./ratchet-inline.js";
import {ratchetDownload} from "./ratchet-download.js";
import {createRatchetMaintenance} from "./ratchet-maintenance.js";
import {RatchetPilotClient,pilotIdentity} from "./ratchet-pilot.js";
import {localRatchetStore} from "./ratchet-storage.js";
import {mountRatchetPilot} from "./ratchet-pilot-ui.js";
import {mountRatchetGroup} from "./ratchet-group-ui.js";
import {incomingCallMarkup} from "./incoming-call-screen.js";
import {createLiveCallVoice} from "./live-call-voice.js";
import {VOICE_MODES,voiceLabel,selectedVoice,saveVoice} from "./call-voice.js";
import {DurableDownloads,fetchRange} from "./durable-downloads.js";
import {createDownloadRecovery,retryableDownload} from "./download-recovery.js";
import {GroupMesh} from "./group-call.js";
import {DurableUploads} from "./durable-uploads.js";
import {syncDelivery} from "./delivery-sync.js";
import {MediaUrlCache,readExactBytes} from "./media-url-cache.js";
import {createTransferQueue} from "./transfer-queue.js";
import {launchExternal} from "./external-link.js";
import {videoCaptureConstraints,createCallQuality,preferVideoDetail} from "./call-quality.js";
import {audioCaptureConstraints,preferSpeech,createAudioPriority,createIceRecovery,isRestartOffer,acceptIce,queueIce,drainIce,sameOffer,replaySdpCandidates,CallSignalUnavailable} from "./call-recovery.js";
import {mergeReceipts,receiptStatus,receiptBatch} from "./message-details.js";
import {PROFILE_AVATARS,profileAvatar} from "./profile-avatars.js";
import {createAlbumViewer,createPhotoCipherCache} from "./album-viewer.js";
import {attachPhotoGestures} from "./photo-gestures.js";
import {albumMembers,exportPhotos,nativeAlbumSink,browserAlbumSink} from "./album-download.js";
import {RINGTONES,createRingtones,ringtoneLabel} from "./call-ringtones.js";
import {TYPING_EVENT,RECORDING_EVENT,createTypingStatus} from "./typing-status.js";
import {composerMode,createMicGesture} from "./composer-action.js";
import {EMOJI_EVENT,validInteraction,matchesInteraction,createInteractionWindow} from "./realtime-emoji.js";
import {gestureIntent,replySwipeFeedback,reactionValue,sameReaction,isReactionDoubleTap,reactionChoices,selectionOps,selectionRange,selectionEdgeStep,messageHasDetails,messageMenuPlacement,messageContextOps,contextReceipt} from "./message-interactions.js";
import {clamp,pipPosition,layoutFloatingVideo,bindFloatingVideo,urlParts,mapUrls,mapPreview,liveLocationLabel,effectiveStatus,callControlState,callEventMatches,currentCallAction,applyAlertReceipt} from "./call-chat-fixes.js";
import {LocalChats,chatList,roomUnreadState,buildMessageIndex,searchMessages,localDay,toggleId} from "./chat-tools.js";
import {VirtualMessages, nearLatest} from "./virtual-list.js";
import {prepareMedia} from "./media-preparation.js";
import {encodePhotoPreview} from "./photo-preview.js";
import {accountIssues,showNotice} from "./feedback.js";
import {VoiceRecorder,voiceExtension} from "./voice-recorder.js";
import {isSingleEmoji,animateEmoji,buildEmojiIndex,emojiAsset,characterAssetPath,mergeEmojiCatalog,clearEmojiEffect,emojiCategory,emojiMatches} from "./emoji-effects.js";
import {createAccessGate} from "./access-gate.js";
import {mountCalculator} from "./calculator-ui.js";
import { missingCachedMessages, mergeMessagePage, upsertMessage as upsertMessages } from "./message-state.js";
import { DEFAULT_API_ROOT } from "./runtime-config.js";
import { serverRoot, fetchServer, verifyServer } from "./connection.js";
import { privacyPolicy } from "./privacy-policy.js";
import { validatePayload } from "./payload.js";
import {MESSAGE_EFFECTS,effectFields,messageEffect,createEffectHistory,drawMessageEffect} from "./message-effects.js";
import {selectedQuote,quoteSnapshot} from "./text-format.js";
import {historyKeys,addHistoryKey,openHistorical} from "./history-keys.js";
import QRCode from "./vendor/qr.js";
import { icon } from "./icons.js";
import {
  vault,
  identity,
  peerKey,
  seal,
  open,
  b64,
  unb64,
  setPin,
  checkPin,
  encryptFile,
  decryptFile,
  prepareRecovery,
  inspectRecovery,
  createRecoveryExport,
  commitRecovery,
  sameIdentity,
} from "./crypto.js";
const $ = (s) => document.querySelector(s),
  app = $("#app"),
  modal = $("#modal");
let messageMenuSession=null;
const outgoingRingback=createOutgoingRingback({native:()=>window.FSNative});
const callRingtones=createRingtones({native:()=>window.FSNative,storage:()=>localStorage});
const escape = (s) =>
  String(s ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
let emojiItems = [];
let legacyVerificationEmojis = [];
let emojiIndex = new Map();
const greetingPicker=createGreetingPicker();
const emojiWindow=createInteractionWindow();let lastEmojiTap=0;let replyReturn=null,replyJumpFlight=null;const deletedInSession=new Set();let deletedRevision=0;const countUnread=createUnreadCounter();
const access = createAccessGate(checkPin);
let bootReady=false;
const isLocked=()=>access.locked;
function assertAccess(){if(isLocked())throw new DOMException("Kilitli oturum", "AbortError");}
function assertEpoch(epoch){if(!access.valid(epoch))throw new DOMException("Oturum kilitlendi veya değişti", "AbortError");}
let adminSequence=0;
const state = {
  user: null,
  token: null,
  settings: {},
  rooms: [],
  contacts: [],
  messages: [],
  page: "lock",
  room: null,
  tab: "Sohbetler",
  selected: new Set(),
  cache: new BoundedCache({count:512,bytes:16*1024*1024,weight:estimateRecordBytes}),
  keys: new BoundedCache({count:256}),
  reply: null,
  call: null,
  socket: null,
  presenceStale: true,
  get locked(){return access.locked},
  pin: "",
  recording: null,
  recorder: null,
  media: [],
  mediaFilter: "Tümü",
  routeVersion: 0,
};
const typing=createTypingStatus({
 context:()=>!isLocked()&&presenceForeground()&&state.page==='chat'&&state.room&&state.user?{room:state.room.id,enabled:state.typingEnabled===true,members:new Map(state.room.members.filter(m=>m.id!==state.user.id).map(m=>[m.id,m.name]))}:null,
 send:event=>{if(state.typingEnabled!==true||state.socket?.readyState!==1||(event.type===RECORDING_EVENT&&!state.recordingStatusEnabled))return false;try{state.socket.send(JSON.stringify(event));return true}catch{return false}},
 render:(names,recording=[])=>{const label=document.querySelector('#typing-status');if(!label)return;const group=state.room?.kind==='group',people=recording.length?recording:names;label.hidden=!people.length;label.textContent=people.length?(group?(people.length===1?people[0]:people.length+' kişi')+' ':'')+(recording.length?'Ses kaydediyor…':group?'yazıyor…':'Yazıyor…'):'';const status=document.querySelector('.chat-head [data-action="status"]');if(status)status.hidden=!!people.length;}
});
let localData=null,localWrite=null,virtualMessages=null,messageIndex=buildMessageIndex([]),outboxSending=false;
const lookupRecord=createRecordLookup();
const messageDateFormatter=new Intl.DateTimeFormat("tr-TR",{day:"numeric",month:"long",year:"numeric"});
let localState={drafts:{},positions:{},preferences:{pinned:[],archived:[],read:{}},pages:{},playback:{},outbox:[]};
state.chatFilter='Tümü';state.chatQuery='';state.mediaDate='';state.mediaQuery='';
async function initLocal(){
 assertAccess();const epoch=access.epoch;
 if(localData?.user===state.user?.id)return;
 clearTimeout(localWrite);
 const store=new LocalChats(state.user.id,state.identity);const data=await store.get('workspace',{});
 assertEpoch(epoch);if(store.user!==state.user?.id)return;
 state.chatFilter="Tümü";localData=store;localState={drafts:{},positions:{},preferences:{pinned:[],archived:[],read:{}},pages:{},playback:{},outbox:[],...data};
 if(data.rooms?.length)state.rooms=data.rooms;
 if(data.settings)state.settings=data.settings;
}
function persistLocal(immediate=false){
 if(!localData)return immediate?Promise.reject(Error('Yerel oturum hazır değil.')):Promise.resolve();
 clearTimeout(localWrite);const store=localData;
 const save=()=>store.put('workspace',structuredClone({...localState,rooms:state.rooms.slice(0,40),settings:state.settings}));
 if(immediate)return save();localWrite=setTimeout(()=>save().catch(error=>console.warn('local-store',error.message)),180);return Promise.resolve();
}
let receiptTimer,receiptFlight=null;
function scheduleReceipts(){
 if(!state.messageDetails||isLocked()||document.hidden||state.page!=="chat")return;
 clearTimeout(receiptTimer);receiptTimer=setTimeout(()=>acknowledgeVisible().catch(error=>console.warn("receipt",error.message)),100);
}
async function acknowledgeVisible(){
 const room=state.room?.id,epoch=access.epoch,route=state.routeVersion,self=state.user?.id,token=state.token,list=$("#messages");
 const active=()=>!isLocked()&&access.valid(epoch)&&!document.hidden&&state.page==="chat"&&state.room?.id===room&&state.routeVersion===route&&state.token===token&&state.messageDetails&&navigator.onLine!==false;
 if(!room||!self||!list||!active())return;
 if(receiptFlight){receiptFlight.again=true;return;}
 const flight={again:false};receiptFlight=flight;let receiptChanged=false;
 try{
  const bounds=list.getBoundingClientRect(),visible=new Set();
  for(const node of list.querySelectorAll("[data-message]")){
   const b=node.getBoundingClientRect();if(!modal.open&&b.height>0&&b.bottom>bounds.top&&b.top<bounds.bottom)visible.add(node.dataset.message);
  }
  const batch=receiptBatch(state.messages.filter(m=>!hiddenMessage(m)),self,visible);
  const ids=[...new Set([...batch.delivered,...batch.read])];
  for(let i=0;i<ids.length&&active();i+=80){
   const set=new Set(ids.slice(i,i+80));
   const result=await api('/rooms/'+room+'/receipts',{method:'POST',body:{delivered:batch.delivered.filter(id=>set.has(id)),read:batch.read.filter(id=>set.has(id))}});
   receiptChanged=receiptChanged||Object.keys(result.receipts||{}).length>0;
   if(!active())return;
   state.messages=state.messages.map(m=>result.receipts?.[m.id]?{...m,receipts_v2:mergeReceipts(m.receipts_v2,[result.receipts[m.id]])}:m);
  }
  if(ids.length&&active())storePage(room,state.messages);
 }finally{if(receiptChanged&&access.valid(epoch)&&state.token===token)refreshHomeReceipts(epoch);if(receiptFlight===flight){receiptFlight=null;if(flight.again)scheduleReceipts();}}
}
let deliveryTimer=null,deliveryRun=null,deliveryAgain=false,deliveryCursor=null;
function scheduleDelivery(){
 if(isLocked()||!state.deliverySync||!state.token||navigator.onLine===false)return;
 if(deliveryRun){deliveryAgain=true;return;}
 clearTimeout(deliveryTimer);deliveryTimer=setTimeout(()=>runDelivery().catch(error=>{if(error.name!=="AbortError")console.warn("delivery",error.message)}),250);
}
async function runDelivery(){
 if(deliveryRun||isLocked()||!state.deliverySync||!state.token)return;
 const epoch=access.epoch,token=state.token,owner=state.user.id,flight={};deliveryRun=flight;
 const valid=()=>access.valid(epoch)&&state.token===token&&state.deliverySync&&navigator.onLine!==false;
 try{
  const result=await syncDelivery({cursor:deliveryCursor,valid,self:owner,fetchPage:(after,afterId)=>api('/delivery-pending?after='+after+'&after_id='+encodeURIComponent(afterId)),decode,
   ack:async(room,ids)=>{const result=await api('/rooms/'+room+'/receipts',{method:'POST',body:{delivered:ids,read:[]}});if(!valid())return;for(const id of ids){const cached=state.cache.get(id);const row=result.receipts?.[id];if(cached&&row)state.cache.set(id,{...cached,receipts_v2:mergeReceipts(cached.receipts_v2,[row])});}if(state.room?.id===room&&state.page==='chat'){state.messages=state.messages.map(m=>result.receipts?.[m.id]?{...m,receipts_v2:mergeReceipts(m.receipts_v2,[result.receipts[m.id]])}:m);storePage(room,state.messages);}}
  });
  if(valid()){deliveryCursor=result.next;if(result.count>0)refreshHomeReceipts(epoch);}
 }finally{if(deliveryRun===flight){deliveryRun=null;const again=deliveryAgain;deliveryAgain=false;if(valid()&&(deliveryCursor||again))scheduleDelivery();else if(!isLocked()&&state.deliverySync&&state.token!==token)scheduleDelivery();}}
}
function resetDelivery(){clearTimeout(deliveryTimer);deliveryCursor=null;deliveryAgain=false;state.deliverySync=false;}
function markCurrentRead(){
 const room=state.room?.id,target=$('#messages');if(!room||!target||document.hidden)return;
 scheduleReceipts();if(!nearLatest(target))return;
 const last=lastReadableMessage(state.messages);if(!last)return;
 localState.preferences.read??={};if(last.created<=(localState.preferences.read[room]||0))return;
 localState.preferences.read[room]=last.created;persistLocal();if(!state.messageDetails&&navigator.onLine!==false)api('/rooms/'+room+'/read',{method:'POST',body:{message:last.id}}).catch(()=>{});
}

function rememberChat(){
 const input=$('#message-text'),list=$('#messages');const id=input?.dataset.room;
 if(!id||!localData)return;
 localState.drafts[id]={text:input.value,reply:state.reply?.room===id?state.reply.id:null,quote:state.reply?.room===id?state.reply.quoteText||null:null};
 if(list)localState.positions[id]={top:list.scrollTop,anchor:virtualMessages?.anchor(),bottom:nearLatest(list)};
 rememberPlayback();persistLocal();
}
function rememberPlayback(){for(const audio of document.querySelectorAll('audio[data-audio]'))if(Number.isFinite(audio.currentTime)&&audio.currentTime>0)localState.playback[audio.dataset.audio]={time:audio.currentTime,rate:audio.playbackRate||1};}
function storePage(room,messages){delete localState.pages[room];const page=[];let size=0;for(const m of messages.filter(m=>!m.pending).slice(-80).reverse()){const length=JSON.stringify(m).length;if(size+length>300000)break;size+=length;page.unshift(m)}localState.pages[room]=page;const keys=Object.keys(localState.pages);while(keys.length>10)delete localState.pages[keys.shift()];persistLocal();}
async function flushOutbox(){
  if(isLocked())return;
 if(outboxSending||!localData||navigator.onLine===false||!state.token)return;
 outboxSending=true;const owner=state.user.id,epoch=access.epoch;
 try{for(const item of [...localState.outbox]){if(!access.valid(epoch)||state.user?.id!==owner)break;const room=state.rooms.find(r=>r.id===item.room);if(!room){item.error='Sohbet bulunamadı.';continue}if(room.ratchet_cutover_active===true){item.error='Eski gönderim kapalı; taslak güvenli kanaldan yeniden gönderilmelidir.';await persistLocal(true);continue}try{await send(item.payload,room,item.id,{replyId:item.reply,fromQueue:true,silent:!!item.silent});if(!access.valid(epoch))break;localState.outbox=localState.outbox.filter(x=>x.id!==item.id);state.messages=state.messages.map(m=>m.id===item.id?{...m,pending:false,queued:false}:m);if(state.page==="chat")renderMessages();await persistLocal(true)}catch(error){if(!access.valid(epoch))break;item.error=error.message;await persistLocal(true);break}}}finally{outboxSending=false;}
}
window.addEventListener('online',()=>{connect();flushOutbox().catch(err=>notice(err.message,4000,'error'));scheduleDelivery();uploadRecovery.kick();downloadRecovery.kick();});
document.addEventListener('visibilitychange',()=>{if(document.hidden){rememberChat();persistLocal(true)}});
const defaultApiRoot = location.hostname === "appassets.androidplatform.net" ? DEFAULT_API_ROOT : location.origin;
let apiRoot = serverRoot(defaultApiRoot);
try { apiRoot = serverRoot(localStorage.getItem("fs-server") || defaultApiRoot); } catch {}
const time = (t) =>
  new Date(t).toLocaleTimeString("tr-TR", {
    hour: "2-digit",
    minute: "2-digit",
  });
const name = (r) =>
  r.title ||
  r.members
    ?.filter((x) => x.id !== state.user?.id)
    .map((x) => x.name)
    .join(", ") ||
  "Sohbet";
const button = (action, ico, label, extra = "") =>
  `<button class="icon" data-action="${action}" aria-label="${escape(label)}" title="${escape(label)}" ${extra}>${icon(ico)}</button>`;
const avatar = (u, large = false, lazy = false) =>
  `<span class="avatar ${large ? "large" : ""}">${
    u?.avatar
      ? `<img class="avatar-photo" ${lazy?'loading="lazy" ':''}decoding="async" src="${escape(u.avatar)}" alt="Profil fotoğrafı">`
      : escape(
          (u?.name || "?")
            .split(" ")
            .slice(0, 2)
            .map((x) => x[0])
            .join(""),
        )
  }${u?.status === "online" ? '<span class="dot"></span>' : ""}</span>`;
const empty = (title, description) =>
  `<div class="empty"><span class="big">Fs</span><strong>${escape(title)}</strong><br>${escape(description)}</div>`;
const row = (action, ico, title, sub = "") =>
  `<button class="row" data-action="${action}">${icon(ico)}<span class="copy">${escape(title)}${sub ? `<small>${escape(sub)}</small>` : ""}</span>${icon("chevron")}</button>`;
function notice(text, duration = 3000, kind = "info", compact = false) {
  if(isLocked()&&state.page!=="setup")return;
  showNotice($("#notice"), text, {duration, kind, compact});
}
function formIssues(form, issues) {
  form.querySelectorAll('.field-error').forEach(e => e.remove());
  form.querySelectorAll('[aria-invalid]').forEach(e => {e.removeAttribute('aria-invalid');e.removeAttribute('aria-describedby')});
  form.querySelector('.error').textContent = issues.length ? "Bilgileri kontrol edin: " + issues.map(e => e.message).join(' ') : '';
  for (const issue of issues) {
    const input=form.elements.namedItem(issue.field);if(!input)continue;
    const error=document.createElement('small');error.className='field-error';error.id='error-'+issue.field;error.textContent=issue.message;
    input.setAttribute('aria-invalid','true');input.setAttribute('aria-describedby',error.id);input.insertAdjacentElement('afterend',error);
  }
  if(issues.length)form.elements.namedItem(issues[0].field)?.focus();
}

function dialog(title, content) {
  assertAccess();
  if (typeof storyController!=="undefined") storyController?.closeViewer();
  closeOnceViewer();
  closeAlbumViewer();
  clearProfileViewer();
  if(modal.querySelector("#ringtone-form"))callRingtones.stop();
  clearMessageMenu();
  if(document.querySelector("#composer-emoji-panel:not([hidden])"))closeComposerEmoji();
  modal.classList.remove("home-preview-dialog");
  state.reactionTarget=null;
  modal.innerHTML = `${button("close-dialog", "close", "Kapat")}<h2>${escape(title)}</h2>${content}`;
  modal.firstElementChild.classList.add("dialog-close");
  modal.showModal();
}
function field(name, label, type = "text", value = "", required = true) {
  return `<label for="${name}">${escape(label)}</label><input id="${name}" name="${name}" type="${type}" value="${escape(value)}" ${required ? "required" : ""} autocomplete="off">`;
}
async function api(path, options = {}) {
  assertAccess();const accessEpoch=access.epoch;
  const headers = {
    ...(options.body instanceof Uint8Array
      ? {}
      : { "Content-Type": "application/json" }),
    ...options.headers,
  };
  if (state.token) headers.Authorization = "Bearer " + state.token;
  const requestToken = state.token, requestRoot = apiRoot;
  const checkRequest = () => {
    if (!access.valid(accessEpoch) || requestToken !== state.token || requestRoot !== apiRoot || options.signal?.aborted)
      throw new DOMException("Oturum veya istek değişti; işlem iptal edildi.", "AbortError");
  };
  const response = await fetchServer(requestRoot, "/api" + path, {
    ...options,
    headers,
    body:
      options.body instanceof Uint8Array
        ? options.body
        : options.body
          ? JSON.stringify(options.body)
          : undefined,
  });
  checkRequest();
  if (!response.ok) {
    let data;
    try {
      data = await response.json();
    } catch {}
    checkRequest();
    const error=Error(data?.error || (response.status === 404 ? "Sunucuda istenen API bulunamadı. Sunucu adresini ve sunucu sürümünü kontrol edin." : `İşlem başarısız (${response.status})`));
    error.status=response.status;error.code=data?.code;throw error;
  }
  let data;
  if(options.binary){const length=Number(response.headers.get('Content-Length'));if(!Number.isSafeInteger(options.maxBytes)||options.maxBytes<1||options.maxBytes>50*1024*1024+16||length!==options.maxBytes)throw Error('Dosya uzunluğu geçersiz.');data=new Uint8Array(await response.arrayBuffer());if(data.length!==options.maxBytes)throw Error('Dosya uzunluğu eşleşmedi.');}else data=response.status===204?null:await response.json();
  checkRequest();
  return data;
}
async function keyFor(peer) {
  assertAccess();const epoch=access.epoch,owner=state.user?.id,token=state.token,identity=state.identity,root=apiRoot;
  const id = peer.id + JSON.stringify(peer.pub);
  const valid=()=>access.valid(epoch)&&state.user?.id===owner&&state.token===token&&state.identity===identity&&apiRoot===root;
  let scope=state.keyFlights;
  if(!scope||scope.epoch!==epoch||scope.owner!==owner||scope.token!==token||scope.identity!==identity||scope.root!==root){state.keys.clear();scope={epoch,owner,token,identity,root,items:new Map()};state.keyFlights=scope;}
  const check=()=>{if(!valid()||state.keyFlights!==scope)throw new DOMException("Oturum değişti", "AbortError");};
  if(state.keys.has(id))return state.keys.get(id);
  let pending=scope.items.get(id);
  if(!pending){pending=(async()=>{const key=await peerKey(identity.pair.privateKey,peer.pub);check();state.keys.set(id,key);return key;})();scope.items.set(id,pending);}
  try{const key=await pending;check();return key;}finally{if(scope.items.get(id)===pending)scope.items.delete(id);}
}
async function envelopes(room, payload) {
  await verifyAdminRecipient(room.audit);
  if(room.ratchet_cutover_active===true||state.rooms.find(r=>r.id===room.id)?.ratchet_cutover_active===true)throw Error("Bu sohbet güvenli kanala geçti. Eski şifreleme kapalı.");
  const result = {};
  await Promise.all(
    [
      ...new Map(
        [...room.members, ...(room.audit ? [room.audit] : [])].map((m) => [
          m.id,
          m,
        ]),
      ).values(),
    ].map(async (m) => {
      result[m.id] = await seal(await keyFor(m), payload, room.id);
    }),
  );
  return result;
}
let historyKeyFlight=null;
function readAccountHistory(){
 const root=apiRoot,account=state.user?.id,token=state.token;
 if(!historyKeyFlight||historyKeyFlight.root!==root||historyKeyFlight.account!==account||historyKeyFlight.token!==token){
  const f={root,account,token};f.promise=historyKeys(root,account).catch(e=>{if(historyKeyFlight===f)historyKeyFlight=null;throw e});historyKeyFlight=f;
 }
 return historyKeyFlight.promise;
}
async function openMessagePayload(room,sender,packet,senderPub){
 const epoch=access.epoch,account=state.user?.id,token=state.token,root=apiRoot;
 const valid=()=>access.valid(epoch)&&state.user?.id===account&&state.token===token&&apiRoot===root;
 try{const value=validatePayload(await open(await keyFor({...sender,pub:senderPub||sender.pub}),packet,room.id));if(!valid())throw new DOMException('Oturum değişti.','AbortError');return value;}
 catch(error){
  if(!valid())throw new DOMException('Oturum değişti.','AbortError');
  if(state.page==='admin-room'||!room.members?.some(m=>m.id===account))throw error;
  return openHistorical({keys:await readAccountHistory(),senderPub:senderPub||sender.pub,ownLegacy:!senderPub&&sender.id===account,packet,room:room.id,valid});
 }
}
async function decode(m) {
  assertAccess();const epoch=access.epoch;
  const cached = state.cache.get(m.id);
  if (cached && cached.edited === m.edited)
    return { ...cached, ...m, receipts_v2:mergeReceipts(cached.receipts_v2,m.receipts_v2), payload: cached.payload };
  const room = state.rooms.find((r) => r.id === m.room),
    sender = room?.members.find((u) => u.id === m.sender) || (room?.kind==='group'&&m.sender_pub?{id:m.sender,pub:m.sender_pub}:null);
  if (!sender)
    return {
      ...m,
      payload: { type: "locked", text: "Gönderen anahtarı bulunamadı." },
    };
  try {
    const payload = await openMessagePayload(room,sender,m.envelope,m.sender_pub);
    assertEpoch(epoch);
    const result = { ...m, payload };
    state.cache.set(m.id, result);
    return result;
  } catch {
    assertEpoch(epoch);
    return {
      ...m,
      payload: {
        type: "locked",
        text: "Bu cihazda mesaj anahtarı bulunamadı.",
      },
    };
  }
}
const ratchetMaintenance=createRatchetMaintenance({snapshot(){
 if(isLocked()||!state.token||!state.user||navigator.onLine===false)return null;
 const epoch=access.epoch,token=state.token,user=state.user.id,root=apiRoot;
 const valid=()=>access.valid(epoch)&&state.token===token&&state.user?.id===user&&apiRoot===root&&navigator.onLine!==false;
 const rooms=state.rooms.filter(r=>r.kind==='direct'&&r.ratchet_pilot===true&&r.members?.length===2&&r.members.some(m=>m.id===user)).map(r=>({id:r.id,peer:r.members.find(m=>m.id!==user)?.id})).filter(r=>r.peer);
 const reserve=window.FSNative?.ratchetReserveCount&&window.FSNative?.stageRatchetReserve?r=>({count:()=>valid()?window.FSNative.ratchetReserveCount(root,token,r.id):-1,stage:bundle=>valid()&&window.FSNative.stageRatchetReserve(root,token,JSON.stringify(bundle))}):null;
 return {account:JSON.stringify([root,user]),user,valid,rooms,reserve};
},async prepare(ctx,room){const scope='pilot-account:'+ctx.user;const [identity,key]=await Promise.all([pilotIdentity(scope),localRatchetStore.storageKey(scope)]);return new RatchetPilotClient({api,room:room.id,user:ctx.user,peer:room.peer,identity,key,valid:ctx.valid});},onError(e){if(e.name!=='AbortError')console.warn('Güvenli sohbet ön anahtarı:',e.status||'bekliyor');}});
function maintainRatchetKeys(){ratchetMaintenance.run().catch(()=>{});}
setInterval(maintainRatchetKeys,65000);
window.addEventListener('online',maintainRatchetKeys);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)maintainRatchetKeys();});
let roomRefreshQueue = createRefreshBatch(()=>refreshRoomsNow());
function refreshRooms() {
  const epoch=access.epoch,token=state.token,root=apiRoot;
  const valid=()=>access.valid(epoch)&&state.token===token&&apiRoot===root;
  return roomRefreshQueue(JSON.stringify([epoch,token,root]),null,valid);
}
async function refreshRoomsNow() {
  if(isLocked())return;
  if (!state.token) return;
  const epoch=access.epoch;
  const presenceSocket=state.socket;const rooms=await api("/rooms");assertEpoch(epoch);
  state.presenceStale=!(presenceSocket&&state.socket===presenceSocket&&presenceSocket.readyState===1&&state.presenceLease===true&&navigator.onLine!==false);
  const oldRooms=state.rooms, nextById=new Map(rooms.map(r=>[r.id,r]));
  for(const old of oldRooms){const next=nextById.get(old.id);if(!next||(next.history_revision&&next.history_revision!==old.history_revision))purgeHomeHistory(old.id);}
  state.rooms=rooms;
  if (state.room)
    state.room = state.rooms.find((r) => r.id === state.room.id) || state.room;
  await Promise.all(
    state.rooms.map(async (r) => {
      if (r.last) {const last=await decode(r.last);assertEpoch(epoch);r.last=last;}
    }),
  );
  assertEpoch(epoch);persistLocal();maintainRatchetKeys();updateCutoverComposer();
  state.rooms.sort(
    (a, b) => (b.last?.created || b.created) - (a.last?.created || a.created),
  );
}
// Reconcile the return affordance without rebuilding the current screen.
function syncCallReturnBanner(){
  const screen=app.querySelector(':scope > .screen');
  const allowed=!!(screen&&state.call&&state.token&&state.user&&!isLocked()&&!['call','lock','setup','auth'].includes(state.page));
  const banners=[...app.querySelectorAll('.call-banner[data-action="return-call"]')];
  let banner=allowed?banners.find(el=>el.parentElement===screen):null;
  for(const el of banners)if(el!==banner)el.remove();
  if(!allowed)return;
  if(!banner){banner=document.createElement('button');banner.type='button';banner.className='call-banner';banner.dataset.action='return-call';banner.textContent='Aramaya geri dön';screen.prepend(banner);}
}
function restoreCallSurface(){
  syncCallReturnBanner();
  if(isLocked()||!state.token||!state.user||!state.call)return;
  if(state.page==='chat'){refreshCallExtrasSurface(state.call);syncChatViewport();}
  attachVideo();
}
function refreshCallExtrasSurface(c){
  const chat=$('.fs-chat'),mini=$('#call-mini');
  if(chat&&c.video&&!mini){const el=document.createElement('video');el.id='call-mini';el.className='chat-pip';el.autoplay=true;el.playsInline=true;el.setAttribute('role','button');el.tabIndex=0;el.setAttribute('aria-label','Görüşmeye dön; sürükleyerek taşı');chat.append(el);$('#fs-background-call')?.remove();bindChatPip();}
  else if(!c.video&&mini){mini.remove();chat?.querySelector('[data-pip-resize="call-mini"]')?.remove();}
}
function shell(title, body, options = "") {
  if(state.page!=="admin"&&state.page!=="admin-room")clearAdminState();
  closeOnceViewer();
  closeInlineRatchet();  window.FSNative?.visibleMessageRoom?.("");
  assertAccess();dismissAlbumViewer();dismissProfileViewer();typing.reset();
  rememberChat();virtualMessages?.destroy();virtualMessages=null;stopThumbnailObservation();
  app.innerHTML = `<section class="screen fs-premium fs-${state.page}"><header>${button("back", "back", "Geri")}<h1>${title}</h1>${options}</header><main class="scroll">${body}</main></section>`;
  syncCallReturnBanner();if(state.call)attachVideo();
}
let calculatorView;
function showLock() {
  // Revoke synchronously and obscure all sensitive DOM before any fallible cleanup.
  access.lock();clearAdminState();state.storiesEnabled=false;historyKeyFlight=null;state.sendOptions=false;state.durableDownload=false;state.durableUpload=false;state.viewOnce=false;state.pendingRecovery=null;app.inert=true;app.style.visibility="hidden";modal.inert=true;modal.style.visibility="hidden";
  const cleanup=fn=>{try{fn()}catch(error){console.warn("lock cleanup",error?.message||String(error))}};
  try {
  cleanup(()=>{if(typeof storyController!=="undefined")storyController?.clear();});
  cleanup(()=>closeOnceViewer());
  cleanup(()=>closeInlineRatchet());cleanup(()=>window.FSNative?.visibleMessageRoom?.(""));
  cleanup(()=>resetDelivery());
  cleanup(()=>closeAlbumViewer());
  cleanup(()=>clearProfileViewer());
  cleanup(()=>outgoingRingback.stop());cleanup(()=>callRingtones.stop());cleanup(()=>{if(state.call?.incoming)window.FSNative?.dismissCallRingtone?.(state.call.callId)});
  cleanup(()=>clearEmojiEffect());cleanup(()=>clearSendEffects());cleanup(()=>typing.reset());
  emojiWindow.clear();deletedInSession.clear();deletedRevision++;state.emojiRealtime=false;state.directDelete=false;state.batchDelete=false;state.historyEveryone=false;state.callHistoryHide=false;state.messageCacheCheck=false;replyReturn=null;replyJumpFlight=null;
  uploadRecovery.stop();uploadController?.abort();downloadRecovery.stop();downloadQueue.cancel();downloadController?.abort();transfers.clear();clearComposer();state.routeVersion++;homeListSequence++;mediaEpoch++;
  cleanup(()=>rememberChat());cleanup(()=>virtualMessages?.destroy());cleanup(()=>discardVoice());
  virtualMessages=null;
  state.page="lock";syncPresence();
  if(modal.open)modal.close();modal.replaceChildren();
  const noticeEl=$("#notice");noticeEl.textContent="";noticeEl.style.display="none";
  const files=$("#files");files.onchange=null;files.value="";
  clearReconnect(true);
  // Clear active call before disconnecting; do not expose it via a return route.
  if(state.call){const c=state.call;try{if(state.socket?.readyState===1)state.socket.send(JSON.stringify({type:c.group?"group-call-leave":"hangup",room:c.room.id,...(c.callId?{callId:c.callId}:{})}))}catch{}state.call=null;clearTimeout(state.controlsTimer);clearInterval(state.callTimer);clearInterval(c.statsTimer);c.recovery?.close();c.extras?.close();c.pendingVoiceRaw?.getTracks().forEach(t=>t.stop());c.voiceCapture?.close();c.stream?.getTracks().forEach(t=>t.stop());c.pc?.close();c.mesh?.close();window.FSNative?.activeCall(false,false);}
  const socket=state.socket;state.socket=null;socket?.close();presenceAuthenticated=false;
  state.room=null;state.reply=null;state.selected.clear();state.messages=[];state.saved=[];state.media=[];state.cache.clear();state.keys.clear();state.keyFlights=null;
  stopThumbnailObservation();for(const cache of [audioUrls,thumbnailUrls])cache.clear()
  recentPhotos=[];
  } catch(error) {
    // Any cleanup error must not restore the previous protected screen.
    console.warn("lock cleanup",error.message);
    try{state.socket?.close()}catch{}state.socket=null;presenceAuthenticated=false;
  } finally {
  state.page="lock";
  try{if(modal.open)modal.close();modal.replaceChildren();}catch{}
  if(!modal.open){modal.inert=false;modal.style.visibility="";}
  app.replaceChildren();calculatorView=null;
  const lockEpoch=access.epoch;
  try {calculatorView=mountCalculator(app,{checkPin:async(pin,explicitEquals)=>{
      if(!access.locked||access.epoch!==lockEpoch||state.page!=="lock")return false;
      return access.submit(pin,explicitEquals);
    },onUnlock:async()=>{try{await unlock(lockEpoch)}catch(error){if(access.valid(lockEpoch))showLock();console.warn("unlock",error.message)}},windowAction:(action,value)=>{
    if(action==='float'&&window.FSNative?.calculatorWindow){showLock();window.FSNative.calculatorWindow(value);return;}
    if(action==='close'||action==='minimize'){showLock();window.FSNative?.minimize?.();return;}
    app.querySelector('.android-calculator')?.classList.toggle('calc-compact',action==='float');
  }});}catch(error){app.textContent="Hesap makinesi başlatılamadı. Uygulamayı yeniden başlatın.";console.warn("calculator",error.message);}
  app.inert=false;app.style.visibility="";
  }
}
window.addEventListener('fs-calculator-restore',event=>{if(!bootReady||state.page==="setup")return;showLock();calculatorView?.restore(event.detail)});

async function unlock(epoch) {
  if(!access.valid(epoch)||state.page!=="lock")return;
  if (!state.token) {
    authPage(false);
    return;
  }
  await initLocal();
  if(!access.valid(epoch))return;
  if(state.rooms.length){applyTheme();home();}
  try {
    const result = await api("/me");
    if(!access.valid(epoch))return;
    state.user = result.user;
    state.settings = result.settings;
    state.isAdmin = !!result.isAdmin;
    nativeSession();
    applyTheme();
    await refreshRooms();
    if(!access.valid(epoch))return;
    connect();
    home();
    await handleMessageAction(epoch);
  } catch (err) {
    if(!access.valid(epoch))return;
    if(state.rooms.length && ![401,403].includes(err.status)){home();connect();notice("Çevrimdışı: cihazdaki sohbetler gösteriliyor.",3000,"info");}
    else {
      if([401,403].includes(err.status)){
        state.token=null;state.user=null;state.isAdmin=false;state.presenceStale=true;state.rooms=[];state.contacts=[];state.settings={};state.cache.clear();state.keys.clear();state.keyFlights=null;localData=null;clearTimeout(localWrite);
        window.FSNative?.logout();await vault("session",null);if(!access.valid(epoch))return;
      }
      authPage(false);notice(err.message,4000,"error");
    }
  }
}
function authPage(register) {
  if(isLocked())return;
  state.page = "auth";
  if(register)state.pendingRecovery=null;
  app.innerHTML = `<section class="screen"><header><span class="brand">Fs</span><h1>FS Mesajlaşma</h1></header><main class="scroll form-page account-page"><h2>${register ? "Aramıza katıl" : "Tekrar hoş geldin"}</h2><p class="hint">${register ? "Yalnızca yeni hesabın yoksa kayıt ol." : "Telefon numaranı ve mevcut hesap şifreni gir. Tekrar üye olmana gerek yok."}</p><form id="account-form" novalidate>${register ? field("name", "Adınız") + field("nick", "Kullanıcı adı") + field("phone", "Telefon", "tel") + field("email", "E-posta adresi", "email") + field("invite", "Davet kodu", "text", "0032") : field("login", "Telefon numarası (veya kullanıcı adı)", "text")}${field("password", "Hesap şifresi (en az 6 karakter)", "password")}${register ? field("passwordConfirm", "Şifre tekrarı", "password") : ""}<p class="security-note">Hesap şifresi, hesap makinesi giriş şifrenden ayrıdır. Yeni kurulumda telefon ve hesap şifrenle giriş yapabilirsin. Yeni cihazın anahtarını etkinleştirmek eski oturumları kapatabilir; eski şifreli mesajlar anahtar yedeği olmadan açılamaz.</p>${register ? '<label class="toggle"><span><button type="button" data-action="privacy-policy">Gizlilik politikasını</button> okudum, kabul ediyorum.</span><input name="privacy" type="checkbox" required></label>' : ""}<button class="primary">${register ? "Hesap oluştur" : "Giriş yap"}</button><div class="error" role="alert"></div></form><button class="secondary" data-action="auth-toggle" data-register="${register ? "0" : "1"}">${register ? "Zaten hesabım var" : "Yeni hesap oluştur"}</button>${register ? "" : '<button class="secondary" data-action="password-recovery">Şifremi unuttum</button>'}<button class="secondary" data-action="import-key">Anahtar yedeğini içe aktar</button>${state.pendingRecovery?'<p class="security-note">Yedek doğrulandı. Anahtar sadece eşleşen hesaba giriş yaptığında etkinleşecek.</p><button class="secondary" data-action="cancel-recovery">Yedek seçimini iptal et</button>':""}</main></section>`;
  const accountForm=$("#account-form");
  accountForm.elements.namedItem("password").autocomplete=register?"new-password":"current-password";
  if(register){accountForm.elements.email.autocomplete="email";accountForm.elements.phone.autocomplete="tel";accountForm.elements.passwordConfirm.autocomplete="new-password";}
  if(!register){accountForm.elements.namedItem("login").autocomplete="username";accountForm.elements.namedItem("login").addEventListener('input',()=>{accountForm.querySelector('#device-replace')?.remove();delete accountForm.dataset.rotationLogin;});}
  accountForm.onsubmit = async (e) => {
    e.preventDefault();
    if(isLocked()||state.page!=="auth"||!e.target.isConnected)return;const epoch=access.epoch;
    const form = e.target,
      submit = form.querySelector("button.primary");
    if (submit.disabled) return;
    submit.disabled = true;
    try {
      const b = Object.fromEntries(new FormData(form));
      const issues = accountIssues(b, register);
      formIssues(form, issues);
      if (issues.length) return;
      for (const key of ["name","nick","phone","invite","login"]) if (b[key]) b[key]=b[key].trim();
      // Preserve exact registered digits for legacy API compatibility; accept formatting separators.
      if(!register && /^\+?[0-9() .-]+$/.test(b.login)) b.login=b.login.replace(/[() .-]/g,"");
      const current=()=>access.valid(epoch)&&state.page==="auth"&&form.isConnected;
      const check=()=>{if(!current())throw new DOMException("Giriş işlemi iptal edildi", "AbortError");};
      await verifyServer(apiRoot);check();
      const candidate=register?null:state.pendingRecovery;
      const deviceIdentity=candidate||await identity();check();
      const r = await api("/session", {
        method: "POST",
        body: {
          ...b,
          register,
          privacy_accepted: b.privacy === "on",
          new_device: !register && !candidate && b.replace_device === "on" && form.dataset.rotationLogin === b.login,
          ...(candidate?.account?{recovery_account:candidate.account}:{}),
          pub: deviceIdentity.pub,
        },
      });
      check();
      if(candidate){
        if(r.deviceChanged||!sameIdentity(candidate.pub,r.user.pub)||(candidate.account&&candidate.account!==r.user.id))throw Error("Anahtar yedeği bu hesaba ait değil.");
        await commitRecovery(candidate,{token:r.token,user:r.user},current);check();
        state.pendingRecovery=null;state.keys.clear();state.keyFlights=null;
      }else{
        if (register || r.deviceChanged) {await prepareRecovery(b.password);check();}
        await vault("session", { token: r.token, user: r.user });check();
      }
      state.identity=deviceIdentity;
      state.token = r.token;
      state.user = r.user;
      state.settings = r.settings;
      state.isAdmin = !!r.isAdmin;
      await initLocal();check();
      state.settings=r.settings;
      nativeSession();
      await refreshRooms();check();
      connect();
      home();
      welcome();
    } catch (err) {
      if(access.valid(epoch)&&form.isConnected&&err.name!=="AbortError"){
        form.querySelector(".error").textContent = err.message;
        if(!register&&!state.pendingRecovery&&err.status===409&&/şifreleme anahtarı farklı/.test(err.message)){
          form.querySelector('#device-replace')?.remove();
          form.dataset.rotationLogin=form.elements.namedItem('login').value.trim().replace(/^[+0-9() .-]+$/,v=>v.replace(/[() .-]/g,''));
          const box=document.createElement('label');box.id='device-replace';box.className='toggle';
          box.innerHTML='<span>Eski anahtar yedeğimi kullanamıyorum. Yeni cihaz anahtarının etkinleşmesi eski oturumları kapatabilir ve eski mesajlar açılamayabilir.</span><input type="checkbox" name="replace_device">';
          submit.before(box);form.querySelector('.error').textContent='Önce kişisel anahtar yedeğini içe aktarmayı dene. Yeni anahtarla devam etmek için onay kutusunu işaretle.';
        }
        notice(err.message, 4000, "error");
      }
    } finally {
      submit.disabled = false;
    }
  };
}
function welcome() {
  if(isLocked())return;
  const w = document.createElement("div");
  w.className = "welcome";
  w.innerHTML = `<div>Hoş geldin, ${escape(state.user.name)}!<br><small>Güven içinde, keyifli sohbetler dileriz.</small></div>${Array.from({ length: 30 }, (_, i) => `<i style="left:${i * 3.3}%;animation-delay:${(i % 5) * 0.08}s;background:hsl(${270 + i * 3} 65% 75%)"></i>`).join("")}`;
  app.append(w);
  setTimeout(() => w.remove(), 2000);
}
let storyController=null;
function storyContext(){if(isLocked()||!state.token||!state.user||!state.identity||state.page!=='home'||state.tab!=='Sohbetler'||!state.storiesEnabled)return null;const epoch=access.epoch,user=state.user,token=state.token,identity=state.identity;return {owner:user,valid:()=>!isLocked()&&access.valid(epoch)&&state.user?.id===user.id&&state.token===token&&state.identity===identity&&state.page==='home'&&state.tab==='Sohbetler'&&state.storiesEnabled};}
async function replyToStory(owner,item,text,valid){
 if(!valid()||navigator.onLine===false)throw Error('Özel yanıt için bağlantı gerekli.');
 let room=state.rooms.find(r=>r.kind==='direct'&&r.members?.some(m=>m.id===owner.id));
 if(!room){const r=await api('/rooms',{method:'POST',body:{members:[owner.id]}});if(!valid())throw new DOMException('Hikâye kapatıldı.','AbortError');await refreshRooms();room=state.rooms.find(x=>x.id===r.id);}
 if(!valid()||!room)throw Error('Sohbet açılamadı.');
 if(room.ratchet_cutover_active)throw Error('Yanıtı güvenli sohbet ekranından gönderin.');
 await send({type:'text',text:'Hikâyene yanıt · '+new Date(item.created).toLocaleString('tr-TR')+'\n'+text},room,null,{replyId:null});
 if(valid())await homeList().catch(()=>{});
}
function attachStories(){storyController??=mountStories({api,modal,dialog,avatar,escape,keyFor,context:storyContext,notice,editMedia:mountMediaEditor,replyToStory,openExternal,homeRoot:()=>app.querySelector('.fs-home-reference')});const root=app.querySelector('.fs-home-reference');if(!root||!storyContext())return;if(!root.querySelector('.fs-story-rail')){const rail=document.createElement('div');rail.className='fs-story-rail';rail.setAttribute('aria-label','Hikâyeler');root.querySelector('.home-search')?.after(rail);}storyController.bind(root);}
// Recover missed story events on foreground/resume and on a bounded fallback interval.
// No background requests or requests while the PIN/session is locked.
let storySyncFlight=null;
function syncVisibleStories(){
 const ctx=storyContext();if(!ctx||document.hidden||navigator.onLine===false||!storyController||storySyncFlight)return;
 const flight=Promise.resolve().then(()=>{if(ctx.valid()&&!document.hidden)return storyController.refresh();});storySyncFlight=flight;
 flight.catch(()=>{}).finally(()=>{if(storySyncFlight===flight)storySyncFlight=null;});
}
function home() {
  if(isLocked())return;if(messageMenuSession&&modal.open){modal.close();clearMessageMenu();}closeInlineRatchet();window.FSNative?.visibleMessageRoom?.("");dismissAlbumViewer();dismissProfileViewer();
  if(!state.token||!state.user||state.page==="setup"){authPage(false);return;}
  rememberChat();virtualMessages?.destroy();virtualMessages=null;stopThumbnailObservation();
  clearComposer();discardVoice();
  clearAdminState();state.page = "home";
  typing.reset();clearEmojiEffect();clearSendEffects();replyReturn=null;
  syncPresence();
  state.room = null;
  state.selected.clear();
  state.chatFilter=resolveFolderFilter(state.chatFilter,localState.preferences?.folders);
  const tabButton=(label,ico)=>`<button type="button" class="${state.tab===label?'active':''}" data-action="tab" data-tab="${label}" aria-pressed="${state.tab===label}"><span class="home-tab-icon">${icon(ico)}</span><span>${label}</span></button>`;
  app.innerHTML = `<section class="screen fs-premium fs-home fs-home-reference" data-home-tab="${escape(state.tab)}"><header class="home-top-bar"><h1>${escape(state.tab==='Aramalar'?'Aramalar':state.tab==='Kişiler'?'Kişiler':'FS Mesajlaşma')}</h1><button class="icon home-call-tab ${state.tab==='Aramalar'?'active':''}" data-action="tab" data-tab="Aramalar" aria-pressed="${state.tab==='Aramalar'}" aria-label="Aramalar">${icon('phone')}</button><button type="button" class="icon home-header-search" data-action="search" aria-label="Sohbet ara" title="Sohbet ara">${icon("search")}</button>${button("menu", "more", "Menü")}</header><button class="home-search" data-action="search" aria-label="Sohbetleri ara" ${state.tab!=='Sohbetler'?'hidden':''}>${icon('search')}<span>Sohbetleri ara</span></button><nav class="chat-filters" ${state.tab !== "Sohbetler" ? "hidden" : ""}>${folderFiltersMarkup(localState.preferences?.folders,state.chatFilter,escape)}</nav><main class="scroll" id="home-list" aria-label="${escape(state.tab)}"></main><div class="home-quick-actions" ${state.tab!=='Sohbetler'?'hidden':''}><button class="home-camera" data-action="home-camera" aria-label="Fotoğraf çek ve sohbete ekle">${icon('camera')}</button><button class="fab" data-action="new-chat" aria-label="Yeni sohbet">${icon('edit')}</button></div><nav class="home-bottom-nav" aria-label="Ana gezinme">${tabButton('Sohbetler','chat-bubbles')}${tabButton('Kişiler','user')}<button type="button" data-action="settings"><span class="home-tab-icon">${icon('settings')}</span><span>Ayarlar</span></button><button type="button" data-action="profile"><span class="home-tab-icon">${avatar(state.user)}</span><span>Profil</span></button></nav></section>`;
  syncCallReturnBanner();if(state.call)attachVideo();
  if(state.tab==='Sohbetler'){bindHomeArchive();bindHomeManagement();if(state.storiesEnabled)attachStories();}
  homeList().catch(err => notice(err.message));
}
// Reconcile direct children by stable ID and exact rendered content. Unchanged
// rows retain their images, focus and interaction state; removed rows are not cached.
function reconcileHomeRows(list,parts){
  const old=new Map(Array.from(list.children,node=>[node._fsHomeKey,node]));
  const wanted=new Set(parts.map(part=>part.key));
  for(const node of Array.from(list.children))if(!wanted.has(node._fsHomeKey))node.remove();
  let cursor=list.firstElementChild;
  for(const {key,html} of parts){
    let node=old.get(key);
    if(!node||node._fsHomeMarkup!==html){
      const template=document.createElement('template');template.innerHTML=html;
      const next=template.content.firstElementChild;
      if(!next)continue;
      next._fsHomeKey=key;next._fsHomeMarkup=html;
      if(node?.parentNode===list){const focused=node===document.activeElement;const atCursor=node===cursor;node.replaceWith(next);if(atCursor)cursor=next;if(focused)next.focus({preventScroll:true});}
      node=next;
    }
    if(node!==cursor){const focused=node.contains(document.activeElement)?document.activeElement:null;list.insertBefore(node,cursor);if(focused&&document.activeElement!==focused)focused.focus({preventScroll:true});}
    cursor=node.nextElementSibling;
  }
}
let homeListSequence = 0;
async function homeList(filter = state.chatQuery || "") {
  const sequence = ++homeListSequence;
  const list = $("#home-list"), tab = state.tab;
  const current = () => sequence === homeListSequence && list?.isConnected && state.page === "home" && state.tab === tab;
  if (!list) return;
  if (state.tab === "Kişiler") {
    const contacts = await api("/contacts");
    if (!current()) return;
    state.contacts = contacts;
    list.innerHTML =
      row("new-chat", "plus", "Kişi ekle") +
      row("deleted", "trash", "Silinen kişiler") +
      state.contacts
        .filter((c) => !c.deleted)
        .sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'tr'))
        .map(
          (c) =>
            `<button class="contact fs-directory-contact" data-action="contact" data-id="${escape(c.id)}">${avatar(c)}<span class="copy"><strong>${escape(c.name)}</strong><p>@${escape(c.nick)}</p></span>${icon("chevron")}</button>`,
        )
        .join("");
    return;
  }
  if (state.tab === "Aramalar") {
    const calls = await api("/calls");
    if (!current()) return;
    const roomIndex=new Map(state.rooms.map(r=>[r.id,r]));
    list.innerHTML =
      calls
        .filter(c=>!hiddenMessage({id:'call_'+c.id,room:c.room}))
        .map((c) => {
          const r = roomIndex.get(c.room);
          return `<button class="contact fs-directory-call" data-action="open-room" data-id="${escape(c.room)}">${avatar(r?.members?.find(x=>x.id!==state.user.id))}<span class="copy"><strong>${escape(r ? name(r) : "Görüşme")}</strong><p><span class="fs-call-direction ${['missed','rejected'].includes(c.status)?'is-failed':''}">${c.caller === state.user.id ? "↗ Giden" : "↙ Gelen"}</span> · ${escape(callLabel(c))}</p></span><span class="fs-directory-call-meta"><time>${escape(time(c.started))}</time>${icon(c.video?'video':'phone')}</span></button>`;
        })
        .join("") || empty("Arama geçmişi", "İlk görüşmeni başlat.");
    return;
  }
  const activeFilter=resolveFolderFilter(state.chatFilter,localState.preferences?.folders);
  const custom=activeFilter.startsWith('folder:');
  const rooms=filterFolderRooms(chatList(state.rooms,localState.preferences,custom?'Tümü':activeFilter,filter,state.user.id),localState.preferences?.folders,activeFilter);
  const archive=activeFilter==='Arşiv';
  const parts=[];
  const archiveHtml=homeArchiveMarkup(list,activeFilter);
  if(archiveHtml)parts.push({key:'archive',html:archiveHtml});
  if(rooms.length){for(const r of rooms)parts.push({key:'room:'+r.id,html:homeRoomMarkup(r)});}
  else parts.push({key:'empty',html:empty(
      archive?"Arşivlenmiş sohbet yok":custom?"Bu klasörde sohbet yok":"İlk sohbetini başlat",
      archive?"Arşivlediğin sohbetler burada görünür.":custom?"Klasör yönetiminden sohbet ekleyebilirsin.":"Sağ alttaki kalemden arkadaşını kullanıcı adıyla bul.",
    )});
  if(activeFilter==='Tümü'&&rooms.length&&!filter)parts.push({key:'end',html:'<button type="button" class="home-list-end" data-action="new-chat">'+icon('plus')+'<span>Yeni sohbet başlat</span></button>'});
  reconcileHomeRows(list,parts);
  list.querySelector('.home-archive-control')?.classList.remove('is-animating');
  paintHomeArchive(list);
  paintHomeSelection();
}
// The archive affordance is view state only. The existing encrypted archive preference
// remains the sole source of room membership; revealing it never acknowledges messages.
function homeArchiveMarkup(list,filter){
 if(filter==='Arşiv')return '<button type="button" class="home-archive-back" data-action="home-archive-back">'+icon('back')+'<span>Arşivlenmiş sohbetler</span></button>';
 if(filter!=='Tümü'||state.chatQuery)return '';
 const archived=new Set(localState.preferences?.archived||[]);
 const count=state.rooms.reduce((n,r)=>n+Number(archived.has(r.id)&&!r.hidden_from_home),0);
 if(!count){if(list._homeArchive)list._homeArchive.visible=false;return '';}
 return `<div class="home-archive-control"><button type="button" class="home-archive-hint" data-action="home-archive-toggle" aria-expanded="false" aria-controls="home-archive-row">${icon('archive')}<span>Arşiv için aşağı çekin</span></button><div id="home-archive-row" class="home-archive-row" hidden><button type="button" class="home-archive-open" data-action="home-archive-open"><span class="home-archive-icon">${icon('archive')}</span><span class="home-archive-copy"><strong>Arşivlenmiş sohbetler</strong><small>${count} sohbet</small></span>${icon('chevron')}</button><button type="button" class="home-archive-hide" data-action="home-archive-toggle" aria-label="Arşivi gizle">${icon('close')}</button></div></div>`;
}
function homeArchiveValid(s){return !!s&&s.root.isConnected&&s.list.isConnected&&s.list._homeArchive===s&&!isLocked()&&access.valid(s.epoch)&&state.user?.id===s.user&&state.token===s.token&&state.page==='home'&&state.tab==='Sohbetler';}
function paintHomeArchive(list){
 const s=list?._homeArchive,control=list?.querySelector('.home-archive-control');if(!homeArchiveValid(s)||!control)return;
 const hint=control.querySelector('.home-archive-hint'),row=control.querySelector('.home-archive-row');
 hint.hidden=s.visible;hint.setAttribute('aria-expanded',String(s.visible));row.hidden=!s.visible;
 control.classList.toggle('is-revealed',s.visible);control.style.removeProperty('--archive-pull');
}
function setHomeArchiveVisible(s,visible,focus=false){
 if(!homeArchiveValid(s)||modal.open||homeManagement()?.ids.size||!s.list.querySelector('.home-archive-control'))return;
 if(s.visible===visible)return;s.visible=visible;paintHomeArchive(s.list);
 s.list.querySelector('.home-archive-control')?.classList.toggle('is-animating',visible);
 if(focus)s.list.querySelector(visible?'.home-archive-open':'.home-archive-hint')?.focus({preventScroll:true});
}
function bindHomeArchive(){
 const root=app.querySelector('.fs-home-reference'),list=root?.querySelector('#home-list');if(!list)return;
 const s={root,list,epoch:access.epoch,user:state.user.id,token:state.token,visible:false,gesture:null,suppressUntil:0,compact:false};list._homeArchive=s;
 const allowed=()=>homeArchiveValid(s)&&!modal.open&&!homeManagement()?.ids.size&&!!list.querySelector('.home-archive-control');
 const reset=()=>{s.gesture=null;list.querySelector('.home-archive-control')?.style.removeProperty('--archive-pull');};
 list.addEventListener('touchstart',e=>{reset();if(!allowed()||e.touches.length!==1||list.scrollTop>2)return;const t=e.touches[0];s.gesture={id:t.identifier,x:t.clientX,y:t.clientY,delta:0,hide:s.visible&&!!e.target.closest('.home-archive-row')};},{passive:true});
 list.addEventListener('touchmove',e=>{const g=s.gesture;if(!g)return;if(!allowed()||e.touches.length!==1){reset();return;}const t=e.touches[0],dx=t.clientX-g.x,dy=t.clientY-g.y;if(t.identifier!==g.id||(Math.abs(dx)>14&&Math.abs(dx)>Math.abs(dy))||(!g.hide&&dy< -10)){reset();return;}g.delta=g.hide?-dy:dy;const progress=Math.max(0,Math.min(1,g.delta/68));list.querySelector('.home-archive-control')?.style.setProperty('--archive-pull',String(Math.round(progress*20)/20));},{passive:true});
 list.addEventListener('touchend',e=>{const g=s.gesture;if(!g)return;const t=[...e.changedTouches].find(t=>t.identifier===g.id);const complete=!!t&&allowed()&&e.touches.length===0&&(g.hide||list.scrollTop<=2)&&g.delta>=68;reset();if(complete){s.suppressUntil=performance.now()+450;setHomeArchiveVisible(s,!g.hide);}},{passive:true});
 list.addEventListener('touchcancel',reset,{passive:true});
 list.addEventListener('click',e=>{if(performance.now()<s.suppressUntil&&e.detail!==0){e.preventDefault();e.stopImmediatePropagation();}},true);
 list.addEventListener('scroll',()=>{if(!homeArchiveValid(s))return;const next=s.compact?list.scrollTop>12:list.scrollTop>36;if(next!==s.compact){s.compact=next;root.classList.toggle('home-scrolled',next);}}, {passive:true});
}
function homeArchiveAction(action,el){
 const list=app.querySelector('#home-list'),s=list?._homeArchive;if(!homeArchiveValid(s)||!list.contains(el)||modal.open||homeManagement()?.ids.size)return;
 if(action==='home-archive-toggle'){setHomeArchiveVisible(s,!s.visible,true);return;}
 if(action==='home-archive-open'&&!s.visible)return;
 state.chatFilter=action==='home-archive-open'?'Arşiv':'Tümü';home();
 if(action==='home-archive-back')setHomeArchiveVisible(app.querySelector('#home-list')?._homeArchive,true);
}
function homeRoomMarkup(r){
 const self=state.user.id, prefs=localState.preferences||{}, members=r.members||[],peer=members.find(m=>m.id!==self),pinned=(prefs.pinned||[]).includes(r.id);
 const muted=state.settings.messageAlerts===false||(state.settings.mutedRooms||[]).includes(r.id)||(r.kind!=='group'&&(state.settings.mutedPeers||[]).includes(peer?.id));
 const tone=Array.from(String(r.id)).reduce((h,ch)=>(Math.imul(h,31)+ch.codePointAt(0))>>>0,0)%7;
 const last=r.last,hidden=last&&hiddenMessage(last),draft=localState.drafts[r.id]?.text,unread=roomUnreadState(r,prefs,self),payload=hidden?null:last?.payload;
 const mediaIcon=payload?.viewOnce?'lock':payload?.type==='file'?(String(payload.mime||'').startsWith('image/')?'image':String(payload.mime||'').startsWith('video/')?'video':String(payload.mime||'').startsWith('audio/')?'waveform':'file'):payload?.type==='poll'?'poll':payload?.type==='call'?'phone':payload?.type==='location'?'location':null;
 const receipt=!hidden&&last?.sender===self?receiptStatus(last,members.filter(m=>m.id!==self).map(m=>m.id)):null;
 const stamp=last?.created&&Number.isFinite(last.created)?time(last.created):'';
 const badge=unread.count>0?`<span class="home-unread ${muted?'is-muted':''}" aria-label="${unread.count} doğrulanmış okunmamış mesaj">${unread.count>9999?'9999+':unread.count}</span>`:unread.pending?`<span class="home-unread home-unread-dot ${muted?'is-muted':''}" aria-label="Okunmamış mesaj; sayı doğrulanmadı"></span>`:'';
 return `<button type="button" class="contact home-room" data-action="open-room" data-id="${escape(r.id)}" aria-pressed="false"><span class="home-room-avatar" data-tone="${tone}">${avatar(r.kind==='group'?{name:name(r)}:peer,false,true)}<span class="home-room-check" aria-hidden="true">${icon('check')}</span>${state.presenceStale!==true&&r.kind==='direct'&&['online','busy'].includes(peer?.status)?`<span class="home-presence ${peer.status==='busy'?'busy':''}" aria-label="${peer.status==='busy'?'Meşgul':'Çevrimiçi'}"></span>`:''}</span><span class="copy"><span class="home-room-title"><strong>${escape(name(r))}</strong>${muted?`<span class="home-room-symbol" title="Bildirimler sessiz" aria-label="Bildirimler sessiz">${icon('bell-off')}</span>`:''}</span><span class="home-room-preview ${draft?'is-draft':''}">${!draft&&mediaIcon?icon(mediaIcon):''}<span>${escape(draft?'Taslak: '+draft:hidden?'Mesaj gizlendi':preview(payload))}</span></span></span><span class="contact-meta"><span class="home-room-time">${receipt?`<span class="list-check${receipt.read?' read':''}" data-receipt="${receipt.state}" title="${escape(receipt.label)}" aria-label="${escape(receipt.label)}">${escape(receipt.mark)}</span>`:''}<time>${escape(stamp)}</time></span><span class="home-room-status">${badge}${pinned?`<span class="home-room-pin" title="Sabit sohbet" aria-label="Sabit sohbet">${icon('pin')}</span>`:''}</span></span></button>`;

}
// A selection belongs to the mounted home screen, not to an account-global set.
function homeManagement(){const root=app.querySelector('.fs-home-reference');return root?._homeManagement;}
function homeManagementValid(session){return !!session&&session===homeManagement()&&session.root.isConnected&&!isLocked()&&access.valid(session.epoch)&&state.user?.id===session.user&&state.token===session.token&&state.page==='home'&&state.tab==='Sohbetler';}
function bindHomeManagement(){
 const root=app.querySelector('.fs-home-reference'),list=root?.querySelector('#home-list');if(!list)return;
 const session={root,epoch:access.epoch,user:state.user.id,token:state.token,ids:new Set(),busy:false,press:null,suppress:null,swipe:null};root._homeManagement=session;
 const stop=()=>{if(session.press)clearTimeout(session.press.timer);session.press=null;};
 const resetSwipe=()=>{if(session.swipe?.row)session.swipe.row.style.removeProperty('--home-swipe');session.swipe=null;};
 list.addEventListener('pointerdown',e=>{stop();resetSwipe();if(!homeManagementValid(session)||e.button!==0||!e.isPrimary||modal.open)return;const row=e.target.closest('.home-room');if(!row)return;const press={id:row.dataset.id,row,x:e.clientX,y:e.clientY,pointer:e.pointerId,avatar:!!e.target.closest('.home-room-avatar')};session.suppress=null;session.press=press;if(e.pointerType==='touch'&&!session.ids.size)session.swipe={...press,dx:0,dy:0};press.timer=setTimeout(()=>{if(session.press!==press||!homeManagementValid(session)||!row.isConnected)return;session.press=null;resetSwipe();session.suppress={id:press.id,until:performance.now()+1000};if(press.avatar&&!session.ids.size)showHomePreview(press.id).catch(e=>notice(e.message,4000,'error'));else toggleHomeRoom(press.id);},500);});
 list.addEventListener('pointermove',e=>{const p=session.press;if(p&&e.pointerId===p.pointer&&Math.hypot(e.clientX-p.x,e.clientY-p.y)>10)stop();const g=session.swipe;if(!g||g.pointer!==e.pointerId)return;g.dx=e.clientX-g.x;g.dy=e.clientY-g.y;if(!homeManagementValid(session)||!g.row.isConnected||Math.abs(g.dy)>Math.abs(g.dx)+10){resetSwipe();return;}if(g.dx< -12&&Math.abs(g.dx)>Math.abs(g.dy)*1.5)g.row.style.setProperty('--home-swipe',`translateX(${Math.max(-64,g.dx*.65)}px)`);else g.row.style.removeProperty('--home-swipe');},{passive:true});
 list.addEventListener('pointerup',e=>{stop();const g=session.swipe;resetSwipe();if(!g||g.pointer!==e.pointerId||!homeManagementValid(session)||modal.open||session.ids.size||!g.row.isConnected)return;const dx=e.clientX-g.x,dy=e.clientY-g.y;if(dx< -72&&Math.abs(dy)<Math.min(36,Math.abs(dx)*.4)){session.suppress={id:g.id,until:performance.now()+1000};toggleHomeRoom(g.id);showHomeManagement();}},{passive:true});
 for(const type of ['pointercancel','pointerleave','scroll'])list.addEventListener(type,()=>{stop();resetSwipe();},{passive:true});
 list.addEventListener('contextmenu',e=>{if(e.target.closest('.home-room'))e.preventDefault();});
 list.addEventListener('click',e=>{const row=e.target.closest('.home-room');if(!row||!homeManagementValid(session))return;if(session.suppress?.id===row.dataset.id&&performance.now()<session.suppress.until){session.suppress=null;e.preventDefault();e.stopImmediatePropagation();return;}if(session.ids.size){e.preventDefault();e.stopImmediatePropagation();if(!session.busy)toggleHomeRoom(row.dataset.id);}},true);
 const toolbar=document.createElement('nav');toolbar.className='home-selection-bar';toolbar.setAttribute('aria-label','Seçili sohbet işlemleri');toolbar.hidden=true;root.querySelector('header').after(toolbar);
 // A keyboard/screen-reader alternative to the long press.
 const trigger=document.createElement('button');trigger.type='button';trigger.className='home-select-trigger';trigger.dataset.action='home-select-start';trigger.setAttribute('aria-label','Sohbet seç');trigger.innerHTML=icon('check');root.querySelector('header').append(trigger);
}
function paintHomeSelection(){const s=homeManagement();if(!homeManagementValid(s))return;const rows=[...s.root.querySelectorAll('.home-room')],visible=new Set(rows.map(x=>x.dataset.id));for(const id of s.ids)if(!visible.has(id))s.ids.delete(id);for(const row of rows){const selected=s.ids.has(row.dataset.id);row.classList.toggle('is-selected',selected);row.setAttribute('aria-pressed',String(selected));}const bar=s.root.querySelector('.home-selection-bar');if(!bar)return;bar.hidden=!s.ids.size;s.root.classList.toggle('home-selecting',!!s.ids.size);bar.innerHTML=s.ids.size?`<button type="button" data-action="home-select-cancel" aria-label="Seçimi kaldır">${icon('close')}</button><strong aria-live="polite">${s.ids.size} seçili</strong><button type="button" data-action="home-manage" aria-label="Sohbet işlemleri" ${s.busy?'disabled':''}>${icon('more')}</button>`:'';}
function toggleHomeRoom(id){const s=homeManagement();if(!homeManagementValid(s)||s.busy||!state.rooms.some(r=>r.id===id))return;s.ids.has(id)?s.ids.delete(id):s.ids.add(id);paintHomeSelection();}
async function showHomePreview(id){
 const s=homeManagement(),room=state.rooms.find(r=>r.id===id);if(!homeManagementValid(s)||!room||modal.open)return;
 dialog(name(room),`<div class="home-preview-content" role="status">Sohbet yükleniyor…</div><button type="button" class="primary" data-action="home-preview-open" data-id="${escape(id)}">Sohbeti aç</button>`);
 const host=modal.querySelector('.home-preview-content');modal.classList.add('home-preview-dialog');
 const valid=()=>homeManagementValid(s)&&modal.open&&host.isConnected&&state.rooms.some(r=>r.id===id)&&!document.hidden;
 const render=rows=>{if(!valid())return;const visible=rows.filter(m=>m.room===id&&!hiddenMessage(m)&&!['reaction','vote'].includes(m.payload?.type)).slice(-8);host.innerHTML=visible.length?visible.map(m=>`<div class="home-preview-message ${m.sender===s.user?'mine':''}"><span>${escape(preview(m.payload).slice(0,240))}</span><time>${escape(time(m.created))}</time></div>`).join(''):'<p class="hint">Önizlenecek mesaj yok.</p>';};
 // Read-only GET, no opening view-once content, no visible-room registration and no receipts.
 try{if(room.ratchet_cutover_active){host.textContent='Güvenli sohbeti açarak mesajlarını görüntüleyebilirsin.';return;}const rows=await api('/rooms/'+encodeURIComponent(id)+'/messages');if(!valid())return;const decoded=[];for(const row of rows.slice(-20)){if(!valid())return;if(row.room===id)decoded.push(await decode(row));}render(decoded);}catch(e){if(valid()){const cached=localState.pages?.[id]||[];if(cached.length)render(cached);else host.textContent='Önizleme yüklenemedi. Sohbeti açarak tekrar deneyebilirsin.';}}
}
function purgeHomeHistory(room){
 const ids=new Set();for(const m of [...(localState.pages?.[room]||[]),...(state.messages||[]),...(state.saved||[]),...(state.media||[]),...state.cache.values()])if(m.room===room&&!m.pending)ids.add(m.id);
 if(state.room?.id===room){messageLoadSequence++;if(state.page==='chat')animateDeletedRows([...ids].filter(id=>!id.startsWith('call_')));state.historyLoadedRoute=null;}
 // Invalidate the cached snapshot, not all IDs permanently: a message may have arrived after the server clear.
 for(const id of ids)removeDeletedMessage(id,true,false);delete localState.pages[room];delete localState.positions[room];
 if(localState.preferences.pinnedMessages)delete localState.preferences.pinnedMessages[room];
 if(localState.drafts[room]){localState.drafts[room].reply=null;localState.drafts[room].quote=null;}
}
function showHomeManagement(){const s=homeManagement();if(!homeManagementValid(s)||s.busy||!s.ids.size)return;const ids=[...s.ids],prefs=localState.preferences,all=(list)=>ids.every(id=>(list||[]).includes(id));const item=(op,label)=>`<button type="button" class="row" data-action="home-manage-apply" data-op="${op}">${icon({pin:"pin",archive:"archive",mute:"bell-off",read:"check"}[op])}<span>${escape(label)}</span></button>`;const rooms=state.rooms.filter(r=>s.ids.has(r.id));const confirm=(op,label)=>`<button type="button" class="row home-destructive" data-action="home-history-confirm" data-op="${op}">${icon("trash")}<span>${escape(label)}</span></button>`;dialog(ids.length+' sohbet seçildi','<div class="home-action-menu">'+item('pin',all(prefs.pinned)?'Sabitlemeyi kaldır':'Sabitle')+item('archive',all(prefs.archived)?'Arşivden çıkar':'Arşivle')+item('mute',all(state.settings.mutedRooms)?'Sesi aç':'Sessize al')+item('read','Okundu olarak işaretle')+(ids.length===1?'<button type="button" class="row" data-action="home-manage-preview">'+icon('chat-bubbles')+'<span>Sohbeti önizle</span></button>':'')+confirm('clear','Geçmişi temizle')+(rooms.every(r=>r.kind==='direct')?confirm('delete','Sohbeti sil'):'')+(rooms.every(r=>r.kind==='group')?confirm('leave','Gruptan ayrıl'):'')+'</div>');}
function confirmHomeHistory(op,el){const s=homeManagement();if(!homeManagementValid(s)||s.busy||!modal.open||!modal.contains(el)||!['clear','delete','leave'].includes(op)||!s.ids.size)return;const ids=[...s.ids];const rooms=state.rooms.filter(r=>s.ids.has(r.id));if(rooms.length!==ids.length)return;if(op==='delete'&&rooms.some(r=>r.kind!=='direct')||op==='leave'&&rooms.some(r=>r.kind!=='group'))return;const title={clear:'Geçmişi temizle',delete:'Sohbeti sil',leave:'Gruptan ayrıl'}[op];const detail=op==='leave'?'Grup üyeliğin sona erecek. Diğer üyelerin geçmişi korunacak.':'Mevcut mesaj ve arama geçmişi yalnızca senin hesabından kaldırılacak. Diğer katılımcıların geçmişi korunacak. '+(op==='delete'?'Yeni mesaj geldiğinde sohbet yeniden görünebilir.':'Sohbet listede kalacak.');dialog(title,`<p>${escape(rooms.length===1?name(rooms[0]):rooms.length+' sohbet')}</p><p class="hint">${escape(detail)} Bekleyen gönderimler ve taslaklar otomatik silinmez.</p><button type="button" class="secondary" data-action="home-history-cancel">Vazgeç</button><button type="button" class="primary home-destructive" data-action="home-history-apply">${escape(title)}</button>`);s.historyConfirmation={op,ids,button:modal.querySelector('[data-action=home-history-apply]')};}
async function applyHomeHistory(el){const s=homeManagement(),c=s?.historyConfirmation;if(!homeManagementValid(s)||s.busy||!modal.open||!c||c.button!==el||!modal.contains(el)||c.ids.length!==s.ids.size||!c.ids.every(id=>s.ids.has(id)))return;s.busy=true;s.historyConfirmation=null;el.disabled=true;try{const result=await api('/room-history/manage',{method:'POST',body:{operation:c.op,rooms:c.ids}});if(!homeManagementValid(s))return;if(result.ok!==true||!Array.isArray(result.rooms)||result.rooms.length!==c.ids.length||!c.ids.every(id=>result.rooms.some(r=>r.room===id)))throw Error('Sunucu işlemi doğrulanamadı.');await refreshRooms();if(!homeManagementValid(s))return;modal.close();s.ids.clear();await homeList();notice('Sohbet işlemi tamamlandı.',2000,'success');}catch(e){if(homeManagementValid(s)){notice(e.status===404?'Sunucu bu işlemi henüz desteklemiyor.':e.message,4000,'error');modal.close();}}finally{s.busy=false;if(homeManagementValid(s))paintHomeSelection();}}
async function applyHomeManagement(op,el){const s=homeManagement();if(!homeManagementValid(s)||s.busy||!s.ids.size||!modal.open||!modal.contains(el)||!['pin','archive','mute','read'].includes(op))return;const ids=[...s.ids],prefs=localState.preferences;const update=(list=[])=>{const result=new Set(list),remove=ids.every(id=>result.has(id));for(const id of ids)remove?result.delete(id):result.add(id);return [...result];};s.busy=true;for(const b of modal.querySelectorAll('button'))b.disabled=true;let done=0;try{
 if(op==='pin'||op==='archive'){const key=op==='pin'?'pinned':'archived',previous=prefs[key];prefs[key]=update(previous);try{await persistLocal(true);}catch(e){prefs[key]=previous;throw e;}}
 if(op==='mute')await patchSettings({mutedRooms:update(state.settings.mutedRooms)});
 if(op==='read'){for(const id of ids){if(!homeManagementValid(s))return;await api('/rooms/'+encodeURIComponent(id)+'/read-delivered',{method:'POST',body:{}});done++;}if(!homeManagementValid(s))return;await refreshRooms();}
 if(!homeManagementValid(s))return;modal.close();s.ids.clear();await homeList();notice(op==='read'?'Teslim edilmiş mesajlar okundu olarak işaretlendi.':'Sohbet ayarları kaydedildi.',2000,'success');
 }catch(e){if(homeManagementValid(s)){if(done)notice(done+' sohbet güncellendi. Kalan işlem tamamlanamadı.',4000,'error');else notice(e.message,4000,'error');}}finally{s.busy=false;if(homeManagementValid(s)){for(const b of modal.querySelectorAll('button'))b.disabled=false;paintHomeSelection();}}}
function preview(p) {
  if (!p) return "Güvenli sohbet";
  if (p.viewOnce===true) return "Tek görüntülemelik medya";
  if (p.type === "file")
    return p.mime.startsWith("image/")
      ? "Fotoğraf"
      : p.mime.startsWith("video/")
        ? "Video"
        : p.name;
  if (p.type === "call") return p.text;
  return p.text || p.type;
}
// Search only the authenticated account's contacts, accessible rooms and saved messages.
function showHomeSearch(){
 if(isLocked()||state.page!=='home'||!state.user||!state.token)return;
 dialog('Ara',`<form id="home-search-form" class="home-search-form">${field('search-text','Sohbet, kişi, grup veya kayıtlı mesaj ara','search','',false)}<button type="submit" class="secondary">Ara</button></form><div class="home-search-filters" role="group" aria-label="Arama kategorisi">${[['all','Tümü'],['rooms','Sohbetler'],['people','Kişiler'],['groups','Gruplar'],['saved','Kayıtlı mesajlar']].map(([key,label])=>`<button type="button" data-search-category="${key}" aria-pressed="${key==='all'}">${label}</button>`).join('')}</div><div id="home-search-recent"></div><p id="home-search-status" role="status"></p><div id="search-room-results" aria-live="polite"></div>`);
 const form=$('#home-search-form'),input=$('#search-text'),results=$('#search-room-results'),status=$('#home-search-status'),recent=$('#home-search-recent');
 const s={epoch:access.epoch,user:state.user.id,token:state.token,workspace:localState,form,input,results,category:'all',contacts:[],saved:[],rows:[],loading:true,failed:[],busy:false};
 form._homeSearch=s;
 const cleanupSearch=()=>{if(modal.open&&form.isConnected)return;modal.removeEventListener("close",cleanupSearch);s.contacts=[];s.saved=[];s.rows=[];form._homeSearch=null;input.value="";results.replaceChildren();recent.replaceChildren();};modal.addEventListener("close",cleanupSearch);
 const valid=()=>homeSearchValid(s);
 const draw=()=>{
  if(!valid())return;const q=searchTerm(input.value);s.rows=homeSearch({rooms:state.rooms,contacts:s.contacts,saved:s.saved,user:s.user,preferences:s.workspace.preferences,tags:s.workspace.tags,query:q,category:s.category,hidden:hiddenMessage,presenceStale:state.presenceStale===true});
  results.innerHTML=s.rows.map((item,i)=>`<button type="button" class="contact home-search-result" data-action="home-search-result" data-index="${i}">${item.person?avatar(item.person):icon(item.kind==='saved'?'bookmark':item.kind==='group'?'user':'chat-bubbles')}<span class="copy"><strong>${escape(item.label)}</strong><p>${escape(item.detail)}</p></span></button>`).join('');
  const history=recentSearches(s.workspace.searchHistory);recent.hidden=!!q||!history.length;recent.innerHTML=recent.hidden?'':`<div class="home-search-recent-title"><strong>Son aramalar</strong><button type="button" id="home-search-clear">Tümünü temizle</button></div>${history.map((term,i)=>`<button type="button" class="home-search-history" data-recent-index="${i}">${icon('search')}<span>${escape(term)}</span></button>`).join('')}`;
  status.textContent=s.loading?'Kişiler ve kayıtlı mesajlar yükleniyor…':s.failed.length?s.failed.join(', ')+' yüklenemedi. Mevcut sonuçlar gösteriliyor.':!q?'':s.rows.length?s.rows.length+(s.rows.length===120?'+':'')+' sonuç':'Sonuç bulunamadı.';
 };
 const commit=async value=>{const previous=s.workspace.searchHistory;s.workspace.searchHistory=value;try{await persistLocal(true);}catch(e){if(s.workspace.searchHistory===value)s.workspace.searchHistory=previous;if(valid())notice(e.message,4000,'error');}if(valid())draw();};
 form.onsubmit=async e=>{e.preventDefault();if(valid()&&searchTerm(input.value))await commit(rememberSearch(s.workspace.searchHistory,input.value));};
 input.oninput=draw;
 modal.querySelector('.home-search-filters').onclick=e=>{const b=e.target.closest('[data-search-category]');if(!valid()||!b)return;s.category=b.dataset.searchCategory;for(const node of modal.querySelectorAll('[data-search-category]'))node.setAttribute('aria-pressed',String(node===b));draw();};
 recent.onclick=async e=>{if(!valid())return;if(e.target.closest('#home-search-clear')){await commit([]);return;}const b=e.target.closest('[data-recent-index]');if(b){input.value=recentSearches(s.workspace.searchHistory)[Number(b.dataset.recentIndex)]||'';draw();input.focus();}};
 draw();input.focus();
 Promise.allSettled([api('/contacts'),api('/saved').then(raw=>{if(!valid())return [];return Promise.all(raw.map(decode));})]).then(([contacts,saved])=>{if(!valid())return;if(contacts.status==='fulfilled')s.contacts=contacts.value;else s.failed.push('Kişiler');if(saved.status==='fulfilled')s.saved=saved.value;else s.failed.push('Kayıtlı mesajlar');s.loading=false;draw();});
}
function homeSearchValid(s){return !!s&&!isLocked()&&access.valid(s.epoch)&&state.user?.id===s.user&&state.token===s.token&&state.page==='home'&&localState===s.workspace&&modal.open&&s.form.isConnected&&modal.contains(s.form);}
async function selectHomeSearchResult(el){
 const s=$('#home-search-form')?._homeSearch;if(!homeSearchValid(s)||s.busy||!s.results.contains(el))return;
 const item=s.rows[Number(el.dataset.index)];if(!item)return;s.busy=true;
 try{
  const previous=s.workspace.searchHistory,next=rememberSearch(previous,s.input.value);s.workspace.searchHistory=next;
  try{await persistLocal(true);}catch(e){if(s.workspace.searchHistory===next)s.workspace.searchHistory=previous;if(homeSearchValid(s))notice(e.message,4000,'error');}
  if(!homeSearchValid(s))return;
  if(item.kind==='person'&&!item.room){await api('/contacts',{method:'POST',body:{peer:item.id}});if(!homeSearchValid(s))return;const r=await api('/rooms',{method:'POST',body:{members:[item.id]}});if(!homeSearchValid(s))return;await refreshRooms();if(homeSearchValid(s))await openRoom(r.id);return;}
  const room=item.room||item.id;if(!state.rooms.some(r=>r.id===room&&!r.hidden_from_home))return;
  if(item.kind==='saved'&&hiddenMessage(item.record))return;
  await openRoom(room);
  if(item.kind==='saved'&&access.valid(s.epoch)&&state.user?.id===s.user&&state.token===s.token&&state.page==='chat'&&state.room?.id===room&&!hiddenMessage(item.record))await jumpReply(item.id);
 }finally{s.busy=false;}
}
async function newChat() {
  dialog(
    "Yeni sohbet",
    `<form id="find-form">${field("query", "Kullanıcı adı, telefon veya e-posta")}<button class="primary">Bul</button></form><div id="people-results"></div><p class="hint">Telefon ve e-posta araması yalnızca izin veren hesapları bulur. İletişim bilgileri sonuçlarda paylaşılmaz.</p><div class="fs-invite-actions">${row("invite","share","Arkadaşına Davet Gönder")}${row("invite-contact","user","Rehberden Davet Gönder")}</div>`,
  );
  let searchSequence = 0;
  const resultsTarget = $("#people-results");
  $("#find-form").onsubmit = async (e) => {
    e.preventDefault();
    const sequence = ++searchSequence;
    try {
      const results = await api(
        "/people?q=" + encodeURIComponent($("#query").value),
      );
      if (sequence !== searchSequence || !resultsTarget.isConnected || !modal.open) return;
      resultsTarget.innerHTML =
        results
          .filter((p) => p.id !== state.user.id)
          .map(
            (p) =>
              `<button class="contact" data-action="start-chat" data-id="${p.id}">${avatar(p)}<span class="copy"><strong>${escape(p.name)}</strong><p>@${escape(p.nick)}</p></span>${icon("plus")}</button>`,
          )
          .join("") || '<p class="hint">Bu kullanıcı adı bulunamadı.</p>';
    } catch (err) {
      notice(err.message, 4000, "error");
    }
  };
}
async function startChat(peer) {
  await api("/contacts", { method: "POST", body: { peer } });
  const r = await api("/rooms", { method: "POST", body: { members: [peer] } });
  modal.close();
  await refreshRooms();
  await openRoom(r.id);
}
let inlineRatchet=null;
function closeInlineRatchet(){const entry=inlineRatchet;inlineRatchet=null;entry?.close?.();}
modal.addEventListener("close",()=>queueMicrotask(()=>{if(!isLocked()&&!modal.open)updateCutoverComposer();}));
function updateCutoverComposer(){
 if(state.page!=='chat'||!state.room?.ratchet_cutover_active){closeInlineRatchet();return;}
 const form=$('#compose');if(!form)return;
 if($("#composer-emoji-panel:not([hidden])"))closeComposerEmoji();
 for(const control of form.querySelectorAll('button,textarea,input'))control.disabled=true;
 form.style.display='none';
 if(inlineRatchet?.root?.isConnected)return;
 closeInlineRatchet();
 let panel=$('#ratchet-cutover-notice');if(!panel){panel=document.createElement('div');panel.id='ratchet-cutover-notice';panel.className='security-note ratchet-inline';form.before(panel);}
 if(state.room.ratchet_pilot!==true){panel.textContent='Güvenli kanal şu anda kullanılamıyor. Eski gönderim kapalı.';return;}
 if(modal.open)return;
 const room=state.room.id,user=state.user.id,peer=state.room.members.find(m=>m.id!==user)?.id,epoch=access.epoch,route=state.routeVersion,token=state.token;
 const entry={root:panel,close:null};inlineRatchet=entry;
 const valid=()=>inlineRatchet===entry&&access.valid(epoch)&&state.user?.id===user&&state.token===token&&state.page==='chat'&&state.room?.id===room&&state.routeVersion===route&&panel.isConnected;
 panel.textContent='Güvenli oturum hazırlanıyor…';
 (async()=>{const scope='pilot-account:'+user;const [identity,key]=await Promise.all([pilotIdentity(scope),localRatchetStore.storageKey(scope)]);if(!valid()||!peer)return;const client=new RatchetPilotClient({api,room,user,peer,identity,key,valid});const transport=createInlineTransport({api,client,room,valid});panel.replaceChildren();entry.close=mountInlineTransport(panel,{transport,valid,user,manage:()=>actions('ratchet-pilot',panel).catch(e=>notice(e.message))});})().catch(e=>{if(valid()){panel.textContent=e.message;closeInlineRatchet();}});
}
async function openRoom(id) {
  if(isLocked())return;
  const room = state.rooms.find((r) => r.id === id);
  if (!room) throw Error("Sohbet artık kullanılamıyor.");
  if(modal.open)modal.close();
  closeInlineRatchet();dismissAlbumViewer();dismissProfileViewer();
  rememberChat();virtualMessages?.destroy();virtualMessages=null;stopThumbnailObservation();
  typing.reset();clearEmojiEffect();clearSendEffects();replyReturn=null;replyJumpFlight=null;
  if (state.room?.id !== id) {clearComposer();discardVoice();state.messages = [];state.reply = null;state.reactionTarget = null;}
  clearAdminState();state.page = "chat";
  state.room = room;
  window.FSNative?.visibleMessageRoom?.(id);
  state.selected.clear();
  const route = ++state.routeVersion;
  state.historyLoadedRoute=null;state.hasOlder=false;
  state.unreadSince=localState.preferences.read?.[id]||0;state.restorePosition=localState.positions[id];
  const peer = room.members.find((x) => x.id !== state.user.id);
  app.innerHTML = `<section class="screen chat-wall fs-premium fs-chat"><header class="chat-head">${button("home", "back", "Sohbetler")}<button data-action="peer-profile" aria-label="${room.kind==='group'?'Grup üyeleri':'Kişi profili'}">${room.kind==='group'?avatar({name:name(room)}):avatar(peer)}</button><h1><span class="chat-peer-name">${escape(name(room))}</span><small><button data-action="status" data-peer-online="${room.kind==='direct'&&state.presenceStale!==true&&peer?.status==='online'}" aria-label="Kendi durumunu değiştir">${room.kind==='group'?`${room.members.length} üye`:escape(peerPresenceLabel(peer))}</button><span id="typing-status" role="status" aria-live="polite" hidden></span></small></h1>${button("audio-call", "phone", "Sesli ara")}${button("video-call", "video", "Görüntülü ara")}<button class="available ${state.settings.available === false ? "off" : ""}" data-action="available" aria-pressed="${state.settings.available !== false}" aria-label="${state.settings.available !== false ? "Müsaitim; değiştirmek için dokunun" : "Müsait değilim; değiştirmek için dokunun"}">${icon("check")}</button>${button("chat-options", "more", "Sohbet seçenekleri")}</header><nav class="chat-tools chat-return-tools"><button data-action="return-reply" id="return-reply" hidden>↩ Önceki konuma dön</button></nav><div id="pinned-message" hidden></div><div id="selection"></div><main class="scroll messages" id="messages"></main><div class="latest-message-anchor"><button type="button" data-action="newest" id="new-messages" aria-label="En yeni mesaja git" hidden><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg><span id="new-messages-count" hidden></span></button></div><div id="selection-bottom"></div><div id="reply"></div><div id="composer-files" hidden></div><div id="upload-progress"></div><div id="voice-status" role="status" aria-live="polite" hidden></div><form class="composer" id="compose"><div class="box">${button("emoji", "smile", "İfade seç", 'type="button"')}<textarea id="message-text" placeholder="Mesaj yaz…" aria-label="Mesaj yaz" rows="1" maxlength="4000"></textarea>${button("attach", "clip", "Dosya ekle", 'type="button"')}</div><button class="icon composer-action" id="composer-action" type="button" data-mode="mic" aria-label="Basılı tutarak ses kaydet">${icon("mic")}</button></form><section id="composer-emoji-panel" aria-label="Emoji seçici" hidden></section>${state.call?.video ? '<video id="call-mini" class="chat-pip" autoplay playsinline role="button" tabindex="0" aria-label="Görüşmeye dön; sürükleyerek taşı"></video>' : ""}</section>`;
  syncCallReturnBanner();syncChatViewport();
  if(state.call?.video) bindChatPip();
  attachVideo();
  const draft=localState.drafts[id];$("#message-text").dataset.room=id;$("#message-text").value=draft?.text||"";resizeComposer($("#message-text"));
  const scrollArea=$("#messages");const scrollEpoch=access.epoch;
  const onChatScroll=frameBatch(()=>{if(!access.valid(scrollEpoch)||state.routeVersion!==route||state.room?.id!==id||state.page!=="chat"||!scrollArea.isConnected)return;if(viewportArea===scrollArea&&scrollArea.clientHeight===previousMessageHeight){viewportAtBottom=nearLatest(scrollArea);viewportScrollTop=scrollArea.scrollTop;}rememberChat();markCurrentRead();updateLatestButton();});
  scrollArea.addEventListener("scroll",onChatScroll,{passive:true});
  bindComposer(room);updateCutoverComposer();
  $("#message-text").onblur = ()=>typing.stop();
  $("#message-text").oninput = (e) => {
    typing.input(e.target.value);syncComposer();rememberChat();
    resizeComposer(e.target);
  };
  if(localState.pages[id]?.length){state.messages=localState.pages[id];renderMessages();}
  if(draft?.reply){const m=state.messages.find(m=>m.id===draft.reply&&!hiddenMessage(m));state.reply=m?{...m,room:id,quoteText:quoteSnapshot(draft.quote)}:null;if(state.reply)renderReply();}
  bindSelection();
  await loadMessages(route).catch(error=>{if(!localState.pages[id]?.length)notice(error.message,4000,'error')});
}
let messageLoadSequence = 0;
async function loadMessages(route = state.routeVersion) {
  if(isLocked())return;
  const sequence = ++messageLoadSequence;
  if (!state.room) return;
  const room = state.room.id;
  const epoch=access.epoch;
  const [rows,calls] = await Promise.all([api("/rooms/" + room + "/messages"),api("/rooms/" + room + "/calls")]);assertEpoch(epoch);
  const currentRoute=()=>sequence===messageLoadSequence&&route===state.routeVersion&&state.room?.id===room&&state.page==="chat";
  if(!currentRoute())return;
  const decoded = (await Promise.all(rows.map(decode))).filter(m=>!deletedInSession.has(m.id));
  assertEpoch(epoch);if(!currentRoute())return;
  decoded.push(
    ...calls.map((c) => ({
      id: "call_" + c.id,
      room,
      sender: c.caller,
      created: c.started,
      payload: { type: "call", text: callLabel(c), history: callHistoryInfo(c,state.user.id) },
      callRecord: true,
    })),
  );
  decoded.sort((a, b) => a.created - b.created);
  if (
    sequence !== messageLoadSequence ||
    route !== state.routeVersion ||
    state.room?.id !== room ||
    state.page !== "chat"
  )
    return;
  if(state.messageCacheCheck){
    const current=()=>access.valid(epoch)&&sequence===messageLoadSequence&&route===state.routeVersion&&state.room?.id===room&&state.page==="chat";
    try{
      const missing=await missingCachedMessages(state.messages,decoded,room,ids=>api(`/rooms/${encodeURIComponent(room)}/messages/check`,{method:"POST",body:{ids}}),current);
      if(!current())return;
      for(const id of missing)removeDeletedMessage(id);
    }catch(error){if(!current())return;console.warn("message cache check",error.message);}
  }
  const queued=localState.outbox.filter(m=>m.room===room).map(m=>({...m,pending:true,queued:true,sender:state.user.id}));
  state.messages = upsertMessages(mergeMessagePage(state.messages, decoded, room),queued).filter(m=>!deletedInSession.has(m.id));
  if(!state.reply&&localState.drafts[room]?.reply){const m=state.messages.find(m=>m.id===localState.drafts[room].reply&&!hiddenMessage(m));if(m){state.reply={...m,room,quoteText:quoteSnapshot(localState.drafts[room].quote)};renderReply();}}
  state.hasOlder = rows.length === 80;
  state.historyLoadedRoute=route;
  storePage(room,state.messages);
  renderMessages();
  markCurrentRead();
}
function renderMessages() {
  if(isLocked())return;
  const target = $("#messages");
  if (!target) return;
  const selecting=target.classList.contains("selection-gesture");
  const bottom = !selecting&&nearLatest(target);
  target.classList.toggle("selection-active",state.selected.size>0);
  messageIndex=buildMessageIndex(state.messages.filter(m=>!hiddenMessage(m)));
  let day = "";
  const visible = [];
  const isUnreadAlbumBoundary=(a,b)=>b.sender!==state.user.id&&a.created<=state.unreadSince&&b.created>state.unreadSince;
  for (const m of state.messages) {
    if (hiddenMessage(m)||m.payload.type === "reaction" || m.payload.type === "vote") continue;
    const previous = visible.at(-1);
    if (
      m.callRecord &&
      previous?.callRecord &&
      state.selected.has(previous.id)===state.selected.has(m.id) &&
      sameCallHistoryKind(previous.payload.history,m.payload.history) &&
      new Date(m.created).toDateString() ===
        new Date(previous.created).toDateString()
    ) {
      previous.count = (previous.count || 1) + 1;
      previous.callIds=[...(previous.callIds||[previous.id]),m.id];
      previous.payload = {
        ...m.payload,
        text: m.payload.text + " ×" + previous.count,
      };
    } else if (
      m.payload.type === "file" && !isViewOnce(m) &&
      m.payload.mime.startsWith("image/") &&
      previous?.album &&
      previous.sender === m.sender &&
      !!previous.pending===!!m.pending && state.selected.has(previous.id)===state.selected.has(m.id) &&
      !m.reply && !previous.reply &&
      !isUnreadAlbumBoundary(previous,m) &&
      new Date(m.created).toDateString() === new Date(previous.created).toDateString() &&
      m.created >= previous.created && m.created - previous.created < 30000
    ) {
      previous.album.push(m);
    } else
      visible.push({
        ...m,
        ...(m.payload.type === "file" && !isViewOnce(m) && m.payload.mime.startsWith("image/")
          ? { album: [m] }
          : {}),
      });
  }
  const isUnread=m=>m&&m.sender!==state.user.id&&m.created>state.unreadSince&&!m.callRecord;
  const firstUnread=visible.findIndex(isUnread);
  const joined=(a,b,boundary)=>chatMessageJoined(a,b,{unreadBoundary:boundary,singleEmoji:isSingleEmoji});
  const groups=bubbleGroups(visible,firstUnread,joined);
  const rows=visible.map((m,i)=>{
    const value=new Date(m.created);const date=Number.isNaN(value.getTime())?value.toLocaleDateString('tr-TR'):messageDateFormatter.format(value);let divider=day!==date?`<div class="day">${date}</div>`:'';day=date;
    if(i===firstUnread){divider+='<div class="unread-divider">Okunmamış mesajlar</div>';}
    const group=groups[i];
    return {id:m.id,callIds:m.callIds||[],albumIds:m.album?.map(x=>x.id)||[],html:()=>divider+`<div class="tg-message-line" data-bubble-group="${group}">${selectionMarker(m)}${renderMessage({...m,bubbleGroup:group})}</div>`};
  });
  if(!rows.length&&!state.hasOlder&&state.historyLoadedRoute===state.routeVersion&&state.room?.kind==='direct'&&!state.room.ratchet_cutover_active){
    const greeting=greetingPicker(state.routeVersion,emojiIndex),asset=emojiAsset(emojiIndex,greeting),path=asset&&!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches?characterAssetPath(asset):null;
    rows.push({id:'__fs_empty_chat__',html:`<div class="fs-empty-chat"><h2>Henüz mesaj yok</h2><p>İlk mesajını göndererek sohbete başla.</p><button type="button" data-action="first-greeting" data-greeting="${escape(greeting)}" aria-label="Selam emojisi gönder">${path?`<img src="${escape(path)}" alt="${escape(greeting)}" decoding="async" draggable="false">`:`<span aria-hidden="true">${escape(greeting)}</span>`}</button><small>Selam göndermek için dokun</small></div>`});
  }
  target.classList.toggle('empty-conversation',rows.length===1&&rows[0].id==='__fs_empty_chat__');
  if(state.hasOlder)rows.unshift({id:'older',html:'<button class="secondary" data-action="older">Önceki mesajları yükle</button>'});
  const previousAnchor=virtualMessages?.anchor();rememberPlayback();
  if(!virtualMessages||virtualMessages.target!==target){virtualMessages?.destroy();virtualMessages=new VirtualMessages(target,keyedMessages,()=>{loadThumbnails();restoreAudio();updateLatestButton();scheduleReceipts()},()=>{updateLatestButton();scheduleReceipts()});}
  const position=state.restorePosition;state.restorePosition=null;
  virtualMessages.set(rows,{bottom:position?position.bottom:bottom,anchor:position?.anchor||previousAnchor});
  if(position&&!position.anchor&&!position.bottom)target.scrollTop=position.top||0;
  updateLatestButton();
  selectionBar();
  renderPinnedMessage();
  scheduleReceipts();
}

function updateLatestButton(){
 const list=$('#messages'),button=$('#new-messages'),badge=$('#new-messages-count');
 if(isLocked()||state.page!=='chat'||!state.room||!list||!button||!badge)return;
 button.hidden=nearLatest(list);
 const read=localState.preferences.read?.[state.room.id]||0;
 const count=button.hidden?0:countUnread(state.messages,{room:state.room.id,self:state.user.id,hiddenRevision:localState.preferences.hiddenMessages?.[state.room.id],deletedRevision,isHidden:hiddenMessage,read});
 const label=count?`${count} yeni mesaj; en yeni mesaja git`:'En yeni mesaja git',text=count>99?'99+':String(count||'');
 if(badge.hidden!==!count)badge.hidden=!count;if(badge.textContent!==text)badge.textContent=text;
 if(button.getAttribute('aria-label')!==label)button.setAttribute('aria-label',label);
}
function jumpToLatest(){
 if(isLocked()||state.page!=='chat')return;
 const list=$('#messages');if(!list)return;
 replyJumpFlight=null;replyReturn=null;const back=$('#return-reply');if(back)back.hidden=true;
 // Render the last virtual window first, then jump to its actual measured bottom.
 if(virtualMessages?.target===list)virtualMessages.draw(true);else list.scrollTop=list.scrollHeight;
 markCurrentRead();rememberChat();updateLatestButton();
}

function selectionMarker(m){return state.selected.size&&eligibleMessage(m.id)?`<button type="button" class="selection-dot ${state.selected.has(m.id)?"checked":""}" data-action="toggle-selection" data-id="${escape(m.id)}" aria-label="${state.selected.has(m.id)?"Mesajın seçimini kaldır":"Mesajı seç"}" aria-pressed="${state.selected.has(m.id)}">${state.selected.has(m.id)?icon("check"):""}</button>`:"";}
function renderMessage(m) {
  const p = m.payload;
  const emoji = p.type === "text" && isSingleEmoji(p.text);
  const asset = emoji ? emojiAsset(emojiIndex,p.text) : null;
  const animatedPath=asset&&!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches?characterAssetPath(asset):null;
  let content = p.type === "text" ? `<span class="fs-chat-text">${linkText(p.text)}</span>` : escape(p.text || "");
  if(p.type==='locked'&&state.page==='chat'&&state.room?.members?.some(u=>u.id===state.user?.id))content+='<button type="button" class="secondary" data-action="recover-history">Eski anahtarı kurtar</button>';
  if(m.callRecord&&p.history){const h=p.history;content=`<div class="fs-call-history-card ${h.failed?'failed':''}"><div><strong>${escape(h.title)}${m.count>1?` ×${m.count}`:''}</strong><small><span class="fs-call-arrow" aria-hidden="true">${h.outgoing?'↗':'↙'}</span> ${escape(time(m.created))} · ${escape(h.detail)}</small></div><span class="fs-call-history-symbol" aria-hidden="true">${icon(h.video?'video':'phone')}</span></div>`;}
  if (p.type === "file")
    content = `<button class="file-button" data-action="download" data-id="${escape(m.id)}"><span class="fs-file-symbol" aria-hidden="true">${icon("file")}</span><span class="fs-file-label"><strong>${escape(p.name)}</strong><small class="muted">${(p.size / 1048576).toFixed(1)} MB · Aç / İndir</small></span></button>`;
  if (p.type === "file" && p.mime.startsWith("image/"))
    content = `<button class="fs-photo-preview" data-action="download" data-id="${escape(m.id)}" aria-label="Fotoğrafı aç: ${escape(p.name)}"><span class="fs-photo-frame"><img class="thumb ${state.settings.blur !== false ? "blurred" : ""}" data-thumb="${escape(m.id)}" alt="${escape(p.name)}"><span class="fs-photo-open" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v12m-5-5 5 5 5-5M5 20h14"/></svg></span></span><small>${escape(p.name)}</small></button>`;
  if (p.type === "file" && p.mime.startsWith("video/"))
    content = `<button class="fs-video-preview" data-action="download" data-id="${escape(m.id)}" aria-label="Videoyu aç: ${escape(p.name)}"><span class="fs-video-preview-stage"><span class="fs-video-play" aria-hidden="true">${icon('play')}</span><span class="fs-video-size">${(p.size/1048576).toFixed(1)} MB</span></span><small>${escape(p.name)}</small></button>`;
  if (p.type === "file" && p.mime.startsWith("audio/"))
    content = `<div class="voice-message"><audio hidden preload="none" data-audio="${escape(m.id)}" data-voice-duration="${voiceDurationHint(p.name)}" ${audioUrls.has(m.id) ? `src="${escape(audioUrls.get(m.id))}"` : ""}></audio><button type="button" data-action="play-audio" data-id="${escape(m.id)}" aria-label="Sesli mesajı oynat">▶</button><div class="voice-message-track"><div class="voice-play-wave" aria-hidden="true"></div><input class="voice-seek" type="range" min="0" max="1" step="0.1" value="0" disabled aria-label="Sesli mesaj konumu"><small class="voice-message-time">0:00 / —</small></div><button type="button" data-action="audio-speed" data-id="${escape(m.id)}" aria-label="Oynatma hızını değiştir">${localState.playback[m.id]?.rate||1}×</button></div>`;
  if (m.album?.length > 1)
    content = `<div class="album" data-photo-count="${Math.min(m.album.length,4)}">${m.album
      .slice(0, 4)
      .map(
        (item, i) =>
          `<button type="button" data-action="view-album" data-id="${escape(m.id)}" data-index="${i}" aria-label="Albümü aç; fotoğraf ${i+1} / ${m.album.length}" ${m.album.some(item=>item.pending)?"disabled":""}><img class="thumb ${state.settings.blur !== false ? "blurred" : ""}" data-thumb="${escape(item.id)}" alt="${escape(item.payload.name)}">${i === 3 && m.album.length > 4 ? `<span class="album-count" aria-label="Toplam ${m.album.length} fotoğraf">${m.album.length}</span>` : ""}</button>`,
      )
      .join("")}</div><button type="button" class="album-download secondary" data-action="download-album" data-id="${escape(m.id)}" ${m.album.some(item=>item.pending)?"disabled":""}>${icon("file")} Albümü indir (${m.album.length})</button>`;
  if(isViewOnce(m))content=`<button type="button" class="once-media" data-action="view-once" data-id="${escape(m.id)}" ${m.pending||m.sender===state.user.id||m.view_once_opened?"disabled":""}><span class="once-symbol" aria-hidden="true">1</span><span><strong>${p.mime?.startsWith('video/')?'Tek görüntülemelik video':'Tek görüntülemelik fotoğraf'}</strong><small>${onceStatus(m,state.user.id)}</small></span></button>`;
  if (p.type === "location")
    content = locationCard(m);
  if (p.type === "poll")
    content = `<strong>${escape(p.text)}</strong>${p.options
      .map((o, i) => {
        const votes = messageIndex.votes.get(m.id)||new Map();
        const count = [...votes.values()].filter((v) => v === i).length;
        return `<button class="row" data-action="vote" data-id="${m.id}" data-choice="${i}">${escape(o)} <span class="badge">${count}</span></button>`;
      })
      .join("")}`;
  if (p.type === "event") content = `📅 ${escape(p.text)}<br>${escape(p.date)}`;
  const quote = messageIndex.byId.get(m.reply);
  const exactQuote=quote&&quoteSnapshot(p.replyQuote);
  const changedQuote=exactQuote&&!validQuote(quote,exactQuote);
  const latestReactions = messageIndex.reactions.get(m.id)||new Map();
  const reactionCounts = new Map();
  for (const value of latestReactions.values())
    if(value&&isSingleEmoji(value)){const existing=[...reactionCounts.keys()].find(e=>sameReaction(e,value))||value;reactionCounts.set(existing,(reactionCounts.get(existing)||0)+1);}
  const reactionBar = [...reactionCounts]
    .map(
      ([emoji, count]) =>
        `<button type="button" class="reaction-chip ${sameReaction(latestReactions.get(state.user.id),emoji)?"own-reaction":""}" data-action="message-reaction" data-id="${escape(m.id)}" data-emoji="${escape(emoji)}" aria-pressed="${sameReaction(latestReactions.get(state.user.id),emoji)}" aria-label="${escape(emoji)} ${count} tepki">${escape(emoji)}${count>1?` <span>${count}</span>`:""}</button>`,
    )
    .join("");
  const own=m.sender===state.user.id&&!m.callRecord;
  const groupName=state.room?.kind==='group'&&!own&&!m.callRecord&&!emoji&&!['middle','end'].includes(m.bubbleGroup)?`<strong class="fs-bubble-sender">${escape(senderName(m))}</strong>`:"";
  const status=receiptStatus(m,(state.room?.members||[]).filter(x=>x.id!==state.user.id).map(x=>x.id));
  const metadata=`${time(m.created)}${m.delete_at?` · <span class="expiry-mark" title="${escape(new Date(m.delete_at).toLocaleString("tr-TR"))}" aria-label="Otomatik silinecek">⏳</span>`:""}${m.edited?' <span class="message-edited">düzenlendi</span>':""}${own?` <span class="receipt-mark ${status.read?'receipt-read':''}" data-receipt="${status.state}" title="${escape(status.label)}" aria-label="${escape(status.label)}">${status.mark}</span>`:""}`;
  return `<article class="message ${m.sender === state.user.id ? "mine" : ""} ${state.selected.has(m.id) ? "selected" : ""} ${emoji ? "emoji" : ""} ${p.type==="text"&&!emoji?"fs-text-bubble":""} ${m.callRecord?"call-history-message":""}" data-message="${m.id}" data-emoji="${emoji ? escape(p.text) : ""}" tabindex="0" aria-label="${escape(preview(p))}">${groupName}${m.reply ? `<button type="button" class="quote reply-quote" data-action="jump-reply" data-id="${escape(m.reply)}"><strong>${escape(quote?senderName(quote):"Yanıtlanan mesaj")}${changedQuote?" · Önceki alıntı":""}</strong><span>${escape(quote?(exactQuote||preview(quote.payload).slice(0,120)):"Mesaja git")}</span></button>` : ""}${emoji ? (animatedPath ? `<img class="animated-emoji" src="${escape(animatedPath)}" alt="${escape(p.text)}" loading="lazy" decoding="async" draggable="false"><span class="emoji-fallback fs-motion-fallback" aria-hidden="true">${escape(p.text)}</span>` : `<span class="emoji-fallback">${escape(p.text)}</span>`) : content}${p.type==="file"?`<div class="transfer-state" data-transfer="${m.id}" role="status"></div>`:""}${reactionBar ? `<div class="reactions">${reactionBar}</div>` : ""}${messageEffect(p.effect,p.effectVariant)?`<button type="button" class="send-effect-replay" data-action="replay-send-effect" data-id="${escape(m.id)}" aria-label="Mesaj efektini oynat">${messageEffect(p.effect,p.effectVariant).glyph}</button>`:""}${m.callRecord&&p.history?"":`<time>${metadata}</time>`}</article>`;
}
async function send(payload, room = state.room, fixedId = null, options = {}) {
  assertAccess();const epoch=access.epoch;
  if (!room) throw Error("Sohbet seçin.");
  if(room.ratchet_cutover_active===true||state.rooms.find(r=>r.id===room.id)?.ratchet_cutover_active===true)throw Error('Bu sohbet güvenli kanala geçti. Güvenli sohbet ekranını kullanın.');
  validatePayload(payload);
  if(payload.viewOnce&&!state.viewOnce)throw Error("Sunucu tek görüntülemeyi desteklemiyor.");
  if(options.silent&&!state.sendOptions)throw Error("Sunucu sessiz gönderimi henüz desteklemiyor.");
  if(navigator.onLine===false&&payload.type==='text'&&!options.fromQueue&&localState.outbox.length>=100)throw Error('Gönderim kuyruğunda 100 mesaj var. Önce kuyruğu tamamlayın.');
  const id = fixedId || crypto.randomUUID().replaceAll("-", ""),
    reply = Object.hasOwn(options,"replyId") ? options.replyId : (["reaction","vote"].includes(payload.type)?null:(state.reply?.room === room.id ? state.reply.id : null));
  if(reply&&!options.fromQueue&&state.reply?.id===reply&&state.reply.room===room.id){const q=quoteSnapshot(state.reply.quoteText);if(q)payload={...payload,replyQuote:q};}
  const visible = state.page === "chat" && state.room?.id === room.id;
  if (visible) {
    state.messages = upsertMessages(state.messages, [{
      id,
      room: room.id,
      sender: state.user.id,
      created: Date.now(),
      pending: true,
      queued: !!options.fromQueue,
      payload,
      reply,
    }]);
    renderMessages();
    if(!["reaction","vote"].includes(payload.type))$("#messages").scrollTop = $("#messages").scrollHeight;
    if(options.composerOrigin&&!fixedId&&payload.type==='text'){
      if(virtualMessages?.target===$("#messages"))virtualMessages.draw(true);
      animateComposerSend($("#messages"),id,options.composerOrigin);
    }
  }
  if(navigator.onLine===false && payload.type==='text' && !options.fromQueue){
    const item={id,room:room.id,payload,reply,silent:!!options.silent,created:Date.now()};if(!localState.outbox.some(m=>m.id===id))localState.outbox.push(item);
    try{await persistLocal(true)}catch(error){assertEpoch(epoch);localState.outbox=localState.outbox.filter(m=>m.id!==id);state.messages=state.messages.filter(m=>m.id!==id);if(visible&&state.room?.id===room.id&&state.page==='chat')renderMessages();throw Error('Mesaj cihazda saklanamadı. Taslağınızı koruyup tekrar deneyin.')}
    assertEpoch(epoch);if(state.room?.id===room.id&&state.page==='chat'){if(state.reply?.id===reply){state.reply=null;if($('#reply'))$('#reply').innerHTML='';}rememberChat();}if(visible&&state.room?.id===room.id&&state.page==='chat'){state.messages=upsertMessages(state.messages,[{...item,sender:state.user.id,pending:true,queued:true}]);renderMessages();}return id;
  }
  try {
    const packets=await envelopes(room,payload);assertEpoch(epoch);
    const record = await api("/rooms/" + room.id + "/messages", {
      method: "POST",
      ...(options.transferSignal?{signal:options.transferSignal}:{}),
      body: {
        id,
        envelopes: packets,
        recipient_pubs: Object.fromEntries([...room.members,...(room.audit?[room.audit]:[])].map(m=>[m.id,m.pub])),
        reply,
        uploads: payload.type === "file" ? [payload.upload] : [],
        ...(payload.viewOnce?{view_once:true}:{}),
        ...(options.silent?{silent:true}:{}),
      },
    });
    assertEpoch(epoch);state.cache.set(id, { ...record, payload });
    if (state.room?.id === room.id)
      state.messages = upsertMessages(state.messages, [{ ...record, payload, pending: false }]);
    if (state.page === "chat" && state.room?.id === room.id){renderMessages();if(payload.effect)playSendEffect(id,payload.effect,payload.effectVariant);}
    if (reply && state.reply?.id === reply && state.room?.id === room.id) {
      state.reply = null;
      if ($("#reply")) $("#reply").innerHTML = "";
      rememberChat();
    }
    if (state.page === "chat" && state.room?.id === room.id)
      await loadMessages().catch(err => console.warn("message-refresh", err.message));
    await refreshRooms().catch(err => console.warn("room-refresh", err.message));
    return id;
  } catch (err) {
    assertEpoch(epoch);
    if(err.code==='KEY_CHANGED'&&!options.keyRetry){await refreshRooms();assertEpoch(epoch);const fresh=state.rooms.find(r=>r.id===room.id);if(fresh)return send(payload,fresh,id,{...options,keyRetry:true,replyId:reply});}
    if(options.fromQueue){const queued=localState.outbox.find(m=>m.id===id);if(queued)state.messages=upsertMessages(state.messages,[{...queued,sender:state.user.id,pending:true,queued:true}]);}
    else state.messages = state.messages.filter((m) => m.id !== id);
    if (state.page === "chat" && state.room?.id === room.id) renderMessages();
    throw err;
  }
}
const quickReactions=["👍","❤️","🔥","🥰","👏","😁","😂"];
const reactionFlight=new Set();
function senderName(m){return m.sender===state.user?.id?"Siz":state.room?.members?.find(u=>u.id===m.sender)?.name||"Kişi";}
function autoDeleteLabel(seconds){return ({0:'Kapalı',3600:'1 saat',86400:'1 gün',604800:'7 gün',2592000:'30 gün'})[seconds]||'Kapalı';}
function showAutoDeleteSettings(){
 const room=state.room,epoch=access.epoch,route=state.routeVersion;
 if(room?.kind!=='direct'||room.ratchet_cutover_active||!Number.isInteger(room.auto_delete_seconds))return;
 dialog('Otomatik silme',`<p class="hint">Bu ayar iki taraf için geçerlidir. Yalnızca bundan sonra gönderilecek mesajlar, gönderildikleri andan itibaren seçilen süre sonunda silinir. Eski mesajların süreleri değişmez.</p><form id="auto-delete-form"><label for="auto-delete-seconds">Silme süresi</label><select id="auto-delete-seconds">${[0,3600,86400,604800,2592000].map(n=>`<option value="${n}" ${n===room.auto_delete_seconds?'selected':''}>${autoDeleteLabel(n)}</option>`).join('')}</select><button class="primary">Uygula</button><button type="button" class="secondary" data-action="close-dialog">Vazgeç</button></form>`);
 const form=$('#auto-delete-form');form.onsubmit=async e=>{e.preventDefault();const active=()=>access.valid(epoch)&&state.room?.id===room.id&&state.routeVersion===route&&form.isConnected;if(!active())return;const button=form.querySelector('.primary');button.disabled=true;try{const result=await api('/rooms/'+encodeURIComponent(room.id)+'/auto-delete',{method:'POST',body:{seconds:Number(form.querySelector('select').value)}});if(!active())return;state.room.auto_delete_seconds=result.seconds;modal.close();notice('Otomatik silme ayarı kaydedildi.',2000,'success');await refreshRooms();}catch(error){if(active()){button.disabled=false;notice(error.message,4000,'error');}}};
}
function hiddenMessage(m){return deletedInSession.has(m.id)||!!localState.preferences.hiddenMessages?.[m.room]?.includes(m.id);}
function eligibleMessage(id){const m=lookupRecord(id,state.messages);return m&&!hiddenMessage(m)&&!m.pending&&!['reaction','vote'].includes(m.payload.type)?m:undefined;}
function renderPinnedMessage(){const bar=$('#pinned-message');if(!bar||isLocked()||!state.room)return;const id=localState.preferences.pinnedMessages?.[state.room.id];const m=id&&messageIndex.byId.get(id);if(!id||hiddenMessage({id,room:state.room.id})){bar.hidden=true;bar.replaceChildren();return;}bar.hidden=false;const html=`<button type="button" class="fs-pin-jump" data-action="jump-reply" data-id="${escape(id)}">${icon('bookmark')}<span><strong>Sabitlenen mesaj</strong><small>${escape(m?preview(m.payload).slice(0,160):'Mesaja git')}</small></span></button>${button('unpin-message','close','Sabitlemeyi kaldır','type="button"')}`;if(bar._pinHtml!==html||!bar.firstElementChild){bar.innerHTML=html;bar._pinHtml=html;}}
let pinFlight=null;
async function toggleMessagePin(id){if(pinFlight||isLocked()||state.page!=="chat"||!state.room)return;const room=state.room.id,epoch=access.epoch,route=state.routeVersion,workspace=localState;const previous=workspace.preferences.pinnedMessages?.[room];const m=id&&eligibleMessage(id);if(id&&id!==previous&&(!m||m.callRecord||isViewOnce(m)))return;const pins=workspace.preferences.pinnedMessages??={};const next=previous===id||!id?null:id;if(next)pins[room]=next;else delete pins[room];const flight={};pinFlight=flight;try{await persistLocal(true);}catch(error){if(localState===workspace&&pins[room]===(next||undefined)){if(previous)pins[room]=previous;else delete pins[room];}throw error;}finally{if(pinFlight===flight)pinFlight=null;}if(access.valid(epoch)&&state.routeVersion===route&&state.room?.id===room&&localState===workspace){renderPinnedMessage();scheduleChatViewport();notice(next?'Mesaj bu cihazda sabitlendi.':'Sabitleme kaldırıldı.',2000,'success');}}
function validQuote(m,q){return m?.payload?.type==="text"&&typeof q==="string"&&q.length>0&&q.length<=512&&typeof m.payload.text==="string"&&m.payload.text.includes(q)?q:null;}
function renderReply(){const target=$("#reply"),m=state.reply;if(!target)return;target.innerHTML=m?`<div class="reply-banner tg-reply"><span class="composer-reply-symbol" aria-hidden="true">${icon("reply")}</span><button type="button" class="reply-quote" data-action="jump-reply" data-id="${escape(m.id)}"><strong>${escape(senderName(m))} kişisine yanıt</strong><span>${escape(m.quoteText||preview(m.payload).slice(0,160))}</span></button>${button("cancel-reply","close","Yanıtı iptal et")}</div>`:"";}
function beginReply(id){if(isLocked()||state.page!=="chat")return;const m=eligibleMessage(id);if(!m||m.callRecord)return;state.reply={...m,room:state.room.id};state.selected.clear();renderMessages();renderReply();rememberChat();$("#message-text")?.focus({preventScroll:true});}
function chooseQuote(id){
 const m=eligibleMessage(id);if(!m||m.payload.type!=="text")return;
 const room=state.room.id,route=state.routeVersion,epoch=access.epoch,text=m.payload.text;
 dialog("Alıntı seç",`<p class="hint">Metinde yanıtlamak istediğin bölümü seç. En fazla 512 karakter.</p><textarea id="quote-source" readonly rows="6">${escape(text)}</textarea><p id="quote-count" role="status">0 / 512</p><button type="button" class="primary" id="quote-confirm" disabled>Seçilen bölümü yanıtla</button>`);
 const source=$("#quote-source"),confirm=$("#quote-confirm"),active=()=>access.valid(epoch)&&state.room?.id===room&&state.routeVersion===route&&source.isConnected&&modal.open;
 const get=()=>selectedQuote(text,source.selectionStart,source.selectionEnd);
 const update=()=>{if(!active())return;$("#quote-count").textContent=`${source.selectionEnd-source.selectionStart} / 512`;confirm.disabled=!get();};
 source.addEventListener('select',update);source.addEventListener('keyup',update);source.addEventListener('pointerup',update);document.addEventListener('selectionchange',update,{signal:(()=>{const c=new AbortController();modal.addEventListener('close',()=>c.abort(),{once:true});return c.signal;})()});
 confirm.onclick=()=>{if(!active())return;const current=eligibleMessage(id);if(!current||current.payload.text!==text){modal.close();notice('Mesaj değişti. Alıntıyı yeniden seç.',3500,'info');return;}const q=get();if(!q)return;modal.close();beginReply(id);if(state.reply?.id===id){state.reply.quoteText=q;renderReply();rememberChat();}};
}
async function jumpReply(id){
 if(isLocked()||state.page!=="chat"||replyJumpFlight)return;
 const route=state.routeVersion,room=state.room?.id,list=$("#messages"),token={};replyJumpFlight=token;
 const original={anchor:virtualMessages?.anchor(),top:list?.scrollTop||0,room,route};
 const active=()=>!isLocked()&&state.page==="chat"&&state.routeVersion===route&&state.room?.id===room&&list?.isConnected;
 try{for(let i=0;i<=30;i++){
  if(!active())return;
  const record=state.messages.find(m=>m.id===id);if(record&&hiddenMessage(record))break;
  const row=virtualMessages?.rows.find(r=>r.id===id||r.albumIds?.includes(id));
  if(row&&virtualMessages.jump(row.id)){
   const target=list.querySelector(`[data-message="${CSS.escape(row.id)}"]`);
   if(target){const exact=row.id===id?target:target.querySelector(`[data-id="${CSS.escape(id)}"]`)||target;
    const bounds=list.getBoundingClientRect(),rect=exact.getBoundingClientRect();list.scrollTop+=rect.top-bounds.top-(bounds.height-rect.height)/2;
    const focus={row:row.id,id,until:Date.now()+3000};list._fsReplyFocus=focus;
    list.querySelectorAll('.found-message').forEach(n=>n.classList.remove('found-message'));
    exact.classList.add("found-message");setTimeout(()=>{if(list._fsReplyFocus!==focus)return;list._fsReplyFocus=null;list.querySelectorAll('.found-message').forEach(n=>n.classList.remove('found-message'));},3000);
   }
   if(!replyReturn)replyReturn=original;const back=$("#return-reply");if(back)back.hidden=false;return;
  }
  if(!state.hasOlder||i===30)break;
  const before=state.messages.find(m=>!m.callRecord&&!m.pending)?.id;await actions("older");
  if(!active())return;if(before===state.messages.find(m=>!m.callRecord&&!m.pending)?.id)break;
 }if(active())notice("Yanıtlanan mesaj silinmiş, gizlenmiş veya daha eski geçmişte olabilir.");}
 finally{if(replyJumpFlight===token)replyJumpFlight=null;}
}
function returnReplyPosition(){const save=replyReturn;replyReturn=null;const back=$("#return-reply");if(back)back.hidden=true;if(!save||isLocked()||state.room?.id!==save.room||state.routeVersion!==save.route)return;const list=$("#messages");if(!list)return;if(save.anchor?.id&&virtualMessages?.jump(save.anchor.id))list.scrollTop+=save.anchor.delta||0;else list.scrollTop=save.top;}
async function reactToMessage(id,emoji,{removeOnly=false}={}){
 if(isLocked()||state.page!=="chat"||!state.room||!eligibleMessage(id)||eligibleMessage(id).callRecord||!isSingleEmoji(emoji))return;
 const room=state.room,user=state.user.id,route=state.routeVersion,key=JSON.stringify([user,room.id,id]);
 if(reactionFlight.has(key))return;
 const current=messageIndex.reactions.get(id)?.get(user);if(removeOnly&&!sameReaction(current,emoji))return;
 const next=reactionValue(current,emoji);reactionFlight.add(key);
 try{
  await send({type:"reaction",target:id,text:next},room,null,{replyId:null});
  if(!isLocked()&&state.user?.id===user&&state.room?.id===room.id&&state.routeVersion===route&&state.page==="chat"&&eligibleMessage(id)&&!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches){
   const row=document.querySelector(`[data-message="${CSS.escape(id)}"]`);
   const chip=[...(row?.querySelectorAll('.reaction-chip.own-reaction')||[])].find(e=>sameReaction(e.dataset.emoji,next));
   if(chip){chip.animate?.([{transform:"scale(.72)"},{transform:"scale(1.22)"},{transform:"scale(1)"}],{duration:260});const spark=document.createElement('span');spark.className='reaction-spark';spark.textContent=next;spark.setAttribute('aria-hidden','true');chip.append(spark);setTimeout(()=>spark.remove(),550);}
  }
 }finally{reactionFlight.delete(key);}
}
function openReactionPicker(id){if(isLocked()||state.page!=="chat"||!eligibleMessage(id)||eligibleMessage(id).callRecord)return;state.reactionTarget={id,room:state.room.id,route:state.routeVersion,user:state.user.id};emojiPicker();}
function takeReactionTarget(){const target=state.reactionTarget;state.reactionTarget=null;if(!target||isLocked()||state.page!=="chat"||state.room?.id!==target.room||state.routeVersion!==target.route||state.user?.id!==target.user||!eligibleMessage(target.id))return null;return target.id;}
function showReactionDetails(id){
 if(isLocked()||state.page!=="chat"||!eligibleMessage(id)||eligibleMessage(id).callRecord)return;
 const entries=[...(messageIndex.reactions.get(id)||new Map())].filter(([,value])=>isSingleEmoji(value));
 const rows=entries.map(([user,value])=>{const name=user===state.user.id?'Siz':state.room.members?.find(m=>m.id===user)?.name||'Kişi';return `<div class="fs-reaction-person"><span aria-hidden="true">${escape(value)}</span><strong>${escape(name)}</strong>${user===state.user.id?'<small>Sizin tepkiniz</small>':''}</div>`;}).join('');
 dialog('Mesaj tepkileri',`<p class="hint">Yüklenmiş mesaj geçmişindeki ${entries.length} tepki</p><div class="fs-reaction-people">${rows||'<p>Henüz tepki yok.</p>'}</div>`);
}
function clearMessageMenu(){
 const session=messageMenuSession;messageMenuSession=null;session?.anchor?.classList.remove("context-target");session?.abort.abort();session?.observer?.disconnect();if(session?.frame)cancelAnimationFrame(session.frame);
 modal.classList.remove("message-context","context-ready");delete modal.dataset.menuSide;
 for(const key of ["--menu-x","--menu-y","--menu-width","--menu-height"])modal.style.removeProperty(key);
 if(session)modal.removeAttribute("aria-label");
}
function validMessageMenu(session){return !!session&&session===messageMenuSession&&modal.open&&modal.classList.contains("message-context")&&!isLocked()&&state.page==="chat"&&state.room?.id===session.room&&state.routeVersion===session.route&&state.user?.id===session.user&&!state.selected.size&&!!eligibleMessage(session.id);}
function positionMessageMenu(session){
 if(session!==messageMenuSession)return;
 if(!validMessageMenu(session)){if(modal.open&&modal.classList.contains("message-context"))modal.close();clearMessageMenu();return;}
 const list=$("#messages"),node=list?.querySelector(`[data-message="${CSS.escape(session.id)}"]`);
 if(!node){modal.close();clearMessageMenu();return;}
 if(session.anchor!==node){session.anchor?.classList.remove("context-target");session.anchor=node;node.classList.add("context-target");}
 const vv=window.visualViewport,viewport={left:vv?.offsetLeft||0,top:vv?.offsetTop||0,width:vv?.width||innerWidth,height:vv?.height||innerHeight};
 const row=node.getBoundingClientRect(),bounds=list.getBoundingClientRect(),top=Math.max(row.top,bounds.top,viewport.top),bottom=Math.min(row.bottom,bounds.bottom,viewport.top+viewport.height);
 if(bottom<=top||viewport.width<80||viewport.height<90){modal.close();clearMessageMenu();return;}
 const width=Math.min(312,viewport.width-16);modal.style.setProperty("--menu-width",width+"px");modal.style.setProperty("--menu-height",Math.max(0,viewport.height-16)+"px");
 const actions=modal.querySelector(".tg-context-actions"),reactions=modal.querySelector(".tg-context-reactions");
 const height=actions.scrollHeight+reactions.offsetHeight+20;
 const pos=messageMenuPlacement({left:row.left,right:row.right,top,bottom,own:node.classList.contains("mine")},viewport,width,height);
 for(const [key,value] of [["x",pos.x],["y",pos.y],["height",pos.height]])modal.style.setProperty("--menu-"+key,value+"px");
 modal.dataset.menuSide=pos.side;modal.classList.add("context-ready");
}
function messageMenu(id,rect){
 if(isLocked()||state.page!=="chat")return;const m=eligibleMessage(id),list=$("#messages");if(!m||!list||modal.open||state.selected.size)return;
 const active=messageIndex.reactions.get(id)?.get(state.user.id),ops=messageContextOps(m,state.user.id),symbols={İndir:"file",Yanıtla:"reply",Alıntıla:"quote",Kopyala:"copy",Düzenle:"edit",İlet:"forward",Paylaş:"share",Kaydet:"bookmark",Bilgi:"info",Sabitle:"bookmark",Seç:"check",Sil:"trash"};
 const receipt=contextReceipt(m,state.user.id,state.room?.members);
 const receiptTime=receipt?.at?new Date(receipt.at).toLocaleTimeString("tr-TR",{hour:"2-digit",minute:"2-digit"}):"";
 const receiptStrip=receipt?`<div class="fs-context-receipt ${receipt.read?"is-read":""}" role="status"><span aria-hidden="true">${receipt.mark}</span><span>${escape(receipt.label)}${receiptTime?` · ${escape(receiptTime)}`:""}</span></div>`:"";
 dialog("Mesaj işlemleri",`<div class="tg-reactions tg-context-reactions" role="group" aria-label="Emoji tepkileri" ${m.callRecord?'hidden':''}>${reactionChoices(quickReactions,active).map(e=>`<button type="button" class="${sameReaction(active,e)?"active":""}" data-action="context-react" data-id="${escape(id)}" data-emoji="${escape(e)}" aria-label="${escape(e)}" aria-pressed="${sameReaction(active,e)}">${e}</button>`).join("")}<button type="button" data-action="context-more" data-id="${escape(id)}" aria-label="Tüm ifadeler">⌄</button></div><div class="tg-menu tg-context-actions" role="group" aria-label="Mesaj işlemleri">${receiptStrip}${!m.callRecord&&[...(messageIndex.reactions.get(id)?.values()||[])].some(isSingleEmoji)?`<button type="button" data-action="context-reaction-details" data-id="${escape(id)}">${icon("smile")}<span>Tepkileri gör</span></button>`:""}${ops.map(op=>`<button type="button" data-action="context-op" data-id="${escape(id)}" data-op="${op}" class="${op==="Sil"?"danger":""}">${icon(symbols[op])}<span>${op==="Bilgi"?"Mesaj bilgileri":op==="Sabitle"&&typeof localState!=="undefined"&&localState.preferences.pinnedMessages?.[state.room.id]===id?"Sabitlemeyi kaldır":op}</span></button>`).join("")}</div>`);
 modal.classList.add("message-context");modal.setAttribute("aria-label","Mesaj işlemleri");
 const session={id,room:state.room?.id,route:state.routeVersion,user:state.user.id,abort:new AbortController(),frame:0,observer:null};messageMenuSession=session;
 const schedule=()=>{if(session!==messageMenuSession||session.frame)return;session.frame=requestAnimationFrame(()=>{session.frame=0;positionMessageMenu(session);});};
 const opts={signal:session.abort.signal,passive:true};window.addEventListener("resize",schedule,opts);window.visualViewport?.addEventListener("resize",schedule,opts);window.visualViewport?.addEventListener("scroll",schedule,opts);list.addEventListener("scroll",schedule,opts);
 session.observer=new window.MutationObserver(schedule);session.observer.observe(app,{childList:true,subtree:true});
 document.addEventListener("visibilitychange",()=>{if(document.hidden&&validMessageMenu(session))modal.close();},{signal:session.abort.signal});
 positionMessageMenu(session);if(validMessageMenu(session)){(modal.querySelector(".tg-context-reactions:not([hidden]) button")||modal.querySelector(".tg-context-actions button"))?.focus({preventScroll:true});}
}
function takeMessageMenu(el){const session=messageMenuSession,valid=validMessageMenu(session)&&el.isConnected&&modal.contains(el)&&el.dataset.id===session.id; if(valid){modal.close();clearMessageMenu();}else if(session){if(modal.open&&modal.classList.contains("message-context"))modal.close();clearMessageMenu();}return valid;}
function bindSelection() {
  const area=$("#messages");let start=null,longTimer=null,tapTimer=null,lastTap=null,suppressUntil=0,edgeFrame=0,reactionCooldown=null;
  const cancelTap=()=>{clearTimeout(tapTimer);lastTap=null;};
  const reset=()=>{clearTimeout(longTimer);if(edgeFrame)cancelAnimationFrame(edgeFrame);edgeFrame=0;const previous=start;start=null;if(previous?.touchTarget)previous.touchTarget.removeEventListener("touchmove",preventHeldScroll);if(previous?.node){previous.node.style.removeProperty("--swipe-x");previous.node.style.removeProperty("--reply-progress");previous.node.classList.remove("swiping","reply-armed");}area.classList.remove("selection-gesture");if(previous){try{if(area.hasPointerCapture(previous.pointer))area.releasePointerCapture(previous.pointer);}catch{}}};
  const preventHeldScroll=e=>{if(start&&(start.mode==="held"||start.mode==="range"||start.selected)&&e.cancelable)e.preventDefault();};
  const active=()=>!!start&&area.isConnected&&!isLocked()&&state.page==="chat"&&state.routeVersion===start.route&&state.room?.id===start.room;
  const targetId=e=>e.target.closest("[data-message]")?.dataset.message||e.target.closest('[data-action="toggle-selection"]')?.dataset.id||(state.selected.size?e.target.closest('.tg-message-line')?.querySelector('[data-message]')?.dataset.message:null);
  const toggle=id=>{if(isLocked()||!eligibleMessage(id))return;toggleSelectedGroup(id);renderMessages();};
  const selectionOrder=()=>((typeof virtualMessages!=="undefined"&&virtualMessages?.target===area)?virtualMessages.rows.map(r=>r.id):[...area.querySelectorAll('[data-message]')].map(n=>n.dataset.message)).filter(id=>eligibleMessage(id));
  const sameSelection=next=>next.size===state.selected.size&&[...next].every(x=>state.selected.has(x));
  const applyRange=id=>{if(!active()||!id)return;const order=selectionOrder();if(!order.includes(start.id)||!order.includes(id))return;const baseline=new Set([...start.baseline].filter(x=>eligibleMessage(x)));const next=selectionRange(order,baseline,start.id,id,start.adding);const lo=Math.min(order.indexOf(start.id),order.indexOf(id)),hi=Math.max(order.indexOf(start.id),order.indexOf(id));for(const rowId of order.slice(lo,hi+1)){for(const member of selectionGroup(rowId))start.adding?next.add(member):next.delete(member);}start.last=id;if(sameSelection(next))return;state.selected=next;renderMessages();};
  const abortRange=()=>{const restore=active()&&["held","range"].includes(start.mode)?new Set([...start.baseline].filter(x=>eligibleMessage(x))):null;reset();if(restore&&!sameSelection(restore)){state.selected=restore;renderMessages();}};
  const atY=y=>{const r=area.getBoundingClientRect();const pos=Math.max(r.top+1,Math.min(r.bottom-1,y));let nearest=null,distance=Infinity;for(const n of area.querySelectorAll('[data-message]')){if(!eligibleMessage(n.dataset.message))continue;const box=n.getBoundingClientRect();if(box.bottom<=r.top||box.top>=r.bottom)continue;const d=pos<box.top?box.top-pos:pos>box.bottom?pos-box.bottom:0;if(d<distance){distance=d;nearest=n.dataset.message;}}return nearest;};
  const edgeScroll=()=>{edgeFrame=0;if(!active()){reset();return;}if(start.mode!=="range")return;const r=area.getBoundingClientRect(),y=start.currentY;const step=selectionEdgeStep(y,r.top,r.bottom);if(!step)return;const old=area.scrollTop;area.scrollTop+=step;const moved=area.scrollTop!==old;
    // The next virtual window must exist before hit-testing the edge. Keep the
    // scroll-only path so unchanged windows do not reparse the full list.
    if(moved&&typeof virtualMessages!=="undefined"&&virtualMessages?.target===area)virtualMessages.draw(false,null,true);
    applyRange(atY(y));if(active()&&start.mode==="range"&&moved)edgeFrame=requestAnimationFrame(edgeScroll);};
  const rangeStart=e=>{start.mode="range";start.currentY=e.clientY;cancelTap();clearTimeout(longTimer);area.classList.add("selection-gesture");try{area.setPointerCapture(e.pointerId)}catch{}applyRange(atY(e.clientY)||start.id);};
  area.onpointerdown=e=>{if(!e.isPrimary){if(start){cancelTap();abortRange();suppressUntil=Date.now()+500;}return;}if(e.button!==0||isLocked())return;const id=targetId(e);if(!id||!eligibleMessage(id))return;const node=area.querySelector(`[data-message="${CSS.escape(id)}"]`);if(!node)return;const selected=state.selected.size>0;if(!selected&&e.target.closest("a,button,audio,video,iframe,input,textarea,select,[contenteditable=true]"))return;reset();suppressUntil=0;start={id,node,x:e.clientX,y:e.clientY,pointer:e.pointerId,mode:"wait",route:state.routeVersion,room:state.room?.id,armed:false,baseline:new Set(state.selected),adding:!state.selected.has(id),selected,touchTarget:e.pointerType==="touch"?e.target:null};start.touchTarget?.addEventListener("touchmove",preventHeldScroll,{passive:false});if(selected)return;longTimer=setTimeout(()=>{if(!active()||start.mode!=="wait")return;cancelTap();start.mode="held";area.classList.add("selection-gesture");applyRange(start.id);suppressUntil=Date.now()+900;try{area.setPointerCapture(start.pointer)}catch{}navigator.vibrate?.(12);},420);};
  area.onpointermove=e=>{if(!start||e.pointerId!==start.pointer)return;if(!active()){cancelTap();reset();suppressUntil=Date.now()+500;return;}const dx=e.clientX-start.x,dy=e.clientY-start.y;if(start.mode==="range"){start.currentY=e.clientY;applyRange(atY(e.clientY));if(!edgeFrame)edgeFrame=requestAnimationFrame(edgeScroll);return;}if((start.mode==="held"||start.selected&&start.mode==="wait")&&Math.abs(dy)>=9&&Math.abs(dy)>=Math.abs(dx)*.75){rangeStart(e);if(!edgeFrame)edgeFrame=requestAnimationFrame(edgeScroll);return;}if(start.mode==="held")return;const intent=gestureIntent(dx,dy);if(start.mode==="wait"&&intent!=="wait"){clearTimeout(longTimer);cancelTap();start.mode=intent==="swipe"&&!start.selected&&!eligibleMessage(start.id)?.callRecord?"swipe":"scroll";if(start.mode==="swipe"){try{area.setPointerCapture(e.pointerId)}catch{}}}if(start.mode==="swipe"){
    // Abort if the rendered row was replaced, the selection changed, or the gesture became vertical.
    if(!start.node.isConnected||state.selected.size||Math.abs(dy)>Math.max(28,Math.abs(dx)*.9)){reset();suppressUntil=Date.now()+500;return;}
    const feedback=replySwipeFeedback(dx,dy);start.node.classList.add("swiping");start.node.style.setProperty("--swipe-x",feedback.offset+"px");start.node.style.setProperty("--reply-progress",String(feedback.progress));start.node.classList.toggle("reply-armed",feedback.armed);if(feedback.armed&&!start.armed&&!start.haptic){start.haptic=true;navigator.vibrate?.(10);}start.armed=feedback.armed;
  }};
  // On touch browsers the first long press begins in scroll mode. Cancel only the
  // held/selection gesture's native scrolling; ordinary chat scrolling remains native.
  area.addEventListener("touchmove",preventHeldScroll,{passive:false});
  area.onpointerup=e=>{if(!start||e.pointerId!==start.pointer)return;const {mode,id,x,y,node}=start;if(active()&&mode==="range")applyRange(atY(e.clientY));const reply=active()&&mode==="swipe"&&node.isConnected&&!state.selected.size&&!!eligibleMessage(id)&&gestureIntent(e.clientX-x,e.clientY-y,true)==="reply";reset();if(mode!=="wait")suppressUntil=Date.now()+500;if(reply){e.preventDefault();beginReply(id);}};
  const cancelGesture=e=>{if(!start||e.pointerId!==start.pointer)return;cancelTap();suppressUntil=Date.now()+500;abortRange();};
  area.onpointercancel=cancelGesture;area.onlostpointercapture=e=>{if(e.target===area)cancelGesture(e);};
  area.addEventListener("touchstart",e=>{if(e.touches.length>1&&start){cancelTap();abortRange();suppressUntil=Date.now()+500;}},{passive:true});
  area.oncontextmenu=e=>{const id=targetId(e);if(!id||!eligibleMessage(id))return;e.preventDefault();if(Date.now()<suppressUntil||start?.mode==="range"||start?.mode==="held")return;cancelTap();reset();toggle(id);suppressUntil=Date.now()+500;};
  area.addEventListener("click",e=>{
    const id=targetId(e);if(!id){cancelTap();return;}if(Date.now()<suppressUntil){e.preventDefault();e.stopPropagation();suppressUntil=0;cancelTap();return;}
    if(isLocked()||!eligibleMessage(id)){cancelTap();return;}const node=area.querySelector(`[data-message="${CSS.escape(id)}"]`);if(!node){cancelTap();return;}
    if(state.selected.size){e.preventDefault();e.stopPropagation();cancelTap();toggle(id);return;}
    if(e.target.closest("a,button,audio,video,iframe,input,textarea,select,[contenteditable=true]")){cancelTap();return;}
    e.preventDefault();e.stopPropagation();
    const tap={id,at:Date.now(),x:e.clientX,y:e.clientY,room:state.room?.id,route:state.routeVersion,user:state.user?.id};
    if(reactionCooldown&&isReactionDoubleTap(reactionCooldown,tap)){cancelTap();return;}
    if(!eligibleMessage(id)?.callRecord&&isReactionDoubleTap(lastTap,tap)){cancelTap();reactionCooldown=tap;reactToMessage(id,"👍").catch(error=>notice(error.message,4000,"error"));return;}
    cancelTap();lastTap=tap;const glyph=node.classList.contains("emoji")&&!!e.target.closest(".animated-emoji,.emoji-fallback");
    tapTimer=setTimeout(()=>{lastTap=null;if(!area.isConnected||area.ownerDocument.querySelector("dialog[open]")||isLocked()||state.page!=="chat"||state.routeVersion!==tap.route||state.room?.id!==tap.room||state.user?.id!==tap.user||state.selected.size||!eligibleMessage(id))return;const fresh=area.querySelector(`[data-message="${CSS.escape(id)}"]`);if(!fresh)return;if(glyph)emojiEffect(fresh);else messageMenu(id,fresh.getBoundingClientRect());},280);
  },true);
  area.onkeydown=e=>{if(e.key==="Escape"&&state.selected.size){e.preventDefault();cancelTap();reset();state.selected.clear();renderMessages();return;}if(!["Enter"," "].includes(e.key)||e.target.closest("button,a"))return;const node=e.target.closest("[data-message]");if(!node||!eligibleMessage(node.dataset.message))return;e.preventDefault();if(state.selected.size)toggle(node.dataset.message);else messageMenu(node.dataset.message,node.getBoundingClientRect());};
}
function selectionGroup(id){const row=typeof virtualMessages!=="undefined"&&virtualMessages?.rows[virtualMessages.indices.get(id)];const members=row?.callIds?.length?row.callIds:row?.albumIds?.length?row.albumIds:[id];return members.filter(x=>eligibleMessage(x));}
function toggleSelectedGroup(id){const members=selectionGroup(id),adding=members.some(member=>!state.selected.has(member));for(const member of members)adding?state.selected.add(member):state.selected.delete(member);}
function selectionBar() {
  const s=$("#selection"),list=$("#messages"),bottom=$("#selection-bottom");if(!s||!list)return;
  const messages=state.messages.filter(m=>state.selected.has(m.id)&&eligibleMessage(m.id)),active=messages.length>0;
  list.classList.toggle("selection-active",active);s.closest(".fs-chat")?.classList.toggle("selection-mode",active);
  if(active&&$("#composer-emoji-panel:not([hidden])"))closeComposerEmoji();
  if(!active){s.innerHTML="";if(bottom)bottom.innerHTML="";delete s.dataset.collapsed;return;}
  const header=s.closest(".fs-chat")?.querySelector(".chat-head");s.style.top=`${header?.offsetTop||0}px`;
  const ops=selectionOps(messages,state.user?.id,true),expanded=s.dataset.collapsed==="1",symbols={İndir:"file",Yanıtla:"reply",Kopyala:"copy",Düzenle:"edit",İlet:"forward",Paylaş:"share",Kaydet:"bookmark",Bilgi:"info",Sil:"trash",Tepki:"smile"};
  const action=(op,label=false)=>`<button type="button" data-action="selection" data-op="${op}" aria-label="${op==='Bilgi'?'Mesaj bilgileri':op}" class="${op==='Sil'?'danger':''}">${icon(symbols[op])}${label?`<span>${op}</span>`:''}</button>`;
  const top=ops.filter(([op])=>["Kopyala","Düzenle","Sil"].includes(op));
  const extra=ops.filter(([op])=>!["Kopyala","Düzenle","Sil","İlet","Yanıtla"].includes(op));
  const lower=ops.filter(([op])=>["Yanıtla","İlet"].includes(op));
  const currentReaction=messages.length===1&&typeof messageIndex!=="undefined"?messageIndex.reactions.get(messages[0].id)?.get(state.user?.id):null;
  s.innerHTML=`<div class="fs-select-top"><button type="button" data-action="selection" data-op="Vazgeç" aria-label="Seçimi kapat">✕</button><strong aria-live="polite">${messages.length} Seçili</strong>${top.map(([op])=>action(op)).join("")}<button type="button" data-action="selection-menu" aria-expanded="${expanded}" aria-controls="selection-menu-actions" aria-label="Diğer mesaj işlemleri">${icon("more")}</button></div><div id="selection-menu-actions" class="tg-menu fs-select-extra" ${expanded?"":"hidden"}>${messages.length===1&&!messages[0].callRecord?`<div class="tg-reactions">${reactionChoices(quickReactions,currentReaction).map(e=>`<button type="button" data-action="selection-react" data-id="${escape(messages[0].id)}" data-emoji="${escape(e)}" aria-label="${escape(e)}" aria-pressed="${sameReaction(currentReaction,e)}">${e}</button>`).join("")}</div>`:""}${extra.map(([op])=>action(op,true)).join("")}</div>`;
  if(bottom)bottom.innerHTML=lower.length?`<div class="fs-select-bottom">${lower.map(([op])=>action(op,true)).join("")}</div>`:"";
}
async function showMessageDetails(id){
 const m=eligibleMessage(id),room=state.room,epoch=access.epoch,route=state.routeVersion;if(!m||!room||!messageHasDetails(m,state.user.id))return;
 const own=m.sender===state.user.id,peer=room.members.find(p=>p.id===m.sender)||(room.kind==='group'&&m.sender_pub?{id:m.sender,pub:m.sender_pub}:null);
 const timestamp=t=>Number.isFinite(t)?new Date(t).toLocaleString('tr-TR'):'—';
 const rows=mergeReceipts(m.receipts_v2);
 const info=own?`<p>Sunucu kabulü: ${escape(timestamp(m.created))}</p>${room.members.filter(p=>p.id!==state.user.id).map(p=>{const r=rows.find(x=>x.user===p.id);return `<section class="receipt-detail"><strong>${escape(p.name)}</strong><p>Teslim: ${r?escape(timestamp(r.delivered)):'Doğrulanmadı'}</p><p>Okuma: ${r?.read_at?escape(timestamp(r.read_at)):(m.read_by||[]).includes(p.id)?'Eski kayıt; okuma doğrulanmadı':'Doğrulanmadı'}</p></section>`}).join('')}<p class="hint">Teslim, alıcı uygulamasının mesajı açabildiğini; okuma, mesajın alıcı ekranında gösterildiğini bildirir. Medyanın indirildiği veya insanın metni okuduğu anlamına gelmez. İlk kayıtlar gösterilir.</p>`:'';
 dialog('Mesaj bilgileri',`${info}${m.edited?`<p>Son değişiklik: ${escape(timestamp(m.edited))}</p>`:''}<div id="message-history-panel" data-message-history="${escape(id)}">${m.history_count?'<p>Şifreli geçmiş yükleniyor…</p>':m.edited?'<p>Bu değişiklik için kaydedilmiş eski sürüm yok.</p>':''}</div>`);
 const panel=$('#message-history-panel');if(!m.history_count)return;
 const active=()=>access.valid(epoch)&&state.routeVersion===route&&state.room?.id===room.id&&modal.open&&panel.isConnected&&!!eligibleMessage(id);
 try{
  const history=await api('/messages/'+encodeURIComponent(id)+'/history');if(!active())return;
  const entries=[];for(const revision of history){
   let html=escape('Bu cihazda eski sürümün anahtarı bulunamadı.');
   try{const payload=await openMessagePayload(room,peer,revision.envelope,revision.sender_pub);if(payload.type==='text')html=linkText(payload.text);}catch{}
   if(!active())return;entries.push(`<section class="receipt-detail"><strong>${escape(timestamp(revision.revision))}</strong><p class="revision-text">${html}</p></section>`);
  }
  if(active())panel.innerHTML=`<h3>Düzenleme geçmişi</h3>${entries.join('')||'<p>Önceki sürüm bulunamadı.</p>'}`;
 }catch(error){if(active())panel.textContent=error.message;}
}
async function selection(op) {
  const messages=state.messages.filter(m=>state.selected.has(m.id)&&eligibleMessage(m.id));
  if(messages.some(m=>m.callRecord)&&!["Sil","Kopyala","Vazgeç"].includes(op))return;
  if(messages.some(isViewOnce)&&["İlet","Paylaş","Kaydet"].includes(op))throw Error("Tek görüntülemelik medya iletilemez, paylaşılamaz veya kaydedilemez.");
  if(op==="Bilgi"){if(messages.length===1&&messageHasDetails(messages[0],state.user.id)){state.selected.clear();renderMessages();await showMessageDetails(messages[0].id);}return;}
  if(op==="Yanıtla"){if(messages.length===1)beginReply(messages[0].id);return;}
  if(op==="Tepki"){if(messages.length===1){const id=messages[0].id;state.selected.clear();renderMessages();openReactionPicker(id);}return;}
  if(op==="Kopyala"){if(!messages.length)return;await navigator.clipboard.writeText(messages.map(m=>preview(m.payload)).join("\n"));notice("Kopyalandı.");}
  if (op === "Düzenle") {
    const m = messages[0];
    if (
      messages.length !== 1 ||
      m.sender !== state.user.id ||
      m.payload.type !== "text"
    )
      throw Error("Düzenlemek için kendi metin mesajını seç.");
    dialog(
      "Mesajı düzenle",
      `<form id="edit-message"><div class="edit-message-context"><span aria-hidden="true">${icon("edit")}</span><div><strong>Mesajı düzenle</strong><small>${escape(m.payload.text.slice(0,160))}</small></div></div><p class="hint">Önceki metin şifreli düzenleme geçmişinde sohbet katılımcılarına görünür. Mesaj herkesten silinince geçmişi de silinir.</p><textarea name="text" maxlength="4000" required>${escape(m.payload.text)}</textarea><button type="submit" class="primary edit-confirm">${icon("check")} Kaydet</button></form>`,
    );
    const room=state.room,epoch=access.epoch,route=state.routeVersion;const form=$("#edit-message"),editInput=form.querySelector("textarea"),saveButton=form.querySelector("button[type=submit]");
    const active=()=>access.valid(epoch)&&state.room?.id===room.id&&state.routeVersion===route&&form.isConnected&&modal.open;
    form.onsubmit = async (e) => {
      e.preventDefault();
      try {
        const edited=textPayload(editInput);
        if (!edited.text||!active()||saveButton.disabled) return;
        if(edited.text===m.payload.text){modal.close();return;}
        saveButton.disabled=true;const {formats:oldFormats,...prior}=m.payload;const next={...prior,...edited};validatePayload(next);
        const encrypted=await envelopes(room,next);if(!active())return;
        await api("/messages/" + m.id, {
          method: "PATCH",
          body: {
            envelopes: encrypted,
            save_revision: true, expected_edited: m.edited??null,
            recipient_pubs: Object.fromEntries([...room.members,...(room.audit?[room.audit]:[])].map(peer=>[peer.id,peer.pub])),
          },
        });
        if(!active())return;state.cache.delete(m.id);
        modal.close();
        await loadMessages();
        notice("Mesaj düzenlendi.",2000,"success");
      } catch (err) {
        if(active())notice(err.message, 4000, "error");
      } finally {if(active())saveButton.disabled=false;}
    };
  }
  if (op === "Sil") {
    if(!messages.length)return;
    const room=state.room,epoch=access.epoch,route=state.routeVersion;
    const hasCalls=messages.some(m=>m.callRecord),everyone=!hasCalls&&messages.every(m=>m.sender===state.user.id||(room.kind==="direct"&&state.directDelete));
    const serverSelf=hasCalls?state.batchDelete&&state.callHistoryHide:state.batchDelete||Number.isInteger(room.auto_delete_seconds);
    dialog("Mesajları sil",`<p class="fs-delete-count">${messages.length} öğe seçildi.</p><p class="hint">${hasCalls?(serverSelf?"Arama kayıtları yalnızca kendi hesabından kaldırılır; karşı tarafta kalır.":"Arama kayıtları ve seçili mesajlar yalnızca bu cihazda gizlenir."):Number.isInteger(room.auto_delete_seconds)?"Kendimden sil: kendi cihazlarından kaldırır; karşı tarafta kalır. Herkesten sil: sohbetten kaldırır.":"Bu sunucu kişisel silme için yalnızca cihazda gizlemeyi destekliyor."}</p><div class="dialog-action-stack"><button class="secondary" id="delete-local">${serverSelf?"Kendimden sil":"Yalnızca bu cihazda gizle"}</button>${everyone?'<button class="primary danger" id="confirm-delete">Herkesten sil</button>':hasCalls?'':'<p class="hint">Karşı tarafın mesajını herkesten silmek için sunucu desteği gerekir.</p>'}<button class="secondary" data-action="close-dialog">Vazgeç</button></div>`);
    const active=()=>access.valid(epoch)&&state.room?.id===room.id&&state.routeVersion===route&&state.page==="chat";
    const ids=messages.map(m=>m.id);
    const originalDeleteButton=$("#delete-local");let deleting=false;
    const confirmationActive=()=>active()&&originalDeleteButton.isConnected&&modal.open&&modal.contains(originalDeleteButton);
    const finish=done=>{if(!active())return;if(originalDeleteButton.isConnected&&modal.open)modal.close();removeDeletedBatch(done);for(const id of done)state.selected.delete(id);renderMessages();};
    const perform=async scope=>{
      if(!confirmationActive()||deleting)return;deleting=true;const btn=originalDeleteButton,all=$("#confirm-delete");btn.disabled=true;if(all)all.disabled=true;
      const done=[];
      try{
        if(state.batchDelete){
          if(ids.length>1000)throw Error("Bir işlemde en fazla 1000 mesaj silebilirsiniz.");
          const messageIds=messages.filter(m=>!m.callRecord).map(m=>m.id),callIds=messages.filter(m=>m.callRecord).map(m=>m.id.slice(5));
          const result=await api("/rooms/"+encodeURIComponent(room.id)+"/messages/batch-delete",{method:"POST",body:{ids:messageIds,scope,...(callIds.length?{call_ids:callIds}:{})}});
          if(!result?.ok||!Array.isArray(result.ids)||result.ids.length!==messageIds.length||!messageIds.every(id=>result.ids.includes(id))||(callIds.length&&(!Array.isArray(result.call_ids)||result.call_ids.length!==callIds.length||!callIds.every(id=>result.call_ids.includes(id)))))throw Error("Silme işlemi doğrulanamadı.");
          done.push(...ids);
        }else if(scope==="everyone"){
          for(const id of ids){if(!active())return;await api("/messages/"+encodeURIComponent(id),{method:"DELETE"});done.push(id);}
        }else{
          for(let i=0;i<ids.length;i+=200){if(!active())return;const part=ids.slice(i,i+200);await api("/rooms/"+encodeURIComponent(room.id)+"/messages/hide",{method:"POST",body:{ids:part}});done.push(...part);}
        }
        if(active()){finish(done);try{await refreshRooms();if(active())await loadMessages();}catch(error){if(active())notice("Silme tamamlandı; sohbet henüz yenilenemedi.",4000,"info");}}
      }catch(error){if(active()){if(done.length)finish(done);else{btn.disabled=false;if(all)all.disabled=false;}notice(`${done.length}/${messages.length} silindi. ${error.message}`,4000,"error");}}finally{deleting=false;}
    };
    $("#delete-local").onclick=async()=>{if(!confirmationActive()||deleting)return;if(serverSelf)return perform("self");deleting=true;const btn=originalDeleteButton;btn.disabled=true;const all=$("#confirm-delete");if(all)all.disabled=true;const workspace=localState,old=workspace.preferences.hiddenMessages?.[room.id]||[];workspace.preferences.hiddenMessages??={};const next=[...new Set([...old,...ids])];workspace.preferences.hiddenMessages[room.id]=next;try{await persistLocal(true);}catch(error){if(localState===workspace&&workspace.preferences.hiddenMessages[room.id]===next)workspace.preferences.hiddenMessages[room.id]=old;if(active()){if(confirmationActive()){btn.disabled=false;if(all)all.disabled=false;}notice("Silme kaydedilemedi.",4000,"error");}return;}finally{deleting=false;}if(!active())return;if(confirmationActive())modal.close();animateDeletedRows(ids);for(const id of ids)state.selected.delete(id);if(state.reply&&ids.includes(state.reply.id)){state.reply=null;renderReply();rememberChat();}renderMessages();};
    const confirm=$("#confirm-delete");if(confirm)confirm.onclick=()=>perform("everyone");
    return;
  }
  if (op === "Kaydet")
    for (const m of messages)
      await api("/saved", { method: "POST", body: { id: m.id } });
  if (op === "Paylaş") {
    const files = messages.filter((m) => m.payload.type === "file");
    if (files.length) {
      for (const m of files) {
        const r = await fetch(apiRoot + "/api/uploads/" + m.payload.upload, {
          headers: { Authorization: "Bearer " + state.token },
        });
        if (!r.ok) throw Error("Paylaşılacak dosya indirilemedi.");
        const blob = await decryptFile(await r.arrayBuffer(), m.payload);
        if (window.FSNative?.beginFile)
          await nativeFile(blob, m.payload.name, m.payload.mime, "share");
        else {
          const file = new File([blob], m.payload.name, {
            type: m.payload.mime,
          });
          if (navigator.canShare?.({ files: [file] }))
            await navigator.share({ files: [file] });
          else await download(m, true);
        }
      }
      state.selected.clear();
      renderMessages();
      return;
    }
    const text = messages.map((m) => preview(m.payload)).join("\n");
    if (navigator.share) await navigator.share({ text });
    else {
      await navigator.clipboard.writeText(text);
      notice("Panoya kopyalandı.");
    }
  }
  if (op === "İlet") {
    dialog(
      "Sohbete ilet",
      state.rooms
        .map(
          (r) =>
            `<button class="row forward-target" data-target="${r.id}">${escape(name(r))}</button>`,
        )
        .join(""),
    );
    for (const b of modal.querySelectorAll(".forward-target"))
      b.onclick = async () => {
        const target = state.rooms.find((r) => r.id === b.dataset.target);
        for (const m of messages) {
          if (m.payload.type === "file") {
            const response = await fetch(
              apiRoot + "/api/uploads/" + m.payload.upload,
              { headers: { Authorization: "Bearer " + state.token } },
            );
            if (!response.ok) throw Error("İletilecek dosya indirilemedi.");
            const blob = await decryptFile(
              await response.arrayBuffer(),
              m.payload,
            );
            await uploadFile(
              new File([blob], m.payload.name, { type: m.payload.mime }),
              target,
            );
          } else {const {replyQuote,formats,...forwardPayload}=m.payload;await send({...forwardPayload,forwarded:true},target,null,{replyId:null});}
        }
        modal.close();
      };
  }
  state.selected.clear();
  renderMessages();
}
let recentRequest=null;
function attach() {
  if(state.page!=="chat"||!state.room)return;
  recentRequest=null;recentPhotos=[];
  dialog("Paylaş",attachmentMarkup(icon,!!window.FSNative?.recentPhotosFor));
}
function attachmentForm(id,build){
  const ctx=attachmentContext(state,access),form=$(id);let busy=false;
  form.onsubmit=async e=>{e.preventDefault();if(busy||!ctx.valid()||!modal.open||!form.isConnected)return;
    const button=form.querySelector('button[type="submit"],button.primary');
    try{const payload=build(new FormData(form));busy=true;button.disabled=true;await send(payload,ctx.room);if(ctx.valid()&&form.isConnected&&modal.open)modal.close();}
    catch(err){if(ctx.valid()&&form.isConnected)notice(err.message,4000,'error');}
    finally{busy=false;if(form.isConnected)button.disabled=false;}
  };
}
async function shareContactDialog(){
 const ctx=attachmentContext(state,access),panel=modal.querySelector('.attachment-panel');
 if(!ctx.valid()||!panel||!modal.open)return;
 const contacts=await api('/contacts');if(!ctx.valid()||!panel.isConnected||!modal.open)return;
 const list=contacts.filter(p=>!p.deleted&&p.nick&&p.name);
 dialog('Kişi paylaş',`<div class="attachment-contact"><label for="attachment-contact-search">Kişi ara</label><input id="attachment-contact-search" type="search" placeholder="Ad veya kullanıcı adı"><div id="attachment-contacts">${list.map((p,i)=>`<button type="button" class="attachment-contact-row" data-contact-index="${i}"><span>${icon('user')}</span><div><strong>${escape(p.name)}</strong><small>@${escape(p.nick)}</small></div></button>`).join('')||'<p class="hint">Paylaşılacak kişi bulunamadı.</p>'}</div><p class="hint">Telefon numarası paylaşılmaz.</p></div>`);
 const search=$('#attachment-contact-search'),box=$('#attachment-contacts');let busy=false;
 search.oninput=()=>{const q=search.value.trim().toLocaleLowerCase('tr-TR');for(const b of box.querySelectorAll('button')){const p=list[Number(b.dataset.contactIndex)];b.hidden=!`${p.name} ${p.nick}`.toLocaleLowerCase('tr-TR').includes(q);}};
 box.onclick=async e=>{const b=e.target.closest('[data-contact-index]');if(!b||busy||!ctx.valid()||!box.isConnected||!modal.open)return;const p=list[Number(b.dataset.contactIndex)];if(!p)return;busy=true;b.disabled=true;try{await send({type:'contact',text:p.name+' · @'+p.nick,nick:p.nick},ctx.room);if(ctx.valid()&&box.isConnected&&modal.open)modal.close();}catch(err){if(ctx.valid()&&box.isConnected)notice(err.message,4000,'error');}finally{busy=false;b.disabled=false;}};
}

// Keep queued media bound to the authenticated room. No auto-send on selection.
let composerFiles=[],composerRoom=null,composerGesture=null,composerMediaBusy=false,composerEditor=null;
function resizeComposer(input){if(!input?.isConnected)return;const max=parseFloat(window.getComputedStyle(input).maxHeight)||120;input.style.height='auto';input.style.height=Math.min(max,input.scrollHeight)+'px';if(typeof scheduleChatViewport==='function')scheduleChatViewport();}
function closeComposerEmoji(){const panel=$('#composer-emoji-panel');if(!panel||panel.hidden)return false;const caret=panel._caret,input=$('#message-text');panel.hidden=true;panel.replaceChildren();delete panel._caret;if(caret&&input)input.setSelectionRange(caret.start,caret.end);const b=$('#compose [data-action=emoji]');if(b){b.innerHTML=icon('smile');b.setAttribute('aria-label','İfade seç');b.setAttribute('title','İfade seç');b.setAttribute('aria-expanded','false');}scheduleChatViewport();return true;}
function clearComposer(){closeComposerEmoji();composerEditor?.();composerEditor=null;composerGesture?.reset();composerGesture=null;composerFiles=[];composerRoom=null;composerMediaBusy=false;}
function currentComposerMode(){return composerMode({text:$('#message-text')?.value||'',files:composerFiles.length,recording:!!state.recording,active:!!voiceController?.session,busy:composerMediaBusy||voiceSending||uploadBusy});}
function syncComposer(){const b=$('#composer-action');if(!b)return;const m=currentComposerMode();if(b.dataset.mode!==m){b.dataset.mode=m;b.innerHTML=icon(m==='send'?'send':'mic');b.setAttribute('aria-label',m==='send'?'Gönder':m==='recording'?'Ses kaydediliyor':m==='busy'?'Gönderiliyor':'Basılı tutarak ses kaydet');b.classList.toggle('recording',m==='recording');b.classList.toggle('send',m==='send');}const form=b.closest('form');if(form){form.dataset.mode=m;const box=form.querySelector('.box');if(box)box.inert=m==='recording';}if(m==='recording')closeComposerEmoji();composerGesture?.changed();}
function renderComposerFiles(){const box=$('#composer-files');if(box){box.hidden=!composerFiles.length;box.replaceChildren();composerFiles.forEach((item,i)=>{const row=document.createElement('div'),name=document.createElement('span'),remove=document.createElement('button');name.textContent=item.file.name+(item.status?' · '+item.status:' · Sırada');remove.type='button';remove.textContent='×';remove.setAttribute('aria-label',item.file.name+' kaldır');remove.disabled=composerMediaBusy||!!item.pendingId;remove.onclick=()=>{if(composerMediaBusy||item.pendingId)return;composerFiles.splice(i,1);renderComposerFiles();};row.append(name);if(mediaKind(item.file)){const edit=document.createElement("button");edit.type="button";edit.className="composer-edit-media";edit.textContent="Düzenle";edit.setAttribute("aria-label",item.file.name+" düzenle");edit.disabled=composerMediaBusy||!!item.pendingId||!!item.oncePending;edit.onclick=()=>openComposerEditor(item);row.append(edit);if(canSendViewOnce(state.room,state.viewOnce,item.file)){const once=document.createElement('button');once.type='button';once.className='composer-once';once.textContent=item.viewOnce?'1 · Açık':'1 · Bir kez';once.setAttribute('aria-pressed',String(!!item.viewOnce));once.setAttribute('aria-label','Tek görüntülemelik medya');once.disabled=composerMediaBusy||!!item.pendingId||!!item.oncePending||composerFiles.length!==1;once.onclick=()=>{item.viewOnce=!item.viewOnce;renderComposerFiles();};row.append(once);}}row.append(remove);box.append(row);});}syncComposer();}
function openComposerEditor(item){
 const room=state.room,epoch=access.epoch,route=state.routeVersion;const valid=()=>access.valid(epoch)&&state.page==='chat'&&state.room?.id===room?.id&&state.routeVersion===route&&composerFiles.includes(item)&&!composerMediaBusy&&!item.pendingId&&!item.oncePending;
 if(!valid()||!mediaKind(item.file))return;composerEditor?.();dialog(mediaKind(item.file)==='image'?'Fotoğrafı düzenle':'Videoyu düzenle','<div class="media-editor"></div>');const host=modal.querySelector('.media-editor');const alive=()=>valid()&&modal.open&&host.isConnected;const close=()=>{if(modal.open&&host.isConnected)modal.close();};
 const dispose=mountMediaEditor(host,item.file,{valid:alive,onApply:file=>{if(alive()){item.file=file;if(!viewOnceMime(file.type))item.viewOnce=false;renderComposerFiles();close();}},onCancel:close});composerEditor=dispose;modal.addEventListener('close',()=>{if(!modal.open||!host.isConnected){dispose();if(composerEditor===dispose)composerEditor=null;}},{once:true});
}
function stageFiles(files,room,epoch){if(!room||!access.valid(epoch)||state.page!=='chat'||state.room?.id!==room.id)return;if(composerRoom!==room.id||composerMediaBusy)throw Error('Gönderim sürerken yeni dosya eklenemez.');const next=[...files];if(next.some(f=>!f.size||f.size>50*1048576))throw Error('Dosya boş veya 50 MB sınırını aşıyor.');if(composerFiles.length+next.length>20)throw Error('Bir seferde en fazla 20 dosya seçebilirsiniz.');composerFiles.push(...next.map(file=>({file,pendingId:null})));renderComposerFiles();}
function bindComposer(room){
 composerGesture?.reset();composerRoom=room.id;
 const b=$('#composer-action'),form=$('#compose');
 const input=$('#message-text'),emojiButton=form.querySelector('[data-action=emoji]');if(emojiButton){emojiButton.setAttribute('aria-expanded','false');emojiButton.setAttribute('aria-controls','composer-emoji-panel');emojiButton.addEventListener('pointerdown',e=>{if(e.isPrimary&&e.button===0)e.preventDefault();});}input.addEventListener('focus',()=>closeComposerEmoji());
 let sendHold=null,sendPointer=null,sendOrigin=null,suppressSend=false;const clearHold=()=>{clearTimeout(sendHold);sendHold=null;sendPointer=null;};
 const epoch=access.epoch,valid=()=>access.valid(epoch)&&state.page==='chat'&&state.room?.id===room.id&&b.isConnected;
 composerGesture=createMicGesture({mode:()=>valid()?currentComposerMode():'busy',start:e=>{if(valid())beginRecording(e).catch(err=>{if(valid())notice(err.message,4000,'error');});},finish:endRecording,cancel:discardVoice});
 const gesture=composerGesture;
 b.onpointerdown=e=>{suppressSend=false;if(valid()&&currentComposerMode()==='send'&&document.activeElement===$('#message-text')&&e.isPrimary&&e.button===0)e.preventDefault();if(valid()&&e.isPrimary&&e.button===0&&currentComposerMode()==='send'&&$('#message-text')?.value.trim()&&!composerFiles.length&&!state.recording){sendPointer=e.pointerId;sendOrigin={x:e.clientX,y:e.clientY};sendHold=setTimeout(()=>{if(valid()&&sendPointer===e.pointerId&&currentComposerMode()==='send'){suppressSend=true;openSendOptions(room,epoch);}},450);}if(gesture.down(e)){e.preventDefault();b.setPointerCapture?.(e.pointerId);}};
 b.onpointermove=e=>{if(sendPointer===e.pointerId&&Math.hypot(e.clientX-sendOrigin.x,e.clientY-sendOrigin.y)>12){clearHold();suppressSend=true;}if(gesture.isRecording()&&state.voicePressed&&!voiceLocked&&voiceStartX-e.clientX>70){discardVoice();return;}if(gesture.isRecording()&&state.voicePressed&&voiceStartY-e.clientY>55){voiceLocked=true;const session=voiceController?.session;if(session)voiceStatus({phase:'recording',elapsed:voiceController.elapsed(session),wave:session.wave,meterAvailable:!!session.analyser});}};
 b.onpointerleave=()=>{if(sendPointer!==null){clearHold();suppressSend=true;}};
 b.onpointerup=e=>{clearHold();gesture.up(e);};b.onpointercancel=e=>{if(sendPointer!==null)suppressSend=true;clearHold();gesture.abort(e);};b.onlostpointercapture=e=>{clearHold();gesture.up(e);};
 b.oncontextmenu=e=>{e.preventDefault();};
 b.onkeydown=e=>{if(e.key==='F10'&&e.shiftKey&&valid()&&currentComposerMode()==='send'){e.preventDefault();openSendOptions(room,epoch);}};
 b.onclick=e=>{e.preventDefault();if(suppressSend){suppressSend=false;return;}if(valid()&&gesture.click())submitComposer(room,epoch).catch(err=>{if(valid())notice(err.message,4000,'error');});};
 form.onsubmit=e=>{e.preventDefault();if(valid()&&currentComposerMode()==='send'){gesture.sent();submitComposer(room,epoch).catch(err=>{if(valid())notice(err.message,4000,'error');});}};
 renderComposerFiles();syncComposer();
}
async function submitComposer(room,epoch,options={}){
 const input=$('#message-text'),valid=()=>access.valid(epoch)&&state.page==='chat'&&state.room?.id===room.id&&input?.isConnected;
 if(!valid()||composerMediaBusy||currentComposerMode()!=='send')return;
 typing.stop();
 if(state.recording&&!input.value.trim()&&!composerFiles.length){await sendRecording();return;}
 // Freeze attachment intent before awaiting the network. New picks cannot sneak into this send.
 const batch=composerFiles.slice(),replyId=state.reply?.room===room.id?state.reply.id:null;if(batch.some(x=>x.viewOnce)&&(batch.length!==1||!canSendViewOnce(room,state.viewOnce,batch[0].file)))throw Error('Tek görüntüleme için desteklenen tek bir fotoğraf veya video seçin.');if(batch.some(x=>x.viewOnce)&&navigator.onLine===false)throw Error('Tek görüntülemelik gönderim için internet bağlantısı gerekiyor.');if(batch.length){composerMediaBusy=true;renderComposerFiles();}
 try{
  const payload=textPayload(input),text=payload.text;if(text){const r=input.getBoundingClientRect(),composerOrigin={x:r.left,y:r.top+r.height/2};input.value='';const panel=$('#composer-emoji-panel');if(panel&&!panel.hidden)panel._caret={start:0,end:0};resizeComposer(input);syncComposer();rememberChat();try{await send({...payload,...effectFields(options.effect)},room,null,{...options,composerOrigin});}catch(error){if(valid()){const tail=input.value;input.value=tail?text+'\n'+tail:text;resizeComposer(input);syncComposer();rememberChat();}throw error;}}
  if(batch.length){assertEpoch(epoch);for(const item of batch)item.status='Cihaza kaydediliyor';if(valid())renderComposerFiles();
   if(batch[0].viewOnce)await sendViewOnceFile(batch[0],room,epoch,replyId);
   else await enqueueAndFlush(batch.map(item=>item.file),room,replyId,()=>{
    if(valid()){for(const item of batch)item.status='Kuyrukta';renderComposerFiles();}
   });
   if(valid()){composerFiles=composerFiles.filter(item=>!batch.includes(item));renderComposerFiles();}
  }}
 finally{if(valid()&&batch.length){composerMediaBusy=false;renderComposerFiles();if($('#upload-progress'))$('#upload-progress').innerHTML='';}}
}
// Long-press options are text-only; attachments retain their existing durable queue.
function openSendOptions(room,epoch){
 const input=$('#message-text');if(!access.valid(epoch)||state.room?.id!==room.id||!input?.value.trim()||composerFiles.length||state.recording||room.ratchet_cutover_active)return;
 const original=input.value,originalPayload=textPayload(input),route=state.routeVersion,replyId=state.reply?.room===room.id?state.reply.id:null,originalQuote=quoteSnapshot(state.reply?.quoteText);
 const valid=()=>access.valid(epoch)&&state.routeVersion===route&&state.room?.id===room.id&&input.isConnected&&input.value===original&&JSON.stringify(textPayload(input))===JSON.stringify(originalPayload)&& (state.reply?.room===room.id?state.reply.id:null)===replyId&&quoteSnapshot(state.reply?.quoteText)===originalQuote;
 const min=new Date(Date.now()+120000);const dateLocal=new Date(min.getTime()-min.getTimezoneOffset()*60000).toISOString().slice(0,16);
 dialog('Gönderme seçenekleri',`<form id="send-options-form"><label for="send-effect">Mesaj efekti</label><select id="send-effect"><option value="">Efektsiz</option>${MESSAGE_EFFECTS.map(e=>`<option value="${e.id}">${e.glyph} ${e.label}</option>`).join('')}</select><button type="button" class="row" id="send-effect-now">Efektle gönder</button><button type="button" class="row" id="send-silent" ${state.sendOptions?'':'disabled'}>Sessiz gönder</button><label for="send-due">Gönderim zamanı (yerel saat)</label><input type="datetime-local" id="send-due" min="${dateLocal}" value="${dateLocal}" required><label><input type="checkbox" id="send-schedule-silent"> Sessiz gönder</label><button type="submit" class="primary" ${state.sendOptions?'':'disabled'}>Mesajı zamanla</button>${state.sendOptions?'':'<p class="hint">Sessiz ve zamanlanmış gönderim için güncel sunucu gerekli.</p>'}<p class="error" role="alert"></p></form>`);
 const form=$('#send-options-form');let busy=false;const id=crypto.randomUUID().replaceAll('-','');
 async function go(silent,scheduled){if(busy||!valid()||!form.isConnected)return;busy=true;form.querySelectorAll('button').forEach(b=>b.disabled=true);
  try{const effect=$('#send-effect').value||undefined;if(!scheduled){modal.close();await submitComposer(room,epoch,{silent,effect});return;}
   if(!state.sendOptions||navigator.onLine===false)throw Error('Zamanlama için sunucu bağlantısı gerekli.');
   const due=new Date($('#send-due').value).getTime();if(!Number.isFinite(due)||due<Date.now()+10000||due>Date.now()+365*86400000)throw Error('Gelecekteki bir zamanı seçin (en fazla bir yıl).');
   const payload={...originalPayload,...effectFields(effect)};if(replyId&&originalQuote)payload.replyQuote=originalQuote;
   const packets=await envelopes(room,payload);assertEpoch(epoch);if(!valid())throw Error('Taslak değişti.');
   await api('/rooms/'+room.id+'/scheduled',{method:'POST',body:{id,due,silent,reply:replyId,envelopes:packets,recipient_pubs:Object.fromEntries([...room.members,...(room.audit?[room.audit]:[])].map(m=>[m.id,m.pub]))}});assertEpoch(epoch);
   if(valid()){input.value='';input.style.height='auto';if(state.reply?.id===replyId){state.reply=null;renderReply();}typing.stop();syncComposer();rememberChat();if(form.isConnected&&modal.open)modal.close();notice('Mesaj zamanlandı.',2500,'success');}
  }catch(error){if(form.isConnected)form.querySelector('.error').textContent=error.message;else if(valid())notice(error.message,4000,'error');}finally{busy=false;if(form.isConnected){form.querySelectorAll('button').forEach(b=>b.disabled=false);if(!state.sendOptions){$('#send-silent').disabled=true;form.querySelector('[type=submit]').disabled=true;}}}}
 $('#send-effect-now').onclick=()=>go(false,false);$('#send-silent').onclick=()=>go(true,false);form.onsubmit=e=>{e.preventDefault();go($('#send-schedule-silent').checked,true);};
}
async function showScheduledMessages(){
 const room=state.room,epoch=access.epoch,route=state.routeVersion;if(!room||!state.sendOptions){notice('Zamanlanmış mesajlar için güncel sunucu gerekli.',3500,'info');return;}
 const records=await api('/rooms/'+room.id+'/scheduled');assertEpoch(epoch);if(state.routeVersion!==route||state.room?.id!==room.id)return;
 const parts=[];for(const record of records){let label='Şifreli mesaj';try{const own=room.members.find(m=>m.id===state.user.id);label=preview(await openMessagePayload(room,own,record.envelope,record.sender_pub));}catch{}if(!access.valid(epoch)||state.routeVersion!==route)return;parts.push(`<div class="note"><p>${escape(label)}</p><small>${escape(new Date(record.due).toLocaleString('tr-TR'))}${record.silent?' · Sessiz':''}${record.error?' · '+escape(record.error):''}</small><button data-action="scheduled-cancel" data-id="${escape(record.id)}" data-room="${escape(room.id)}">İptal et</button></div>`);}
 dialog('Zamanlanan mesajlar',parts.join('')||'<p>Bekleyen mesaj yok.</p>');
}
const sendEffectHistory=createEffectHistory();
function clearSendEffects(){document.querySelectorAll('.send-effect-overlay').forEach(n=>n.remove());}
function playSendEffect(id,effect,variant,manual=false){
 const spec=messageEffect(effect,variant);if(!spec||state.page!=="chat"||document.hidden||window.matchMedia?.('(prefers-reduced-motion: reduce)').matches)return;
 const node=document.querySelector(`[data-message="${CSS.escape(id)}"]`);if(!node||!node.isConnected)return;
 if(!manual&&!sendEffectHistory.accept(JSON.stringify([state.user?.id,state.room?.id,id])))return;
 drawMessageEffect(node,spec);
}
async function chooseFiles(kind) {
  const ctx=attachmentContext(state,access),selectedRoom=ctx.room,epoch=ctx.epoch;
  if(!ctx.valid())return;modal.close();
  const input = $("#files");
  input.multiple = kind !== "camera";
  input.accept =
    kind === "gallery" ? "image/*,video/*" : kind === "camera" ? "image/*" : "";
  if (kind === "camera") input.setAttribute("capture", "environment");
  else input.removeAttribute("capture");
  input.onchange = async () => {
    try {
      if(ctx.valid()&&input.isConnected)stageFiles(input.files,selectedRoom,epoch);
    } catch (err) {
      notice(err.message, 4000, "error");
    } finally {
      input.value = "";
      syncComposer();
    }
  };
  input.click();
}
let uploadBusy = false,uploadController=null;
const uploadEligible=()=>!isLocked()&&!!state.token&&!!state.identity&&!!state.user?.id&&state.durableUpload&&navigator.onLine!==false&&!document.hidden;
const uploadRecovery=createTransferRecovery({eligible:uploadEligible,run:flushDurableUploads,onError:(error,retry,attempt)=>{if(error.code!=='TRANSFER_BUSY'&&(!retry||attempt===0))reportUploadError(error);}});
window.addEventListener('offline',()=>{uploadRecovery.stop();uploadController?.abort();});
document.addEventListener('visibilitychange',()=>{if(!document.hidden)uploadRecovery.kick();});
async function uploadRequest(run){const controller=new AbortController();uploadController=controller;try{return await transferDeadline(run,{signal:controller.signal});}finally{if(uploadController===controller)uploadController=null;}}
function currentUploadStore(){
 assertAccess();const epoch=access.epoch,token=state.token,owner=state.user?.id;
 if(!token||!owner||!state.identity)throw Error('Dosya kuyruğu oturumu hazır değil.');
 return new DurableUploads({user:owner,identity:state.identity,read:vault,valid:()=>access.valid(epoch)&&state.token===token&&state.user?.id===owner});
}
function reportUploadError(error){if(!isLocked()&&error.name!=="AbortError"){const label=$('#upload-progress small');if(label)label.textContent=transferRetryable(error)?'Bağlantı bekleniyor · Kuyruk korundu':'Yükleme durdu · Veri ve Depolama bölümünü kontrol edin';notice('Dosya kuyruğu cihazda korundu. Veri ve Depolama bölümünden yeniden deneyebilirsin. '+error.message,5000,'error');}}
async function flushDurableUploadsLocked(queue){
 if(!state.durableUpload||navigator.onLine===false||!state.token||isLocked())return false;
 const epoch=access.epoch,token=state.token,owner=state.user?.id;const valid=()=>access.valid(epoch)&&state.token===token&&state.user?.id===owner;
 const jobs=await queue.list();if(!valid())throw abortTransfer();
 for(const job of jobs){
  if(!valid()||navigator.onLine===false)throw abortTransfer();const room=state.rooms.find(r=>r.id===job.room);
  if(!room)throw Error('Bekleyen dosyanın sohbeti bulunamadı. Gönderim durduruldu.');
  const bytes=await queue.body(job);if(!valid())throw abortTransfer();
  const record=await uploadRequest(signal=>api('/uploads',{method:'POST',signal,body:{room:job.room,size:bytes.length,client_id:job.id}}));if(!valid())throw abortTransfer();
  if(record.id!==job.id)throw Error('Sunucu kalıcı yükleme kimliğini desteklemiyor.');
  await transferUploadRecord({...job,bytes},room);if(!valid())throw abortTransfer();
  await queue.remove(job);if(!valid())throw abortTransfer();
 }
 return true;
}
async function flushDurableUploads(){
 if(!uploadEligible())return false;if(uploadBusy){const e=Error('Aktarım kuyruğu meşgul.');e.code='TRANSFER_BUSY';throw e;}
 uploadBusy=true;syncComposer();try{return await flushDurableUploadsLocked(currentUploadStore());}finally{uploadBusy=false;syncComposer();}
}
async function enqueueAndFlush(files,room,replyId=null,onSaved=()=>{}){
 if(uploadBusy)throw Error('Dosya yüklemesi sürüyor; tamamlanmasını bekleyin.');
 assertAccess();const epoch=access.epoch;
 if(!room||!state.rooms.some(r=>r.id===room.id))throw Error('Sohbet bulunamadı.');
 uploadBusy=true;syncComposer();
 try{
  const queue=currentUploadStore();await queue.enqueue(files,room.id,file=>prepareMedia(file,thumbnail),replyId);assertEpoch(epoch);onSaved();
  try{if(!await flushDurableUploadsLocked(queue)&&access.valid(epoch))notice('Dosyalar cihazda şifreli olarak kuyruğa alındı.',3500,'info');}
  catch(error){if(access.valid(epoch)){reportUploadError(error);if(transferRetryable(error))uploadRecovery.retry();}else if(error.name!=='AbortError')console.warn('queue',error.message);}
 }finally{uploadBusy=false;syncComposer();}
}
async function sendViewOnceFile(item,room,epoch,replyId=state.reply?.room===room.id?state.reply.id:null){
 if(uploadBusy||!canSendViewOnce(room,state.viewOnce,item.file))throw Error('Tek görüntüleme şu anda kullanılamıyor.');
 uploadBusy=true;syncComposer();try{
  const file=item.file;let pending=item.oncePending;
  if(!pending){const encrypted=await encryptFile(file);assertEpoch(epoch);pending={id:crypto.randomUUID().replaceAll('-',''),messageId:crypto.randomUUID().replaceAll('-',''),bytes:new Uint8Array(encrypted.data),meta:{type:'file',name:file.name,mime:file.type,size:file.size,key:encrypted.key,iv:encrypted.iv,viewOnce:true},replyId};item.oncePending=pending;}
  const record=await uploadRequest(signal=>api('/uploads',{method:'POST',signal,body:{room:room.id,size:pending.bytes.length,client_id:pending.id,view_once:true}}));assertEpoch(epoch);
  if(record.id!==pending.id)throw Error('Sunucu tek görüntüleme kimliğini doğrulamadı.');
  await transferUploadRecord(pending,room);assertEpoch(epoch);item.oncePending=null;
 }finally{uploadBusy=false;syncComposer();}
}
async function uploadFile(file,targetRoom=state.room){return enqueueAndFlush([file],targetRoom,state.reply?.room===targetRoom?.id?state.reply.id:null);}
async function resumeUpload(){
 if(uploadBusy)throw Error('Dosya yüklemesi sürüyor; tamamlanmasını bekleyin.');
 uploadBusy=true;syncComposer();
 try{
  const epoch=access.epoch,p=await vault('pending-upload');assertEpoch(epoch);
  // Explicit legacy resume only. The server HEAD validates uploader ownership.
  if(p){const room=state.rooms.find(r=>r.id===p.room);if(!room)throw Error('Bekleyen eski yüklemenin sohbeti bulunamadı.');await transferUploadRecord({...p,replyId:null},room);assertEpoch(epoch);await vault('pending-upload',null);}
  if(!await flushDurableUploadsLocked(currentUploadStore()))throw Error('Kuyruk için bağlantı ve güncel sunucu gerekiyor.');
 }finally{uploadBusy=false;syncComposer();}
}
async function transferUploadRecord(p,room){
 assertAccess();const epoch=access.epoch,token=state.token,headers={Authorization:'Bearer '+token};
 const valid=()=>access.valid(epoch)&&state.token===token&&navigator.onLine!==false;
 const path='/uploads/'+encodeURIComponent(p.id);
 await uploadChunks({size:p.bytes.length,valid,
    readOffset:async()=>{const check=await uploadRequest(signal=>fetchServer(apiRoot,'/api'+path,{method:'HEAD',headers,signal}));if(!check.ok){const e=Error('Yüklemeye devam edilemedi.');e.status=check.status;throw e;}return Number(check.headers.get('Upload-Offset')??NaN);},
    write:async(offset,end)=>(await uploadRequest(signal=>api(path,{method:'PUT',signal,headers:{'Upload-Offset':String(offset),'Content-Type':'application/octet-stream'},body:p.bytes.slice(offset,end)}))).offset,
    progress:(offset,size)=>{if(valid()&&state.room?.id===room.id&&$('#upload-progress'))$('#upload-progress').innerHTML=`<progress class="file-transfer-progress" max="${size}" value="${offset}" aria-label="Dosya yükleme ilerlemesi"></progress><small role="status">Yükleniyor · %${Math.floor(offset/size*100)}</small>`;}});
 if(!valid())throw abortTransfer();await uploadRequest(signal=>send({...p.meta,upload:p.id},room,p.messageId,{replyId:p.replyId??null,transferSignal:signal}));assertEpoch(epoch);if(state.room?.id===room.id&&$('#upload-progress'))$('#upload-progress').textContent='';
}
// Writes to the persistent manifest are serialized, including cancellation and export.
let downloadTail=Promise.resolve(),downloadController=null,downloadResume=null;
const downloadEligible=()=>!isLocked()&&!!state.durableDownload&&!!state.token&&!!state.identity&&!!state.user?.id&&navigator.onLine!==false&&!document.hidden;
const downloadRecovery=createDownloadRecovery({eligible:downloadEligible,run:resumeDownloads,onError:reportDownloadError});
document.addEventListener('visibilitychange',()=>{if(!document.hidden)downloadRecovery.kick();});
window.addEventListener('offline',()=>{downloadRecovery.stop();downloadController?.abort();});
function serialDownload(fn){const p=downloadTail.then(fn);downloadTail=p.catch(()=>{});return p;}
function currentDownloadStore(){
 assertAccess();const epoch=access.epoch,token=state.token,user=state.user?.id;
 if(!token||!user||!state.identity)throw Error('İndirme oturumu hazır değil.');
 return new DurableDownloads({user,identity:state.identity,read:vault,valid:()=>access.valid(epoch)&&token===state.token&&user===state.user?.id});
}
function reportDownloadError(error){if(!isLocked()&&error.name!=='AbortError')console.warn('download queue:',error.message);}
async function requestDownloadPart(job,start,end){
 if(navigator.onLine===false)throw Object.assign(Error('İnternet bağlantısı bekleniyor.'),{code:'NETWORK'});
 const token=state.token,epoch=access.epoch,controller=new AbortController();downloadController=controller;
 let timedOut=false;const timer=setTimeout(()=>{timedOut=true;controller.abort();},30000);
 try{const bytes=await fetchVerifiedRange(fetch,apiRoot+'/api/messages/'+encodeURIComponent(job.id)+'/download/'+encodeURIComponent(job.upload),token,start,end,job.total,controller.signal);assertEpoch(epoch);if(token!==state.token)throw new DOMException('Oturum değişti.','AbortError');return bytes;}
 catch(error){if(timedOut&&access.valid(epoch)&&token===state.token){const e=Error('İndirme zaman aşımı.');e.code='DOWNLOAD_TIMEOUT';throw e;}throw error;}
 finally{clearTimeout(timer);if(downloadController===controller)downloadController=null;controller.abort();}
}
async function finishDownload(store,job){
 if(navigator.onLine===false)throw Object.assign(Error('İnternet bağlantısı bekleniyor.'),{code:'NETWORK'});
 try{return await store.fetch(job,requestDownloadPart,(n,total)=>transferStatus(job.id,`İndiriliyor · %${Math.floor(n/total*100)}`));}
 catch(error){if([403,404,410].includes(error.status)&&store.valid())await store.remove(job.id);throw error;}
}
async function exportDownload(store,job){
 job=await finishDownload(store,job);
 // Revalidate access to the original message before exporting a completed cache.
 try{await requestDownloadPart(job,0,1);}catch(error){if([403,404,410].includes(error.status)&&store.valid())await store.remove(job.id);throw error;}
 const blob=await decryptFile(await store.bytes(job),job.meta);store.active();
 if(window.FSNative?.beginFile)await nativeFile(blob,job.meta.name,job.meta.mime,'save');
 else{const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=job.meta.name;a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);}
 // Android document chooser may still be cancelled. Keep authenticated ciphertext until explicit removal.
 store.active();transferStatus(job.id,'Hazır');notice('Dosya hazır. Kaydettikten sonra Veri ve Depolama bölümünden kuyruk kaydını kaldırabilirsin.',4000,'info');
}
function resumeDownloads(){
 if(downloadResume||!downloadEligible())return downloadResume||Promise.resolve(false);
 const store=currentDownloadStore();const flight=serialDownload(async()=>{let retry=false;for(const job of await store.list()){store.active();if(!downloadEligible())return false;if(job.offset<job.total){try{await finishDownload(store,job);}catch(error){if(error.name==='AbortError'||!store.valid())throw error;reportDownloadError(error);if(retryableDownload(error)||transferRetryable(error))retry=true;}}}return retry;});downloadResume=flight;flight.finally(()=>{if(downloadResume===flight)downloadResume=null;}).catch(()=>{});return flight;
}
async function showTransferStorage(){
 const epoch=access.epoch,queue=currentUploadStore(),jobs=await queue.list(),downloads=await currentDownloadStore().list();assertEpoch(epoch);
 dialog('Veri ve Depolama',`<p class="hint">Dosya başına 50 MB. Gönderim ve indirme kuyrukları ayrı ayrı 20 dosya ve 200 MB ile sınırlı. Kesilen yükleme ve indirmeler internet bağlantısı ve PIN oturumu açıldığında sürer. Tamamlanan indirmeyi kaydetmek için dosyaya dokun.</p><p role="status">Bekleyen yükleme: ${jobs.length}</p>${jobs.map(j=>`<p class="hint">${escape(j.meta.name)} · ${Math.ceil(j.meta.size/1024)} KB</p>`).join('')}<button class="row" data-action="resume">Bekleyen yüklemeleri tamamla</button><button class="row danger" data-action="cancel-upload">İlk bekleyen yüklemeyi iptal et</button><h3>Kalıcı indirmeler (${downloads.length})</h3>${downloads.map(j=>`<p>${escape(j.meta.name)} · %${Math.floor(100*j.offset/j.total)}</p><button class="row" data-action="resume-download" data-id="${escape(j.id)}">${j.offset===j.total?'Dosyayı kaydet':'İndirmeyi sürdür ve kaydet'}</button><button class="row danger" data-action="remove-download" data-id="${escape(j.id)}">Kuyruktan kaldır</button>`).join('')}`);
}
async function cancelPendingUpload(){
 if(uploadBusy)throw Error('Yükleme sürerken iptal edilemez; tamamlanmasını bekleyin.');
 uploadBusy=true;syncComposer();try{
  const epoch=access.epoch,queue=currentUploadStore(),legacy=await vault('pending-upload');assertEpoch(epoch);
  const job=legacy||(await queue.list())[0];if(!job)return false;
  try{await api('/uploads/'+job.id,{method:'DELETE'});}catch(e){if(e.status!==404)throw e;}
  assertEpoch(epoch);if(legacy)await vault('pending-upload',null);else await queue.remove(job);return true;
 }finally{uploadBusy=false;syncComposer();}
}
const transfers=new Map();
const downloadQueue=createTransferQueue(2);
function transferStatus(id,text,retry=false){if(state.openMediaId===id)modal._fsVideoViewer?.progress(text);for(const target of document.querySelectorAll(`[data-transfer="${id}"]`)){target.textContent=text;if(retry){const button=document.createElement('button');button.dataset.action='download';button.dataset.id=id;button.textContent='Yeniden dene';target.append(button)}}}
async function fileBytes(m,persistent=true){
 assertAccess();if(isViewOnce(m))throw Error("Tek görüntülemelik medya yalnızca özel görüntüleyiciden açılır.");
 const transferKey=persistent?m.id:`direct:${m.id}`;
 if(transfers.has(transferKey))return transfers.get(transferKey);
 const token=state.token,epoch=access.epoch,admin=state.page==='admin-room';
 if(!admin&&hiddenMessage(m))throw abortTransfer();
 if(persistent&&state.durableDownload&&!admin&&!m.pending&&m.room&&!hiddenMessage(m)){
  const store=currentDownloadStore();const task=serialDownload(async()=>{
   const existing=(await store.list()).some(j=>j.id===m.id);store.active();const job=await store.enqueue(m);const ready=await finishDownload(store,job);
   // Cached ciphertext is never released after message deletion or authorization loss.
   try{await requestDownloadPart(ready,0,1);}catch(e){if([403,404,410].includes(e.status)&&store.valid())await store.remove(job.id);throw e;}
   const bytes=await store.bytes(ready);store.active();if(hiddenMessage(m))throw abortTransfer();if(!existing)await store.remove(job.id);store.active();return bytes;
  });transfers.set(transferKey,task);
  try{return await task;}catch(e){if(e.code==='QUEUE_LIMIT'&&store.valid()){if(transfers.get(transferKey)===task)transfers.delete(transferKey);return fileBytes(m,false);}if(store.valid()&&e.name!=='AbortError'){transferStatus(m.id,'İndirme kesildi. ',true);if(retryableDownload(e)||transferRetryable(e))downloadRecovery.retry();}throw e;}finally{if(transfers.get(transferKey)===task)transfers.delete(transferKey);}
 }
 transferStatus(m.id,'İndirme sırasında…');
 const task=downloadQueue.add(async signal=>{assertEpoch(epoch);if(token!==state.token)throw new DOMException('Oturum değişti.','AbortError');try{transferStatus(m.id,'İndiriliyor…');const controller=new AbortController();const cancel=()=>controller.abort();signal.addEventListener('abort',cancel,{once:true});let timer=setTimeout(()=>controller.abort(),30000);let reader;try{const endpoint=admin?'/api/admin/uploads/'+encodeURIComponent(m.payload.upload):state.durableDownload&&!m.pending&&m.room?'/api/messages/'+encodeURIComponent(m.id)+'/download/'+encodeURIComponent(m.payload.upload):'/api/uploads/'+encodeURIComponent(m.payload.upload);const response=await fetch(apiRoot+endpoint,{headers:{Authorization:'Bearer '+token},signal:controller.signal,cache:'no-store',redirect:'error'});if(!response.ok)throw Error('Dosya indirilemedi ('+response.status+').');let bytes;if(response.body?.getReader){reader=response.body.getReader();let last=0;bytes=await readExactBytes(reader,m.payload.size+16,{valid:()=>access.valid(epoch)&&state.token===token&&!signal.aborted,progress:received=>{clearTimeout(timer);timer=setTimeout(()=>controller.abort(),30000);if(Date.now()-last>100){transferStatus(m.id,`İndiriliyor · %${Math.min(100,Math.round(received/(m.payload.size+16)*100))}`);last=Date.now()}}})}else bytes=new Uint8Array(await response.arrayBuffer());assertEpoch(epoch);if(state.token!==token||signal.aborted)throw new DOMException('Oturum değişti.','AbortError');if(bytes.length!==m.payload.size+16)throw Error('Dosya boyutu doğrulanamadı.');transferStatus(m.id,'Dosya açılıyor…');return bytes;}finally{clearTimeout(timer);signal.removeEventListener('abort',cancel);controller.abort();reader?.releaseLock();}}catch(error){if(access.valid(epoch)&&state.token===token&&!signal.aborted)transferStatus(m.id,'İndirilemedi. ',true);throw error}});transfers.set(transferKey,task);try{return await task;}finally{if(transfers.get(transferKey)===task)transfers.delete(transferKey);}
}
let albumViewer=null;
let onceViewer=null;
function closeOnceViewer(){const viewer=onceViewer;onceViewer=null;viewer?.close();}
function confirmViewOnce(m){
 if(isLocked()||state.page!=='chat'||state.room?.id!==m.room||!isViewOnce(m)||m.pending||m.sender===state.user.id||m.view_once_opened)return;
 const epoch=access.epoch,room=m.room,route=state.routeVersion;dialog('Tek görüntülemelik medya','<p>Bu fotoğraf veya video yalnızca bir kez açılır. Açtıktan sonra bağlantı kesilse bile tekrar görüntüleyemeyebilirsiniz.</p><button type="button" id="once-confirm" class="primary">Bir kez görüntüle</button><div class="once-view-host" role="status"></div>');
 const host=modal.querySelector('.once-view-host'),confirm=modal.querySelector('#once-confirm');
 const valid=()=>access.valid(epoch)&&state.page==='chat'&&state.room?.id===room&&state.routeVersion===route&&modal.open&&host.isConnected&&!document.hidden;
 const viewer=createOnceViewer({valid,request:signal=>api('/messages/'+encodeURIComponent(m.id)+'/view-once',{method:'POST',signal,binary:true,maxBytes:m.payload.size+16}),decrypt:bytes=>decryptFile(bytes,m.payload),show:url=>{host.replaceChildren();const media=document.createElement(m.payload.mime.startsWith('video/')?'video':'img');media.src=url;media.setAttribute('draggable','false');media.addEventListener('contextmenu',e=>e.preventDefault());if(media.tagName==='VIDEO'){media.controls=true;media.controlsList='nodownload noremoteplayback';media.disablePictureInPicture=true;media.playsInline=true;}else media.alt='Tek görüntülemelik fotoğraf';host.append(media);},hide:()=>{host.querySelector('video')?.pause();host.replaceChildren();}});
 onceViewer=viewer;confirm.onclick=async()=>{if(!valid()||confirm.disabled)return;confirm.disabled=true;host.textContent='Açılıyor…';try{const opened=await viewer.open();if(opened&&valid()){confirm.remove();} }catch(error){if(valid())host.textContent=error.status===410?'Bu medya daha önce açıldı.':'Medya açılamadı; açma hakkı kullanılmış olabilir.';}finally{if(access.valid(epoch)){loadMessages().catch(()=>{});}}};
}
modal.addEventListener('close',()=>{if(!modal.open)closeOnceViewer();});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&onceViewer){closeOnceViewer();if(modal.open)modal.close();}});
function closeAlbumViewer(){if(modal._fsVideoViewer){modal._fsVideoViewer.dispose();modal._fsVideoViewer=null;state.openMediaId=null;}modal.classList.remove("video-viewer");if(albumViewer){const view=albumViewer;albumViewer=null;view.gestures?.dispose();view.root.querySelector("img")?.removeAttribute("src");view.controller.close();view.cipherCache?.close();view.cacheAbort?.abort();state.openMediaId=null;}if(modal.classList.contains('album-viewer'))modal.removeAttribute('aria-label');modal.classList.remove('album-viewer');}
function dismissAlbumViewer(){if(albumViewer||modal._fsVideoViewer){closeAlbumViewer();if(modal.open)modal.close();}}
function photoCandidates(page){return page==='media'?filteredMedia():page==='saved'?state.saved||[]:page==='admin-room'?state.media:state.messages;}
function visiblePhoto(m){return !isViewOnce(m)&&!hiddenMessage(m)&&!m.pending&&m.payload?.type==='file'&&m.payload.mime.startsWith('image/');}
function currentPhoto(id,page){const m=lookupRecord(id,page==='media'?state.media:photoCandidates(page));return m&&visiblePhoto(m)&&(page!=='media'||matchesMediaFilter(m))?m:undefined;}
function viewAlbum(anchor,start){
  if(isLocked()||state.page!=="chat"||state.selected.size||albumJob)return;
  const room=state.room?.id;
  const photos=albumMembers(virtualMessages?.rows||[],anchor,state.messages,m=>!hiddenMessage(m)&&!m.pending&&m.room===room);
  if(photos.length<2){notice("Albüm değişti veya henüz gönderiliyor. Tekrar deneyin.",3500,"error");return;}
  openPhotoViewer(photos,start,anchor);
}
function viewPhoto(m){
  if(isLocked()||hiddenMessage(m)||m.pending)return;
  const page=state.page,room=state.room?.id;
  const photos=photoCandidates(page).filter(x=>visiblePhoto(x)&&(page!=='chat'||x.room===room)&&(page!=='admin-room'||x.room===m.room));
  const start=photos.findIndex(x=>x.id===m.id);if(start<0)return;
  openPhotoViewer(photos,start,null);
}
function openPhotoViewer(photos,start,anchor){
  if(!Number.isInteger(start)||start<0||start>=photos.length)return;
  const page=state.page,room=state.room?.id,route=state.routeVersion,epoch=access.epoch,token=state.token;
  dialog('Fotoğraf',`<div id="album-viewer-content"><div id="album-stage" tabindex="0" role="group" aria-label="Fotoğraf · yakınlaştırmak için iki parmak, kapatmak için geri"><img id="album-photo" hidden alt="Gönderilen fotoğraf" draggable="false"><div class="fs-album-status" aria-live="polite"><span class="fs-album-spinner" aria-hidden="true" hidden></span><p id="album-photo-status" role="status"></p></div><button type="button" class="secondary" data-action="album-retry" hidden>Yeniden dene</button></div></div>`);
  modal.classList.add('album-viewer');modal.setAttribute('aria-label','Fotoğraf');
  const root=$('#album-viewer-content'),img=$('#album-photo'),status=$('#album-photo-status'),stage=$('#album-stage');
  const eligible=m=>{const live=currentPhoto(m.id,page);return !!live&&live.room===m.room&&live.payload.upload===m.payload.upload;};
  const active=()=>access.valid(epoch)&&state.token===token&&state.page===page&&state.room?.id===room&&state.routeVersion===route&&modal.open&&root.isConnected&&!document.hidden;
  const cacheAbort=new AbortController();
  const cipherCache=createPhotoCipherCache({read:m=>fileBytes(m,false),valid:m=>active()&&eligible(m),enabled:m=>!!state.durableDownload&&page!=='admin-room'&&Number.isSafeInteger(m.payload.size)&&!m.pending&&!isViewOnce(m),authorize:m=>transferDeadline(signal=>fetchVerifiedRange(fetch,apiRoot+'/api/messages/'+encodeURIComponent(m.id)+'/download/'+encodeURIComponent(m.payload.upload),token,0,1,m.payload.size+16,signal),{signal:cacheAbort.signal})});
  let gestures,zoomAllowed=false;
  const controller=createAlbumViewer(photos,{active,eligible,blur:state.settings.blur!==false,read:async m=>decryptFile(await cipherCache.load(m),m.payload),render:({index,total,photo,url,phase,revealed})=>{
    const changed=root.dataset.current!==photo.id||phase==='loading';stage.dataset.phase=phase;stage.setAttribute('aria-busy',String(phase==='loading'));root.querySelector('.fs-album-spinner').hidden=phase!=='loading';state.openMediaId=photo.id;root.dataset.current=photo.id;root.querySelector('[data-action="album-retry"]').hidden=phase!=='error';
    img.hidden=phase!=='ready';img.classList.toggle('blurred',!revealed);zoomAllowed=phase==='ready'&&revealed;if(url){if(img.getAttribute('src')!==url)img.src=url;}else img.removeAttribute('src');
    status.textContent=phase==='loading'?'Fotoğraf açılıyor…':phase==='error'?'Fotoğraf açılamadı. Yeniden deneyebilirsiniz.':!revealed?'Netleştirmek için fotoğrafa dokun.':'';
    if(changed)gestures?.reset();else gestures?.refresh();
  }});
  gestures=attachPhotoGestures(stage,img,null,{active,canZoom:()=>zoomAllowed&&controller.ready,reveal:()=>controller.reveal(),step:delta=>controller.step(delta),dismiss:()=>dismissAlbumViewer()});
  albumViewer={controller,anchor,root,ids:new Set(photos.map(m=>m.id)),gestures,eligible,page,cipherCache,cacheAbort};
  img.onerror=()=>{if(active()&&img.getAttribute('src'))controller.imageError();};
  stage.focus({preventScroll:true});controller.select(start);
}
let albumJob=null;
async function downloadAlbum(anchor){
  if(isLocked()||state.page!=="chat"||state.selected.size||albumJob)return;
  const members=albumMembers(virtualMessages?.rows||[],anchor,state.messages,m=>!hiddenMessage(m)&&!m.pending&&m.room===state.room?.id);
  if(members.length<2){notice("Albüm değişti veya henüz gönderiliyor. Tekrar deneyin.",3500,"error");return;}
  const job={cancelled:false},epoch=access.epoch,route=state.routeVersion,room=state.room.id,token=state.token;
  albumJob=job;
  const inRoom=()=>access.valid(epoch)&&state.routeVersion===route&&state.room?.id===room&&state.page==="chat"&&state.token===token;
  const live=()=>inRoom()&&!job.cancelled&&modal.open&&document.querySelector('#album-progress')===progress;
  const eligible=m=>!!eligibleMessage(m.id)&&eligibleMessage(m.id).payload.upload===m.payload.upload;
  const native=typeof window.FSNative?.beginPhotoAlbum==='function';
  dialog('Albümü indir',`<p class="hint">${native?'Fotoğrafların kaydedileceği klasörü seçin.':'Fotoğraflar tek ZIP dosyasında hazırlanır.'}</p><p id="album-progress" role="status">0 / ${members.length}</p><progress id="album-meter" value="0" max="${members.length}"></progress><button type="button" class="secondary" data-action="cancel-album">Vazgeç</button><div id="album-result"></div>`);
  const progress=$('#album-progress'),meter=$('#album-meter'),resultBox=$('#album-result'),cancel=modal.querySelector('[data-action="cancel-album"]');
  let archive=null,albumStore=null,albumQueued=false,albumPersistent=state.durableDownload,addedIds=[];
  const sink=native?nativeAlbumSink(window.FSNative,{encode:b64}):browserAlbumSink(blob=>{archive=blob;});
  try{
    if(!native&&members.reduce((sum,m)=>sum+m.payload.size,0)>128*1024*1024)throw Error('Bu albüm tarayıcıda 128 MB sınırını aşıyor. Android uygulamasından indirin.');
    const outcome=await exportPhotos(members,{active:live,eligible,read:async m=>{
      if(!albumPersistent)return decryptFile(await fileBytes(m,false),m.payload);
      if(!albumStore)albumStore=currentDownloadStore();
      return serialDownload(async()=>{
        if(!live())throw new DOMException('Albüm işlemi kapandı.','AbortError');
        if(!albumQueued){try{const existing=new Set((await albumStore.list()).map(j=>j.id));await albumStore.enqueueBatch(members);addedIds=members.filter(x=>!existing.has(x.id)).map(x=>x.id);albumQueued=true;}catch(error){if(error.code!=='QUEUE_LIMIT')throw error;albumPersistent=false;notice('Albüm kalıcı kuyruk sınırını aşıyor. Normal albüm indirmesi kullanılıyor.',4000,'info');return decryptFile(await fileBytes(m,false),m.payload);}}
        const item=(await albumStore.list()).find(x=>x.id===m.id);if(!item)throw Error('Albüm dosyası artık mevcut değil.');
        const ready=await albumStore.fetch(item,async(j,start,end)=>{if(!live())throw new DOMException('Albüm kapandı.','AbortError');return requestDownloadPart(j,start,end);});
        await requestDownloadPart(ready,0,1);if(!live())throw new DOMException('Albüm kapandı.','AbortError');return decryptFile(await albumStore.bytes(ready),ready.meta);
      });
    },onSaved:async m=>{if(native&&albumStore&&albumQueued&&albumStore.valid())await serialDownload(()=>albumStore.remove(m.id)).catch(reportDownloadError);},sink,progress:r=>{if(live()){progress.textContent=`${r.saved+r.failed} / ${r.total} · ${r.failed} başarısız`;meter.value=r.saved+r.failed;}}});
    if(!inRoom()||!progress.isConnected||!modal.open)return;
    cancel.hidden=true;
    if(outcome.cancelled){progress.textContent=native?`İptal edildi · ${outcome.saved} fotoğraf kaydedildi.`:'İptal edildi · Dosya indirilmedi.';return;}
    progress.textContent=native?`${outcome.saved} / ${outcome.total} fotoğraf kaydedildi.`:`${outcome.saved} / ${outcome.total} fotoğraf hazırlandı.`;
    if(outcome.failed)resultBox.textContent=`${outcome.failed} fotoğraf indirilemedi. Albümün tamamı kaydedilmedi.`;
    if(archive){const url=URL.createObjectURL(archive),link=document.createElement('a');link.className='primary album-archive-link';link.href=url;link.download='FS-Album-'+new Date().toISOString().slice(0,10)+'.zip';link.textContent='ZIP dosyasını indir';resultBox.append(link);const revoke=()=>URL.revokeObjectURL(url);modal.addEventListener('close',revoke,{once:true});setTimeout(revoke,300000);}
  }catch(error){if(inRoom()&&progress.isConnected&&modal.open){progress.textContent=error.message||'Albüm indirilemedi.';cancel.hidden=true;}}
  finally{if(job.cancelled&&albumStore?.valid())await serialDownload(async()=>{for(const id of addedIds)await albumStore.remove(id)}).catch(reportDownloadError);if(albumJob===job)albumJob=null;}
}
function viewVideo(m){
 if(isLocked()||hiddenMessage(m)||m.pending||!m.payload?.mime?.startsWith('video/'))return;
 const page=state.page,room=state.room?.id,route=state.routeVersion,epoch=access.epoch,token=state.token;
 const current=()=>photoCandidates(page).find(x=>x.id===m.id&&x.room===m.room&&!hiddenMessage(x)&&!x.pending&&x.payload?.upload===m.payload.upload&&x.payload?.mime?.startsWith('video/'));
 if(!current())return;
 dialog(m.payload.name,videoPlayerMarkup);modal.classList.add('video-viewer');
 const root=modal.querySelector('.fs-video-player');state.openMediaId=m.id;
 const active=()=>access.valid(epoch)&&state.token===token&&state.page===page&&state.room?.id===room&&state.routeVersion===route&&modal.open&&root.isConnected&&!document.hidden&&!!current();
 const player=mountVideoPlayer(root,{active,read:async()=>{const bytes=await fileBytes(m);if(!active())throw new DOMException('Video kapatıldı.','AbortError');return decryptFile(bytes,m.payload);},onSave:async()=>{const item=current();if(active()&&item)await download(item,true);}});
 modal._fsVideoViewer=player;void player.load();
}
async function download(m, save = false) {
  if(isLocked())return;
  if(isViewOnce(m))throw Error("Tek görüntülemelik medya indirilemez.");
  const p = m.payload;
  save = save || !/^(audio|image|video)\//.test(p.mime);
  if(!save&&p.mime.startsWith("image/")){viewPhoto(m);return;}
  if(!save&&p.mime.startsWith("video/")){viewVideo(m);return;}
  if(save&&state.durableDownload&&state.page!=='admin-room'&&!m.pending&&m.room){const store=currentDownloadStore();try{await serialDownload(async()=>{const job=await store.enqueue(m);await exportDownload(store,job);});}catch(error){if(store.valid()){transferStatus(m.id,'İndirilemedi. ',true);if(retryableDownload(error)||transferRetryable(error))downloadRecovery.retry();}throw error;}return;}
  state.openMediaId = m.id;
  const token=state.token,page=state.page,room=state.room?.id,epoch=access.epoch;
  let blob;try{blob=await decryptFile(await fileBytes(m),p)}catch(error){transferStatus(m.id,"Dosya açılamadı. ",true);throw error}
  transferStatus(m.id,'Hazır');
  if(!access.valid(epoch)||state.token!==token||(!save&&(state.page!==page||state.room?.id!==room)))return;
  const url = URL.createObjectURL(blob);
  if (save && window.FSNative?.beginFile) {
    URL.revokeObjectURL(url);
    await nativeFile(blob, p.name, p.mime, "save");
    return;
  }
  if (save) {
    const a = document.createElement("a");
    a.href = url;
    a.download = p.name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 10000);
    return;
  }
  if (p.mime.startsWith("audio/"))
    dialog(p.name, `<audio controls autoplay src="${url}"></audio>`);
  else {
    URL.revokeObjectURL(url);
    return download(m, true);
  }
  modal.addEventListener("close", () => URL.revokeObjectURL(url), {
    once: true,
  });
}
let voiceController=null,voiceRoom=null,voicePreviewUrl=null,voiceSending=false,voiceDuration=0;
let voiceLocked=false,voiceStartY=0,voiceStartX=0;
function voiceStatus({phase,elapsed=0,wave=[],meterAvailable=false}){
 if(state.recordingStatusEnabled)typing.record(phase==='recording'&&voiceRoom===state.room?.id);
 syncComposer();const box=$('#voice-status');if(!box)return;box.hidden=phase==='idle';box.dataset.phase=phase;if(box.hidden){box.innerHTML='';return}
 if(['recording','paused'].includes(phase)){
  if(!box.querySelector('.voice-wave'))box.innerHTML='<span class="record-dot"></span><strong class="voice-label"></strong><time class="voice-time"></time><div class="voice-wave" aria-label="Mikrofon ses seviyesi"></div><button type="button" data-action="voice-lock" aria-label="Kaydı kilitle">↑ Kilitle</button><button type="button" data-action="voice-pause" aria-label="Kaydı duraklat">Ⅱ</button><button type="button" data-action="voice-resume" aria-label="Kayda devam et" hidden>▶</button><button type="button" data-action="voice-finish" aria-label="Kaydı bitir ve dinle">■ Dinle</button><button type="button" data-action="discard-recording" aria-label="Kaydı iptal et">×</button>';
  box.dataset.locked=String(voiceLocked);box.querySelector('.voice-label').textContent=phase==='paused'?'Kayıt duraklatıldı':voiceLocked?'Kayıt kilitli':'← Kaydır, iptal et · ↑ Kilitle';box.querySelector('.voice-time').textContent=Math.floor(elapsed/60000)+':'+String(Math.floor(elapsed/1000)%60).padStart(2,'0');box.querySelector('[data-action="voice-lock"]').hidden=voiceLocked;box.querySelector('[data-action="voice-pause"]').hidden=phase==='paused';box.querySelector('[data-action="voice-resume"]').hidden=phase!=='paused';box.querySelector('.voice-wave').innerHTML=meterAvailable&&wave.length?wave.map(v=>`<i style="height:${Math.max(2,Math.round(v*28))}px"></i>`).join(''):'<small>Ses seviyesi gösterimi kullanılamıyor</small>';
 }else box.textContent=phase==='permission'?'Mikrofon izni bekleniyor…':'Ses kaydı hazırlanıyor…';
}

function discardVoice(){voiceLocked=false;state.voicePressed=false;voiceController?.cancel();voiceController=null;state.recording=null;voiceRoom=null;if(voicePreviewUrl){URL.revokeObjectURL(voicePreviewUrl);voicePreviewUrl=null}voiceStatus({phase:'idle',elapsed:0});syncComposer()}
async function beginRecording(e){
 if(isLocked()||currentComposerMode()!=='mic'||voiceSending||state.recording||voiceController?.session)return;if(state.call)throw Error('Görüşme sırasında yeni ses kaydı başlatılamaz.');
 document.querySelectorAll('audio[data-audio]').forEach(audio=>audio.pause());
 voiceLocked=false;voiceStartY=e.clientY;voiceStartX=e.clientX;state.voicePressed=true;const room=state.room?.id;voiceRoom=room;
 // The initiating pointer is already captured by the composer button.
 const controller=new VoiceRecorder({mediaDevices:navigator.mediaDevices,Recorder:globalThis.MediaRecorder,onStatus:voiceStatus,onError:error=>{voiceLocked=false;state.voicePressed=false;notice(error.message,4000,'error');syncComposer();},onReady:({blob,duration,mime})=>{
  if(voiceController!==controller||voiceRoom!==room||state.room?.id!==room||state.page!=='chat'||isLocked())return;
  state.recording=new File([blob],'ses-'+Date.now()+'-'+Math.round(duration)+'.'+voiceExtension(mime),{type:mime});
  voicePreviewUrl=URL.createObjectURL(blob);voiceDuration=duration;
  const box=$('#voice-status');if(box){box.hidden=false;box.dataset.phase='ready';box.innerHTML='<strong>Ses kaydı hazır</strong><button type="button" data-action="review-recording">Dinle / Gönder</button><button type="button" data-action="discard-recording">Vazgeç</button>';}
  syncComposer();reviewRecording();
 }});voiceController=controller;await controller.start();
}
function reviewRecording(){if(state.recording&&voicePreviewUrl)dialog('Ses kaydı',`<p>${Math.ceil(voiceDuration/1000)} saniyelik kayıt hazır. Önce dinleyebilir, sonra gönderebilirsiniz.</p><audio controls src="${voicePreviewUrl}" aria-label="Ses kaydı önizlemesi"></audio><button class="primary" data-action="send-recording">Gönder</button><button class="secondary" data-action="discard-recording">Vazgeç</button>`)}
function endRecording(){state.voicePressed=false;if(!voiceLocked)voiceController?.stop()}
async function sendRecording(){
 if(voiceSending||!state.recording)return;
 if(voiceRoom!==state.room?.id||state.page!=='chat'){discardVoice();throw Error('Ses kaydının sohbeti değişti. Yeniden kayıt yapın.');}
 voiceSending=true;syncComposer();const file=state.recording,room=state.room,epoch=access.epoch;const same=()=>access.valid(epoch)&&state.room?.id===room.id&&state.recording===file;document.querySelectorAll('[data-action="send-recording"],[data-action="discard-recording"]').forEach(b=>b.disabled=true);
 try{const pending=await vault('pending-upload');if(pending&&pending.room===voiceRoom&&pending.meta.name===file.name&&pending.meta.size===file.size)await resumeUpload();else await uploadFile(file,room);if(same()){if(modal.querySelector('[data-action="send-recording"]'))modal.close();discardVoice()}}catch(error){if(same())notice('Ses kaydı gönderilemedi. Kayıt korundu; yeniden gönderebilirsiniz.',4000,'error');throw error}finally{voiceSending=false;syncComposer();document.querySelectorAll('[data-action="send-recording"],[data-action="discard-recording"]').forEach(b=>b.disabled=false)}
}
document.addEventListener('visibilitychange',()=>{if(document.hidden){voicePlayIntent++;if(voiceController?.session)discardVoice();document.querySelectorAll('audio[data-audio]').forEach(a=>a.pause());}});

function toggleComposerEmoji(){const panel=$('#composer-emoji-panel'),input=$('#message-text');if(!panel||!input||input.disabled||currentComposerMode()==='recording')return;if(!panel.hidden){closeComposerEmoji();input.focus({preventScroll:true});return;}if(modal.open)return;panel._caret={start:input.selectionStart,end:input.selectionEnd};input.blur();modal.replaceChildren();panel.hidden=false;emojiPicker(panel);const b=$('#compose [data-action=emoji]');if(b){b.innerHTML=icon('keyboard');b.setAttribute('aria-label','Klavyeye dön');b.setAttribute('title','Klavyeye dön');b.setAttribute('aria-expanded','true');}scheduleChatViewport();}
function insertComposerEmoji(input,emoji){if(!input||input.disabled||typeof emoji!=='string'||!emoji)return false;const panel=$('#composer-emoji-panel'),caret=panel&&!panel.hidden?panel._caret:null;const start=Math.min(input.value.length,caret?.start??input.selectionStart??input.value.length),end=Math.min(input.value.length,caret?.end??input.selectionEnd??start);const max=input.maxLength;if(max>=0&&input.value.length-(end-start)+emoji.length>max)return false;input.setRangeText(emoji,start,end,'end');const next=start+emoji.length;if(caret)panel._caret={start:next,end:next};input.dispatchEvent(new window.Event('input',{bubbles:true}));input.setSelectionRange(next,next);return true;}
function emojiPicker(panel=null) {
  const reaction=state.reactionTarget;const active=reaction?messageIndex.reactions.get(reaction.id)?.get(state.user.id):null;
  const content=`${active?`<button type="button" class="secondary remove-reaction" data-action="choose-reaction" data-remove-only="true" data-emoji="${escape(active)}">${escape(active)} Tepkimi kaldır</button>`:""}<div class="emoji-showcase" aria-hidden="true">${reaction?"":"🥰"}</div><input id="emoji-search" aria-label="Emoji ara" placeholder="Emoji veya kelime (kalp, gül…)"><p id="emoji-results" class="hint fs-emoji-results" role="status"></p><nav class="emoji-categories" aria-label="Emoji kategorileri"></nav><div class="emoji-grid" id="emoji-list"></div><button type="button" class="secondary emoji-more" id="emoji-more">Diğer emojiler</button>`;
  if(panel){panel.innerHTML=content;panel.onpointerdown=e=>{if(e.target.closest('button')&&e.isPrimary&&e.button===0)e.preventDefault();};}else dialog(reaction?"Mesaja tepki ver":"İfade Seç",reaction?`<div class="fs-reaction-picker">${content}</div>`:content);
  const find=selector=>panel?panel.querySelector(selector):$(selector);
  if(reaction)state.reactionTarget=reaction;
  const categories=[['Tümü','M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z'],['Yüzler','M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20 M8 9h.01 M16 9h.01 M7 14q5 6 10 0'],['Kalpler','M12 20 4 12C-1 6 7 1 12 7c5-6 13-1 8 5Z'],['Hayvanlar','M3 4l5 4h8l5-4v10c0 5-4 7-9 7s-9-2-9-7Z M8 13h.01 M16 13h.01 M10 16l2 2 2-2'],['Diğer','m12 2 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1Z']];
  let category='Tümü',visible=72,previousQuery=null,previousCategory=null,previousVisible=0,previousReduced=null;
  const draw=()=>{
    const q=find('#emoji-search').value.trim();const items=emojiItems.filter(e=>(category==='Tümü'||emojiCategory(e.emoji)===category)&&emojiMatches(e.emoji,q));
    find('#emoji-results').textContent=items.length?`${Math.min(visible,items.length)} / ${items.length} emoji`: 'Emoji bulunamadı';
    find('.emoji-categories').querySelectorAll('button').forEach(b=>{b.classList.toggle('active',b.dataset.category===category);b.setAttribute('aria-pressed',b.dataset.category===category)});
    const reduced=!!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    const list=find('#emoji-list'),append=previousQuery===q&&previousCategory===category&&previousReduced===reduced&&previousVisible>0&&visible>previousVisible;
    const markup=items.slice(append?previousVisible:0,visible).map(e=>`<button data-action="${reaction?"choose-reaction":"choose-emoji"}" data-emoji="${escape(e.emoji)}" aria-label="${escape(e.emoji)}" ${reaction?`aria-pressed="${sameReaction(active,e.emoji)}"`:""}><span class="emoji-picker-glyph" aria-hidden="true">${escape(e.emoji)}</span></button>`).join('');
    if(append){if(markup)list.insertAdjacentHTML('beforeend',markup);}else list.innerHTML=markup||'<p class="hint">Eşleşen emoji bulunamadı.</p>';
    previousQuery=q;previousCategory=category;previousVisible=visible;previousReduced=reduced;
    find('#emoji-more').hidden=items.length<=visible;
  };
  find('.emoji-categories').innerHTML=categories.map(([title,path])=>`<button type="button" data-category="${title}" title="${title}" aria-label="${title}"><svg viewBox="0 0 24 24" width="23" height="23" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="${path}"/></svg></button>`).join('');
  find('.emoji-categories').onclick=e=>{const b=e.target.closest('[data-category]');if(!b)return;category=b.dataset.category;visible=72;draw()};
  find('#emoji-search').oninput=()=>{visible=72;draw()};find('#emoji-more').onclick=()=>{visible+=72;draw()};draw();
}

const liveLocations = new Map();
function locationDialog(mode="once") {
  const ctx=attachmentContext(state,access);if(!ctx.valid())return;
  dialog(
    "Konum paylaş",
    `<form id="location-form" class="attachment-form"><p class="hint">Konum yalnızca izin verdiğinde alınır. Android’de arka plan paylaşımı sırasında görünür bir konum bildirimi gösterilir.</p><label for="location-mode">Paylaşım türü</label><select id="location-mode" name="mode"><option value="once">Mevcut konum</option><option value="live" ${mode==='live'?'selected':''}>Canlı konum</option></select><div id="location-duration" ${mode==='live'?'':'hidden'}><label for="location-preset">Süre seç</label><select id="location-preset"><option value="15">15 dakika</option><option value="60">1 saat</option><option value="480">8 saat</option><option value="custom">Özel süre</option></select><label for="location-minutes">Süre (dakika)</label><input id="location-minutes" name="minutes" type="number" min="1" max="480" value="15"></div><button class="primary" type="submit">Konumumu paylaş</button></form>${liveLocations.size || state.nativeLive ? '<button class="secondary" data-action="stop-location">Canlı konumu durdur</button>' : ""}`,
  );
  const form=$("#location-form"),type=$("#location-mode"),duration=$("#location-duration"),minutesInput=$("#location-minutes"),preset=$("#location-preset");
  const sync=()=>{duration.hidden=type.value!=='live';minutesInput.disabled=duration.hidden;};type.onchange=sync;sync();preset.onchange=()=>{if(preset.value==='custom')minutesInput.focus();else minutesInput.value=preset.value;};minutesInput.oninput=()=>{preset.value=['15','60','480'].includes(minutesInput.value)?minutesInput.value:'custom';};
  form.onsubmit = (e) => {
    e.preventDefault();if(!ctx.valid()||!form.isConnected||!modal.open)return;
    const f = new FormData(e.target),
      minutes = Number(f.get("minutes")),
      live = f.get("mode") === "live";
    if (live && (!Number.isInteger(minutes) || minutes < 1 || minutes > 480)) {
      notice("1–480 dakika arasında bir süre gir.");
      return;
    }
    const room = ctx.room, locationToken = state.token;
    modal.close();
    let last = 0,
      messageId = null,
      busy = false;
    const expires = Date.now() + (live ? minutes * 60000 : 60000);
    const update = async (pos) => {
      if (isLocked() || state.token !== locationToken || Date.now() >= expires || busy || Date.now() - last < 10000 || (!messageId&&!ctx.valid())) return;
      last = Date.now();
      busy = true;
      try {
        const payload = {
          type: "location",
          text: live ? "Canlı konum" : "Konum",
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          expires,
          live,
        };
        if (!messageId) messageId = await send(payload, room);
        else {
          await api("/messages/" + messageId, {
            method: "PATCH",
            body: { envelopes: await envelopes(room, payload) },
          });
          state.cache.delete(messageId);
          if (state.room?.id === room.id && state.page === "chat")
            await loadMessages();
        }
      } catch (err) {
        notice(err.message, 4000, "error");
      } finally {
        busy = false;
      }
    };
    const fail = (err) => notice("Konum alınamadı: " + err.message);
    if (live && window.FSNative?.startLiveLocation) {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          try {
            if (!ctx.valid()||isLocked()||state.token !== locationToken || Date.now() >= expires) return;
            const payload = {
              type: "location",
              text: "Canlı konum",
              lat: pos.coords.latitude,
              lng: pos.coords.longitude,
              live: true,
              expires,
            };
            const message = await send(payload, room);
            const keys = {};
            for (const peer of [
              ...new Map(
                [...room.members, ...(room.audit ? [room.audit] : [])].map(
                  (p) => [p.id, p],
                ),
              ).values(),
            ]) {
              const publicKey = await crypto.subtle.importKey(
                "jwk",
                peer.pub,
                { name: "ECDH", namedCurve: "P-256" },
                false,
                [],
              );
              const key = await crypto.subtle.deriveKey(
                { name: "ECDH", public: publicKey },
                state.identity.pair.privateKey,
                { name: "AES-GCM", length: 256 },
                true,
                ["encrypt"],
              );
              keys[peer.id] = b64(await crypto.subtle.exportKey("raw", key));
            }
            if(isLocked()||state.token!==locationToken||Date.now()>=expires)return;
            window.FSNative.startLiveLocation(
              JSON.stringify({
                room: room.id,
                message,
                keys,
                expires,
                lat: payload.lat,
                lng: payload.lng,
              }),
            );
            state.nativeLive = true;
          } catch (err) {
            notice(err.message, 4000, "error");
          }
        },
        fail,
        { enableHighAccuracy: true, timeout: 20000 },
      );
      return;
    }
    if (live) {
      const watch = navigator.geolocation.watchPosition(update, fail, {
        enableHighAccuracy: true,
        maximumAge: 5000,
        timeout: 20000,
      });
      const timer = setTimeout(() => {
        navigator.geolocation.clearWatch(watch);
        liveLocations.delete(watch);
      }, minutes * 60000);
      liveLocations.set(watch, { timer, room, getMessageId: () => messageId });
    } else
      navigator.geolocation.getCurrentPosition(update, fail, {
        enableHighAccuracy: true,
        timeout: 20000,
      });
  };
}
async function stopLocations() {
  if (state.nativeLive) {
    window.FSNative?.stopLiveLocation();
    state.nativeLive = false;
  }
  for (const [watch, record] of liveLocations) {
    navigator.geolocation.clearWatch(watch);
    clearTimeout(record.timer);
    const id = record.getMessageId(),
      m = state.messages.find((m) => m.id === id);
    if (m) {
      await api("/messages/" + id, {
        method: "PATCH",
        body: {
          envelopes: await envelopes(record.room, {
            ...m.payload,
            live: false,
            text: "Canlı konum sona erdi",
            expires: Date.now(),
          }),
        },
      });
      state.cache.delete(id);
    }
  }
  liveLocations.clear();
  modal.close();
  if (state.page === "chat") await loadMessages();
}
function pollDialog() {
  dialog('Anket oluştur',`<form id="poll-form" class="attachment-form"><label for="poll-question">Soru</label><input id="poll-question" name="question" maxlength="300" required placeholder="Ne düşünüyorsun?"><label for="poll-options">Seçenekler</label><textarea id="poll-options" name="options" rows="5" maxlength="2010" required placeholder="Her satıra bir seçenek"></textarea><p class="hint">2–10 farklı seçenek · Her biri en fazla 200 karakter</p><button type="submit" class="primary">Anket gönder</button></form>`);
  attachmentForm('#poll-form',f=>makePoll(f.get('question'),f.get('options')));
}
function eventDialog() {
  dialog('Etkinlik oluştur',`<form id="event-form" class="attachment-form"><label for="event-title">Etkinlik adı</label><input id="event-title" name="title" maxlength="300" required><label for="event-date">Tarih ve saat</label><input id="event-date" name="date" type="datetime-local" required><button type="submit" class="primary">Etkinlik gönder</button></form>`);
  attachmentForm('#event-form',f=>makeEvent(f.get('title'),f.get('date')));
}
function profile(peer = state.user) {
  if(isLocked())return;
  discardVoice();
  const own=peer.id===state.user.id, group=(title,content)=>`<section class="fs-detail-group"><h3>${title}</h3>${content}</section>`;
  state.page = own ? "profile" : "peer";
  const status=state.presenceStale===true&&!own?"Durum bilinmiyor":peer.status === "online" ? "Çevrimiçi" : peer.status === "busy" ? "Meşgul" : "Çevrimdışı";
  const mediaRoom=!own&&state.room?.kind==='direct'&&state.room.members?.some(m=>m.id===peer.id)?state.room.id:null;
  shell(own ? "Profilim" : escape(peer.name),
    `<div class="profile-hero fs-detail-hero"><div class="profile-photo-controls"><button type="button" class="profile-avatar-button" data-action="view-avatar" aria-label="Profil fotoğrafını görüntüle" title="${peer.avatar ? "Profil fotoğrafını görüntüle" : "Profil fotoğrafı yok"}" ${peer.avatar ? "" : "disabled"}>${avatar(peer, true)}</button>${own ? `<button type="button" class="profile-photo-change" data-action="profile-photo" aria-label="Profil resmini değiştir" title="Profil resmini değiştir">${icon("camera")}<span>Resmi değiştir</span></button><input id="profile-photo-file" type="file" accept="image/jpeg,image/png,image/webp" hidden>` : ""}</div><h2>${escape(peer.name)}</h2>${own?`<button class="status" data-action="status">${escape(status)}</button>`:`<span class="status ${status==='Çevrimiçi'?'is-online':''}">${escape(status)}</span>`}</div>`+
    group('Bilgi',`${!own&&peer.nick?`<div class="fs-profile-info"><span>@${escape(peer.nick)}</span><small>Kullanıcı adı</small></div>`:''}${peer.about?`<div class="fs-profile-info"><span>${escape(peer.about)}</span><small>Hakkında</small></div>`:''}`+(own?row("edit-profile", "edit", "Profili Düzenle")+row("qr", "qr", "QR Kodum")+row("username", "user", "Kullanıcı Adı", "@" + (peer.nick||'')):''))+
    (own?group('Ayarlar',row("settings", "settings", "Ayarlar")+row("saved", "bookmark", "Kayıtlı Mesajlar")+row("manage-folders", "menu", "Sohbet klasörleri")+row("media", "image", "Medya")+row("about", "info", "Hakkımda"))+
      group('Güvenlik',row("export-key", "key", "Şifreli anahtar yedeğini indir")+row("recover-history", "key", "Eski mesaj anahtarını kurtar")+row("privacy-policy", "shield", "Gizlilik politikası"))+
      group('Görünüm',`<div class="themes"><button data-action="dark" aria-pressed="${state.settings.theme !== 'light'}" class="${state.settings.theme !== 'light'?'active':''}">☾ Koyu</button><button data-action="light" aria-pressed="${state.settings.theme === 'light'}" class="${state.settings.theme === 'light'?'active':''}">☀ Açık</button></div>`):
      (mediaRoom?group('Ortak medya',`<button type="button" class="row" data-action="peer-media" data-id="${escape(mediaRoom)}">${icon('image')}<span class="copy">Fotoğraflar, videolar ve dosyalar</span>${icon('chevron')}</button>`):'')+
      group('Kişi işlemleri',row("mute-peer", "bell", (state.settings.mutedPeers || []).includes(peer.id) ? "Kişinin sesini aç" : "Kişiyi sessize al")+row("block-peer", "shield", "Kişiyi engelle")+row("contact-delete", "trash", "Kişiyi sil")))
  );
}
function settings() {
  if(isLocked())return;
  state.page = "settings";
  const group=(title,content)=>`<section class="fs-detail-group"><h3>${title}</h3>${content}</section>`;
  shell("Ayarlar",
    group('Bildirimler ve ses',row("notifications","bell","Bildirimler",state.settings.messageAlerts===false?"Mesaj bildirimleri kapalı · Çağrı ve sistem ayarları":"Mesaj bildirimleri açık · Çağrı ve sistem ayarları")+
      row("call-ringtones", "bell", "Çağrı zil sesi", ringtoneLabel(callRingtones.selected()))+row("call-mute", "bell", "Çağrı sesi", callRingtones.muted()?"Sessiz":"Açık")+row("call-voice", "mic", "Görüşme sesim", voiceLabel(selectedVoice(state.user?.id,localStorage))))+
    group('Gizlilik ve güvenlik',row("privacy","shield","Gizlilik ve Güvenlik","Giriş kilidi, görünürlük, aranabilirlik")+row("account-email","user","Hesap e-postası","E-posta ekle veya doğrula")+row("blocked","shield","Engellenen kişiler"))+
    group('Görünüm ve depolama',row("theme","moon","Tema",state.settings.theme === "light" ? "Açık" : "Koyu")+row("storage","file","Veri ve Depolama","Medya indirme ve bekleyen yüklemeler")+row("language","info","Dil","Türkçe"))+
    group('Uygulama',row("app-about","info","FS Mesajlaşma Hakkında","Sürüm 34.32 · Android")+row("third-party-licenses","info","Açık kaynak lisansları")+row("lock","lock","Uygulamayı kilitle")+row("logout","user","Hesaptan çıkış")));
}
async function showAccountEmail(){
 const epoch=access.epoch,user=state.user?.id;
 const valid=()=>access.valid(epoch)&&state.user?.id===user;
 const current=await api("/account/email");if(!valid())return;
 dialog("Hesap e-postası",`<form id="account-email-form"><p class="hint">${current.verified?"Mevcut adres doğrulandı.":"E-posta adresinizi doğrulayın."}</p>${field("email","E-posta adresi","email",current.email)}${field("password","Mevcut hesap şifresi","password")}<button class="primary" type="submit">Doğrulama kodu gönder</button></form>`);
 const form=$("#account-email-form");form.elements.email.autocomplete="email";
 form.onsubmit=async e=>{e.preventDefault();const submit=form.querySelector("button");if(submit.disabled||!valid())return;submit.disabled=true;
 try{await api("/account/email/start",{method:"POST",body:{email:form.elements.email.value.trim(),password:form.elements.password.value}});if(!valid()||!form.isConnected)return;
 dialog("E-posta doğrulama",`<form id="account-code-form"><p class="hint">E-postanıza gönderilen kodu girin. Kod 10 dakika geçerlidir.</p>${field("code","Doğrulama kodu")}<button class="primary" type="submit">Doğrula</button></form>`);
 const codeForm=$("#account-code-form");codeForm.elements.code.autocomplete="one-time-code";
 codeForm.onsubmit=async ev=>{ev.preventDefault();const b=codeForm.querySelector("button");if(b.disabled||!valid())return;b.disabled=true;try{await api("/account/email/finish",{method:"POST",body:{code:codeForm.elements.code.value.trim()}});if(valid()&&codeForm.isConnected){modal.close();notice("E-posta doğrulandı.",2000,"success");}}catch(err){if(valid()&&codeForm.isConnected)notice(err.message,4000,"error");}finally{b.disabled=false;}};
 }catch(err){if(valid()&&form.isConnected)notice(err.message,4000,"error");}finally{submit.disabled=false;}};
}
function showVoiceSettings(){
 const user=state.user?.id,epoch=access.epoch,c=state.call,selected=c?.voiceMode??selectedVoice(user,localStorage);
 if(c&&(!c.voiceCapture||c.incoming)){notice("Görüşmenin bağlanmasını bekle.",3000,"info");return;}
 dialog("Görüşme sesim",`<form id="call-voice-form"><p class="hint">Karşı tarafın duyacağı sesi seçin. ${c?'Görüşme kesilmeden uygulanır.':'Sonraki görüşmelerde geçerlidir.'} Dönüştürülmüş ses cihazda oluşturulur; sonuç cihazınıza göre değişebilir.</p><div class="ringtone-list">${VOICE_MODES.map(v=>`<div class="ringtone-option"><label><input type="radio" name="voice" value="${v.id}" ${v.id===selected?'checked':''}><span>${v.label}</span></label></div>`).join('')}</div><button class="primary" type="submit">${c?'Uygula':'Kaydet'}</button></form>`);
 $('#call-voice-form').onsubmit=async e=>{e.preventDefault();const form=e.target,submit=form.querySelector('button[type=submit]'),next=new FormData(form).get('voice');if(submit.disabled||!access.valid(epoch)||state.user?.id!==user||state.call!==c)return;submit.disabled=true;
 try{if(c){await c.voiceCapture.switchMode(next);if(state.call!==c||!access.valid(epoch))return;c.voiceMode=next;updateCallVoiceControls(c);}if(!saveVoice(user,next,localStorage)){notice("Ses tercihi kalıcı olarak kaydedilemedi.",3500,"error");return;}if(form.isConnected&&modal.open)modal.close();if(state.page==='settings')settings();notice("Görüşme sesi: "+voiceLabel(next),2000,"success");}catch(error){if(access.valid(epoch)&&state.call===c)notice(error.message||"Ses değiştirilemedi.",3500,"error");}finally{submit.disabled=false;}};
}
function updateCallVoiceControls(c){for(const b of document.querySelectorAll('.call [data-action="call-voice"]')){b.setAttribute('aria-label',voiceLabel(c.voiceMode));if(b.nextElementSibling)b.nextElementSibling.textContent=voiceLabel(c.voiceMode);}}
async function captureCallMedia(c,constraints,valid){
 c.voiceMode??=selectedVoice(state.user?.id,localStorage);
 const raw=await navigator.mediaDevices.getUserMedia(constraints);
 if(!valid()){raw.getTracks().forEach(t=>t.stop());return null;}
 raw.getAudioTracks().forEach(preferSpeech);
 c.pendingVoiceRaw=raw;
 let voice;try{voice=await createLiveCallVoice(raw,c.voiceMode,{onFailure:()=>{if(valid()){notice("Ses dönüştürme durdu; normal ses gönderilmedi.",4500,"error");endCall().catch(console.warn);}}});}finally{if(c.pendingVoiceRaw===raw)c.pendingVoiceRaw=null;}
 if(!valid()){voice.close();return null;}
 c.voiceCapture=voice;c.stream=voice.stream;return c.stream;
}
function showCallMuteSettings(){
 const muted=callRingtones.muted();
 dialog("Çağrı sesi",`<form id="call-mute-form"><label class="toggle">Gelen çağrıları sessize al<input name="muted" type="checkbox" ${muted?'checked':''}></label><p class="hint">Sesli ve görüntülü çağrılar görünmeye devam eder. Yalnız gelen çağrının zil sesi kapatılır; görüşme sesi ve aranabilirlik değişmez. Seçtiğiniz zil sesi korunur. Zil sesi ayarlarında Dinle düğmesiyle sesi önizleyebilirsiniz.</p>${window.FSNative?'<p class="hint">Android bildirim kanalı ve sistem ayarları geçerlidir. Sessiz kanalın sesini Android ayarlarından açmayın.</p>':''}<button type="submit" class="primary">Kaydet</button></form>`);
 $('#call-mute-form').onsubmit=e=>{e.preventDefault();const value=e.target.elements.namedItem('muted').checked;if(!callRingtones.saveMuted(value)){notice("Çağrı sesi ayarı kaydedilemedi.",4000,"error");return;}modal.close();if(state.page==='settings')settings();notice(value?"Çağrı sesi sessize alındı.":"Çağrı sesi açıldı.",2000,"success");};
}
function showRingtoneSettings(){
 const selected=callRingtones.selected();
 dialog("Çağrı zil sesi",`<form id="ringtone-form"><p class="hint">Gelen sesli ve görüntülü aramalar için bir zil sesi seçin. 30 saniye dinleyebilir veya istediğiniz anda durdurabilirsiniz. Bu ayar bu cihazda saklanır.</p><div class="ringtone-list">${[...RINGTONES,...(window.FSNative?.pickCallRingtoneFile?CUSTOM_RINGTONES:[])].map(t=>`<div class="ringtone-option"><label><input type="radio" name="ringtone" value="${t.id}" ${t.id===selected?'checked':''}><span>${t.label}${CUSTOM_RINGTONES.some(x=>x.id===t.id)&&!window.FSNative?.hasCallRingtoneFile?.(t.id)?" · Dosya seçilmedi":""}</span></label><button type="button" class="ringtone-preview" data-action="preview-ringtone" data-tone="${t.id}" aria-label="${t.label} zil sesini dinle">${icon("play")}<span>Dinle</span></button>${CUSTOM_RINGTONES.some(x=>x.id===t.id)?`<button type="button" class="secondary ringtone-file-picker" data-action="pick-ringtone-file" data-tone="${t.id}">Dosya seç</button>`:""}</div>`).join('')}</div><button type="button" class="secondary" data-action="stop-ringtone-preview">Dinlemeyi durdur</button><button type="submit" class="primary">Kaydet</button>${window.FSNative?.callRingtoneChannelSettings?'<button type="button" class="secondary" data-action="ringtone-system-settings">Android çağrı sesi ayarları</button><p class="hint">Android bildirim izni, zil sesi seviyesi, sessiz mod ve Rahatsız Etmeyin ayarları önceliklidir.</p>':''}</form>`);
 $('#ringtone-form').onsubmit=e=>{e.preventDefault();const id=new FormData(e.target).get("ringtone");if(!callRingtones.save(id)){notice("Zil sesi kaydedilemedi.",4000,"error");return;}callRingtones.stop();modal.close();if(state.page==='settings')settings();notice("Çağrı zil sesi kaydedildi.",2000,"success");};
}
async function patchSettings(p) {
  const r = await api("/me", { method: "PATCH", body: p });
  state.user = r.user;
  state.settings = r.settings;
  state.isAdmin = !!r.isAdmin;
  nativeSession();
  applyTheme();
  return r;
}
function nativeSession() {
  if(isLocked())return;
  window.FSNative?.session(
    apiRoot,
    state.token,
    state.settings.available !== false,
    state.settings.messageAlerts !== false,
  );
  if(window.FSNative?.notificationPrivacy)window.FSNative.notificationPrivacy(state.settings.notificationDetails===true,state.settings.notificationAvatars===true);
  else window.FSNative?.notificationDetails?.(state.settings.notificationDetails===true);
}
function applyTheme() {
  document.body.classList.toggle("light", state.settings.theme === "light");
}
async function savedPage() {
  if(isLocked())return;
  rememberChat();state.page='saved';
  const raw=await api('/saved');if(state.page!=='saved')return;
  state.saved=await Promise.all(raw.map(decode));
  shell('Kayıtlı Mesajlar',`<div class="library-tools"><input id="saved-query" aria-label="Kayıtlı mesajlarda ara" placeholder="Metin, etiket veya dosya ara"><select id="saved-room" aria-label="Sohbete göre filtrele"><option value="">Tüm sohbetler</option>${state.rooms.map(r=>`<option value="${r.id}">${escape(name(r))}</option>`).join('')}</select></div><div id="saved-results"></div>`);
  const draw=()=>{const q=$('#saved-query').value.toLocaleLowerCase('tr'),room=$('#saved-room').value;$('#saved-results').innerHTML=state.saved.filter(m=>!hiddenMessage(m)&&(!room||m.room===room)&&[preview(m.payload),localState.tags?.[m.id]||''].join(' ').toLocaleLowerCase('tr').includes(q)).map(m=>`<div class="note"><div>${escape(preview(m.payload))}</div><small>${new Date(m.created).toLocaleDateString('tr-TR')} · ${escape(localState.tags?.[m.id]||'Etiketsiz')}</small><div class="inline-actions"><button data-action="saved-original" data-id="${m.id}">Mesaja git</button><button data-action="saved-tag" data-id="${m.id}">Etiket</button>${button('unsave','trash','Kayıttan kaldır',`data-id="${m.id}"`)}</div></div>`).join('')||empty('Kayıtlı mesaj bulunamadı','Bir mesaja basılı tutup Kaydet seçeneğini kullan.');};
  $('#saved-query').oninput=draw;$('#saved-room').onchange=draw;draw();
}
let mediaCursor='',mediaLoading=false,mediaHasMore=true,mediaEpoch=0,mediaReturnPage='home',mediaRoomScope=null;
async function mediaPage(roomScope=undefined){
  if(isLocked())return;
 if(roomScope===undefined)roomScope=state.page==='media'?mediaRoomScope:null;
 if(roomScope&&!((state.page==='peer'||state.page==='media')&&state.room?.kind==='direct'&&state.room.id===roomScope))return;
 if(state.page!=='media')mediaReturnPage=state.page==='profile'?'profile':roomScope?'peer':'home';
 if(mediaRoomScope!==roomScope){state.mediaFilter="Tümü";state.mediaQuery="";state.mediaDate="";}
 mediaRoomScope=roomScope;
 rememberChat();mediaEpoch++;state.page='media';state.media=[];mediaCursor='';mediaLoading=false;mediaHasMore=true;
 shell(roomScope?'Ortak medya':'Medya',`<nav class="tabs fs-media-tabs">${['Tümü','Fotoğraflar','Videolar','Dosyalar',...(roomScope?['Bağlantılar']:[])].map(x=>`<button data-action="media-filter" data-filter="${x}" class="${state.mediaFilter===x?'active':''}" aria-pressed="${state.mediaFilter===x}">${x}</button>`).join('')}</nav><div class="library-tools"><input id="media-query" aria-label="Medya veya bağlantı ara" placeholder="Yüklenen içerikte ara"><label>Tarih<input id="media-date" type="date" aria-label="Medya tarihi"></label><button id="clear-media-date">Tarihi temizle</button></div><p id="media-status" role="status"></p><div class="gallery" id="gallery"></div><button class="secondary" data-action="media-more" id="media-more">Daha eski medya yükle</button><button class="secondary" data-action="download-all" ${state.mediaFilter==='Bağlantılar'?'hidden':''}>Yüklenen / filtrelenen dosyaları indir</button>`);
 $('#media-date').value=state.mediaDate;$('#media-query').value=state.mediaQuery;
 $('#media-date').oninput=e=>{state.mediaDate=e.target.value;renderGallery()};$('#media-query').oninput=e=>{state.mediaQuery=e.target.value;renderGallery()};$('#clear-media-date').onclick=()=>{state.mediaDate='';$('#media-date').value='';renderGallery()};
 await loadMediaPage();
}
async function loadMediaPage(){
 if(isLocked()||mediaLoading||!mediaHasMore||state.page!=='media')return;
 const scope=mediaRoomScope,links=state.mediaFilter==='Bağlantılar',epoch=mediaEpoch,accessEpoch=access.epoch,target=$('#gallery'),status=$('#media-status'),button=$('#media-more'),token=state.token,user=state.user?.id,root=apiRoot;
 if(!target||!status||!button)return;
 const valid=()=>!isLocked()&&access.valid(accessEpoch)&&state.page==='media'&&mediaEpoch===epoch&&state.token===token&&state.user?.id===user&&apiRoot===root&&target.isConnected&&$('#gallery')===target&&$('#media-status')===status&&$('#media-more')===button;
 mediaLoading=true;status.textContent='Medya yükleniyor…';button.disabled=true;
 try{
  if(links&&(!scope||state.room?.ratchet_cutover_active)){mediaHasMore=false;status.textContent='Güvenli sohbet bağlantıları bu görünümde henüz desteklenmiyor.';return;}
  const raw=await api((links?'/rooms/'+encodeURIComponent(scope)+'/messages':'/media')+mediaCursor);if(!valid())return;
  if(!Array.isArray(raw))throw Error('Geçersiz medya yanıtı.');
  if(links&&raw.some(m=>m.room!==scope))throw Error('Bağlantı kayıtları bu sohbetle eşleşmiyor.');
  const decoded=await Promise.all(raw.filter(m=>!scope||m.room===scope).map(decode));if(!valid())return;
  state.media=upsertMessages(state.media,decoded.filter(m=>links?sharedMessageLinks(m).length>0:m.payload.type==='file')).sort((a,b)=>b.created-a.created||b.id.localeCompare(a.id));mediaHasMore=raw.length===(links?80:100);
  if(raw.length){const last=links?raw[0]:raw.at(-1);const nextCursor='?before='+last.created+'&before_id='+encodeURIComponent(last.id);if(nextCursor===mediaCursor)mediaHasMore=false;mediaCursor=nextCursor;}renderGallery();
 }catch(error){if(!valid())return;status.textContent='Medya yüklenemedi. Daha eski medya yükle ile yeniden deneyin.';throw error;}
 finally{if(epoch===mediaEpoch&&access.valid(accessEpoch)&&state.token===token&&state.user?.id===user&&apiRoot===root)mediaLoading=false;if(valid()){button.disabled=false;button.hidden=!mediaHasMore;}}
}
function matchesMediaFilter(m){return state.mediaFilter!=='Bağlantılar'&&(!isViewOnce(m)&&!hiddenMessage(m)&&(!state.mediaDate||localDay(m.created)===state.mediaDate)&&(!state.mediaQuery||m.payload.name.toLocaleLowerCase('tr').includes(state.mediaQuery.toLocaleLowerCase('tr')))&&(state.mediaFilter==='Tümü'||state.mediaFilter==='Fotoğraflar'&&m.payload.mime.startsWith('image/')||state.mediaFilter==='Videolar'&&m.payload.mime.startsWith('video/')||state.mediaFilter==='Dosyalar'&&!/^(image|video)\//.test(m.payload.mime)));}
function filteredMedia(){return state.mediaFilter==='Bağlantılar'?[]:state.media.filter(matchesMediaFilter);}
function sharedMessageLinks(m){if(m.room!==mediaRoomScope||m.pending||m.callRecord||isViewOnce(m)||hiddenMessage(m)||!['text','file'].includes(m.payload?.type))return [];return [...new Map(urlParts(m.payload.text||'').filter(p=>p.url).map(p=>[p.url,p])).values()];}
function renderSharedLinks(target){const q=state.mediaQuery.toLocaleLowerCase('tr'),items=state.media.filter(m=>!state.mediaDate||localDay(m.created)===state.mediaDate).flatMap(m=>sharedMessageLinks(m).filter(p=>!q||[p.text,p.url].join(' ').toLocaleLowerCase('tr').includes(q)).map(p=>({m,p})));target.classList.add('fs-media-files');target.innerHTML=items.map(({m,p})=>`<div class="media-item fs-shared-link"><a href="${escape(p.url)}" data-action="open-link" data-url="${escape(p.url)}" target="_blank" rel="noopener noreferrer">${icon('clip')}<span><strong>${escape(new URL(p.url).hostname)}</strong><small>${escape(p.text)}</small><small>${new Date(m.created).toLocaleDateString('tr-TR')}</small></span></a></div>`).join('')||'<p class="hint">Yüklenen mesajlarda bağlantı bulunamadı. Daha eski mesajları yükleyebilirsiniz.</p>';$('#media-status').textContent=`${items.length} bağlantı · yalnızca bu sohbet`;}
function renderGallery(){const target=$('#gallery');if(!target)return;if(state.mediaFilter==='Bağlantılar'){renderSharedLinks(target);return;}const items=filteredMedia();target.classList.toggle("fs-media-files",state.mediaFilter==='Dosyalar');target.innerHTML=items.map(m=>`<div class="media-item"><button data-action="download" data-id="${m.id}">${m.payload.mime.startsWith('image/')?`<img loading="lazy" class="thumb ${state.settings.blur!==false?'blurred':''}" data-thumb="${m.id}" alt="${escape(m.payload.name)}">`:icon('file')}<p>${escape(m.payload.name)}</p><small>${new Date(m.created).toLocaleDateString('tr-TR')}</small></button><div class="transfer-state" data-transfer="${m.id}" role="status"></div></div>`).join('')||'<p class="hint">Yüklenen medya içinde eşleşme yok. Daha eski medyayı yükleyebilirsiniz.</p>';$('#media-status').textContent=`${state.media.length} dosya yüklendi · ${items.length} eşleşme`;loadThumbnails();}
function showOutbox(){dialog('Gönderim kuyruğu',`<p class="hint">Çevrimdışıyken gönderilen metinler cihazda şifreli tutulur. İnternet gelince aynı mesaj kimliğiyle gönderilir.</p>${localState.outbox.map(m=>`<div class="note"><p>${escape(m.payload.text)}</p><small>${escape(m.error||'Bağlantı bekleniyor')}</small><button data-action="cancel-outbox" data-id="${m.id}">Kuyruktan kaldır</button></div>`).join('')||'<p>Kuyruk boş.</p>'}<button class="primary" data-action="retry-outbox">Yeniden dene</button>`);}
function chatSearch(){const room=state.room.id;dialog('Sohbette ara',`<input id="chat-query" placeholder="Mesaj veya dosya adı" aria-label="Sohbette aranacak metin"><label>Tarih<input id="chat-date" type="date"></label><button class="secondary" data-action="search-history">Daha eski geçmişte ara</button><p id="chat-search-status" role="status"></p><div id="chat-search-results"></div>`);const draw=()=>{if(!$('#chat-query')||state.room?.id!==room)return;const items=searchMessages(state.messages.filter(m=>!hiddenMessage(m)),$('#chat-query').value,$('#chat-date').value);$('#chat-search-status').textContent=`Yüklenen ${state.messages.length} mesaj · ${items.length} eşleşme`;$('#chat-search-results').innerHTML=items.slice(-100).reverse().map(m=>`<button class="row" data-action="jump-message" data-id="${m.id}">${escape(preview(m.payload).slice(0,160))}<small>${new Date(m.created).toLocaleDateString('tr-TR')}</small></button>`).join('')||'<p>Eşleşme bulunamadı.</p>';};$('#chat-query').oninput=draw;$('#chat-date').oninput=draw;draw();}
async function searchHistory(){
 const room=state.room,route=state.routeVersion,epoch=access.epoch,token=state.token,user=state.user?.id,root=apiRoot,button=modal.querySelector('[data-action="search-history"]'),query=$('#chat-query');
 if(!room||!button||button.disabled||!query)return;
 const valid=()=>!isLocked()&&access.valid(epoch)&&state.token===token&&state.user?.id===user&&apiRoot===root&&state.page==='chat'&&state.room?.id===room.id&&state.routeVersion===route&&modal.open&&modal.contains(button)&&modal.querySelector('[data-action="search-history"]')===button&&$('#chat-query')===query;
 if(!valid())return;button.disabled=true;
 try{for(let batch=0;batch<10&&valid();batch++){
  const first=state.messages.filter(m=>m.room===room.id&&!m.callRecord&&!m.pending).sort((a,b)=>a.created-b.created||a.id.localeCompare(b.id))[0];if(!first)break;
  const rows=await api(`/rooms/${room.id}/messages?before=${first.created}&before_id=${encodeURIComponent(first.id)}`);if(!valid())return;
  if(!Array.isArray(rows)||rows.some(m=>m.room!==room.id))throw Error('Geçmiş kayıtları bu sohbetle eşleşmiyor.');
  const decoded=await Promise.all(rows.map(decode));if(!valid())return;
  state.messages=upsertMessages(state.messages,decoded);state.hasOlder=rows.length===80;renderMessages();if(valid())query.oninput();if(rows.length<80)break;
 }}catch(error){if(valid())throw error;}
 finally{if(valid())button.disabled=false;}
}
function restoreAudio(){for(const audio of document.querySelectorAll('audio[data-audio]')){const saved=localState.playback[audio.dataset.audio];audio.preload='none';if(saved?.rate)audio.playbackRate=saved.rate;bindVoicePlayer(audio);if(audio._fsPlaybackBound)continue;audio._fsPlaybackBound=true;audio.addEventListener('loadedmetadata',()=>{const position=localState.playback[audio.dataset.audio];if(position?.time&&audioDuration(audio))audio.currentTime=Math.min(position.time,Math.max(0,audioDuration(audio)-.1));});audio.addEventListener('timeupdate',()=>{if(!audio.seeking){localState.playback[audio.dataset.audio]={time:audio.currentTime,rate:audio.playbackRate};}});audio.addEventListener('pause',()=>{rememberPlayback();persistLocal()});audio.addEventListener('ended',()=>{localState.playback[audio.dataset.audio]={time:0,rate:audio.playbackRate};persistLocal()});}}

let reconnectTimer = null,reconnectFailures=0;
// TCP/WebSocket open alone does not establish an authenticated session.
function watchSocketHandshake(ws,active,{schedule=setTimeout,cancel=clearTimeout,ms=20000}={}){
  let timer=schedule(()=>{timer=null;if(active())ws.close(4000,"Handshake timeout");},ms);
  return ()=>{if(timer!==null){cancel(timer);timer=null;}};
}
function clearReconnect(reset=false){clearTimeout(reconnectTimer);reconnectTimer=null;if(reset)reconnectFailures=0;}
function scheduleReconnect(){
 if(isLocked()||!state.token||reconnectTimer!==null)return;
 const delay=reconnectDelay(reconnectFailures,{online:navigator.onLine!==false,activeCall:!!state.call});if(delay===null)return;
 reconnectFailures=Math.min(5,reconnectFailures+1);const epoch=access.epoch,token=state.token;
 reconnectTimer=setTimeout(()=>{reconnectTimer=null;if(access.valid(epoch)&&state.token===token&&navigator.onLine!==false)connect();},delay);
}
window.addEventListener('offline',()=>clearReconnect());
let callSignalQueue = Promise.resolve();
function queuedCallSignal(b,guard=()=>true) {
  const epoch=access.epoch;
  if(!access.valid(epoch))return Promise.resolve();
  callSignalQueue = callSignalQueue.then(() => {if(access.valid(epoch)&&guard())return callSignal(b)}).catch(async err => { if(!access.valid(epoch)||!callEventMatches(state.call,b))return;if(err instanceof CallSignalUnavailable&&(state.call?.pc?.remoteDescription||state.call?.pc?.localDescription?.type==="offer")){void state.call.recovery?.tick();return;}console.warn("call", err.message); await endCall(); notice("Görüşme kurulamadı. Mikrofon/kamera izinlerini ve bağlantıyı kontrol edin."); });
  return callSignalQueue;
}
// A response from an earlier foreground/connection epoch must not replace a newer call.
async function reconcileCurrentCall(epoch,ws=null){
  const before=state.call;
  if(before?.group)return false;
  const current=await api("/calls/current");
  const valid=()=>access.valid(epoch)&&state.call===before&&(!ws||state.socket===ws);
  if(!valid())return false;
  if(before?.offerer&&!before.started&&current?.alertStatus&&current.callId===before.callId)applyCallAlertStatus(before,current.alertStatus);
  const action=currentCallAction(before,current);
  if(action==="open"){await queuedCallSignal(current,valid);return true;}
  if(action==="close"){
    await queuedCallSignal({type:"hangup",room:before.room.id,callId:before.callId},()=>valid()&&!before.accepting&&before.incoming);
    // On waking up, a newer invitation may have replaced a missed call.
    // Re-read after closing instead of opening an old HTTP response.
    if(access.valid(epoch)&&(!ws||state.socket===ws)&&!state.call&&currentCallAction(null,current)==="open")return reconcileCurrentCall(epoch,ws);
  }
  return false;
}
const batchRoomRefresh=createRefreshBatch(()=>refreshRooms());
const batchMessageRefresh=createRefreshBatch(({route})=>loadMessages(route));
function scheduleRefresh(){const epoch=access.epoch;return batchRoomRefresh(epoch,null,()=>access.valid(epoch)&&!isLocked());}
function refreshHomeReceipts(epoch){
 if(!access.valid(epoch)||isLocked()||!state.rooms.some(r=>Number.isSafeInteger(r.unread_delivered_count)))return;
 scheduleRefresh().then(()=>{if(access.valid(epoch)&&state.page==='home'&&state.tab==='Sohbetler')return homeList();}).catch(error=>console.warn('home receipts',error.message));
}
function scheduleMessageRefresh(){const epoch=access.epoch,route=state.routeVersion,room=state.room?.id;return batchMessageRefresh(`${epoch}:${route}`,{route},()=>access.valid(epoch)&&!isLocked()&&state.routeVersion===route&&state.room?.id===room&&state.page==='chat');}
function animateDeletedRows(ids){
 const list=$("#messages");if(!list||!ids.length||window.matchMedia?.("(prefers-reduced-motion: reduce)").matches)return;
 const root=list.closest('.fs-chat');if(!root)return;
 const wanted=new Set(ids),bounds=list.getBoundingClientRect(),box=root.getBoundingClientRect();
 const overlay=document.createElement('div');overlay.className='fs-delete-fragments';overlay.setAttribute('aria-hidden','true');overlay.inert=true;overlay.style.clipPath=`inset(${Math.max(0,bounds.top-box.top)}px ${Math.max(0,box.right-bounds.right)}px ${Math.max(0,box.bottom-bounds.bottom)}px ${Math.max(0,bounds.left-box.left)}px)`;
 let count=0;const rendered=[...list.querySelectorAll('[data-message]')].filter(node=>{const id=node.dataset.message;const row=virtualMessages?.rows[virtualMessages.indices.get(id)];const members=row?.callIds?.length?row.callIds:row?.albumIds?.length?row.albumIds:[id];return members.every(member=>wanted.has(member));});
 for(const node of rendered){
  const r=node.getBoundingClientRect(),top=Math.max(r.top,bounds.top),bottom=Math.min(r.bottom,bounds.bottom);if(bottom<=top||r.width<1)continue;
  // Clone only the visible bubble, never active video/audio, iframes or interactive controls.
  const clone=node.cloneNode(true);clone.classList.remove('selected','swiping','reply-armed');const style=window.getComputedStyle(node);for(const prop of ['background','color','border','borderRadius','padding','fontFamily','fontSize','lineHeight','fontWeight','overflowWrap','wordBreak','textAlign','display'])clone.style[prop]=style[prop];clone.style.boxShadow='none';
  for(const el of [clone,...clone.querySelectorAll('*')]){for(const attr of [...el.attributes])if(attr.name==='id'||attr.name==='tabindex'||attr.name.startsWith('data-')||attr.name.startsWith('on'))el.removeAttribute(attr.name);}
  for(const el of clone.querySelectorAll('audio,video,iframe,object,embed,source,input,textarea')){const label=document.createElement('span');label.textContent=el.tagName==='AUDIO'?'Sesli mesaj':'Medya';el.replaceWith(label);}
  for(const img of clone.querySelectorAll('img'))if(!img.complete||!img.naturalWidth||!img.getAttribute('src'))img.remove();
  const columns=Math.max(1,Math.min(4,Math.ceil(r.width/65))),rows=Math.max(1,Math.min(3,Math.ceil((bottom-top)/45)));const tileCount=columns*rows;
  const budget=count+tileCount<=96?tileCount:1;if(count>=128)break;
  for(let k=0;k<budget;k++){
   const x=budget===1?0:k%columns,y=budget===1?0:Math.floor(k/columns),left=r.width*x/(budget===1?1:columns),right=r.width*(x+1)/(budget===1?1:columns),a=top-r.top+(bottom-top)*y/(budget===1?1:rows),b=top-r.top+(bottom-top)*(y+1)/(budget===1?1:rows);
   const tile=document.createElement('div');tile.className='fs-delete-fragment';Object.assign(tile.style,{left:`${r.left-box.left+left}px`,top:`${r.top-box.top+a}px`,width:`${right-left}px`,height:`${b-a}px`});
   const piece=clone.cloneNode(true);Object.assign(piece.style,{position:'absolute',left:`${-left}px`,top:`${-a}px`,width:`${r.width}px`,height:`${r.height}px`,maxWidth:'none',margin:'0',boxSizing:'border-box',transform:'none',animation:'none'});tile.append(piece);
   tile.style.setProperty('--delete-x',`${(Math.random()-.5)*94}px`);tile.style.setProperty('--delete-y',`${-25-Math.random()*68}px`);tile.style.setProperty('--delete-r',`${(Math.random()-.5)*28}deg`);overlay.append(tile);count++;
  }
 }
 if(!count)return;
 // FLIP surviving rows only, after the same synchronous render that removes the originals.
 const oldPositions=new Map([...list.querySelectorAll('[data-row-id]')].map(row=>[row.dataset.rowId,row.getBoundingClientRect().top]));
 root.append(overlay);const epoch=access.epoch,route=state.routeVersion;let frame=0;requestAnimationFrame(()=>{if(!overlay.isConnected||!access.valid(epoch)||state.routeVersion!==route||isLocked()||list.classList.contains('selection-gesture'))return;for(const row of list.querySelectorAll('[data-row-id]')){const old=oldPositions.get(row.dataset.rowId),rect=row.getBoundingClientRect();if(!Number.isFinite(old)||rect.bottom<bounds.top||rect.top>bounds.bottom)continue;const dy=old-rect.top;if(Math.abs(dy)>1&&Math.abs(dy)<bounds.height)row.animate?.([{transform:`translateY(${dy}px)`},{transform:'translateY(0)'}],{duration:200,easing:'cubic-bezier(.22,.65,.45,1)'});}});const dispose=()=>{cancelAnimationFrame(frame);overlay.remove();document.removeEventListener('visibilitychange',hidden);};const hidden=()=>{if(document.hidden)dispose();};document.addEventListener('visibilitychange',hidden);const started=performance.now();const check=now=>{if(!overlay.isConnected||!access.valid(epoch)||state.routeVersion!==route||isLocked()||document.hidden||now-started>440)dispose();else frame=requestAnimationFrame(check);};frame=requestAnimationFrame(check);
}
function removeDeletedBatch(ids){
  const unique=[...new Set(ids)].filter(id=>typeof id==="string"&&!deletedInSession.has(id));if(!unique.length)return;
  animateDeletedRows(unique);for(const id of unique)removeDeletedMessage(id,true);
  if(state.page==='media')renderGallery();persistLocal();
}
function removeDeletedMessage(id,batch=false,markDeleted=true){
 if(messageMenuSession?.id===id){if(modal.open&&modal.classList.contains("message-context"))modal.close();clearMessageMenu();}
  if(!isLocked()&&state.token&&state.identity){try{const downloads=currentDownloadStore();serialDownload(()=>downloads.remove(id)).catch(reportDownloadError);}catch{}}
 if(modal.querySelector("[data-message-history]")?.dataset.messageHistory===id){modal.close();modal.innerHTML="";}
 if(markDeleted){deletedInSession.add(id);if(deletedInSession.size>20000)deletedInSession.delete(deletedInSession.values().next().value);}deletedRevision++;
 if(albumViewer?.ids.has(id))dismissAlbumViewer();else if(state.openMediaId===id&&modal.open){if(modal._fsVideoViewer)closeAlbumViewer();modal.close();}state.media=state.media.filter(m=>m.id!==id);state.saved=(state.saved||[]).filter(m=>m.id!==id);state.cache.delete(id);state.messages=state.messages.filter(m=>m.id!==id);state.selected.delete(id);
 if(state.reply?.id===id){state.reply=null;renderReply();rememberChat();}
 for(const room of Object.keys(localState.pages))localState.pages[room]=localState.pages[room].filter(m=>m.id!==id);
 for(const draft of Object.values(localState.drafts))if(draft.reply===id)draft.reply=null;
 for(const cache of [thumbnailUrls,audioUrls])cache.delete(id);
 if(localState.preferences.pinnedMessages)for(const room of Object.keys(localState.preferences.pinnedMessages))if(localState.preferences.pinnedMessages[room]===id)delete localState.preferences.pinnedMessages[room];
 if(localState.tags)delete localState.tags[id];if(localState.playback)delete localState.playback[id];
 for(const room of state.rooms)if(room.last?.id===id)room.last=null;
 if(localState.outbox)localState.outbox=localState.outbox.filter(m=>m.id!==id);
 if(modal.open&&modal.querySelector('#chat-query'))$('#chat-query').oninput?.();
 if(state.page==='saved'&&$('#saved-query'))$('#saved-query').oninput?.();
 if(!batch){if(state.page==='media')renderGallery();persistLocal();}
}
function peerPresenceLabel(peer){if(state.presenceStale===true)return 'Durum doğrulanamadı';if(peer?.status==='online')return 'Çevrimiçi';if(peer?.status==='busy')return 'Meşgul';const stamp=peer?.last_seen;if(Number.isSafeInteger(stamp)&&stamp>0&&stamp<=Date.now()&&Date.now()-stamp<=7*86400000)return 'Son görülme '+new Date(stamp).toLocaleString('tr-TR',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'});return 'Çevrimdışı';}
function updateChatPeer(){
 if(isLocked()||state.page!=="chat"||!state.room)return;
 typing.update();
 const peer=state.room.members.find(m=>m.id!==state.user.id);
 if(!peer)return;
 const status=document.querySelector('.chat-head [data-action="status"]'),photo=document.querySelector('.chat-head [data-action="peer-profile"]');
 if(status){status.textContent=state.room.kind==="group"?`${state.room.members.length} üye`:peerPresenceLabel(peer);status.dataset.peerOnline=String(state.room.kind==='direct'&&state.presenceStale!==true&&peer?.status==='online');}
 if(photo)photo.innerHTML=state.room.kind==="group"?avatar({name:name(state.room)}):avatar(peer);
}
function markPresenceStale(){state.presenceStale=true;if(isLocked())return;document.querySelectorAll(".home-presence").forEach(e=>e.remove());if(state.page==="chat")updateChatPeer();if(state.page==="home"&&modal.open)modal.querySelector("#home-search-form #search-text")?.oninput?.();}
function connect() {
  if(isLocked())return;
  if(navigator.onLine===false)return;
  clearReconnect();
  if (state.socket && [WebSocket.OPEN, WebSocket.CONNECTING].includes(state.socket.readyState)) return;
  state.socket?.close();
  if (!state.token) return;
  const url = new URL(apiRoot);
  url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
  url.pathname = url.pathname.replace(/\/$/, "") + "/api/socket";
  let ws;try{ws=new WebSocket(url);}catch(error){console.warn("socket",error.message);scheduleReconnect();return;}
  state.socket = ws;
  const epoch=access.epoch;
  const stopHandshake=watchSocketHandshake(ws,()=>access.valid(epoch)&&state.socket===ws);
  ws.onopen = () => {if(access.valid(epoch)&&state.socket===ws)ws.send(JSON.stringify({ token: state.token, callIds:true, groupCalls:true, presenceSocket:true,batchDelete:true }));else ws.close();};
  ws.onmessage = async (e) => {
    if(!access.valid(epoch)||state.socket!==ws)return;
    try {
      const b = JSON.parse(e.data);
      if(typeof b.type==="string"&&b.type.startsWith("group-call-")){await queuedGroupSignal(b,epoch,ws);return;}
      if(b.type==="session-revoked"){await actions("logout");notice("Hesabına başka bir kurulumdan giriş yapıldı. Bu cihazdaki oturum kapatıldı.",5000,"info");return;}
      if(b.type==="stories-changed-v1"){if(state.storiesEnabled&&state.page==="home"&&state.tab==="Sohbetler")storyController?.refresh();return;}
      if(b.type===TYPING_EVENT||b.type===RECORDING_EVENT){typing.receive(b);return;}
      if(b.type===EMOJI_EVENT){await receiveEmojiInteraction(b,epoch);return;}
      if(b.type==="receipt-v2"){
        const merge=m=>m&&m.id===b.id&&m.room===b.room&&m.sender===state.user.id?{...m,receipts_v2:mergeReceipts(m.receipts_v2,[b.receipt])}:m;
        const cached=state.cache.get(b.id);if(cached)state.cache.set(b.id,merge(cached));
        const summary=state.rooms.find(r=>r.id===b.room);if(summary?.last){const next=merge(summary.last);if(next!==summary.last){summary.last=next;if(state.page==='home'&&state.tab==='Sohbetler')homeList().catch(error=>console.warn('home receipt',error.message));}}
        if(b.room===state.room?.id&&state.page==="chat"){state.messages=state.messages.map(merge);storePage(b.room,state.messages);renderMessages();}
        else if(localState.pages[b.room]){localState.pages[b.room]=localState.pages[b.room].map(merge);persistLocal();}return;}
      if(b.type==="read"){state.messages=state.messages.map(m=>m.room===b.room&&m.created<=b.ts?{...m,read_by:[...new Set([...(m.read_by||[]),b.from])]}:m);if(state.page==="chat"&&state.room?.id===b.room){storePage(b.room,state.messages);renderMessages();}return;}
      if (
        b.type === "message" ||
        b.type === "rooms" ||
        b.type === "profile"
      ) {
        if (b.deleted&&Array.isArray(b.ids)&&b.ids.length<=1000){removeDeletedBatch(b.ids);if(state.page==="chat"&&b.room===state.room?.id)renderMessages();}
        else if (b.deleted&&b.id){removeDeletedBatch([b.id]);if(state.page==="chat"&&b.room===state.room?.id)renderMessages();}
        await scheduleRefresh();
        if(!access.valid(epoch)||state.socket!==ws)return;
        if(b.type==="message"||b.type==="rooms")scheduleDelivery();
        if (b.type === "profile" && state.page === "chat") updateChatPeer();
        if (
          state.page === "chat" &&
          !state.rooms.some((r) => r.id === state.room?.id)
        ) {
          state.cache.clear();
          home();
          return;
        }
        if (state.page === "home") homeList();
        if (state.page === "chat" && b.room === state.room.id)
          await scheduleMessageRefresh();
        if(b.type==="message"&&b.from!==state.user?.id&&b.room===state.room?.id&&state.page==="chat"&&!b.deleted){const m=state.messages.find(x=>x.id===b.id);if(m?.payload?.effect)playSendEffect(m.id,m.payload.effect,m.payload.effectVariant);}
      } else if (b.type === "connected") {
        stopHandshake();
        reconnectFailures=0;presenceAuthenticated = true;state.storiesEnabled=Array.isArray(b.features)&&b.features.includes("stories-v1");if(state.storiesEnabled&&state.page==="home"&&state.tab==="Sohbetler")attachStories();state.viewOnce=Array.isArray(b.features)&&b.features.includes("view-once-v1");state.sendOptions=Array.isArray(b.features)&&b.features.includes("send-options-v1");state.presenceSocket=Array.isArray(b.features)&&b.features.includes("presence-socket-v2");presenceSent=null;state.groupCalls=Array.isArray(b.features)&&b.features.includes("group-call-v1");state.durableDownload=Array.isArray(b.features)&&b.features.includes("durable-download-v1");state.durableUpload=Array.isArray(b.features)&&b.features.includes("durable-upload-v1");state.deliverySync=Array.isArray(b.features)&&b.features.includes("delivery-sync-v1");state.messageDetails=Array.isArray(b.features)&&b.features.includes("message-details-v1");state.typingEnabled=Array.isArray(b.features)&&b.features.includes(TYPING_EVENT);state.recordingStatusEnabled=Array.isArray(b.features)&&b.features.includes(RECORDING_EVENT);state.callIds=Array.isArray(b.features)&&b.features.includes("call-id-v1");state.presenceLease=Array.isArray(b.features)&&b.features.includes("presence-lease-v1");state.emojiRealtime=Array.isArray(b.features)&&b.features.includes(EMOJI_EVENT);state.directDelete=Array.isArray(b.features)&&b.features.includes("direct-delete-everyone-v1");state.batchDelete=Array.isArray(b.features)&&b.features.includes("batch-delete-v1");state.historyEveryone=Array.isArray(b.features)&&b.features.includes("history-clear-everyone-v1");state.callHistoryHide=Array.isArray(b.features)&&b.features.includes("call-history-hide-v1");state.messageCacheCheck=Array.isArray(b.features)&&b.features.includes("message-cache-check-v1");syncPresence(true);
        scheduleRefresh().then(()=>{
          if(!access.valid(epoch)||state.socket!==ws)return;
          scheduleDelivery();uploadRecovery.kick();downloadRecovery.kick();
          if(state.page==="chat"&&state.room){
            if(!state.rooms.some(r=>r.id===state.room.id)){home();return;}
            updateChatPeer();return scheduleMessageRefresh();
          }else if(state.page==="home")homeList();
        }).catch(error=>console.warn("reconnect refresh",error.message));
        wakeCallRecovery();
        await reconcileCurrentCall(epoch,ws);
        if(!access.valid(epoch)||state.socket!==ws)return;
        flushOutbox().catch(error=>console.warn("outbox",error.message));
      } else if(b.type==="call"&&b.from===state.user.id&&state.call?.offerer&&callEventMatches(state.call,b)){
        if(state.call.phase==="Bağlanıyor…"&&!state.call.started&&!state.call.alertAccepted){state.call.phase="Aranıyor…";if(state.page==="call")showCall();}
      } else if (b.from !== state.user.id || (b.type === "call-rejected" && state.call?.incoming && b.callId === state.call.callId)) await queuedCallSignal(b,()=>state.socket===ws);
    } catch (err) {
      console.error("event", err.message);
    }
  };
  ws.onclose = () => {
    stopHandshake();
    if (state.socket !== ws) return;
    state.socket = null;state.groupCalls=false;resetDelivery();state.durableUpload=false;state.viewOnce=false;state.messageDetails=false;state.typingEnabled=false;state.recordingStatusEnabled=false;typing.reset();state.callIds=false;state.emojiRealtime=false;state.directDelete=false;state.batchDelete=false;state.historyEveryone=false;state.callHistoryHide=false;state.messageCacheCheck=false;
    presenceAuthenticated=false;state.presenceLease=false;state.presenceSocket=false;presenceSent=null;if(state.user)state.user.status="offline";markPresenceStale();
    scheduleReconnect();
  };
}
function wakeCallRecovery(){const c=state.call;if(!c||isLocked())return;if(c.group)c.mesh?.wake();else void c.recovery?.wake();}
window.addEventListener("online",wakeCallRecovery);
function signal(b) {
  if (state.socket?.readyState !== 1 || !presenceAuthenticated)
    throw new CallSignalUnavailable("Bağlantı kesik. Yeniden bağlanmayı bekleyin.");
  const id=b.callId??state.call?.callId;
  try{state.socket.send(JSON.stringify(id?{...b,callId:id}:b));}catch{throw new CallSignalUnavailable("Arama sinyali gönderilemedi.");}
}
let groupSignalQueue=Promise.resolve();
function queuedGroupSignal(b,epoch,ws){
 groupSignalQueue=groupSignalQueue.then(async()=>{if(access.valid(epoch)&&state.socket===ws)await groupSignal(b)}).catch(async err=>{if(access.valid(epoch)&&state.socket===ws&&state.call?.group&&state.call.callId===b.callId){if(err instanceof CallSignalUnavailable&&state.call.mesh){state.call.mesh.wake();return;}await endCall();notice("Grup bağlantısı kurulamadı.",4000,"error");}});return groupSignalQueue;
}
function groupCallRecord(room,callId,video,incoming,host){return {group:true,room,callId,video,incoming,host,participants:{[host]:"joined",...(incoming?{[state.user.id]:"ringing"}:{})},phase:incoming?"Gelen grup araması":"Aranıyor…"};}
async function setupGroupMedia(c){
 if(c.mesh)return;
 const epoch=access.epoch,valid=()=>access.valid(epoch)&&state.call===c;
 const config=await api("/config");if(!valid())return;
 const stream=await captureCallMedia(c,{audio:audioCaptureConstraints(),video:c.video?videoCaptureConstraints():false},valid);
 if(!stream||!valid())return;
 stream.getVideoTracks().forEach(preferVideoDetail);stream.getAudioTracks().forEach(preferSpeech);c.stream=stream;
 c.mesh=new GroupMesh({self:state.user.id,stream,iceServers:config.iceServers,valid,canSignal:()=>state.socket?.readyState===1&&presenceAuthenticated,send:(to,kind,payload)=>signal({type:"group-call-signal",room:c.room.id,callId:c.callId,to,kind,...payload}),change:()=>attachGroupMedia(c),failed:()=>notice("Bir grup katılımcısının bağlantısı kesildi.",3500,"info")});
 window.FSNative?.activeCall(true,c.video);attachGroupMedia(c);
}
async function startGroupCall(room,video){
 if(!state.groupCalls)throw Error("Grup araması için güncel sunucu gerekli.");
 if(room.members.length<3||room.members.length>4)throw Error("Grup görüşmeleri 3–4 üyeli sohbetlerde kullanılabilir.");
 const c=groupCallRecord(room,crypto.randomUUID().replaceAll("-",""),video,false,state.user.id);state.call=c;showCall();
 try{await setupGroupMedia(c);if(state.call===c)signal({type:"group-call-start",room:room.id,callId:c.callId,video});}catch(err){if(state.call===c)await endCall(false);throw err;}
}
async function groupSignal(b){
 if(isLocked())return;
 let c=state.call;
 if(b.type==="group-call-none"){if(c?.group&&c.groupAcknowledged)await endCall(false);return;}
 if(!state.groupCalls)return;
 if(b.type==="group-call-invite"){
  if(c?.group&&c.callId===b.callId)return;
  const reject=()=>signal({type:"group-call-leave",room:b.room,callId:b.callId});
  if(c||state.settings.available===false){reject();return;}
  const epoch=access.epoch;let room=state.rooms.find(r=>r.id===b.room);
  if(!room){await refreshRooms();if(!access.valid(epoch))return;room=state.rooms.find(r=>r.id===b.room);}
  if(state.call||!room||room.kind!=="group"||!room.members.some(m=>m.id===b.from)||state.settings.available===false){reject();return;}
  c=groupCallRecord(room,b.callId,b.video,true,b.from);state.call=c;if(modal.open)modal.close();callRingtones.stop();
  const silent=(state.settings.mutedPeers||[]).includes(b.from)||(state.settings.mutedRooms||[]).includes(b.room);
  if(typeof window.FSNative?.presentIncomingCall==='function'&&b.callId)window.FSNative.presentIncomingCall(b.callId,!!b.video,silent);
  else if(!silent)callRingtones.incoming();
  showCall();return;
 }
 if(!c?.group||c.callId!==b.callId||c.room.id!==b.room){if(!c&&b.type==="group-call-state"&&b.participants?.[state.user.id]==="joined")signal({type:"group-call-leave",room:b.room,callId:b.callId});return;}
 if(b.type==="group-call-end"){await endCall(false);if(b.reason==="unavailable")notice("Uygun grup katılımcısı bulunamadı.",3500,"info");return;}
 if(b.type==="group-call-state"){
  const members=new Set(c.room.members.map(m=>m.id));const peers=Object.entries(b.participants||{}).filter(([id,v])=>members.has(id)&&["joined","ringing"].includes(v)).slice(0,4);
  c.groupAcknowledged=true;c.participants=Object.fromEntries(peers);
  if(!c.participants[state.user.id]){await endCall(false);return;}
  if(!c.incoming)await c.mesh?.update(peers.filter(([,v])=>v==="joined").map(([id])=>id));
  if(state.call===c){if(state.page==="call")showCall();else attachGroupMedia(c);}return;
 }
 if(b.type==="group-call-signal"&&c.room.members.some(m=>m.id===b.from))await c.mesh?.handle(b);
}
function attachGroupMedia(c){
 if(isLocked()||state.call!==c)return;
 const remotes=[...(c.mesh?.peers||[])];c.remote=remotes.find(([,p])=>p.remote?.getVideoTracks().length)?.[1].remote||remotes.find(([,p])=>p.remote)?.[1].remote;
 const attach=(el,stream,muted)=>{if(!el)return;if(el.srcObject!==(stream||null))el.srcObject=stream||null;el.muted=muted;if(stream)el.play?.().catch(()=>{});};
 let audioBox=$("#fs-group-background");
 if(state.page==="call"){
  audioBox?.remove();for(const el of app.querySelectorAll("[data-group-peer]")){const id=el.dataset.groupPeer,p=c.mesh?.get(id),local=id===state.user.id;attach(el,local?c.stream:p?.remote,local);el.hidden=!el.srcObject;}
  for(const el of app.querySelectorAll("[data-group-status]")){const id=el.dataset.groupStatus,p=c.mesh?.get(id);el.textContent=id===state.user.id?"Sen":c.participants[id]==="ringing"?"Aranıyor…":p?.pc.connectionState==="connected"?(p.networkLabel||"Bağlandı"):p?.pc.connectionState==="failed"||p?.pc.connectionState==="disconnected"?(p.recoveryExpired?"Bağlantı kesildi":"Yeniden bağlanıyor…"):"Bağlanıyor…";}
 }else{
  attach($("#call-mini"),c.remote,true);
  if(!audioBox){audioBox=document.createElement("div");audioBox.id="fs-group-background";app.append(audioBox);}
  for(const el of audioBox.querySelectorAll("audio"))if(!c.mesh?.get(el.dataset.groupPeer)?.remote)el.remove();
  for(const [id,p] of remotes){if(!p.remote)continue;let el=[...audioBox.children].find(x=>x.dataset.groupPeer===id);if(!el){el=document.createElement("audio");el.autoplay=true;el.dataset.groupPeer=id;audioBox.append(el);}attach(el,p.remote,false);}
 }
}
function showGroupCall(c){
 let audio={};try{audio=JSON.parse(window.FSNative?.audioState?.()||"{}");}catch{}
 const controls=[["mute","mic",c.voiceCapture?.muted?"Mikrofon Kapalı":"Mikrofon Açık",""],...(c.video?[["camera-toggle","video",c.stream?.getVideoTracks().some(t=>t.enabled)?"Kamera Açık":"Kamera Kapalı",""]]:[]),...(audio.bluetooth?[["bluetooth","bluetooth","Bluetooth",audio.route==="bluetooth"?"on":""]]:[]),["speaker",callAudioIcon(audio.route),callAudioLabel(audio.route),audio.route==="speaker"?"on":""],["call-voice","mic",voiceLabel(c.voiceMode??selectedVoice(state.user?.id,localStorage)),""],["end-call","phone","Kapat","red"]];
 const members=c.room.members.filter(m=>c.participants[m.id]);
 app.innerHTML=`<section class="call fs-premium fs-group-call"><header>${button("call-back","back","Sohbete dön")}<h1>${escape(c.room.title||"Grup görüşmesi")}<small>${c.video?"Görüntülü":"Sesli"} grup araması</small></h1></header><div class="group-tiles">${members.map(m=>`<div class="group-tile">${avatar(m,true)}${c.video?`<video autoplay playsinline hidden data-group-peer="${escape(m.id)}"></video>`:`<audio autoplay hidden data-group-peer="${escape(m.id)}"></audio>`}<div class="group-label">${escape(m.name)}<small data-group-status="${escape(m.id)}"></small></div></div>`).join("")}</div><div class="controls">${controls.map(([a,i,l,cl])=>`<div class="control"><button data-action="${a}" class="${cl}" aria-label="${l}">${icon(i)}</button><span>${l}</span></div>`).join("")}</div></section>`;
 attachGroupMedia(c);clearInterval(state.callTimer);clearTimeout(state.controlsTimer);
 if(c.video&&!c.incoming){applyCallControls(c);$(".group-tiles").onclick=()=>{Object.assign(c,callControlState(c,Date.now(),true));applyCallControls(c);};}
}

async function startCall(video) {
  if(isLocked())return;
  if(!presenceAuthenticated)throw Error("Bağlantı kuruluyor. Biraz sonra tekrar deneyin.");
  const room = state.room;
  if (!room) throw Error("Önce bir sohbet açın.");
  if (state.call) throw Error("Zaten bir görüşmedesin.");
  if(room.kind!=="direct")return startGroupCall(room,video);
  state.call = {
    room,
    callId:state.callIds?crypto.randomUUID().replaceAll("-",""):null,
    video,
    phase: "Bağlanıyor…",
    offerer:true,
    incoming: false,
    started: null,
    peer: room.members.find((x) => x.id !== state.user.id),
  };
  try { signal({ type: "call", room: room.id, video }); } catch(err) { state.call = null; throw err; }
  const dialing=state.call;
  outgoingRingback.start(dialing,{valid:()=>state.call===dialing&&!isLocked(),onError:()=>notice("Arama bekleme sesi başlatılamadı.",3500,"error"),onTimeout:()=>{if(state.call===dialing){void endCall().catch(console.warn);notice(dialing.phase==="Aranıyor…"||dialing.phase==="Bağlanıyor…"?"Aramanın karşı cihaza ulaştığı doğrulanamadı.":"Arama yanıtlanmadı.",3500,"info");}}});
  showCall();
}
function applyCallAlertStatus(call,status){
  if(!applyAlertReceipt(call,status))return;
  if(state.call===call&&state.page==="call"){const el=$("#call-timer");if(el)el.textContent=call.phase;const surface=$(".fs-direct-call");if(surface)surface.dataset.callPhase=callVisualPhase(call);}
}
async function acknowledgeIncomingAlert(call,status){
  if(!call.callId||state.call!==call||isLocked())return;
  try{await api('/calls/alert-ack',{method:'POST',body:{callId:call.callId,status}});}catch{} // older server or expired invitation
}
async function callSignal(b) {
  if(isLocked())return;
  if (b.type === "call") {
    if(state.call&&b.callId&&state.call.callId===b.callId)return;
    if (state.settings.available === false) { signal({type:"call-rejected",room:b.room,callId:b.callId}); return; }
    if (state.call) {
      signal({ type: "call-rejected", room: b.room,callId:b.callId });
      return;
    }
    const room = state.rooms.find((r) => r.id === b.room);
    if (!room) return;
    state.call = {
      room,
      callId:b.callId||null,
      video: b.video,
      phase: "Gelen Arama",
      offerer:false,
      incoming: true,
      peer: room.members.find((x) => x.id === b.from),
    };
    if(modal.open)modal.close();
    callRingtones.stop();
    const silent=(state.settings.mutedPeers||[]).includes(b.from)||(state.settings.mutedRooms||[]).includes(b.room);
    const incoming=state.call;
    if(typeof window.FSNative?.presentIncomingCall==='function'&&b.callId)window.FSNative.presentIncomingCall(b.callId,!!b.video,silent);
    else if(!silent&&!callRingtones.muted()){
      void Promise.resolve(callRingtones.incoming()).then(played=>{if(state.call===incoming&&!isLocked())void acknowledgeIncomingAlert(incoming,played?'alerted':'displayed');});
    }else if(document.visibilityState==='visible')void acknowledgeIncomingAlert(incoming,'silent');
    showCall();
    if(typeof window.FSNative?.presentIncomingCall==='function'&&document.visibilityState==='visible')void acknowledgeIncomingAlert(incoming,'displayed');
    return;
  }
  const call = state.call;
  if(call?.group)return;
  if (!callEventMatches(call,b)) return;
  if(b.type==="call-alert-ack"){if(b.callId&&b.callId===call.callId&&b.from===call.peer?.id)applyCallAlertStatus(call,b.status);return;}
  if (b.type === "call-rejected" || b.type === "hangup") {
    const rejected=b.type==="call-rejected"&&call.offerer&&!call.started;
    await endCall(false);
    if(rejected)notice("Arama yanıtlanamadı veya kişi müsait değil.",3500,"info");
    else if(b.from==="server"&&call.offerer&&!call.started)notice(call.phase==="Aranıyor…"||call.phase==="Bağlanıyor…"?"Aramanın karşı cihaza ulaştığı doğrulanamadı.":"Arama yanıtlanmadı.",3500,"info");
    return;
  }
  if (b.type === "restart-request") {call.recovery?.request();return;}
  if (b.type === "answer") {
    if (!call.pc) await setupPeer();
    if (state.call !== call || !call.pc) return;
    if(call.pc.signalingState!=="have-local-offer"){
      if(call.pc.signalingState==="stable")await replaySdpCandidates(call.pc,b.description,()=>state.call===call&&!isLocked());
      return;
    }
    await call.pc.setRemoteDescription(b.description);call.recovery?.answered();
    await flushIce(call);
    return;
  }
  if (b.type === "offer") {
    // A reserved video m-line is not permission to start a camera.
    await setupPeer();
    if (state.call !== call || !call.pc) return;
    if(call.pc.remoteDescription&&!isRestartOffer(call.pc.remoteDescription,b.description)){
      if(sameOffer(call.pc.remoteDescription,b.description)&&call.pc.localDescription?.type==="answer"){
        await replaySdpCandidates(call.pc,b.description,()=>state.call===call&&!isLocked());
        if(state.call===call&&!isLocked())signal({type:"answer",room:call.room.id,callId:call.callId,description:call.pc.localDescription});
      }
      return;
    }
    if(call.offerer||call.pc.signalingState!=="stable")return;
    await call.pc.setRemoteDescription(b.description);
    for(const t of call.pc.getTransceivers())if(t.receiver?.track?.kind==="video"&&!call.video&&t.direction==="recvonly")t.direction="sendrecv";
    await flushIce(call);
    if(state.call!==call)return;
    const answer = await call.pc.createAnswer();
    if(state.call!==call)return;
    await call.pc.setLocalDescription(answer);
    if(state.call!==call)return;
    signal({ type: "answer", room: call.room.id, callId:call.callId, description: call.pc.localDescription||answer });
    if(state.page==="call")showCall();
    return;
  }
  if (b.type === "ice") {
    if(call.pc)await acceptIce(call.pc,call.pendingIce??=[],b.candidate);
    else queueIce(call.pendingIce??=[],b.candidate);
  }
  if (b.type === "accepted") {
    outgoingRingback.stop();call.alertAccepted=true;call.phase="Bağlanıyor…";if(state.page==="call")showCall();
    try{await setupPeer();}catch(error){if(state.call===call){await endCall();notice(error.message||"Mikrofon veya kamera açılamadı.",3500,"error");}return;}
    if (state.call !== call || !call.pc || call.pc.localDescription || !call.offerer) return;
    const offer = await call.pc.createOffer();
    if(state.call!==call)return;
    await call.pc.setLocalDescription(offer);
    if(state.call!==call)return;
    signal({ type: "offer", room: call.room.id, callId:call.callId, description: call.pc.localDescription||offer });
  }
}
async function flushIce(c) {
  if(state.call!==c||!c.pc)return;
  await drainIce(c.pc,c.pendingIce??=[],()=>state.call===c);
}
async function setupPeer() {
  const c = state.call;
  if (!c) throw Error("Arama sona erdi.");
  if (c.pc) return;
  if(c.setupPromise)return c.setupPromise;
  c.setupPromise=initializePeer(c);
  try{return await c.setupPromise}finally{c.setupPromise=null}
}
async function initializePeer(c){
  const config = await api("/config");
  if (state.call !== c) return;
  const stream = await captureCallMedia(c,{
    audio: audioCaptureConstraints(),
    video: c.video
      ? videoCaptureConstraints()
      : false,
  },()=>state.call===c&&!isLocked());
  if (!stream || state.call !== c) return;
  c.pc = new RTCPeerConnection({ iceServers: config.iceServers });
  c.stream.getTracks().forEach((t) => {preferVideoDetail(t);preferSpeech(t);c.pc.addTrack(t, c.stream)});
  // Reserve a single video sender in audio calls; camera stays off until an explicit tap.
  if(c.offerer&&!c.video)c.pc.addTransceiver("video",{direction:"sendrecv"});
  c.extras=createCallExtras({pc:c.pc,stream:c.stream,initialVideo:c.video,valid:()=>state.call===c&&!isLocked(),mediaDevices:nativeScreenDevices(window.FSNative,navigator.mediaDevices),videoConstraints:videoCaptureConstraints,onChange:()=>refreshCallExtras(c),onReaction:emoji=>showCallReaction(c,emoji)});
  if(c.offerer)c.extras.bind(c.pc.createDataChannel(CALL_CHANNEL));
  else c.pc.ondatachannel=e=>c.extras.bind(e.channel);
  c.nativeCamera=c.video;window.FSNative?.activeCall(true, c.video);
  c.pc.onicecandidate = (e) => {
    if (e.candidate && state.call === c && state.socket?.readyState === 1 && presenceAuthenticated)
      try{signal({ type: "ice", room: c.room.id, candidate: e.candidate.toJSON() });}catch(err){if(!(err instanceof CallSignalUnavailable))console.warn("ice",err.message);}
  };
  c.pc.ontrack = (e) => {
    if(state.call!==c)return;
    c.remote??=new MediaStream();
    if(!c.remote.getTracks().includes(e.track))c.remote.addTrack(e.track);
    if(state.page==="call"&&c.video&&e.track.kind==="video"&&$("#remote-video")?.tagName!=="VIDEO")showCall();else attachVideo();
  };
  const quality=createCallQuality(),prioritizeAudio=createAudioPriority();
  c.recovery=createIceRecovery({pc:c.pc,offerer:c.offerer===true,valid:()=>state.call===c&&!isLocked(),canSignal:()=>state.socket?.readyState===1&&presenceAuthenticated,send:(type,payload)=>signal({type,room:c.room.id,callId:c.callId,...payload}),onExpired:()=>{if(state.call!==c)return;notice("Görüşme bağlantısı kurtarılamadı.",4000,"error");endCall().catch(console.warn);}});
  async function refreshCallQuality(){
    if(state.call!==c)return;
    void c.recovery.tick();
    void refreshCallVerification(c);
    try{
      await prioritizeAudio(c.pc,()=>state.call===c&&!isLocked());
      const result=await quality.sample(c.pc,()=>state.call===c);
      if(!result||state.call!==c)return;
      c.qualitySample=result.metrics?{...result.metrics,at:Date.now()}:null;
      c.networkLabel=c.pc.connectionState==='connected'?'':c.phase;
      const label=$('#call-network');if(label)label.textContent=c.started?c.networkLabel:"";
    }catch{}
  }
  c.statsTimer=setInterval(refreshCallQuality,3000);
  void refreshCallQuality();
  c.pc.onconnectionstatechange = () => {
    if(state.call!==c)return;
    const status=c.pc.connectionState;
    void refreshCallVerification(c);
    if(status==='connected'){outgoingRingback.stop();c.phase='Bağlandı';c.started??=Date.now();c.networkLabel='';if(state.page==="call")showCall();}
    else if(status==='connecting'||status==='disconnected'){c.phase=status==='disconnected'?'Yeniden bağlanıyor…':'Bağlanıyor…';c.networkLabel=c.phase;if(state.page==="call"){const n=$("#call-network");if(n)n.textContent=c.started?c.networkLabel:"";}}
    else if(status==='failed'){c.phase=c.networkLabel="Yeniden bağlanıyor…";const n=$("#call-network");if(n)n.textContent=c.started?c.networkLabel:"";}
    void c.recovery.tick();
  };
  c.pc.onsignalingstatechange=()=>{if(state.call===c)void refreshCallVerification(c);};
  c.pc.oniceconnectionstatechange=()=>{if(state.call===c){void refreshCallVerification(c);void c.recovery.tick();}};
  attachVideo();
}
function attachVideo() {
  if(isLocked())return;
  const c=state.call;if(!c)return;
  if(c.group){attachGroupMedia(c);return;}
  const mini=$("#call-mini"),remote=$("#remote-video"),local=$("#local-video");
  // Swapping is valid only while both video surfaces and both streams exist.
  if((state.page==='call'&&(!local||remote?.tagName!=="VIDEO"||!c.stream||!c.remote))||(c.extras&&(c.extras.remote==="off"||c.extras.mode==="off")))c.swapped=false;
  function attach(el,stream,muted=false){if(!el)return;el.muted=muted;if(el.srcObject!==(stream||null))el.srcObject=stream||null;if(stream&&el.paused)el.play?.().catch(()=>{});}
  if(state.page!=='call'&&(!mini||c.extras?.remote==='off')&&c.remote){let audio=$('#fs-background-call');if(!audio){audio=document.createElement('audio');audio.id='fs-background-call';audio.autoplay=true;app.append(audio)}attach(audio,c.remote)}
  if(state.page==="call"||(mini&&c.extras?.remote!=="off"))$("#fs-background-call")?.remove();
  // Silence the outgoing surface before enabling the new remote audio owner.
  if(c.swapped&&remote)remote.muted=true;if(!c.swapped&&local)local.muted=true;
  attach(mini,c.extras?.remote==="off"?c.stream:c.remote,c.extras?.remote==="off");attach(remote,c.swapped?c.stream:c.remote,!!c.swapped);attach(local,c.swapped?c.remote:c.stream,!c.swapped);
  if(remote?.tagName==="VIDEO")remote.style.objectFit=(c.swapped?c.extras?.mode:c.extras?.remote)==="screen"?"contain":"";
}
function callElapsedLabel(c,now=Date.now()){
  if(!c.started)return c.phase||"Bağlanıyor…";
  const seconds=Math.max(0,Math.floor((now-c.started)/1000));
  const minutes=Math.floor(seconds/60);
  return `${String(minutes).padStart(2,"0")}:${String(seconds%60).padStart(2,"0")}`;
}
function callVisualPhase(c){
  if(c.started)return c.pc?.connectionState==='connected'?'active':'connecting';
  return c.alertStatus==='alerted'&&!c.alertAccepted?'ringing':'connecting';
}
function updateCallControl(el,on,iconName,label){
  el.classList.toggle("on",!!on);el.setAttribute("aria-pressed",String(!!on));
  if(label){el.setAttribute("aria-label",label);if(el.nextElementSibling)el.nextElementSibling.textContent=label;}
  if(iconName)el.innerHTML=icon(iconName);
}
function callAudioLabel(route){return ({speaker:"Hoparlör",earpiece:"Ahize",bluetooth:"Bluetooth",wired:"Kablolu kulaklık"})[route]||"Ses çıkışı";}
function callAudioIcon(route){return route==="bluetooth"?"bluetooth":route==="earpiece"?"phone":route==="wired"?"headphones":"speaker";}
function showAudioRouteMenu(){
 const c=state.call;if(!c||c.incoming||!window.FSNative?.audioRoute)return;
 let info={};try{info=JSON.parse(window.FSNative.audioState?.()||"{}");}catch{}
 const routes=["auto",...(info.earpiece!==false?["earpiece"]:[]),...(info.speaker!==false?["speaker"]:[]),...(info.bluetooth?["bluetooth"]:[]),...(info.wired?["wired"]:[])];
 dialog("Ses çıkışı",`<div class="dialog-action-stack audio-route-list">${routes.map(route=>`<button type="button" class="secondary" data-action="choose-audio-route" data-route="${route}" aria-pressed="${info.preference===route}">${icon(route==="auto"?"speaker":callAudioIcon(route))}<span>${route==="auto"?"Otomatik":callAudioLabel(route)}</span>${info.route===route?'<small>Etkin</small>':info.preference===route?'<small>Seçili</small>':""}</button>`).join("")}</div>`);modal._fsAudioCall=c;
}
function updateAudioRouteControls(info){
 for(const b of document.querySelectorAll('.call [data-action="speaker"],.call [data-action="bluetooth"]')){
  const bt=b.dataset.action==="bluetooth";const label=bt?"Bluetooth":callAudioLabel(info.route);
  updateCallControl(b,bt?info.route==="bluetooth":info.route==="speaker",bt?"bluetooth":callAudioIcon(info.route),label);
  b.setAttribute("aria-busy",String(!!info.pending&&(bt?info.pending==="bluetooth":true)));
 }
}
function showCallReaction(c,emoji){
 if(state.call!==c||isLocked()||state.page!=="call")return;
 const root=$('.call');if(!root)return;
 root.querySelector('.call-reaction-float')?.remove();
 const el=document.createElement('div');el.className='call-reaction-float';el.textContent=emoji;el.setAttribute('role','status');root.append(el);setTimeout(()=>el.remove(),1800);
}
function callMediaLayout(c){return [!!c.video,!!c.extras?.ready,c.extras?.mode??"",c.extras?.remote??""].join("|");}
function refreshCallExtras(c){
 if(state.call!==c||isLocked())return;
 const nextVideo=c.extras.mode!=="off"||c.extras.remote!=="off";
 const changed=c.video!==nextVideo;c.video=nextVideo;
 if(changed)c.swapped=false;
 // Android camera foreground service depends on LOCAL capture, not remote video.
 if(c.nativeCamera!==(c.extras.mode==="camera")){c.nativeCamera=c.extras.mode==="camera";window.FSNative?.activeCall(true,c.nativeCamera);}
 if(state.page==="call"){if(c.renderedMediaLayout===callMediaLayout(c)&&$(".fs-direct-call")){attachVideo();placeCallPip();}else showCall();}
 else if(state.page==="chat"){
  refreshCallExtrasSurface(c);
  attachVideo();
 }
}
function showCallExtras(){
 const c=state.call,x=c?.extras;if(!x||c.incoming||!x.ready)throw Error('Görüşmenin bağlanmasını bekleyin; iki cihazda da güncel sürüm gerekli.');
 const metrics=c.qualitySample, measured=metrics&&c.pc?.connectionState==='connected'&&Date.now()-metrics.at<10000;
 const size=v=>v?`${v.width} × ${v.height}`:'Ölçülmedi',number=(v,suffix)=>Number.isFinite(v)?`${Math.round(v)} ${suffix}`:'Ölçülmedi';
 const details=measured?`<details class="call-quality-details"><summary>Bağlantı ayrıntıları</summary><dl><dt>Gönderilen görüntü</dt><dd>${size(metrics.localSize)} · ${number(metrics.sendFps,'FPS')}</dd><dt>Alınan görüntü</dt><dd>${size(metrics.remoteSize)} · ${number(metrics.receiveFps,'FPS')}</dd><dt>Görüntü veri hızı</dt><dd>${number(metrics.sendBitrate==null?null:metrics.sendBitrate/1000,'kb/sn')}</dd><dt>Gidiş dönüş gecikmesi</dt><dd>${number(metrics.rtt==null?null:metrics.rtt*1000,'ms')}</dd></dl><p class="hint">Son ölçüm; değerler ağ ve cihaza göre değişebilir.</p></details>`:'<p class="hint">Bağlantı ölçümü henüz hazır değil.</p>';
 const switcher=x.canSwitchCamera?'<button class="secondary" data-action="call-switch-camera">Ön / arka kamerayı değiştir</button>':'';
 const share=x.mode==="screen"?'<button class="secondary" data-action="call-media-off">Ekran paylaşımını durdur</button>':x.canShare?'<button class="secondary" data-action="call-share-screen">Ekranımı paylaş</button>':'<p class="hint">Bu cihazda ekran paylaşımı desteklenmiyor.</p>';
 dialog('Görüşme seçenekleri',`<div class="dialog-action-stack">${switcher}${share}<button class="secondary" data-action="call-voice">Görüşme sesim</button>${x.mode==='camera'?'<button class="secondary" data-action="call-media-off">Kendi kameramı kapat</button>':''}<div class="call-reactions-grid" aria-label="Görüşme emojileri">${CALL_REACTIONS.map(emoji=>`<button type="button" data-action="call-reaction" data-emoji="${emoji}" aria-label="${emoji} gönder">${emoji}</button>`).join('')}</div>${details}</div>`);modal._fsExtrasCall=c;
}
function showCall() {
  if(isLocked())return;
  window.FSNative?.visibleMessageRoom?.("");
  dismissAlbumViewer();dismissProfileViewer();
  discardVoice();
  const c = state.call;
  if (!c) return;
  stopThumbnailObservation();
  if(state.page==="admin"||state.page==="admin-room")clearAdminState();
  state.page = "call";
  typing.reset();
  if(c.incoming){
    clearInterval(state.callTimer);clearTimeout(state.controlsTimer);
    app.innerHTML=incomingCallMarkup(c,avatar);
    return;
  }
  if(c.group){showGroupCall(c);return;}
  let audio = {bluetooth:false};
  try { audio = JSON.parse(window.FSNative?.audioState?.() || "{}"); } catch {}
  const muted=c.voiceCapture?.muted??(c.stream?.getAudioTracks().length>0&&!c.stream.getAudioTracks().some(t=>t.enabled));
  const camera=c.extras?c.extras.mode==="camera":!!c.stream?.getVideoTracks().some(t=>t.enabled);
  const controls = [
    ["mute", muted?"mic-off":"mic", muted?"Mikrofon kapalı":"Mikrofon", muted?"on":"", muted],
    ["camera-toggle", camera?"video":"video-off", camera?"Kamera açık":"Kamera", camera?"on":"", camera],
    ...(audio.bluetooth ? [["bluetooth", "bluetooth", "Bluetooth", audio.route === "bluetooth" ? "on" : "", audio.route === "bluetooth"]] : []),
    ["speaker", callAudioIcon(audio.route), callAudioLabel(audio.route), audio.route==="speaker"?"on":"", audio.route==="speaker"],
    ...(c.extras?.ready?[["call-extras", "more", "Diğer", "", null]]:[["call-voice", "waveform", voiceLabel(c.voiceMode??selectedVoice(state.user?.id,localStorage)), "", null]]),
    ["end-call", "phone-off", "Kapat", "red", null],
  ];
  const liveVideo=!!(c.remote&&c.video&&(!c.extras?.ready||c.extras.remote!=="off")&&(c.remote.getVideoTracks?.().some(t=>t.readyState!=="ended")??true));
  app.innerHTML = `<section class="call fs-premium fs-direct-call ${c.video?"fs-video-call":"fs-audio-call"} ${liveVideo?"fs-video-live":""}" data-call-phase="${callVisualPhase(c)}" aria-label="${c.video?"Görüntülü":"Sesli"} görüşme">${liveVideo ? '<video class="remote" id="remote-video" autoplay playsinline></video>' : '<audio id="remote-video" autoplay></audio>'}<header style="width:100%;z-index:3;background:none;border:0">${button("call-back", "back", "Sohbete dön")}<button class="call-security" id="call-security" type="button" data-action="verification" aria-label="Arama güvenlik kodu" aria-expanded="false">${callSecurityMarkup(c)}</button><button type="button" id="call-security-confirm" class="call-security-confirm" data-action="verify-call" hidden>Emojiler eşleşiyor</button></header><div class="person">${liveVideo ? "" : `<div class="call-avatar-frame">${avatar(c.peer,true)}</div>`}<h2 dir="auto">${escape(c.peer?.name||"Görüşme")}</h2><p id="call-timer" class="timer">${escape(callElapsedLabel(c))}</p><small id="call-network" role="status" aria-live="polite">${escape(c.started&&c.pc?.connectionState!=="connected"?(c.networkLabel||""):"")}</small></div>${c.extras?.mode==="screen"?'<button class="call-share-stop" data-action="call-stop-sharing">Ekran paylaşımını durdur</button>':""}${c.video && (!c.extras?.ready||c.extras.mode!=="off") ? '<video class="local" id="local-video" autoplay muted playsinline role="button" tabindex="0" aria-label="Görüntüleri değiştir; sürükleyerek taşı"></video>' : ""}<div class="controls" role="group" aria-label="Görüşme kontrolleri">${controls.map(([a,i,l,cl,pressed])=>`<div class="control"><button type="button" data-action="${a}" class="${cl}" aria-label="${escape(l)}" ${pressed===null?'':`aria-pressed="${!!pressed}"`}>${icon(i)}</button><span>${escape(l)}</span></div>`).join("")}</div></section>`;
  c.renderedMediaLayout=callMediaLayout(c);
  void refreshCallVerification(c);
  attachVideo();
  const remoteView = $("#remote-video");
  clearTimeout(state.controlsTimer);
  if(c.video && !c.incoming){
    applyCallControls(c);
    const toggle=()=>{Object.assign(c,callControlState(c,Date.now(),true));applyCallControls(c);};
    if(remoteView?.tagName === "VIDEO")remoteView.onclick=toggle;
    else $(".call")?.addEventListener("click",e=>{if(!e.target.closest("button,header,.controls,video"))toggle();});
  }
  clearInterval(state.callTimer);
  state.callTimer = setInterval(() => {
    if(state.call!==c||state.page!=="call")return;
    const el=$("#call-timer");if(el)el.textContent=callElapsedLabel(c);const surface=$(".fs-direct-call");if(surface)surface.dataset.callPhase=callVisualPhase(c);
  },1000);
  const local = $("#local-video");
  if(local){
    bindFloatingVideo(local,c,{bounds:()=>callPipBounds(local),place:()=>placeCallPip(),positionKey:'callPipRatio',sizeKey:'callPipHeight',defaultSize:144,onTap:()=>{const remote=$("#remote-video");if(remote?.tagName==="VIDEO"&&c.remote&&c.stream){c.swapped=!c.swapped;attachVideo();}}});
  }
}
function callPipBounds(el){
 const section=el?.closest('.call');if(!section)return null;
 const r=section.getBoundingClientRect(),head=section.querySelector('header')?.getBoundingClientRect(),dock=section.querySelector('.controls')?.getBoundingClientRect();
 const top=Math.max(6,(head?.bottom??r.top)-r.top+6),hidden=section.querySelector('.controls')?.classList.contains('hidden-controls'),bottom=Math.min(r.height-6,((hidden?r.bottom:dock?.top)??r.bottom)-r.top-6);
 return {left:6,top,width:Math.max(0,r.width-12),height:Math.max(0,bottom-top)};
}
function placeCallPip(){const el=$('#local-video'),c=state.call;if(!el||!c||state.page!=='call')return;layoutFloatingVideo(el,callPipBounds(el),c,'callPipRatio','callPipHeight',144);const grip=el.parentElement?.querySelector('[data-pip-resize="local-video"]');if(grip&&c.controlsHidden)grip.hidden=true;}

async function endCall(notify = true) {
  const c = state.call;
  if (!c) return;
  if(modal.open&&(modal._fsAudioCall===c||modal._fsExtrasCall===c)){modal.close();modal._fsAudioCall=null;}
  outgoingRingback.stop();callRingtones.stop();if(c.incoming)window.FSNative?.dismissCallRingtone?.(c.callId);
  clearTimeout(state.controlsTimer);
  if (notify) {
    try {
      signal({ type: c.group?"group-call-leave":"hangup", room: c.room.id });
    } catch {}
  }
  state.call = null;
  syncCallReturnBanner();$("#fs-background-call")?.remove();$("#fs-group-background")?.remove();$("#call-mini")?.remove();$('[data-pip-resize="call-mini"]')?.remove();
  if(c.pc) {c.pc.onconnectionstatechange = null;c.pc.oniceconnectionstatechange=null;c.pc.onsignalingstatechange=null;c.pc.onicecandidate = null;c.pc.ontrack = null;}
  clearInterval(c.statsTimer);c.recovery?.close();c.extras?.close();
  c.pendingVoiceRaw?.getTracks().forEach(t=>t.stop());
  c.voiceCapture?.close();
  c.stream?.getTracks().forEach((t) => t.stop());
  c.pc?.close();c.mesh?.close();
  window.FSNative?.activeCall(false, false);
  clearInterval(state.callTimer);
  state.call = null;
  await openRoom(c.room.id);
}
function callSecurityMarkup(c){
  const code=c.callSecurity;
  if(!code?.symbols||!sameCallVerification(code.snapshot,callVerificationSnapshot(c.pc,c.callId)))return icon("shield");
  return `<span class="call-security-emojis">${code.symbols.map(x=>`<span>${escape(x)}</span>`).join("")}</span>`;
}
function renderCallSecurity(c){
  if(state.call!==c||state.page!=="call"||isLocked())return;
  const el=$("#call-security");if(!el)return;
  const html=callSecurityMarkup(c);if(el.innerHTML!==html)el.innerHTML=html;
  const valid=!!c.callSecurity?.symbols&&sameCallVerification(c.callSecurity.snapshot,callVerificationSnapshot(c.pc,c.callId));
  const expanded=valid&&c.securityExpanded===true;
  el.classList.toggle("matched",valid&&c.verified===true);
  el.classList.toggle("expanded",expanded);el.setAttribute('aria-expanded',String(expanded));
  el.setAttribute('aria-label',!valid?'Arama güvenlik kodu henüz hazır değil':c.verified?'Güvenlik kodu eşleşmesi onaylandı':expanded?'Güvenlik emojilerini küçült':'Güvenlik emojilerini büyüt');
  if(!expanded||c.verified===true)c.securityProof=null;
  else if(c.securityProof?.code!==c.callSecurity)c.securityProof={call:c,code:c.callSecurity};
  const confirm=$('#call-security-confirm');if(confirm){confirm.hidden=!expanded||c.verified===true;confirm._fsVerification=c.securityProof??null;}
}
async function refreshCallVerification(c){
  if(state.call!==c||isLocked()||c.group)return null;
  const snapshot=callVerificationSnapshot(c.pc,c.callId);
  if(!sameCallVerification(c.callSecurity?.snapshot,snapshot)){
    c.verified=false;c.callSecurity=null;c.securityExpanded=false;c.securityProof=null;
    if(modal.open&&modal.querySelector('[data-action="verify-call"]')?._fsVerification?.call===c)modal.close();
    if(snapshot)c.callSecurity={snapshot,symbols:null};
    renderCallSecurity(c);
  }
  if(!snapshot||!legacyVerificationEmojis.length)return null;
  const code=c.callSecurity;
  if(code.pending)return code.pending;
  code.pending=(async()=>{
    try{
      const valid=await verifyCallTransport(snapshot);
      if(state.call!==c||isLocked()||c.callSecurity!==code||!sameCallVerification(snapshot,callVerificationSnapshot(c.pc,c.callId)))return null;
      if(!valid){c.verified=false;c.securityExpanded=false;c.securityProof=null;c.callSecurity=null;renderCallSecurity(c);return null;}
      if(code.symbols){renderCallSecurity(c);return code;}
      const digest=await verificationDigest(snapshot);
      if(state.call!==c||isLocked()||c.callSecurity!==code||!sameCallVerification(snapshot,callVerificationSnapshot(c.pc,c.callId)))return null;
      code.symbols=Array.from({length:4},(_,i)=>legacyVerificationEmojis[((digest[i * 2] << 8) | digest[i * 2 + 1]) % legacyVerificationEmojis.length].emoji);
      renderCallSecurity(c);return code;
    }catch{if(state.call===c&&c.callSecurity===code){c.verified=false;c.securityExpanded=false;c.securityProof=null;c.callSecurity=null;renderCallSecurity(c);}return null;}finally{code.pending=null;}
  })();
  return code.pending;
}
async function verification() {
  const c=state.call;
  if(!c||c.group||!callVerificationSnapshot(c.pc,c.callId))throw Error("Güvenlik kodu için görüşmenin bağlanmasını bekle.");
  const code=await refreshCallVerification(c);
  if(!code?.symbols||state.call!==c||isLocked()||c.callSecurity!==code||!sameCallVerification(code.snapshot,callVerificationSnapshot(c.pc,c.callId)))return;
  c.securityExpanded=!c.securityExpanded;
  c.securityProof=null;
  renderCallSecurity(c);
}
// Folder changes use the existing account-scoped workspace store.
function showFolderManager(){dialog('Sohbet klasörleri',folderManagerMarkup(localState.preferences?.folders,escape));}
let folderWrite=null;
async function commitFolders(next){
 if(!localData||isLocked())throw Error('Yerel oturum hazır değil.');
 if(folderWrite)throw Error('Önceki klasör değişikliği kaydediliyor.');
 const store=localData,workspace=localState,epoch=access.epoch,user=state.user.id,previous=workspace.preferences.folders;
 const valid=()=>!isLocked()&&access.valid(epoch)&&localData===store&&localState===workspace&&state.user?.id===user;
 const token={};folderWrite=token;
 workspace.preferences.folders=next;
 try{await persistLocal(true);if(!valid())return false;state.chatFilter=resolveFolderFilter(state.chatFilter,next);return true;}
 catch(error){if(valid())workspace.preferences.folders=previous;throw error;}
 finally{if(folderWrite===token)folderWrite=null;}
}
function refreshFolderHome(){if(state.page==='home'&&state.tab==='Sohbetler'){const nav=app.querySelector('.chat-filters');if(nav)nav.innerHTML=folderFiltersMarkup(localState.preferences?.folders,state.chatFilter,escape);homeList().catch(e=>notice(e.message));}}
function showFolderEditor(id){
 const existing=normalizeFolders(localState.preferences?.folders).find(f=>f.id===id);
 if(id&&!existing)throw Error('Klasör bulunamadı.');
 const rooms=state.rooms.slice(),store=localData,epoch=access.epoch,user=state.user.id;
 dialog(existing?'Klasörü düzenle':'Yeni klasör',folderEditorMarkup(existing,rooms,name,escape));
 const form=$('#folder-form'),valid=()=>!isLocked()&&access.valid(epoch)&&state.user?.id===user&&localData===store&&modal.open&&form.isConnected;
 form.onsubmit=async event=>{
  event.preventDefault();if(!valid())return;
  const submit=form.querySelector('[type="submit"]');if(submit.disabled)return;submit.disabled=true;
  try{
   const current=normalizeFolders(localState.preferences?.folders),fresh=existing?current.find(f=>f.id===existing.id):null;
   if(existing&&!fresh)throw Error('Klasör artık mevcut değil.');
   const checked=[...form.querySelectorAll('[name="room"]:checked')].map(el=>el.value);
   const next=saveFolder(current,{id:fresh?.id||Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,"0")).join(""),name:form.elements.folderName.value,roomIds:mergeFolderMembers(fresh?.roomIds||[],rooms.map(r=>r.id),checked)});
   if(await commitFolders(next)){refreshFolderHome();if(valid()){showFolderManager();notice('Klasör kaydedildi.',2000,'success');}}
  }catch(e){if(valid())$('#folder-error').textContent=e.message;}
  finally{if(valid())submit.disabled=false;}
 };
}
function showChatHistoryClear(){
 const room=state.room,epoch=access.epoch,route=state.routeVersion;if(!room||room.ratchet_cutover_active)return;
 const valid=()=>access.valid(epoch)&&state.routeVersion===route&&state.page==='chat'&&state.room?.id===room.id;
 const shared=room.kind==='direct'&&state.historyEveryone;
 dialog('Sohbet geçmişini temizle',`<p class="hint">Mevcut geçmiş temizlenir. Taslaklar ve bekleyen gönderimler korunur.${shared?' İki taraflı işlem geri alınamaz; kişisel arama kayıtları korunur.':''}</p><div class="dialog-action-stack"><button type="button" class="secondary" id="history-self">Kendimden temizle</button>${shared?'<button type="button" class="danger" id="history-everyone">Her iki taraftan temizle</button>':''}<button type="button" class="secondary" data-action="close-dialog">Vazgeç</button></div>`);
 const self=$('#history-self'),both=$('#history-everyone');let busy=false;
 async function clear(scope){if(busy||!valid()||!self.isConnected||!modal.open)return;busy=true;for(const b of modal.querySelectorAll('button'))b.disabled=true;
  try{const result=await api('/room-history/manage',{method:'POST',body:{operation:'clear',rooms:[room.id],...(scope==='everyone'?{scope}: {})}});if(!valid())return;
   if(result?.ok!==true||!Array.isArray(result.rooms)||result.rooms.length!==1||result.rooms[0]?.room!==room.id||(scope==='everyone'?result.rooms[0].scope!=='everyone':result.rooms[0].scope!=null&&result.rooms[0].scope!=='self'))throw Error('Temizleme işlemi doğrulanamadı.');
   if(self.isConnected&&modal.open)modal.close();try{await refreshRooms();if(!valid())return;await loadMessages();if(valid())notice('Sohbet geçmişi temizlendi.',2000,'success');}catch(error){if(valid())notice('Geçmiş temizlendi; sohbet henüz yenilenemedi.',4000,'info');}
  }catch(error){if(valid())notice(error.message,4000,'error');}finally{busy=false;if(self.isConnected)for(const b of modal.querySelectorAll('button'))b.disabled=false;}
 }
 self.onclick=()=>clear('self');if(both)both.onclick=()=>clear('everyone');
}
async function actions(a, el) {
  if(isLocked())return;
  // PIN unlock alone is not a logged-in account. Limit actions while on the sign-in form.
  if((state.page==="auth"||!state.token||!state.user)&&!["auth-toggle","privacy-policy","import-key","cancel-recovery","close-dialog","password-recovery"].includes(a))return;
  switch (a) {
    case 'chat-filter':state.chatFilter=resolveFolderFilter(el.dataset.filter,localState.preferences?.folders);home();break;
    case 'manage-folders':showFolderManager();break;
    case 'new-folder':showFolderEditor();break;
    case 'edit-folder':showFolderEditor(el.dataset.id);break;
    case 'confirm-remove-folder':{const f=normalizeFolders(localState.preferences?.folders).find(f=>f.id===el.dataset.id);if(f)dialog('Klasörü sil',`<p>${escape(f.name)} klasörü silinecek. Sohbetler ve mesajlar korunur.</p><button type="button" class="danger" data-action="remove-folder" data-id="${escape(f.id)}">Klasörü sil</button><button type="button" class="secondary" data-action="manage-folders">Vazgeç</button>`);break;}
    case 'remove-folder':{const source=el;if(await commitFolders(removeFolder(localState.preferences?.folders,el.dataset.id))){refreshFolderHome();if(source.isConnected&&modal.open){showFolderManager();notice('Klasör silindi.',2000,'success');}}break;}
    case 'first-greeting':{if(state.page!=='chat'||!el.isConnected||state.room?.kind!=='direct'||state.room.ratchet_cutover_active||state.historyLoadedRoute!==state.routeVersion||state.hasOlder||state.messages.some(m=>!hiddenMessage(m)&&!['reaction','vote'].includes(m.payload.type))||el.disabled)break;const room=state.room,epoch=access.epoch,route=state.routeVersion;el.disabled=true;try{await send({type:'text',text:greetingPicker(route,emojiIndex)},room,null,{replyId:null});}catch(error){if(access.valid(epoch)&&state.routeVersion===route){if(el.isConnected)el.disabled=false;notice(error.message,4000,'error');}}break;}
    case 'history-clear':showChatHistoryClear();break;
    case 'chat-options':dialog('Sohbet seçenekleri',`<div class="chat-options-menu"><button class="row" data-action="chat-search">${icon('search')} Sohbette ara</button><button class="row" data-action="outbox">${icon('file')} Gönderim kuyruğu</button><button class="row" data-action="scheduled-list">${icon('calendar')} Zamanlananlar</button>${state.room.kind==='group'&&state.room.ratchet_group_pilot===true?'<button class="row" data-action="ratchet-group">Deneysel şifreli grup</button>':''}<button class="row" data-action="pin-chat">${icon('pin')} ${localState.preferences.pinned.includes(state.room.id)?'Sabitlemeyi kaldır':'Sohbeti sabitle'}</button><button class="row" data-action="archive-chat">${icon('archive')} ${localState.preferences.archived.includes(state.room.id)?'Arşivden çıkar':'Sohbeti arşivle'}</button><button class="row" data-action="mute-room">${icon('bell-off')} ${(state.settings.mutedRooms||[]).includes(state.room.id)?'Sohbetin sesini aç':'Sohbeti sessize al'}</button>${!state.room.ratchet_cutover_active?'<button class="row danger" data-action="history-clear">Geçmişi temizle</button>':''}${state.room.kind==='direct'&&!state.room.ratchet_cutover_active&&Number.isInteger(state.room.auto_delete_seconds)?`<button class="row" data-action="auto-delete-settings">${icon('calendar')} Otomatik silme · ${autoDeleteLabel(state.room.auto_delete_seconds)}</button>`:''}${state.room.kind==='direct'&&state.room.ratchet_pilot===true?'<button class="row" data-action="ratchet-pilot">Deneysel güvenli sohbet ve dosya</button>':''}</div>`);break;
    case 'auto-delete-settings':showAutoDeleteSettings();break;
    case 'ratchet-group':{
      const room=state.room,user=state.user.id,epoch=access.epoch;
      if(room?.kind!=='group'||room.ratchet_group_pilot!==true)return;
      dialog('Deneysel şifreli grup','<div id="ratchet-group-root"></div>');
      const root=$("#ratchet-group-root"),valid=()=>access.valid(epoch)&&state.user?.id===user&&state.room?.id===room.id&&modal.open&&root.isConnected;
      const clean=await mountRatchetGroup(root,{api,room:room.id,user,members:room.members,valid});
      if(!valid())clean();else modal.addEventListener('close',clean,{once:true});break;
    }
    case 'ratchet-pilot':{
      const room=state.room,user=state.user.id,epoch=access.epoch,peer=room?.members.find(m=>m.id!==user)?.id;
      if(room?.kind!=="direct"||room.ratchet_pilot!==true||!peer)return;
      closeInlineRatchet();
      dialog("Deneysel güvenli sohbet",'<div id="ratchet-pilot-root"></div>');
      const root=$("#ratchet-pilot-root"),valid=()=>access.valid(epoch)&&state.user?.id===user&&state.room?.id===room.id&&modal.open&&root.isConnected;
      const token=state.token,downloadStore=()=>new DurableDownloads({user,identity:state.identity,read:vault,valid,namespace:'ratchet-downloads-v1'});
      const transfer=async info=>ratchetDownload({store:downloadStore(),info,request:async(info,start,end)=>{const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),30000);try{const bytes=await fetchRange(fetch,apiRoot+'/api'+info.path,token,start,end,info.media.size+16,controller.signal);if(!valid())throw new DOMException('Oturum değişti.','AbortError');return bytes;}finally{clearTimeout(timer);controller.abort();}}});
      const clean=await mountRatchetPilot(root,{api,room:room.id,user,peer,valid,transfer,removeCached:id=>downloadStore().remove(id),cutover:room.ratchet_cutover_available===true,onCutover:async()=>{await refreshRooms();if(valid())updateCutoverComposer();}});
      if(!valid())clean();else modal.addEventListener('close',clean,{once:true});
      break;
    }
    case 'mute-room':{const room=state.room.id;const muted=new Set(state.settings.mutedRooms||[]);const turnOn=muted.has(room);if(turnOn)muted.delete(room);else muted.add(room);await patchSettings({mutedRooms:[...muted]});modal.close();notice(turnOn?'Sohbetin sesi açıldı.':'Sohbet sessize alındı.',2000,'success');break;}
    case 'unpin-message':await toggleMessagePin(null);break;
    case 'pin-chat':localState.preferences.pinned=toggleId(localState.preferences.pinned,state.room.id);await persistLocal(true);modal.close();break;
    case 'archive-chat':localState.preferences.archived=toggleId(localState.preferences.archived,state.room.id);await persistLocal(true);modal.close();home();break;
    case 'chat-search':chatSearch();break;
    case 'search-history':await searchHistory();break;
    case 'jump-message':{const id=el.dataset.id;modal.close();await jumpReply(id);break;}
    case 'outbox':showOutbox();break;
    case 'scheduled-list':await showScheduledMessages();break;
    case 'scheduled-cancel':if(state.room?.id===el.dataset.room&&state.sendOptions){await api('/rooms/'+el.dataset.room+'/scheduled/'+el.dataset.id,{method:'DELETE'});await showScheduledMessages();}break;
    case 'replay-send-effect':{const m=eligibleMessage(el.dataset.id);if(m)playSendEffect(m.id,m.payload.effect,m.payload.effectVariant,true);break;}
    case 'retry-outbox':await flushOutbox();showOutbox();break;
    case 'cancel-outbox':localState.outbox=localState.outbox.filter(x=>x.id!==el.dataset.id);state.messages=state.messages.filter(x=>x.id!==el.dataset.id);await persistLocal(true);showOutbox();if(state.page==='chat')renderMessages();break;
    case 'newest':jumpToLatest();break;
    case 'audio-speed':{const previous=localState.playback[el.dataset.id]||{};previous.rate=nextVoiceRate(previous.rate||1);localState.playback[el.dataset.id]=previous;const audio=document.querySelector(`[data-audio="${el.dataset.id}"]`);if(audio)audio.playbackRate=previous.rate;el.textContent=previous.rate+'×';persistLocal();break;}
    case 'voice-lock':voiceLocked=true;voiceStatus({phase:voiceController?.session?.recorder?.state==='paused'?'paused':'recording',elapsed:voiceController?.session?voiceController.elapsed(voiceController.session):0,wave:voiceController?.session?.wave||[],meterAvailable:!!voiceController?.session?.analyser});break;
    case 'voice-pause':voiceLocked=true;voiceController?.pause();break;
    case 'voice-resume':voiceController?.resume();break;
    case 'voice-finish':voiceController?.stop();break;
    case 'media-more':await loadMediaPage();break;
    case 'saved-original':{const record=state.saved.find(m=>m.id===el.dataset.id);if(record){await openRoom(record.room);if(!virtualMessages?.jump(record.id)){state.messages=upsertMessages(state.messages,[record]);renderMessages();virtualMessages?.jump(record.id)}}break;}
    case 'saved-tag':{const id=el.dataset.id;dialog('Etiket',`<form id="saved-tag-form">${field('tag','Etiket','text',localState.tags?.[id]||'',false)}<button class="primary">Kaydet</button></form>`);$('#saved-tag-form').onsubmit=async event=>{event.preventDefault();localState.tags??={};localState.tags[id]=new FormData(event.target).get('tag').trim().slice(0,40);await persistLocal(true);modal.close();await savedPage()};break;}


    case "recover-history":
      recoverHistoryDialog();
      break;
    case "export-key":
      await exportKeyDialog();
      break;
    case "cancel-recovery":
      state.pendingRecovery=null;authPage(false);
      break;
    case "import-key":
      importKeyDialog();
      break;
    case "admin":
      modal.close();
      await adminPage();
      break;
    case 'admin-page':
      await adminPage(state.adminQuery||'',Number(el.dataset.usersOffset),Number(el.dataset.roomsOffset));
      break;
    case 'admin-older':
      state.adminOlder=el.dataset.id;
      await adminRoom(el.dataset.id);
      break;
    case 'admin-key-info':
      await adminKeyInfo();
      break;
    case "admin-room":
      await adminRoom(el.dataset.id);
      break;
    case "admin-delete":
      await adminDelete(el.dataset.kind, el.dataset.id);
      break;
    case "toggle-selection":
      if(!eligibleMessage(el.dataset.id))break;
      toggleSelectedGroup(el.dataset.id);
      renderMessages();
      break;
    case "close-dialog":
      closeAlbumViewer();if(modal.classList.contains("profile-viewer"))dismissProfileViewer();else modal.close();
      break;
    case "older": {
      const first = state.messages.find((m) => !m.callRecord&&!m.pending);
      if (!first) break;
      const room = state.room, route = state.routeVersion;
      const target = $("#messages"),
        height = target.scrollHeight,
        top = target.scrollTop;
      const rows = await api(
        "/rooms/" + room.id + "/messages?before=" + first.created + "&before_id=" + encodeURIComponent(first.id),
      );
      const previous = await Promise.all(rows.map(decode));
      if (state.page !== "chat" || state.room?.id !== room.id || state.routeVersion !== route || !target.isConnected) break;
      const anchor=virtualMessages?.anchor();
      state.hasOlder = rows.length === 80;
      const existing = new Set(state.messages.map((m) => m.id));
      state.messages = [
        ...previous.filter((m) => !existing.has(m.id)&&!deletedInSession.has(m.id)),
        ...state.messages,
      ];
      renderMessages();
      if(anchor)virtualMessages?.jump(anchor.id);else target.scrollTop = top + target.scrollHeight - height;
      break;
    }
    case "home":
      home();
      break;
    case "back":
      if(state.page==='media'&&mediaReturnPage==='peer'){
        const peer=state.room?.id===mediaRoomScope&&state.room.members?.find(m=>m.id!==state.user.id);if(peer)profile(peer);else home();break;
      }
      if (
        state.page === "settings" ||
        state.page === "saved" ||
        (state.page === "media" && mediaReturnPage === "profile")
      )
        profile();
      else home();
      break;
    case "password-recovery":
      passwordRecoveryDialog();
      break;
    case "auth-toggle":
      authPage(el.dataset.register === "1");
      break;
    case "tab":
      state.tab = el.dataset.tab;
      home();
      break;
    case 'home-archive-toggle':case 'home-archive-open':case 'home-archive-back':homeArchiveAction(a,el);break;
    case 'home-select-start':{const first=app.querySelector('.home-room');if(first)toggleHomeRoom(first.dataset.id);break;}
    case 'home-select-cancel':{const s=homeManagement();if(s&&!s.busy){s.ids.clear();paintHomeSelection();}break;}
    case 'home-manage':showHomeManagement();break;
    case 'home-manage-apply':await applyHomeManagement(el.dataset.op,el);break;
    case 'home-history-confirm':confirmHomeHistory(el.dataset.op,el);break;
    case 'home-history-cancel':modal.close();break;
    case 'home-history-apply':await applyHomeHistory(el);break;
    case 'home-manage-preview':{const s=homeManagement(),id=s?.ids.size===1?[...s.ids][0]:null;if(id){modal.close();await showHomePreview(id);}break;}
    case 'home-preview-open':if(homeManagementValid(homeManagement())&&modal.contains(el))await openRoom(el.dataset.id);break;
    case "open-room":
      await openRoom(el.dataset.id);
      break;
    case "home-camera": {
      if(state.page!=='home')break;
      const rooms=state.rooms.filter(r=>!r.ratchet_cutover_active);
      dialog('Fotoğraf çek',rooms.length?'<p class="hint">Fotoğrafı ekleyeceğin sohbeti seç. Gönderim için ayrıca onay vermen gerekir.</p>'+rooms.map(r=>`<button type="button" class="contact" data-action="home-camera-room" data-id="${escape(r.id)}">${avatar(r.kind==='group'?{name:name(r)}:r.members.find(m=>m.id!==state.user.id))}<span class="copy"><strong>${escape(name(r))}</strong></span>${icon('camera')}</button>`).join(''):'<p class="hint">Önce bir sohbet oluştur.</p><button class="primary" data-action="new-chat">Yeni sohbet</button>');break;
    }
    case "home-camera-room": {
      if(state.page!=='home'||!modal.open||!el.isConnected||!state.rooms.some(r=>r.id===el.dataset.id&&!r.ratchet_cutover_active))break;
      const id=el.dataset.id,epoch=access.epoch,opening=openRoom(id);
      try{if(access.valid(epoch)&&state.page==='chat'&&state.room?.id===id)await chooseFiles('camera');}finally{await opening;}break;
    }
    case "new-chat":
      await newChat();
      break;
    case "start-chat":
      await startChat(el.dataset.id);
      break;
    case "contact":
      dialog(
        "Kişi",
        row("start-chat", "edit", "Sohbet başlat") +
          `<button class="row danger" data-action="delete-contact" data-id="${el.dataset.id}">Kişiyi sil</button>`,
      );
      modal.querySelector('[data-action="start-chat"]').dataset.id =
        el.dataset.id;
      break;
    case "delete-contact":
      await api("/contacts/" + el.dataset.id, { method: "DELETE" });
      modal.close();
      await homeList();
      notice("Kişi silinenler listesine taşındı.", 2000, "success");
      break;
    case "deleted": {
      const all = await api("/contacts");
      dialog(
        "Silinen kişiler",
        all
          .filter((c) => c.deleted)
          .map(
            (c) =>
              `<div class="card">${escape(c.name)}<button data-action="restore-contact" data-id="${c.id}">Geri al</button><button class="danger" data-action="purge-contact" data-id="${c.id}">Tamamen sil</button></div>`,
          )
          .join("") || '<p class="hint">Liste boş.</p>',
      );
      break;
    }
    case "restore-contact":
      await api("/contacts", { method: "POST", body: { peer: el.dataset.id } });
      modal.close();
      await homeList();
      notice("Kişi geri alındı.", 2000, "success");
      break;
    case "purge-contact":
      await api("/contacts/" + el.dataset.id + "?permanent=1", {
        method: "DELETE",
      });
      modal.close();
      await homeList();
      notice("Kişi tamamen silindi.",2000,"success");
      break;
    case "search":showHomeSearch();break;
    case 'home-search-result':await selectHomeSearchResult(el);break;
    case "menu":
      dialog(
        "FS Mesajlaşma",
        row("profile", "user", "Profilim") +
          row("settings", "settings", "Ayarlar") +
          row("saved", "bookmark", "Kayıtlı Mesajlar") +
          row("media", "image", "Medya") +
          row("group", "plus", "Grup oluştur") +
          (state.isAdmin ? row("admin", "shield", "Yönetim Paneli") : "") +
          row("lock", "lock", "Kilitle"),
      );
      break;
    case "profile":
      modal.close();
      profile();
      break;
    case "peer-profile": {
      const room=state.room;if(!room)break;
      if(room.kind==='group'){
        dialog(name(room),`<p class="hint">${room.members.length} grup üyesi</p>${room.members.map(m=>`<div class="contact">${avatar(m)}<span class="copy"><strong>${escape(m.name)}</strong><p>${escape(m.status==='online'?'Çevrimiçi':m.status==='busy'?'Meşgul':'Çevrimdışı')}</p></span></div>`).join('')}`);
      }else{const peer=room.members.find(x=>x.id!==state.user.id);if(peer)profile(peer);}
      break;
    }
    case "settings":
      modal.close();
      settings();
      break;
    case "lock":
      modal.close();
      if (!state.call) state.socket?.close();
      showLock();
      break;
    case "logout":
      storyController?.clear();state.storiesEnabled=false;
      uploadRecovery.stop();uploadController?.abort();downloadRecovery.stop();downloadController?.abort();resetDelivery();state.sendOptions=false;state.durableDownload=false;state.durableUpload=false;state.viewOnce=false;callRingtones.stop();
      rememberChat();await persistLocal(true).catch(()=>{});
      if (state.call) await endCall().catch(() => {});
      discardVoice();
      for (const [watch, record] of liveLocations) {navigator.geolocation.clearWatch(watch);clearTimeout(record.timer)}
      liveLocations.clear();state.nativeLive=false;
      window.FSNative?.logout();
      try{await api("/logout", {method:"POST"})}catch{notice("Cihazdaki oturum kapatıldı; sunucuya ulaşılamadı.")}
      clearTimeout(localWrite);localData=null;
      presenceAuthenticated=false;presenceSent=null;approvedMaps.clear();
      state.token=null;state.user=null;state.isAdmin=false;state.room=null;state.reply=null;state.reactionTarget=null;state.keys.clear();state.keyFlights=null;state.contacts=[];state.selected.clear();state.settings={};
      state.messages=[];state.rooms=[];state.presenceStale=true;state.media=[];state.saved=[];state.cache.clear();
      stopThumbnailObservation();for(const cache of [audioUrls,thumbnailUrls])cache.clear()
      await vault("session",null);state.socket?.close();state.socket=null;clearReconnect(true);showLock();
      break;
    case "available": {
      if(el.disabled) break;
      el.disabled=true;
      try {
        await patchSettings({ available: state.settings.available === false });
        const available=state.settings.available !== false;
        document.querySelectorAll('[data-action="available"]').forEach(button=>{button.classList.toggle("off",!available);button.setAttribute('aria-pressed',String(available));button.setAttribute('aria-label',available?'Müsaitim; değiştirmek için dokunun':'Müsait değilim; değiştirmek için dokunun')});
        notice(available ? "Müsaitim" : "Müsait değilim", 2000, available ? "success" : "error", true);
      } finally {el.disabled=false;}
      break;
    }
    case "status":
      dialog(
        "Durumun",
        `<div class="card">${["online", "offline", "busy"].map((v, i) => `<button class="row" data-action="set-status" data-value="${v}">${["Çevrimiçi", "Çevrimdışı", "Meşgul"][i]}</button>`).join("")}</div>`,
      );
      break;
    case "set-status":
      setPresencePreference(el.dataset.value);
      await syncPresence(true);
      modal.close();
      break;
    case "view-avatar":
      viewProfilePhoto(el);
      break;
    case "profile-photo":
      profilePhotoChoices();
      break;
    case "edit-profile":
      dialog(
        "Profilini düzenle",
        `<form id="profile-form">${field("name", "Ad", "text", state.user.name)}${field("about", "Hakkımda", "text", state.user.about || "", false)}<button class="primary">Kaydet</button></form>`,
      );
      $("#profile-form").onsubmit = async (e) => {
        e.preventDefault();
        const submit=e.target.querySelector("button.primary");if(submit.disabled)return;submit.disabled=true;
        try {
        await patchSettings(Object.fromEntries(new FormData(e.target)));
        modal.close();
        profile();
        notice("Profil kaydedildi.", 2000, "success");
        } catch(err) {notice("Kaydedilemedi: "+err.message,4000,"error");}
        finally {submit.disabled=false;}
      };
      break;
    case "dark":
    case "light":
      {const page=state.page;await patchSettings({ theme: a === "dark" ? "dark" : "light" });
      if(modal.open)modal.close();
      if(state.page===page){if(page==="settings")settings();else if(page==="peer"){const peer=state.room?.members.find(m=>m.id!==state.user.id);if(peer)profile(peer);}else if(page==="profile")profile();}}
      notice("Tema kaydedildi.", 2000, "success");
      break;
    case "theme":
      dialog(
        "Tema",
        `<button class="row" data-action="dark">☾ Koyu</button><button class="row" data-action="light">☀ Açık</button>`,
      );
      break;
    case "call-voice":
      showVoiceSettings();
      break;
    case "call-mute":
      showCallMuteSettings();
      break;
    case "call-ringtones":
      showRingtoneSettings();
      break;
    case "preview-ringtone":
      if(!state.call)await callRingtones.preview(el.dataset.tone,()=>notice("Zil sesi dinletilemedi.",4000,"error"));
      break;
    case "stop-ringtone-preview":
      callRingtones.stop();
      break;
    case "pick-ringtone-file":
      if(!state.call){callRingtones.stop();window.FSNative?.pickCallRingtoneFile?.(el.dataset.tone);}
      break;
    case "ringtone-system-settings":
      callRingtones.stop();window.FSNative?.callRingtoneChannelSettings?.();
      break;
    case "android-full-screen-calls":
      window.FSNative?.fullScreenCallSettings?.();
      break;
    case "android-notifications":
      window.FSNative?.notificationSettings?.();
      break;
    case "account-email":
      await showAccountEmail();
      break;
    case "notifications":
    case "privacy":
      dialog(
        a === "privacy" ? "Gizlilik ve Güvenlik" : "Bildirimler",
        `<form id="prefs-form"><label class="toggle">Telefon numaramla bulunabilirim<input name="discoverByPhone" type="checkbox" ${state.settings.discoverByPhone===true ? "checked" : ""}></label><label class="toggle">E-posta adresimle bulunabilirim<input name="discoverByEmail" type="checkbox" ${state.settings.discoverByEmail===true ? "checked" : ""}></label><label class="toggle">Aranabilir<input name="available" type="checkbox" ${state.settings.available !== false ? "checked" : ""}></label><label class="toggle">Medya önizlemesini bulanıklaştır<input name="blur" type="checkbox" ${state.settings.blur !== false ? "checked" : ""}></label><label class="toggle">Mesaj bildirimleri<input name="messageAlerts" type="checkbox" ${state.settings.messageAlerts !== false ? "checked" : ""}></label><label class="toggle">Sessize alınan sohbetlerde sessiz bildirim<input name="silentMessageAlerts" type="checkbox" ${state.settings.silentMessageAlerts===true ? "checked" : ""}></label><label class="toggle">Bildirimlerde kişi veya grup adı<input name="notificationDetails" type="checkbox" ${state.settings.notificationDetails===true ? "checked" : ""}></label><label class="toggle">Bildirimlerde profil resmi<input name="notificationAvatars" type="checkbox" ${state.settings.notificationAvatars===true ? "checked" : ""}></label><p class="hint">Profil resmi için kişi/grup adı ayarı da açık olmalıdır. Kişi/grup adı isteğe bağlıdır; kilit ekranında Android gizlilik ayarları geçerlidir. Mesaj metni ve fotoğraflar güvenli girişe kadar gizlidir. Sessiz bildirim ayrı Android kanalını kullanır. Aranabilirlik yalnızca gelen çağrıları etkiler. Gelen aramalar için Android bildirim izni ve arka plan bağlantısı gerekir. Zorla durdurma ve cihazın pil kısıtlamaları çağrıları engelleyebilir.</p><button type="button" data-action="android-notifications">Android bildirim ayarları</button>${window.FSNative?.fullScreenCallSettings?`<p class="hint">Tam ekran arama izni: ${window.FSNative.canFullScreenCalls?.()?"Açık":"Kapalı — aramalar bildirim olarak gösterilir"}. Kilit ekranından yanıtlamak için güvenli giriş gerekir.</p><button type="button" data-action="android-full-screen-calls">Tam ekran arama izni</button>`:""}<button class="primary">Kaydet</button></form>`,
      );
      $("#prefs-form").onsubmit = async (e) => {
        e.preventDefault();
        const submit=e.target.querySelector("button.primary");if(submit.disabled)return;submit.disabled=true;
        try {
        const f = e.target;
        await patchSettings({
          available: f.available.checked,
          discoverByPhone: f.discoverByPhone.checked,
          discoverByEmail: f.discoverByEmail.checked,
          blur: f.blur.checked,
          messageAlerts: f.messageAlerts.checked,
          silentMessageAlerts: f.silentMessageAlerts.checked,
          notificationDetails: f.notificationDetails.checked,
          notificationAvatars: f.notificationAvatars?.checked===true,
        });
        modal.close();
        notice("Ayarlar kaydedildi.", 2000, "success");
        } catch(err) {notice("Kaydedilemedi: "+err.message,4000,"error");}
        finally {submit.disabled=false;}
      };
      break;
    case "saved":
      modal.close();
      await savedPage();
      break;
    case "unsave":
      await api("/saved/" + el.dataset.id, { method: "DELETE" });
      await savedPage();
      break;
    case "media":
      modal.close();
      await mediaPage();
      break;
    case "peer-media":
      if(state.page==='peer'&&state.room?.kind==='direct'&&state.room.id===el.dataset.id){modal.close();await mediaPage(el.dataset.id);}
      break;
    case "media-filter": {
      if(state.page!=='media'||!['Tümü','Fotoğraflar','Videolar','Dosyalar',...(mediaRoomScope?['Bağlantılar']:[])].includes(el.dataset.filter))break;
      const switched=(state.mediaFilter==='Bağlantılar')!==(el.dataset.filter==='Bağlantılar');
      state.mediaFilter = el.dataset.filter;
      if(switched){state.mediaQuery='';state.mediaDate='';await mediaPage();break;}
      document.querySelectorAll('[data-action="media-filter"]').forEach(b=>{const selected=b.dataset.filter===state.mediaFilter;b.classList.toggle("active",selected);b.setAttribute("aria-pressed",selected);});
      renderGallery();
      break;
    }
    case "download-all":
      for (const m of filteredMedia()) await download(m, true);
      break;
    case "attach":
      attach();
      break;
    case "recent-photos":
      requestRecentPhotos();
      break;
    case "send-recent":
      toggleRecentPhoto(el.dataset.id);
      break;
    case "confirm-recent":
      await sendRecentPhotos([...recentRequest?.selected||[]]);
      break;
    case "gallery":
    case "camera":
    case "document":
      await chooseFiles(a);
      break;

    case "emoji":
      state.reactionTarget=null;toggleComposerEmoji();
      break;
    case "choose-reaction": {const target=takeReactionTarget();modal.close();if(target)await reactToMessage(target,el.dataset.emoji,{removeOnly:el.dataset.removeOnly==="true"});break;}
    case "choose-emoji":
      if (state.reactionTarget||state.page!=='chat'||!el.isConnected) break;
      if(!insertComposerEmoji($("#message-text"),el.dataset.emoji))break;
      if(!el.closest('#composer-emoji-panel')){if(modal.open)modal.close();$("#message-text").focus({preventScroll:true});}
      break;
    case "message-reaction": await reactToMessage(el.dataset.id,el.dataset.emoji);break;
    case "context-react": if(takeMessageMenu(el))await reactToMessage(el.dataset.id,el.dataset.emoji);break;
    case "context-more": if(!takeMessageMenu(el))break;openReactionPicker(el.dataset.id);break;
    case "context-reaction-details": if(takeMessageMenu(el))showReactionDetails(el.dataset.id);break;
    case "context-op": {const id=el.dataset.id,op=el.dataset.op;if(!takeMessageMenu(el)||!messageContextOps(eligibleMessage(id),state.user.id).includes(op))break;if(op==="İndir"){const m=eligibleMessage(id);if(m&&!isViewOnce(m))await download(m,true);break;}if(op==="Yanıtla"){beginReply(id);break;}if(op==="Alıntıla"){chooseQuote(id);break;}if(op==="Bilgi"){await showMessageDetails(id);break;}if(op==="Sabitle"){await toggleMessagePin(id);break;}state.selected=new Set(selectionGroup(id));if(op==="Seç")renderMessages();else await selection(op);break;}
    case "jump-reply": await jumpReply(el.dataset.id);break;
    case "return-reply": returnReplyPosition();break;
    case "selection-menu": {const box=$("#selection");if(box){box.dataset.collapsed=box.dataset.collapsed==="1"?"0":"1";selectionBar();}break;}
    case "selection-react": {const id=el.dataset.id;if(state.selected.size!==1||!state.selected.has(id))break;state.selected.clear();renderMessages();await reactToMessage(id,el.dataset.emoji);break;}
    case "selection":
      await selection(el.dataset.op);
      break;
    case "cancel-reply":
      state.reply = null;
      $("#reply").innerHTML = "";rememberChat();
      break;
    case "play-audio":
      await playAudio(el.dataset.id);
      break;
    case "view-album": viewAlbum(el.dataset.id,Number(el.dataset.index));break;
    case "album-prev": await albumViewer?.controller.step(-1);break;
    case "album-next": await albumViewer?.controller.step(1);break;
    case "album-retry": await albumViewer?.controller.retry();break;
    case "album-save": {const view=albumViewer;if(view?.controller.ready){const m=currentPhoto(view.controller.current.id,view.page);if(m&&view.eligible(m))await download(m,true);}break;}
    case "album-save-all": {const anchor=albumViewer?.anchor;if(anchor){dismissAlbumViewer();await downloadAlbum(anchor);}break;}
    case "download-album":
      await downloadAlbum(el.dataset.id);break;
    case "cancel-album":
      if(albumJob)albumJob.cancelled=true;break;
    case "view-once": {
      const m=state.messages.find(x=>x.id===el.dataset.id);if(m)confirmViewOnce(m);break;
    }
    case "download":
    case "save-file": {
      const m = [
        ...state.messages,
        ...state.media,
        ...(state.saved || []),
      ].find((x) => x.id === el.dataset.id);
      if (m) await download(m, a === "save-file");
      break;
    }
    case "review-recording":
      reviewRecording();
      break;
    case "send-recording":
      await sendRecording();
      break;
    case "discard-recording":
      if(voiceSending)break;discardVoice();
      if(modal.open&&modal.querySelector('[data-action="send-recording"]'))modal.close();
      break;
    case "stop-location":
      await stopLocations();
      break;
    case "live-location":
      locationDialog("live");
      break;
    case "location":
      locationDialog();
      break;
    case "map": {
      const p = state.messages.find((m) => m.id === el.dataset.id)?.payload;
      const urls=p?.type==='location'&&mapUrls(p.lat,p.lng);if(urls) openExternal(urls.external);break;
    }
    case "map-preview": {
      const p = state.messages.find((m) => m.id === el.dataset.id)?.payload;
      if(p?.type!=='location'||!mapUrls(p.lat,p.lng))break;
      // Explicit permission: remote map provider receives location coordinates.
      dialog("Harita önizlemesi", `<p>Harita yüklenirken OpenStreetMap harita bölgesi ve internet bağlantınız hakkında bilgi alabilir. Canlı konum güncellendiğinde önizleme de güncellenir.</p><button class="primary" data-action="map-consent" data-id="${escape(el.dataset.id)}">Bu haritayı göster</button><button class="secondary" data-action="map-consent-all" data-id="${escape(el.dataset.id)}">Bu cihazda haritaları her zaman göster</button>`);break;
    }
    case "map-consent":
    case "map-consent-all": {
      const m=state.messages.find(m=>m.id===el.dataset.id);if(m?.payload?.type!=='location'||!mapUrls(m.payload.lat,m.payload.lng)){modal.close();break;}
      if(a==="map-consent-all"){try{localStorage.setItem('fs-map-preview:'+state.user?.id,'yes')}catch{}}
      approvedMaps.add(mapConsentKey(m));modal.close();renderMessages();break;
    }
    case "open-link": openExternal(el.dataset.url);break;
    case "poll":
      pollDialog();
      break;
    case "vote": {
      const m = state.messages.find((x) => x.id === el.dataset.id);
      await send({
        type: "vote",
        text: `${m.payload.text}: ${m.payload.options[Number(el.dataset.choice)]}`,
        poll: m.id,
        choice: Number(el.dataset.choice),
      });
      break;
    }
    case "event":
      eventDialog();
      break;
    case "invite": {
      const text = `FS Mesajlaşma'ya katıl. Kullanıcı adım: @${state.user.nick}. Davet kodu: 0032`;
      if (navigator.share) await navigator.share({ text });
      else {
        await navigator.clipboard.writeText(text);
        notice("Davet metni kopyalandı.");
      }
      break;
    }
    case "share-contact": await shareContactDialog();break;
    case "group": {
      const c = await api("/contacts");
      dialog(
        "Grup oluştur",
        `<form id="group-form">${field("title", "Grup adı")}${c
          .filter((p) => !p.deleted)
          .map(
            (p) =>
              `<label class="toggle">${escape(p.name)}<input type="checkbox" name="member" value="${p.id}"></label>`,
          )
          .join("")}<button class="primary">Oluştur</button></form>`,
      );
      $("#group-form").onsubmit = async (e) => {
        e.preventDefault();
        try {
        const f = new FormData(e.target),
          members = f.getAll("member");
        if (members.length < 2) throw Error("En az iki arkadaşını seç.");
        const r = await api("/rooms", {
          method: "POST",
          body: { title: f.get("title"), members },
        });
        modal.close();
        await refreshRooms();
        await openRoom(r.id);
        } catch (err) { notice(err.message, 4000, "error"); }
      };
      break;
    }
    case "resume-download": {const store=currentDownloadStore(),id=el.dataset.id;await serialDownload(async()=>{const job=(await store.list()).find(j=>j.id===id);if(job)await exportDownload(store,job);});await showTransferStorage();break;}
    case "remove-download": {const store=currentDownloadStore(),id=el.dataset.id;await serialDownload(()=>store.remove(id));await showTransferStorage();break;}
    case "storage":
      await showTransferStorage();break;
    case "cancel-upload": {
      const cancelled=await cancelPendingUpload();await showTransferStorage();notice(cancelled?'Bekleyen yükleme iptal edildi.':'Bekleyen yükleme yok.',3000,'info');break;
    }
    case "resume":
      await resumeUpload();await showTransferStorage();notice('Bekleyen yüklemeler tamamlandı.',3000,'success');break;
    case "language":
      dialog("Dil", "<p>Türkçe</p>");
      break;
    case "app-about":
      dialog(
        "FS Mesajlaşma",
        '<p>Sürüm 34.32</p><p class="hint">Geliştirme sürümü. Yayınlanmadı. Android cihaz testleri ve arka plan bildirim entegrasyonu tamamlanmadan üretim sürümü değildir.</p>',
      );
      break;
    case "third-party-licenses":
      dialog("Açık kaynak lisansları",'<p>Animated Noto Emoji — Google. CC BY 4.0.</p><p>Mevcut FS paketinde çizimler 160 × 160 boyutuna ölçeklenmiş ve oynatma döngüsü sınırlandırılmıştır.</p><p><a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noopener noreferrer">Creative Commons Attribution 4.0 International</a></p><p><a href="https://googlefonts.github.io/noto-emoji-files/?view=docs" target="_blank" rel="noopener noreferrer">Noto Emoji kaynak ve belgeleri</a></p><p>Özgün FS karakter çizimleri, qrcode ve dijkstrajs bildirimleri kaynak paketinin licenses dizinindedir.</p>');
      break;
    case "privacy-policy":
      dialog(
        "Gizlilik politikası",
        `<div class="policy">${escape(privacyPolicy)}</div>`,
      );
      break;
    case "about":
    case "username":
      dialog(
        a === "username" ? "Kullanıcı Adı" : "Hakkımda",
        `<p>${escape(a === "username" ? "@" + state.user.nick : state.user.about)}</p>`,
      );
      break;
    case "invite-contact":
      if (window.FSNative?.inviteContact)
        window.FSNative.inviteContact(
          `FS Mesajlaşma'ya katıl. Kullanıcı adım: @${state.user.nick}. Davet kodu: 0032`,
        );
      else if (navigator.share)
        await navigator.share({
          text: `FS Mesajlaşma kullanıcı adım: @${state.user.nick}. Davet kodu: 0032`,
        });
      else notice("Rehber daveti Android uygulamasında kullanılabilir.");
      break;
    case "block-peer": {
      const peer = state.room?.members.find((m) => m.id !== state.user.id);
      if (peer) {
        await api("/blocks", { method: "POST", body: { peer: peer.id } });
        home();
        notice("Kişi engellendi.", 2000, "success");
      }
      break;
    }
    case "blocked": {
      const peers = await api("/blocks");
      dialog(
        "Engellenen kişiler",
        peers
          .map(
            (p) =>
              `<button class="row" data-action="unblock" data-id="${p.id}">${escape(p.name)} · Engeli kaldır</button>`,
          )
          .join("") || '<p class="hint">Engellenen kişi yok.</p>',
      );
      break;
    }
    case "unblock":
      await api("/blocks/" + el.dataset.id, { method: "DELETE" });
      modal.close();
      notice("Kişinin engeli kaldırıldı.",2000,"success");
      break;
    case "mute-peer": {
      const peer=state.room?.members.find(m=>m.id!==state.user.id); if(!peer)break;
      const muted=new Set(state.settings.mutedPeers||[]); if(muted.has(peer.id))muted.delete(peer.id);else muted.add(peer.id);
      await patchSettings({mutedPeers:[...muted]}); profile(peer); notice(muted.has(peer.id)?"Kişi sessize alındı.":"Kişinin sessiz ayarı kaldırıldı.",2000,"success"); break;
    }
    case "contact-delete": {
      const peer = state.room?.members.find((m) => m.id !== state.user.id);
      if (peer) await api("/contacts/" + peer.id, { method: "DELETE" });
      home();
      break;
    }
    case "qr":
      dialog(
        "QR Kodum",
        `<canvas id="qr-canvas" aria-label="Davet QR kodu"></canvas><p>@${escape(state.user.nick)}</p><button class="primary" data-action="invite">Arkadaşına Davet Gönder</button>`,
      );
      await QRCode.toCanvas(
        $("#qr-canvas"),
        JSON.stringify({ app: "FS", nick: state.user.nick, invite: "0032" }),
        { width: 260, margin: 2, color: { dark: "#301639", light: "#ffffff" } },
      );
      break;
    case "audio-call":
      await startCall(false);
      break;
    case "video-call":
      await startCall(true);
      break;
    case "accept-call":
      if (!state.call?.incoming || state.call.accepting) break;
      const acceptedCall = state.call;
      callRingtones.stop();window.FSNative?.dismissCallRingtone?.(acceptedCall.callId);
      state.call.accepting = true;
      state.call.phase = "Bağlanıyor…";
      showCall();
      try { if(acceptedCall.group)await setupGroupMedia(acceptedCall);else await setupPeer(); } catch(err) { if(state.call===acceptedCall){await endCall(); throw err;} break; }
      if (state.call !== acceptedCall) break;
      try { signal({ type: acceptedCall.group?"group-call-accept":"accepted", room: acceptedCall.room.id }); }
      catch(err) { await endCall(false); throw err; }
      acceptedCall.incoming = false;
      showCall();
      break;
    case "reject-call":
      if(!state.call?.incoming) break;
      try { signal({ type: state.call.group?"group-call-leave":"call-rejected", room: state.call.room.id }); }
      finally { await endCall(false); }
      break;
    case "end-call":
      await endCall();
      break;
    case "call-back":
      await openRoom(state.call.room.id);
      break;
    case "return-call":
      if(state.call){if(modal.open)modal.close();showCall();}
      break;
    case "mute": {
      const tracks=state.call?.stream?.getAudioTracks()||[];
      if(!tracks.length)throw Error("Görüşmenin bağlanmasını bekle.");
      const capture=state.call.voiceCapture,enabled=capture?!capture.muted:tracks.some(t=>t.enabled);if(capture)capture.setMuted(enabled);else tracks.forEach(t=>t.enabled=!enabled);
      updateCallControl(el,enabled,enabled?"mic-off":"mic",enabled?"Mikrofon kapalı":"Mikrofon");break;
    }
    case "camera-toggle":
      if(state.call?.group){const tracks=state.call.stream?.getVideoTracks()||[];if(!tracks.length)throw Error("Grup aramasında kamera bulunmuyor.");const enabled=tracks.some(t=>t.enabled);tracks.forEach(t=>t.enabled=!enabled);showCall();break;}
      if (!state.call?.pc || !state.call?.stream)
        throw Error("Görüşmenin bağlanmasını bekle.");
      if(state.call.extras?.ready){const x=state.call.extras;await x.setMode(x.mode==="camera"?"off":"camera");break;}
      if(!state.call.stream?.getVideoTracks().length)throw Error("Görüntüye geçmek için iki cihazda da güncel sürüm gerekli.");
      {const tracks=state.call.stream.getVideoTracks();const enabled=tracks.some(t=>t.enabled);tracks.forEach(t=>t.enabled=!enabled);state.call.extras?.legacyCamera(!enabled);updateCallControl(el,!enabled,enabled?"video-off":"video",enabled?"Kamera":"Kamera açık");}
      break;
    case "call-extras":showCallExtras();break;
    case "call-switch-camera":{const c=state.call;if(!c?.extras?.canSwitchCamera||modal._fsExtrasCall!==c)break;modal.close();await c.extras.switchCamera();break;}
    case "call-stop-sharing":if(state.call?.extras?.mode==="screen")await state.call.extras.setMode("off");break;
    case "call-share-screen":
    case "call-media-off":{
      const c=state.call;if(!c?.extras||modal._fsExtrasCall!==c)break;
      modal.close();await c.extras.setMode(a==="call-share-screen"?"screen":"off");break;
    }
    case "call-reaction":{
      const c=state.call;if(!c?.extras||modal._fsExtrasCall!==c)break;
      if(!c.extras.react(el.dataset.emoji))throw Error("Emoji gönderilemedi; biraz sonra tekrar deneyin.");modal.close();break;
    }
    case "speaker":
      if(window.FSNative?.audioRoute)showAudioRouteMenu();else notice("Ses çıkışını cihazın ses menüsünden seç.");
      break;
    case "bluetooth": {
      if(!state.call||state.call.incoming)break;
      if(window.FSNative?.audioRoute){let info={};try{info=JSON.parse(window.FSNative.audioState?.()||"{}");}catch{}if(info.route==="bluetooth"||info.pending==="bluetooth")window.FSNative.audioRoute(state.call.previousAudioRoute||(state.call.video?"speaker":"earpiece"));else{state.call.previousAudioRoute=["wired","speaker","earpiece"].includes(info.route)?info.route:null;window.FSNative.audioRoute("bluetooth");}}
      else notice("Ses çıkışını cihazın ses menüsünden seç.");
      break;
    }
    case "choose-audio-route": {
      const route=el.dataset.route;
      if(state.call&&!state.call.incoming&&modal._fsAudioCall===state.call&&["auto","speaker","earpiece","bluetooth","wired"].includes(route)){modal.close();window.FSNative?.audioRoute?.(route);}
      break;
    }
    case "verification":
      await verification();
      break;
    case "verify-call": {
      const proof=el?._fsVerification,c=state.call;
      if(!proof||!c||state.page!=="call"||proof.call!==c||proof!==c.securityProof||proof.code!==c.callSecurity||!proof.code?.symbols||!c.securityExpanded||!sameCallVerification(proof.code.snapshot,callVerificationSnapshot(c.pc,c.callId))||!await verifyCallTransport(proof.code.snapshot)||state.call!==c||state.page!=="call"||isLocked()||proof!==c.securityProof||proof.code!==c.callSecurity||!c.securityExpanded||!sameCallVerification(proof.code.snapshot,callVerificationSnapshot(c.pc,c.callId))){if(modal.open)modal.close();if(state.call===c&&c){c.verified=false;c.securityExpanded=false;c.securityProof=null;renderCallSecurity(c);}throw Error("Görüşme değişti veya sertifika doğrulanamadı. Yeniden doğrulayın.");}
      c.verified = true;
      c.securityExpanded=false;c.securityProof=null;
      if(modal.open)modal.close();
      notice("Güvenlik kodu eşleşmesi onaylandı.");if(state.page==="call")renderCallSecurity(c);
      break;
    }
    case "reply-call": {
      if(!state.call?.incoming || state.call.accepting) break;
      const room = state.call.room;
      await endCall();
      const input=$("#message-text");if(state.page!=="chat"||state.room?.id!==room.id||!input||input.disabled)break;
      input.value = "Şu an yanıtlayamıyorum, sana yazacağım.";syncComposer();rememberChat();
      break;
    }

  }
}
document.addEventListener("click", async (e) => {
  const el = e.target.closest("[data-action]");
  if(isLocked()){if(el?.dataset.action==="open-link")e.preventDefault();return;}
  if (!el) return;
  if(el.dataset.action==="open-link"){e.preventDefault();if(state.selected.size)return;}
  try {
    await actions(el.dataset.action, el);
  } catch (err) {
    if (err.name !== "AbortError") notice(err.message, 4000, "error");
  }
});
modal.addEventListener("close",()=>{if(!modal.open){if(modal.classList.contains("home-preview-dialog")){modal.classList.remove("home-preview-dialog");modal.replaceChildren();}modal._fsAudioCall=null;state.reactionTarget=null;clearMessageMenu();if(modal.querySelector("[data-message-history]"))modal.innerHTML="";closeAlbumViewer();clearProfileViewer();scheduleReceipts();}if(modal.querySelector("#ringtone-form")&&!state.call?.incoming)callRingtones.stop();});
// A system file chooser is a temporary interruption, not dismissal of the story draft.
function nativeStoryPickerOpen(){try{return window.FSNative?.isFileChooserOpen?.()===true;}catch{return false;}}
document.addEventListener("visibilitychange",()=>{if(document.hidden){storyController?.closeViewer();if(modal.open&&(modal.querySelector(".story-view")||(modal.querySelector(".story-compose")&&!nativeStoryPickerOpen())))modal.close();if(modal.classList.contains("home-preview-dialog")&&modal.open)modal.close();dismissAlbumViewer();dismissProfileViewer();if(!state.call?.incoming)callRingtones.stop();}});
window.addEventListener("pagehide",()=>{dismissAlbumViewer();dismissProfileViewer();outgoingRingback.stop();callRingtones.stop()});
modal.addEventListener("click", (e) => {
  if (e.target === modal) {if(modal.classList.contains("profile-viewer"))dismissProfileViewer();else modal.close();}
});
$("#notice").onclick = () => ($("#notice").style.display = "none");

function textPayload(input){return {type:'text',text:input.value.trim()};}
function linkText(text){return urlParts(text).map(p=>p.url?`<a class="message-link" href="${escape(p.url)}" data-action="open-link" data-url="${escape(p.url)}" target="_blank" rel="noopener noreferrer">${escape(p.text)}</a>`:escape(p.text)).join('');}
function openExternal(value){assertAccess();launchExternal(value,{native:window.FSNative,open:(...args)=>window.open(...args)});}
const approvedMaps=new Set();
function mapConsentKey(m){return `${state.user?.id}:${m.id}`;}
function locationCard(m){const p=m.payload,urls=mapUrls(p.lat,p.lng);if(!urls)return 'Geçersiz konum';let allowed=approvedMaps.has(mapConsentKey(m));try{allowed||=localStorage.getItem('fs-map-preview:'+state.user?.id)==='yes'}catch{};
 const preview=allowed?mapPreview(p.lat,p.lng):null;
 const map=preview?`<div class="location-map" role="img" aria-label="Paylaşılan konumun harita önizlemesi"><div class="location-tiles" style="left:calc(50% - ${preview.x}px);top:calc(50% - ${preview.y}px)">${preview.tiles.map(t=>`<img src="${escape(t.url)}" alt="" loading="lazy" decoding="async" referrerpolicy="strict-origin-when-cross-origin" draggable="false" style="left:${t.col*256}px;top:${t.row*256}px">`).join('')}</div><span class="location-pin" aria-hidden="true">📍</span></div><button class="location-attribution" data-action="open-link" data-url="https://www.openstreetmap.org/copyright">© OpenStreetMap contributors</button>`:allowed?'<small>Bu konum için harita önizlemesi kullanılamıyor.</small>':`<button class="location-map-placeholder" data-action="map-preview" data-id="${escape(m.id)}">🗺️ Haritayı göster</button>`;
 return `<div class="location-card">${map}<strong data-live-location="${p.live===true?'true':'false'}" data-location-expiry="${Number.isFinite(p.expires)?p.expires:0}">📍 ${escape(liveLocationLabel(p))}</strong><small>${p.lat.toFixed(5)}, ${p.lng.toFixed(5)}</small><button class="location-open" data-action="map" data-id="${escape(m.id)}">Haritada aç ↗</button></div>`;
}
// An expired share must not be presented as live even if the last update was lost.
function expireLocationLabels(){if(document.hidden||state.page!=='chat'||isLocked())return;const now=Date.now();for(const el of document.querySelectorAll('[data-live-location="true"]'))if(Number(el.dataset.locationExpiry)<=now){el.textContent='📍 Canlı konum sona erdi';el.dataset.liveLocation='false';}}
foregroundInterval(document,expireLocationLabels,5000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)expireLocationLabels();});
function applyCallControls(c){const el=$('.call .controls');if(!el||state.call!==c||state.page!=='call')return;clearTimeout(state.controlsTimer);Object.assign(c,callControlState(c,Date.now()));el.classList.toggle('hidden-controls',!!c.controlsHidden);el.inert=!!c.controlsHidden;el.setAttribute('aria-hidden',String(!!c.controlsHidden));if(typeof placeCallPip==='function')placeCallPip();if(!c.controlsHidden)state.controlsTimer=setTimeout(()=>{if(state.call===c&&state.page==='call'){c.controlsHidden=true;applyCallControls(c)}},Math.max(0,c.controlsUntil-Date.now()));}
let viewportFrame=0, previousChatHeight=0, previousMessageHeight=0, viewportArea=null, viewportObserver=null;
let viewportScrollTop=0,viewportAtBottom=true;
function syncChatViewport(){
 if(state.page==='call'&&typeof placeCallPip==='function')placeCallPip();
 const area=$('#messages');
 if(state.page!=='chat'||!area){viewportObserver?.disconnect();viewportArea=null;app.style.removeProperty('--chat-viewport-height');app.style.removeProperty('--chat-viewport-top');previousChatHeight=previousMessageHeight=0;app.classList.remove('chat-compact-viewport','chat-tiny-viewport');return;}
 const v=window.visualViewport;const currentHeight=area.clientHeight;
 const bottom=viewportArea===area&&previousMessageHeight>0&&currentHeight!==previousMessageHeight?viewportAtBottom:nearLatest(area);
 const savedTop=viewportArea===area&&previousMessageHeight>0&&currentHeight!==previousMessageHeight?viewportScrollTop:area.scrollTop;
 // Fixed positioning is relative to the layout viewport; offsetTop is the visible viewport's displacement within it.
 const height=Math.max(1,Math.floor(v?.height>0?v.height:window.innerHeight));const top=Math.max(0,v?.offsetTop||0);
 if(viewportArea!==area){viewportObserver?.disconnect();viewportArea=area;previousChatHeight=previousMessageHeight=0;if(typeof ResizeObserver==='function'){viewportObserver??=new ResizeObserver(scheduleChatViewport);viewportObserver.observe(area);}}
 app.style.setProperty('--chat-viewport-height',height+'px');app.style.setProperty('--chat-viewport-top',top+'px');app.classList.toggle('chat-compact-viewport',height<420);app.classList.toggle('chat-tiny-viewport',height<280);
 const messageHeight=area.clientHeight;
 if(previousChatHeight!==height||previousMessageHeight!==messageHeight){previousChatHeight=height;previousMessageHeight=messageHeight;if(bottom)area.scrollTop=area.scrollHeight;else area.scrollTop=savedTop;virtualMessages?.draw(!!bottom);}
 viewportAtBottom=nearLatest(area);viewportScrollTop=area.scrollTop;
 placeChatPip();updateLatestButton();
}
function scheduleChatViewport(){if(viewportFrame)return;viewportFrame=requestAnimationFrame(()=>{viewportFrame=0;syncChatViewport()});}
function pipBounds(){const area=$('#messages');if(!area)return null;const a=area.getBoundingClientRect(),b=app.getBoundingClientRect();return {left:a.left-b.left+4,top:a.top-b.top+4,width:Math.max(0,a.width-8),height:Math.max(0,a.height-8)};}
function placeChatPip(){const el=$('#call-mini'),c=state.call,b=pipBounds();if(!el||!c||!b)return;layoutFloatingVideo(el,b,c,'chatPipRatio','chatPipHeight',128);}
function bindChatPip(){const el=$('#call-mini'),c=state.call;if(!el||!c)return;bindFloatingVideo(el,c,{bounds:pipBounds,place:placeChatPip,positionKey:'chatPipRatio',sizeKey:'chatPipHeight',onTap:()=>showCall()});}
window.visualViewport?.addEventListener('resize',scheduleChatViewport);window.visualViewport?.addEventListener('scroll',scheduleChatViewport);window.addEventListener('resize',scheduleChatViewport);document.addEventListener('focusin',scheduleChatViewport);document.addEventListener('focusout',scheduleChatViewport);
// Publish lifecycle via existing authenticated /me PATCH. Server-side expiry is additionally required for process kill/network loss.
document.addEventListener('visibilitychange',()=>{if(document.hidden)typing.reset()});window.addEventListener('pagehide',()=>typing.reset());window.addEventListener('offline',()=>typing.reset());
let presenceAuthenticated=false,presenceSent=null,presenceWriting=false,presenceQueued=null;
function presencePreference(){try{return localStorage.getItem('fs-presence:'+state.user?.id)||'online'}catch{return 'online'}}
function setPresencePreference(value){try{localStorage.setItem('fs-presence:'+state.user?.id,value)}catch{}}
function presenceForeground(){return !document.hidden&&!state.locked&&state.page!=='auth'&&state.page!=='setup'&&(typeof window==='undefined'||window.FSNative?.isForeground?.()!==false);}
async function syncPresence(force=false,leaving=false){
 if(!state.token||!state.user)return;
 const token=state.token,foreground=!leaving&&presenceForeground();
 if(foreground&&!presenceAuthenticated&&!presenceSent)return;
 const preferred=presencePreference();
 const wanted=effectiveStatus(foreground,presenceAuthenticated&&navigator.onLine!==false,preferred);
 if(state.presenceSocket&&presenceAuthenticated){
  const ws=state.socket;if(ws?.readyState!==1||navigator.onLine===false){presenceSent=null;state.user.status='offline';return;}
  if(!force&&presenceSent?.socket===ws&&presenceSent?.status===wanted&&presenceSent?.foreground===foreground)return;
  try{ws.send(JSON.stringify({type:'presence-socket-v2',foreground,preference:preferred}));presenceSent={token,socket:ws,status:wanted,foreground};state.user.status=wanted;}catch{presenceSent=null;state.user.status='offline';}
  return;
 }
 if(presenceWriting){presenceQueued={force,leaving};return;}
 if(!force&&presenceSent?.token===token&&presenceSent?.status===wanted)return;
 if(!apiRoot||navigator.onLine===false)return;
 presenceWriting=true;
 try{const res=await fetch(apiRoot+'/api/me',{method:'PATCH',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({status:wanted}),keepalive:true});if(!res.ok)throw Error('Durum güncellenemedi');if(state.token===token){presenceSent={token,status:wanted};if(state.user)state.user.status=wanted;}}catch{if(force&&!leaving&&!document.hidden)notice('Durum sunucuya iletilemedi. Bağlantı geldiğinde yeniden denenecek.');}finally{presenceWriting=false;if(presenceQueued){const next=presenceQueued;presenceQueued=null;queueMicrotask(()=>syncPresence(next.force,next.leaving))}}
}
document.addEventListener('visibilitychange',()=>{if(document.hidden){clearEmojiEffect();clearSendEffects();}else{restoreCallSurface();connect();scheduleChatViewport();scheduleReceipts();syncVisibleStories()}syncPresence();});window.addEventListener('pagehide',()=>syncPresence(true,true));window.addEventListener('online',()=>{syncPresence();syncVisibleStories();});window.addEventListener('offline',()=>{presenceSent=null;if(state.user)state.user.status='offline';typing.reset();markPresenceStale();});foregroundInterval(document,()=>{if(presenceForeground()&&state.token){syncPresence(state.presenceLease===true||state.presenceSocket===true);}},8000);
foregroundInterval(document,syncVisibleStories,30000);

async function boot() {
  // FS v2 verification uses the stable bundled legacy emoji ordering, never the extension catalog.
  const {catalog:[legacy,extension],identity:deviceIdentity}=await prepareBoot(()=>Promise.all([fetch("emojis.json").then(r=>r.json()),fetch("emoji-extension.json").then(r=>r.ok?r.json():[]).catch(()=>[])]),identity);
  legacyVerificationEmojis=legacy;
  emojiItems=mergeEmojiCatalog(legacy,extension);
  emojiIndex = buildEmojiIndex(emojiItems);
  state.identity = deviceIdentity;
  const session = await vault("session");
  if (session) {
    state.token = session.token;
    state.user = session.user;
  }
  const pinRecord=await vault("pin");
  if(!pinRecord && session){app.textContent="Kilit kaydı eksik. Güvenlik nedeniyle oturum açılmadı.";return;}
  bootReady=true;
  if (!pinRecord) {
    state.page = "setup";
    app.innerHTML = `<section class="lock"><div class="brand">Fs</div><h1>Hesap Kilidi Oluştur</h1><p class="hint">Bu cihaza en az 6 rakamlı bir PIN belirle. PIN’i hesap makinesine yazıp = tuşuna bas. Mevcut hesabın varsa ardından telefon numaran ve hesap şifrenle giriş yap; yeniden üye olman gerekmez.</p><form id="pin-form">${field("pin", "Hesap makinesi PIN’i", "password")}${field("confirm-pin", "PIN tekrar", "password")}<button class="primary">Şifre oluştur</button><div class="error" role="alert"></div></form></section>`;
    for(const input of app.querySelectorAll('#pin-form input')){input.inputMode="numeric";input.autocomplete="new-password";}
    $("#pin-form").onsubmit = async (e) => {
      e.preventDefault();
      const submit=e.target.querySelector("button.primary");if(submit.disabled)return;submit.disabled=true;
      try {
        const f = new FormData(e.target);
        if (f.get("pin") !== f.get("confirm-pin"))
          throw Error("Şifreler aynı olmalı.");
        if(state.page!=="setup"||!isLocked()||await vault("pin"))return;
        await setPin(f.get("pin"));
        showLock();
      } catch (err) {
        e.target.querySelector(".error").textContent = err.message;
      } finally {submit.disabled=false;}
    };
  } else showLock();
}
// A pending calculator check cannot complete after the app is hidden or a native window is opened.
function cancelPendingEntry(){if(bootReady&&(state.page==="lock"||state.page==="auth"))showLock();}
document.addEventListener("visibilitychange",()=>{if(document.hidden&&state.page==="lock")cancelPendingEntry();});
window.addEventListener("pagehide",cancelPendingEntry);
window.addEventListener("popstate",()=>{if(bootReady&&state.page!=="setup")showLock()});
window.addEventListener("pageshow",e=>{if(e.persisted&&bootReady&&state.page!=="setup")showLock()});
boot().catch((err) => {
  app.textContent = "Başlatılamadı: " + err.message;
});
window.FSApp = {
  back() {
    if(isLocked()||state.page==="lock"||state.page==="setup"){
      if(state.page==="lock"){const popup=app.querySelector(".calc-popup");if(popup)popup.remove();else if(calculatorView)showLock();}
      return;
    }
    if (modal.open) {if(modal.classList.contains("profile-viewer"))dismissProfileViewer();else modal.close();}
    else if (state.page === "chat" && closeComposerEmoji()) return;
    else if (state.page === "call")
      actions("call-back").catch((err) => notice(err.message,4000,"error"));
    else if (state.page === "chat" && state.selected.size){state.selected.clear();renderMessages();}
    else if (state.page === "chat") home();
    else if (state.page === "home" && homeManagement()?.ids.size) {homeManagement().ids.clear();paintHomeSelection();}
    else if (state.page === "home") showLock();
    else if (state.page === "auth") showLock();
    else if (state.page === "setup") return;
    else actions("back").catch(err=>notice(err.message,4000,"error"));
  },
};

// View only the displayed profile. The edit button remains a separate action.
function clearProfileViewer() {
  if(!modal.classList.contains("profile-viewer"))return;
  modal.querySelector(".profile-viewer-image")?.disposeZoom?.();
  modal.classList.remove("profile-viewer","profile-viewer-full");
  modal.replaceChildren();
}
function dismissProfileViewer() {
  if(!modal.classList.contains("profile-viewer"))return;
  if(modal.open)modal.close();
  clearProfileViewer();
}
// Coordinates are relative to the image center. Limit pan to visible image edges.
function profileZoomBounds(view, width, height, photoWidth, photoHeight) {
  photoWidth=Number.isFinite(photoWidth)?Math.max(0,photoWidth):0;photoHeight=Number.isFinite(photoHeight)?Math.max(0,photoHeight):0;
  const scale=Math.max(1,Math.min(5,Number.isFinite(view.scale)?view.scale:1));
  const maxX=Math.max(0,(photoWidth*scale-width)/2),maxY=Math.max(0,(photoHeight*scale-height)/2);
  return {scale,x:Math.max(-maxX,Math.min(maxX,Number.isFinite(view.x)?view.x:0)),y:Math.max(-maxY,Math.min(maxY,Number.isFinite(view.y)?view.y:0))};
}
function profileZoomAt(view,scale,from,to=from) {
  scale=Math.max(1,Math.min(5,scale));const factor=scale/view.scale;
  return {scale,x:to.x-(from.x-view.x)*factor,y:to.y-(from.y-view.y)*factor};
}
function attachProfileZoom(stage,image,controls,active,toggle) {
  const pointers=new Map(),win=stage.ownerDocument.defaultView;
  let view={scale:1,x:0,y:0},suppress=false,dead=false;
  const valid=()=>!dead&&active()&&!stage.hidden;
  const minus=controls.querySelector('[data-zoom="out"]'),plus=controls.querySelector('[data-zoom="in"]'),resetButton=controls.querySelector('[data-zoom="reset"]'),label=controls.querySelector('output');
  function paint(next=view){
    if(!valid())return;
    // The img uses object-fit:contain; its untransformed box is centered in the stage.
    const w=stage.clientWidth,h=stage.clientHeight,iw=image.clientWidth,ih=image.clientHeight;
    const f=image.naturalWidth&&image.naturalHeight?Math.min(iw/image.naturalWidth,ih/image.naturalHeight):0;
    view=profileZoomBounds(next,w,h,image.naturalWidth*f,image.naturalHeight*f);
    // In fullscreen the image box and stage match. In medium they coincide as well.
    image.style.transform=`translate(${view.x}px,${view.y}px) scale(${view.scale})`;
    stage.classList.toggle('is-zoomed',view.scale>1);minus.disabled=view.scale<=1;plus.disabled=view.scale>=5;resetButton.disabled=view.scale===1;
    label.textContent=`${Math.round(view.scale*100)}%`;
  }
  function reset(){paint({scale:1,x:0,y:0});}
  function local(point){const r=stage.getBoundingClientRect();return {x:point.x-r.left-r.width/2,y:point.y-r.top-r.height/2};}
  function pair(){const [a,b]=pointers.values();return b?{center:local({x:(a.x+b.x)/2,y:(a.y+b.y)/2}),distance:Math.hypot(a.x-b.x,a.y-b.y)}:null;}
  stage.onpointerdown=e=>{
    if(!valid()||e.button!==0)return;
    if(!pointers.size)suppress=false;else suppress=true;
    pointers.set(e.pointerId,{x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY});
    try{stage.setPointerCapture(e.pointerId);}catch{}
  };
  stage.onpointermove=e=>{
    const p=pointers.get(e.pointerId);if(!p||!valid())return;
    const before=pair(),dx=e.clientX-p.x,dy=e.clientY-p.y;
    p.x=e.clientX;p.y=e.clientY;
    if(Math.hypot(p.x-p.startX,p.y-p.startY)>5)suppress=true;
    if(before){const after=pair();suppress=true;if(before.distance>1&&after.distance>1)paint(profileZoomAt(view,view.scale*after.distance/before.distance,before.center,after.center));}
    else if(suppress&&view.scale>1)paint({...view,x:view.x+dx,y:view.y+dy});
  };
  function end(e){if(pointers.delete(e.pointerId)&&e.type==='pointercancel')suppress=true;}
  stage.onpointerup=end;stage.onpointercancel=end;stage.onlostpointercapture=end;
  stage.onclick=e=>{if(!valid())return;if(suppress&&e.detail!==0){suppress=false;return;}if(pointers.size)return;reset();toggle();};
  stage.onwheel=e=>{if(!valid())return;e.preventDefault();const anchor=local({x:e.clientX,y:e.clientY});const delta=e.deltaY*(e.deltaMode===1?16:e.deltaMode===2?stage.clientHeight:1);paint(profileZoomAt(view,view.scale*Math.exp(-delta*.002),anchor));};
  const center={x:0,y:0};minus.onclick=()=>paint(profileZoomAt(view,view.scale/1.25,center));plus.onclick=()=>paint(profileZoomAt(view,view.scale*1.25,center));resetButton.onclick=reset;
  stage.onkeydown=e=>{if(!valid())return;const offsets={ArrowLeft:[32,0],ArrowRight:[-32,0],ArrowUp:[0,32],ArrowDown:[0,-32]};if(offsets[e.key]&&view.scale>1){e.preventDefault();const [x,y]=offsets[e.key];paint({...view,x:view.x+x,y:view.y+y});}else if(['+','=','-','0'].includes(e.key)){e.preventDefault();if(e.key==='0')reset();else paint(profileZoomAt(view,view.scale*(e.key==='-'?.8:1.25),center));}};
  const resize=win?.ResizeObserver?new win.ResizeObserver(()=>paint()):null;resize?.observe(stage);image.onload=()=>paint();
  stage.disposeZoom=()=>{dead=true;for(const id of pointers.keys()){try{stage.releasePointerCapture(id);}catch{}}pointers.clear();resize?.disconnect();stage.onpointerdown=stage.onpointermove=stage.onpointerup=stage.onpointercancel=stage.onlostpointercapture=stage.onclick=stage.onwheel=stage.onkeydown=image.onload=null;};
  paint();return {reset};
}
function viewProfilePhoto(trigger) {
  if(isLocked() || !["profile","peer"].includes(state.page) || !trigger?.isConnected || trigger!==app.querySelector('.profile-avatar-button'))return;
  const photo=trigger.querySelector('img.avatar-photo'),src=photo?.getAttribute('src');
  if(!src)return;
  const epoch=access.epoch,owner=state.user?.id,page=state.page;
  dialog("Profil fotoğrafı",'<button type="button" class="profile-viewer-image" aria-label="Tam ekran görüntüle" aria-pressed="false"><img alt="Profil fotoğrafı" draggable="false"></button><div class="profile-zoom-controls" role="group" aria-label="Fotoğraf yakınlaştırma"><button type="button" data-zoom="out" aria-label="Uzaklaştır">−</button><output aria-label="Yakınlaştırma oranı">100%</output><button type="button" data-zoom="in" aria-label="Yakınlaştır">+</button><button type="button" data-zoom="reset" aria-label="Yakınlaştırmayı sıfırla">Sıfırla</button></div><p class="profile-viewer-hint">Tam ekran için dokun · İki parmakla yakınlaştır</p><p class="profile-viewer-error" role="status" hidden>Profil fotoğrafı açılamadı.</p>');
  modal.classList.add('profile-viewer');
  const stage=modal.querySelector('.profile-viewer-image'),image=stage.querySelector('img'),hint=modal.querySelector('.profile-viewer-hint'),error=modal.querySelector('.profile-viewer-error'),controls=modal.querySelector('.profile-zoom-controls');
  const active=()=>access.valid(epoch)&&state.user?.id===owner&&state.page===page&&trigger.isConnected&&modal.open&&stage.isConnected&&modal.querySelector('.profile-viewer-image')===stage;
  image.onerror=()=>{if(active()){stage.disposeZoom?.();stage.hidden=true;controls.hidden=true;hint.hidden=true;error.hidden=false;}};
  attachProfileZoom(stage,image,controls,active,()=>{
    const full=modal.classList.toggle('profile-viewer-full');
    stage.setAttribute('aria-pressed',String(full));
    stage.setAttribute('aria-label',full?'Orta boy görüntüle':'Tam ekran görüntüle');
    hint.textContent=(full?'Orta boy için dokun':'Tam ekran için dokun')+' · İki parmakla yakınlaştır';
  });
  image.src=src;
}

function profilePhotoChoices() {
  if(isLocked() || state.page !== "profile" || !state.user || !state.token) return;
  const input = $("#profile-photo-file");
  if(!input || input.dataset.busy === "true") return;
  const epoch=access.epoch, token=state.token, userId=state.user.id;
  const ownerCurrent=()=>access.valid(epoch)&&state.token===token&&state.user?.id===userId&&state.page==="profile"&&$("#profile-photo-file")===input&&input.isConnected;
  const selected=PROFILE_AVATARS.find(a=>a.photo===state.user.avatar)?.id || "";
  dialog("Profil resmi", `<div class="avatar-picker"><button type="button" class="secondary avatar-gallery" id="profile-avatar-gallery">${icon("image")}<span>Galeriden fotoğraf seç</span></button><h3>Hazır avatar seç</h3><form id="profile-avatar-form"><div class="avatar-picker-grid" role="radiogroup" aria-label="Hazır profil avatarları">${PROFILE_AVATARS.map(a=>`<label class="avatar-option"><input type="radio" name="avatar" value="${a.id}" aria-label="${escape(a.label)}" ${selected===a.id?"checked":""}><img src="${a.photo}" alt="" width="72" height="72" decoding="async"><span class="avatar-option-check" aria-hidden="true">✓</span></label>`).join("")}</div><button class="primary avatar-save" type="submit" ${selected?"":"disabled"}>Avatarı kaydet</button></form></div>`);
  const form=$("#profile-avatar-form"), gallery=$("#profile-avatar-gallery"), save=form.querySelector('button[type="submit"]');
  const active=()=>ownerCurrent()&&modal.open&&$("#profile-avatar-form")===form&&form.isConnected;
  form.onchange=()=>{if(active()&&!input.dataset.busy)save.disabled=!profileAvatar(form.querySelector('input:checked')?.value);};
  gallery.onclick=()=>{if(!active()||input.dataset.busy)return;modal.close();profilePhoto();};
  form.onsubmit=async e=>{
    e.preventDefault();
    if(!active()||input.dataset.busy)return;
    const choice=profileAvatar(form.querySelector('input:checked')?.value);
    if(!choice)return;
    input.dataset.busy="true";
    const controls=[...form.querySelectorAll('input,button'),gallery,...input.parentElement.querySelectorAll('[data-action="profile-photo"]')];
    controls.forEach(c=>c.disabled=true);
    try{
      // Store the actual JPEG with the existing authenticated profile API, not a device-local path.
      await patchSettings({avatar:choice.photo});
      if(!active())return;
      modal.close();profile();notice("Profil avatarı kaydedildi.",2000,"success");
    }catch(err){if(active())notice(err.message||"Avatar kaydedilemedi.",4000,"error");}
    finally{delete input.dataset.busy;controls.forEach(c=>c.disabled=false);if(active())save.disabled=!profileAvatar(form.querySelector('input:checked')?.value);}
  };
}

async function profilePhoto() {
  // A dedicated picker prevents profile selection from overwriting the chat attachment handler.
  if (isLocked() || state.page !== "profile" || !state.user || !state.token) return;
  const input = $("#profile-photo-file");
  if (!input || input.dataset.busy === "true") return;
  const epoch = access.epoch, token = state.token, userId = state.user.id;
  const current = () => access.valid(epoch) && state.token === token && state.user?.id === userId && state.page === "profile" && $("#profile-photo-file") === input && input.isConnected;
  const controls = [...input.parentElement.querySelectorAll('[data-action="profile-photo"]')];
  input.value = "";
  input.onchange = async () => {
    const file = input.files?.[0];
    input.value = "";
    if (!file || !current() || input.dataset.busy === "true") return;
    input.dataset.busy = "true";
    controls.forEach(control => { control.disabled = true; });
    let bitmap;
    try {
      if (!/^image\/(jpeg|png|webp)$/.test(file.type) || !file.size || file.size > 10 * 1048576)
        throw Error("10 MB altında bir JPEG, PNG veya WebP fotoğrafı seçin.");
      bitmap = await createImageBitmap(file);
      if (!current()) return;
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      const side = Math.min(bitmap.width, bitmap.height);
      if (!ctx || !side) throw Error("Fotoğraf okunamadı.");
      let photo='';
      // Retain compatibility with the server's 150000-character avatar limit.
      for(const [edge,quality] of [[512,.92],[512,.82],[384,.86],[256,.85],[256,.65]]){
        canvas.width=canvas.height=edge;ctx.imageSmoothingQuality='high';
        ctx.drawImage(bitmap,(bitmap.width-side)/2,(bitmap.height-side)/2,side,side,0,0,edge,edge);
        photo=canvas.toDataURL('image/jpeg',quality);
        if(photo.startsWith('data:image/jpeg;base64,')&&photo.length<=150000)break;
      }
      canvas.width=canvas.height=1;
      if (!photo.startsWith("data:image/jpeg;base64,") || photo.length > 150000) throw Error("Fotoğraf kaydedilemedi. Farklı bir fotoğraf seçin.");
      if (!current()) return;
      await patchSettings({ avatar: photo });
      if (!current()) return;
      profile();
      notice("Profil fotoğrafı kaydedildi.", 2000, "success");
    } catch (err) {
      if (current()) notice(err.message || "Fotoğraf kaydedilemedi.", 4000, "error");
    } finally {
      bitmap?.close();
      delete input.dataset.busy;
      controls.forEach(control => { control.disabled = false; });
    }
  };
  input.click();
}

function recoverHistoryDialog(){
 if(isLocked()||!state.user||!state.token||state.page==='admin-room')return;
 const epoch=access.epoch,account=state.user.id,token=state.token,root=apiRoot;
 dialog('Eski mesaj anahtarını kurtar',`<form id="history-key-form"><p class="hint">Bu hesaba ait şifreli v2 anahtar yedeğini ve kurtarma parolasını seç. Mevcut cihaz anahtarı, oturum ve mesajlar değişmez. Yedek cihazda çözülür; sunucuya gönderilmez. Eski anahtar yoksa şifreli mesajlar geri getirilemez.</p><label for="history-key-file">Şifreli kişisel anahtar yedeği</label><input id="history-key-file" type="file" accept="application/json,.json" required>${field('history-key-password','Yedek parolası','password')}<button class="primary">Eski anahtarı ekle</button><p class="error" role="alert"></p></form>`);
 const form=$('#history-key-form');form.onsubmit=async e=>{
  e.preventDefault();const btn=form.querySelector('button.primary');if(btn.disabled)return;btn.disabled=true;
  const sessionValid=()=>access.valid(epoch)&&state.user?.id===account&&state.token===token&&apiRoot===root;
  const current=()=>sessionValid()&&form.isConnected&&modal.open;
  try{
   const file=form.querySelector('#history-key-file').files[0];if(!file||file.size>20000)throw Error('Geçersiz anahtar dosyası.');
   const packet=JSON.parse(await file.text());if(!current())return;
   const result=await addHistoryKey({root,account,packet,password:new FormData(form).get('history-key-password'),activePub:state.identity.pub,valid:current});if(!current())return;
   historyKeyFlight=null;state.cache.clear();form.reset();modal.close();
   notice(result.current?'Bu anahtar zaten etkin.':result.added?'Eski anahtar eklendi.':'Bu eski anahtar zaten kayıtlı.',3000,'info');
   if(state.page==='chat'&&state.room){const route=state.routeVersion,room=state.room.id;
    const updated=await Promise.all(state.messages.map(m=>m.payload?.type==='locked'&&m.envelope?decode(m):m));
    if(!sessionValid()||state.routeVersion!==route||state.room?.id!==room||state.page!=='chat')return;
    const recovered=new Map(updated.filter(m=>m.payload?.type!=='locked').map(m=>[m.id,m]));
    state.messages=state.messages.map(m=>m.payload?.type==='locked'&&recovered.has(m.id)&&recovered.get(m.id).edited===m.edited?recovered.get(m.id):m);
    storePage(room,state.messages);renderMessages();await loadMessages(route);
   }
  }catch(err){if(current())form.querySelector('.error').textContent='Yedek açılamadı veya bu hesaba ait değil. '+(err.message||'');else if(sessionValid())notice('Mesajlar yeniden yüklenemedi. Daha sonra tekrar dene.',3000,'error');}finally{btn.disabled=false;}
 };
}
async function exportKeyDialog(){
  if(isLocked()||!state.user||!state.token)return;
  const epoch=access.epoch,account=state.user.id,pub=state.identity.pub;
  const packet=await vault("recovery");assertEpoch(epoch);
  if(!packet)throw Error("Anahtar yedeği bulunamadı.");
  dialog("Şifreli anahtar yedeği",`<form id="export-key-form"><p class="hint">Dosyayı güvenli bir yerde sakla. Kurtarma parolanı unutursan yedeğin açılamaz. Dosya veya parola sunucuya gönderilmez.</p>${field("old-key-password",packet.version===1?"İlk anahtar oluşturulurken kullanılan hesap şifresi":"Mevcut kurtarma parolası","password")}${field("new-key-password","Yeni kurtarma parolası (en az 16 karakter)","password")}${field("confirm-key-password","Kurtarma parolası tekrar","password")}<button class="primary">Şifreli yedeği indir</button><p class="error" role="alert"></p></form>`);
  const form=$("#export-key-form");form.onsubmit=async e=>{
    e.preventDefault();const submit=form.querySelector("button.primary");if(submit.disabled)return;submit.disabled=true;
    const current=()=>access.valid(epoch)&&state.user?.id===account&&form.isConnected&&modal.open;
    try{
      const data=new FormData(form),pass=data.get("new-key-password");if(pass!==data.get("confirm-key-password"))throw Error("Kurtarma parolaları eşleşmiyor.");
      const backup=await createRecoveryExport(packet,data.get("old-key-password"),pass,account,pub);if(!current())return;
      const blob=new Blob([JSON.stringify(backup)],{type:"application/json"}),name="FS-kisisel-anahtar-yedegi.json";
      if(window.FSNative?.beginFile)await nativeFile(blob,name,"application/json","save");else{const url=URL.createObjectURL(blob),link=document.createElement("a");link.href=url;link.download=name;link.click();setTimeout(()=>URL.revokeObjectURL(url),10000);}
      if(current()){form.reset();modal.close();notice("Şifreli yedek için kaydetme işlemi başlatıldı.",3000,"info");}
    }catch(err){if(current())form.querySelector(".error").textContent=err.message||"Yedek oluşturulamadı.";}finally{submit.disabled=false;}
  };
}
function passwordRecoveryDialog() {
  if(isLocked()||state.page!=="auth"||state.token)return;
  const epoch=access.epoch;
  dialog("Şifre yenileme",`<form id="recovery-start-form">${field("recovery-phone","Telefon numarası","tel")}${field("recovery-email","Doğrulanmış e-posta","email")}<button class="primary">Kurtarma kodu iste</button><p class="error" role="alert"></p></form>`);
  const form=$("#recovery-start-form");
  const current=f=>access.valid(epoch)&&state.page==="auth"&&!state.token&&f.isConnected&&modal.open;
  form.onsubmit=async e=>{
    e.preventDefault();const button=form.querySelector("button.primary");if(button.disabled||!current(form))return;button.disabled=true;
    const phone=form.elements.namedItem("recovery-phone").value.trim(),email=form.elements.namedItem("recovery-email").value.trim();
    try{
      await verifyServer(apiRoot);if(!current(form))return;
      await api("/account/recovery/start",{method:"POST",body:{phone,email}});if(!current(form))return;
      modal.close();
      dialog("Yeni hesap şifresi",`<p class="hint">Bilgiler eşleşiyorsa doğrulanmış e-postana kod gönderilir. Kod 10 dakika geçerlidir.</p><form id="recovery-finish-form">${field("recovery-code","E-postadaki kurtarma kodu")}${field("recovery-password","Yeni şifre","password")}${field("recovery-confirm","Yeni şifre tekrar","password")}<p class="security-note">Eski oturumlar kapanır. Şifreli mesajların açılması için kişisel anahtar yedeğin ve yedek parolan gerekebilir.</p><button class="primary">Şifreyi yenile</button><p class="error" role="alert"></p></form>`);
      const finish=$("#recovery-finish-form");finish.elements.namedItem("recovery-code").autocomplete="one-time-code";
      for(const name of ["recovery-password","recovery-confirm"])finish.elements.namedItem(name).autocomplete="new-password";
      finish.onsubmit=async ev=>{
        ev.preventDefault();const submit=finish.querySelector("button.primary"),error=finish.querySelector(".error");if(submit.disabled||!current(finish))return;
        const code=finish.elements.namedItem("recovery-code").value.trim(),password=finish.elements.namedItem("recovery-password").value;
        if(code.length!==32||password.length<6||password.length>256||password!==finish.elements.namedItem("recovery-confirm").value){error.textContent="Kodu ve eşleşen yeni şifreleri kontrol edin (en az 6 karakter).";return;}
        submit.disabled=true;error.textContent="";
        try{await api("/account/recovery/finish",{method:"POST",body:{phone,email,code,password}});if(!current(finish))return;finish.reset();modal.close();authPage(false);notice("Şifre yenilendi. Yeni şifrenle giriş yap. Eski cihaz anahtarın yoksa önce kişisel anahtar yedeğini içe aktar.",6000,"success");}
        catch(err){if(current(finish))error.textContent=err.message||"Şifre yenilenemedi.";}finally{submit.disabled=false;}
      };
    }catch(err){if(current(form))form.querySelector(".error").textContent=err.message||"Kod istenemedi.";}finally{button.disabled=false;}
  };
}
function importKeyDialog() {
  if(isLocked()||state.page!=="auth"||state.token)return;
  const epoch=access.epoch;
  dialog("Kişisel anahtar yedeği",`<form id="key-form"><p class="hint">Yeni yedeklerde kurtarma parolanı, eski yedeklerde oluşturulurken kullanılan hesap şifreni gir. Anahtar henüz değiştirilmeyecek.</p><label for="key-file">Şifreli anahtar dosyası</label><input id="key-file" type="file" accept="application/json,.json" required>${field("key-password", "Yedek parolası", "password")}<button class="primary">Yedeği doğrula</button><p class="error" role="alert"></p></form>`);
  const form=$("#key-form");form.onsubmit=async e=>{
    e.preventDefault();const submit=form.querySelector("button.primary");if(submit.disabled)return;submit.disabled=true;
    const current=()=>access.valid(epoch)&&state.page==="auth"&&!state.token&&form.isConnected&&modal.open;
    try{
      const file=form.querySelector("#key-file").files[0];if(!file||file.size>20000)throw Error("Geçersiz anahtar dosyası.");
      const candidate=await inspectRecovery(JSON.parse(await file.text()),new FormData(form).get("key-password"));
      if(!current())return;
      state.pendingRecovery=candidate;form.reset();modal.close();authPage(false);notice("Yedek doğrulandı. Şimdi ilgili hesabınla giriş yap.",3000,"success");
    }catch(err){if(current())form.querySelector(".error").textContent="Dosya veya yedek parolası doğrulanamadı.";}finally{submit.disabled=false;}
  };
}

function callLabel(c) {
  const seconds =
    c.connected && c.ended
      ? Math.max(0, Math.floor((c.ended - c.connected) / 1000))
      : 0;
  return `${c.video ? "Görüntülü" : "Sesli"} arama · ${c.status === "missed" ? "Cevapsız" : c.status === "rejected" ? "Reddedildi" : c.status === "ringing" ? "Aranıyor" : seconds ? Math.floor(seconds / 60) + ":" + String(seconds % 60).padStart(2, "0") : "Sona erdi"}`;
}

async function nativeFile(blob, name, mime, action) {
  if(isLocked())return;
  const epoch=access.epoch,token=state.token;
  const active=()=>{assertEpoch(epoch);if(state.token!==token)throw new DOMException("Oturum değişti.","AbortError");};
  const id = window.FSNative.beginFile(name, mime, action);
  if (!id) throw Error("Dosya işlemi başlatılamadı.");
  try {
    for (let offset = 0; offset < blob.size; offset += 49152) {
      const bytes = new Uint8Array(
        await blob.slice(offset, offset + 49152).arrayBuffer(),
      );
      active();if (!window.FSNative.appendFile(id, b64(bytes)))
        throw Error("Dosya yazılamadı.");
    }
    active();window.FSNative.finishFile(id);
  } catch (err) {
    window.FSNative.cancelFile(id);
    throw err;
  }
}

// Administration is a separate transient workspace. Do not put decrypted
// administrative records into normal chat caches or persist them locally.
async function verifyAdminRecipient(admin){
  assertAccess();const epoch=access.epoch,root=apiRoot,account=state.user?.id,token=state.token;
  return assertAdminTrust(root,admin,{read:key=>vault(key),write:(key,value)=>vault(key,value),valid:()=>access.valid(epoch)&&apiRoot===root&&state.user?.id===account&&state.token===token});
}
async function adminKeyInfo(){
  if(isLocked()||state.isAdmin!==true||state.page!=='admin')return;
  const valid=adminGuard('admin'),admin=state.adminAudit;
  if(!admin||admin.id!==state.user.id)throw Error('Yönetici kimliği doğrulanamadı.');
  const actual={id:state.user.id,pub:state.identity.pub};
  const expected=await adminFingerprint(admin),local=await adminFingerprint(actual);
  if(!valid())return;
  if(expected!==local)throw Error('Bu cihazın anahtarı sunucudaki yönetici anahtarıyla eşleşmiyor.');
  await verifyAdminRecipient(admin);if(!valid())return;
  dialog('Yönetici anahtarı',`<p>Bu cihazın anahtarıyla eşleşiyor. Başka cihazlarda karşılaştırmak için SHA256 parmak izi:</p><p class="admin-fingerprint">${expected.match(/.{1,4}/g).join(' ')}</p><p>Özel anahtar gösterilmez veya sunucuya gönderilmez. Kurtarma yedeğinizi güvenli ve çevrimdışı saklayın.</p>`);
}
function clearAdminState(){
  adminSequence++;state.adminRooms=[];state.adminMessages=[];state.adminAudit=null;state.adminOlder=null;
  if(state.adminRoomId){if(state.media===state.adminMedia)state.media=[];state.adminRoomId=null;state.adminMedia=null;}
}
function adminGuard(page){
  const sequence=++adminSequence,epoch=access.epoch,token=state.token,user=state.user?.id,root=apiRoot;
  return ()=>!isLocked()&&access.valid(epoch)&&state.isAdmin===true&&state.token===token&&state.user?.id===user&&apiRoot===root&&state.page===page&&adminSequence===sequence;
}
async function adminPage(query='',userOffset=0,roomOffset=0) {
  if(isLocked()||state.isAdmin!==true)return;
  clearAdminState();state.page = "admin";
  const valid=adminGuard("admin");
  shell("Yönetim Paneli",'<p role="status" class="hint">Yükleniyor…</p>');
  const [summary,users,rooms] = await Promise.all([
    api('/admin/overview'),
    api('/admin/console/users?limit=50&offset='+userOffset+'&q='+encodeURIComponent(query)),
    api('/admin/console/rooms?limit=50&offset='+roomOffset+'&q='+encodeURIComponent(query)),
  ]);
  if(!valid())return;
  state.adminRooms = rooms.items;state.adminQuery=query;state.adminAudit=summary.admin;
  shell(
    "Yönetim Paneli",
    adminDashboard(summary,users,rooms,escape,query,userOffset,roomOffset),
  );
  $('#admin-search-form').onsubmit=e=>{e.preventDefault();if(valid())adminPage($('#admin-query').value.trim()).catch(error=>notice(error.message,4000,'error'));};
}
async function adminRoom(id) {
  if(isLocked()||state.isAdmin!==true||!['admin','admin-room'].includes(state.page))return;
  const room = state.adminRooms?.find((r) => r.id === id);
  if (!room) throw Error("Sohbet bulunamadı.");
  const previous=state.adminOlder===id&&state.adminRoomId===id?state.adminMessages:[];state.adminOlder=null;
  state.page = "admin-room";state.adminMessages=[];state.media=[];state.adminMedia=state.media;state.adminRoomId=id;
  const valid=adminGuard("admin-room");
  shell("Sohbet Denetimi",'<p role="status" class="hint">Yükleniyor…</p>');
  const tail=previous.at(-1);
  const records=await api("/admin/rooms/" + encodeURIComponent(id) + "/messages"+(tail?'?before='+tail.created+'&before_id='+encodeURIComponent(tail.id):''));
  if(!valid())return;
  const decoded=[...previous];const seen=new Set(previous.map(m=>m.id));
  for(const m of records){
    if(!valid())return;
    if(m.room!==id||seen.has(m.id))continue;
    const sender=room.members.find(u=>u.id===m.sender)||(room.kind==='group'&&m.sender_pub?{id:m.sender,pub:m.sender_pub}:null);
    let payload={type:'locked',text:'Bu cihazda mesaj anahtarı bulunamadı.'};
    if(sender)try{payload=await openMessagePayload(room,sender,m.envelope,m.sender_pub);}catch{}
    if(!valid())return;
    decoded.push({...m,payload});
  }
  state.adminMessages=decoded;
  state.media = decoded.filter((m) => m.payload.type === "file");state.adminMedia=state.media;
  shell(
    "Sohbet Denetimi",
    (decoded.map(m=>`<div class="card"><p class="hint">${escape(room.members.find(u=>u.id===m.sender)?.name||m.sender)} · ${new Date(m.created).toLocaleString("tr-TR")}</p><p>${escape(preview(m.payload))}</p>${m.payload.type==="file"&&!isViewOnce(m)?`<button class="secondary" data-action="download" data-id="${escape(m.id)}">Dosyayı aç</button>`:""}<button class="danger" data-action="admin-delete" data-kind="messages" data-id="${escape(m.id)}">Sil</button></div>`).join("")||empty("Mesaj yok", "Bu sohbette kayıt bulunmuyor."))+(records.length===200?`<button class="secondary" data-action="admin-older" data-id="${escape(id)}">Daha eski mesajları yükle</button>`:''),
  );
}
async function adminDelete(kind, id) {
  if(isLocked()||state.isAdmin!==true||!['admin','admin-room'].includes(state.page)||!['messages','rooms','users'].includes(kind))return;
  const valid=adminGuard(state.page);
  dialog("Kalıcı silme",`<p>Seçilen kayıt kalıcı silinecek. Bu işlem geri alınamaz.</p><button id="admin-confirm" class="primary">Kalıcı sil</button>`);
  const confirm=$("#admin-confirm");
  confirm.onclick = async () => {
    if(!valid()||!modal.open||!confirm.isConnected||confirm.disabled)return;
    confirm.disabled=true;
    try {
      const result=await api("/admin/" + kind + "/" + encodeURIComponent(id), { method: "DELETE" });
      if(!valid())return;
      if(modal.contains(confirm))modal.close();
      await adminPage();
      if(result.pendingFileDeletions)notice('Kayıt erişimi kaldırıldı. '+result.pendingFileDeletions+' dosyanın silinmesi sunucuda yeniden denenecek.',6000,'info');
    } catch (err) {
      if(valid()&&confirm.isConnected){confirm.disabled=false;notice(err.message,4000,"error");}
    }
  };
}

async function thumbnail(file) {
  if (!/^image\/(jpeg|png|webp)$/.test(file.type)) return undefined;
  let bitmap;
  try {
    bitmap = await createImageBitmap(file);
    const blob=await encodePhotoPreview(bitmap,(w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;return c;},(c,quality)=>new Promise(resolve=>c.toBlob(resolve,'image/jpeg',quality)));
    if(!blob)return undefined;
    const encrypted = await encryptFile(blob);
    return {
      data: b64(encrypted.data),
      key: encrypted.key,
      iv: encrypted.iv,
      mime: "image/jpeg",
    };
  } catch {
    return undefined;
  } finally {bitmap?.close();}
}
const thumbnailUrls = new MediaUrlCache({count:40,bytes:16*1024*1024});
let thumbnailObserver=null;
function stopThumbnailObservation(){thumbnailObserver?.disconnect();thumbnailObserver=null;}
function loadThumbnails() {
  stopThumbnailObservation();
  const nodes=[...document.querySelectorAll("[data-thumb]")];if(!nodes.length||isLocked())return;
  const epoch=access.epoch,token=state.token,page=state.page,route=state.routeVersion;
  const current=()=>access.valid(epoch)&&state.token===token&&state.page===page&&state.routeVersion===route;
  if(typeof IntersectionObserver==="function"){const observer=new IntersectionObserver(entries=>{if(thumbnailObserver!==observer||!current())return;for(const e of entries)if(e.isIntersecting){observer.unobserve(e.target);e.target._fsShowThumb?.();}},{rootMargin:"240px"});thumbnailObserver=observer;}
  for (const img of nodes) {
    const m = lookupRecord(img.dataset.thumb,state.messages,state.media),meta=!m||isViewOnce(m)||hiddenMessage(m)?null:m.payload.thumbnail;
    if(!meta){img.removeAttribute("data-thumb");continue;}
    const show=async()=>{
      if(!img.isConnected||img._fsThumbLoading||!current()||deletedInSession.has(m.id))return;
      img._fsThumbLoading=true;
      try{const valid=()=>current()&&!hiddenMessage(m);const url=await thumbnailUrls.load(m.id,()=>decryptFile(unb64(meta.data),meta),valid);if(valid()&&img.isConnected&&img.dataset.thumb===m.id&&thumbnailUrls.has(m.id)){img.src=url;img.removeAttribute("data-thumb");}}
      catch(error){if(current()&&img.isConnected&&error.name!=="AbortError")img.alt="Önizleme açılamadı";}
      finally{img._fsThumbLoading=false;}
    };
    img._fsShowThumb=show;if(thumbnailObserver)thumbnailObserver.observe(img);else show();
  }
}

function keyedMessages(target, markup) {
  const template = document.createElement("template");
  template.innerHTML = markup;
  const key = (node) =>
    node.dataset.key || node.dataset.message || node.dataset.action || "day:" + node.dataset.day;
  const old = new Map([...target.children].map((node) => [key(node), node]));
  let cursor = target.firstElementChild;
  for (const fresh of [...template.content.children]) {
    const id = key(fresh),
      existing = old.get(id),
      signature = fresh.outerHTML;
    let node;
    if (existing && existing._fsMarkup === signature) node = existing;
    else {
      const activeLine=existing?.querySelector(':scope > .tg-message-line[data-composer-animated="1"]');
      const freshLine=fresh.querySelector(':scope > .tg-message-line');
      const otherMarkup=(parent,line)=>[...parent.children].filter(child=>child!==line).map(child=>child.outerHTML).join('');
      if(activeLine&&freshLine&&activeLine.getAnimations?.().some(a=>a.playState==='running')&&
         otherMarkup(existing,activeLine)===otherMarkup(fresh,freshLine)&&
         activeLine.querySelector('.message.mine.fs-text-bubble')&&freshLine.querySelector('.message.mine.fs-text-bubble')){
        activeLine.dataset.bubbleGroup=freshLine.dataset.bubbleGroup;
        activeLine.replaceChildren(...freshLine.childNodes);
        node=existing;node._fsMarkup=signature;
      }else{
      node = fresh;
      node._fsMarkup = signature;
      if (existing) {
        for(const audio of existing.querySelectorAll("audio[data-audio]")){const replacement=node.querySelector(`audio[data-audio="${CSS.escape(audio.dataset.audio)}"]`);if(replacement)replacement.replaceWith(audio);}
        existing.replaceWith(node);
        if (cursor === existing) cursor = node;
      }
      }
    }
    old.delete(id);
    if (node !== cursor) target.insertBefore(node, cursor);
    cursor = node.nextElementSibling;
  }
  for (const node of old.values()) node.remove();
  const focus=target._fsReplyFocus;
  if(focus&&Date.now()<focus.until){const row=target.querySelector(`[data-message="${CSS.escape(focus.row)}"]`);const node=focus.id===focus.row?row:row?.querySelector(`[data-id="${CSS.escape(focus.id)}"]`)||row;node?.classList.add('found-message');}
}
const audioUrls = new MediaUrlCache({count:32,bytes:64*1024*1024});
let voicePlayIntent=0;
async function playAudio(id) {
  if(isLocked())return;
  const m=lookupRecord(id,state.messages);if(!m||m.payload.type!=='file'||!m.payload.mime.startsWith('audio/'))return;
  const initial=document.querySelector(`audio[data-audio="${CSS.escape(id)}"]`);if(!initial||initial._fsVoiceLoading)return;if(!initial.paused){voicePlayIntent++;initial.pause();return;}if(state.call||voiceController?.session)throw Error('Ses kaydı veya görüşme sırasında sesli mesaj oynatılamaz.');
  const epoch=access.epoch,token=state.token,room=state.room?.id,route=state.routeVersion;
  const valid=()=>access.valid(epoch)&&state.token===token&&!deletedInSession.has(id)&&state.routeVersion===route&&state.room?.id===room&&state.page==='chat';
  const intent=++voicePlayIntent;const control=initial.closest('.voice-message')?.querySelector('[data-action="play-audio"]');initial._fsVoiceLoading=true;if(control){control.disabled=true;control.textContent='…';}
  try{
  const url=await audioUrls.load(id,async()=>{const blob=await decryptFile(await fileBytes(m),m.payload);if(valid())transferStatus(id,'Hazır');return blob;},valid);
  if(intent!==voicePlayIntent||!valid()||state.routeVersion!==route||state.room?.id!==room)return;
  const audio=document.querySelector(`audio[data-audio="${CSS.escape(id)}"]`);if(!audio?.isConnected||!audioUrls.has(id)||state.call||voiceController?.session)return;
  if(audio.getAttribute('src')!==url)audio.src=url;restoreAudio();await audio.play();
  }finally{initial._fsVoiceLoading=false;if(control)control.disabled=false;const current=initial.closest('.voice-message')?.querySelector('[data-action="play-audio"]');if(current)current.disabled=false;syncVoicePlayer(initial);}
}
document.addEventListener('play',event=>{const audio=event.target;if(audio?.matches?.('audio[data-audio]'))document.querySelectorAll('audio[data-audio]').forEach(other=>{if(other!==audio)other.pause()})},true);
function emojiEffect(target){if(isLocked()||state.page!=="chat"||state.selected.size)return;const m=eligibleMessage(target.dataset.message);if(!m||m.payload.type!=="text"||!isSingleEmoji(m.payload.text))return;if(!animateEmoji(target,m.payload.text,{reducedMotion:!!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches}))return;sendEmojiInteraction(m).catch(error=>console.warn("emoji relay",error.message));}
async function sendEmojiInteraction(m){
 const room=state.room,epoch=access.epoch,ws=state.socket,route=state.routeVersion;if(!state.emojiRealtime||ws?.readyState!==1||!room||document.hidden||Date.now()-lastEmojiTap<100)return;lastEmojiTap=Date.now();
 const payload={type:EMOJI_EVENT,id:crypto.randomUUID().replaceAll("-",""),target:m.id,emoji:m.payload.text};if(!validInteraction(payload))return;const packets=Object.create(null);
 await Promise.all(room.members.filter(x=>x.id!==state.user.id).map(async peer=>{packets[peer.id]=await seal(await keyFor(peer),payload,room.id);}));
 if(!access.valid(epoch)||state.routeVersion!==route||state.room?.id!==room.id||state.page!=="chat"||document.hidden||state.socket!==ws||ws.readyState!==1)return;
 ws.send(JSON.stringify({type:EMOJI_EVENT,id:payload.id,room:room.id,target:m.id,envelopes:packets}));
}
async function receiveEmojiInteraction(b,epoch){
 const room=state.room,route=state.routeVersion;if(!state.emojiRealtime||!access.valid(epoch)||state.page!=="chat"||document.hidden||room?.id!==b.room||b.from===state.user?.id||!b.envelope)return;
 const peer=room.members.find(m=>m.id===b.from);if(!peer)return;
 const payload=await open(await keyFor(peer),b.envelope,room.id);if(!access.valid(epoch)||state.routeVersion!==route||state.room?.id!==room.id||state.page!=="chat"||document.hidden||state.selected.size)return;
 if(payload.id!==b.id||payload.target!==b.target||!matchesInteraction(payload,eligibleMessage(b.target),room.id)||!emojiWindow.accept(b.from+"-"+b.id,b.ts))return;
 const node=document.querySelector(`[data-message="${CSS.escape(b.target)}"]`),host=$(".fs-chat");if(!host)return;
 const rect=node?.getBoundingClientRect(),bounds=$("#messages")?.getBoundingClientRect(),visible=rect&&bounds&&rect.bottom>bounds.top&&rect.top<bounds.bottom;
 animateEmoji(visible?node:host,payload.emoji,{reducedMotion:!!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches,center:!visible,assetPath:emojiAsset(emojiIndex,payload.emoji)});
}
document.addEventListener('error',event=>{const image=event.target;if(image?.matches?.('.fs-empty-chat button > img')){const fallback=document.createElement('span');fallback.textContent=image.alt||'👋';fallback.setAttribute('aria-hidden','true');image.replaceWith(fallback);return;}if(image?.classList?.contains('emoji-picker-image')){const fallback=document.createElement('span');fallback.className='emoji-picker-glyph';fallback.textContent=image.alt;fallback.setAttribute('aria-hidden','true');image.replaceWith(fallback);return;}if(image?.classList?.contains('animated-emoji')){const fallback=document.createElement('span');fallback.className='emoji-fallback';fallback.textContent=image.alt;image.parentElement?.querySelector('.fs-motion-fallback')?.remove();image.replaceWith(fallback)}},true);

let messageActionFlight=false;
async function handleMessageAction(epoch=access.epoch){
  if(isLocked()||!state.token||messageActionFlight||state.call||!access.valid(epoch))return false;
  const raw=window.FSNative?.pendingMessageAction?.();if(!raw)return false;
  let action;try{action=JSON.parse(raw);}catch{return false;}
  if(!action||!['open','reply','read'].includes(action.action)||!state.rooms.some(r=>r.id===action.room)||!(/^[A-Za-z0-9_-]{10,64}$/.test(action.id)))return false;
  messageActionFlight=true;
  try{
    if(action.action==='read'){
      const result=await api('/rooms/'+action.room+'/notification-read',{method:'POST',body:{message:action.id}});
      assertEpoch(epoch);localState.preferences.read??={};localState.preferences.read[action.room]=Math.max(localState.preferences.read[action.room]||0,result.created);persistLocal();
      if(state.page==='home')homeList().catch(()=>{});notice('Mesajlar okundu olarak işaretlendi.',2000,'success');
    }else{await openRoom(action.room);assertEpoch(epoch);if(state.page!=='chat'||state.room?.id!==action.room)return false;if(action.action==='reply')$('#message-text')?.focus();else if(!state.messages?.some(m=>m.id===action.id&&(hiddenMessage(m)||m.pending))&&(state.messages?.some(m=>m.id===action.id)||state.hasOlder)){await jumpReply(action.id);assertEpoch(epoch);if(state.page!=='chat'||state.room?.id!==action.room)return false;}}
    window.FSNative?.completeMessageAction?.(raw);return true;
  }catch(err){if(access.valid(epoch)){if([403,404].includes(err.status))window.FSNative?.completeMessageAction?.(raw);notice('Bildirim işlemi: '+err.message,3500,'error');}return false;}
  finally{messageActionFlight=false;}
}

window.FSApp.pause = () => {if(onceViewer){closeOnceViewer();if(modal.open)modal.close();}typing.reset();syncPresence(true,true);};
window.FSApp.resume = async () => {
  if (isLocked() || !state.token) return;
  restoreCallSurface();
  const epoch=access.epoch;
  connect();syncPresence(true);uploadRecovery.kick();downloadRecovery.kick();syncVisibleStories();
  try {
    await refreshRooms();
    if(!access.valid(epoch))return;
    if(await reconcileCurrentCall(epoch))return;
    if(!access.valid(epoch))return;
    if(await handleMessageAction(epoch))return;
    if(!access.valid(epoch))return;
    const room = window.FSNative?.pendingMessage();
    if (room && state.rooms.some((r) => r.id === room)) await openRoom(room);
  } catch (err) {
    notice(err.message, 4000, "error");
  }
};

let recentPhotos = [];
function requestRecentPhotos(){
 const ctx=attachmentContext(state,access),strip=$('#recent-strip');if(!ctx.valid()||!strip||!modal.open||!window.FSNative?.recentPhotosFor)return;
 const id=Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join('');recentPhotos=[];recentRequest={id,ctx,strip,busy:false,selected:new Set()};const confirm=modal.querySelector(".recent-confirm");if(confirm)confirm.hidden=true;strip.textContent='Fotoğraflar yükleniyor…';window.FSNative.recentPhotosFor(id);
}
function recentActive(r){return !!r&&recentRequest===r&&r.ctx.valid()&&r.strip.isConnected&&modal.open;}
window.addEventListener('fs-recent-photos',e=>{
 const r=recentRequest;if(!recentActive(r)||e.detail?.request!==r.id)return;
 recentPhotos=recentItems(e.detail.photos);r.selected.clear();const confirm=modal.querySelector(".recent-confirm");if(confirm)confirm.hidden=true;
 r.strip.innerHTML=recentPhotos.map(p=>`<button type="button" data-action="send-recent" data-id="${escape(p.id)}" aria-label="${escape(p.name)} seç" aria-pressed="false"><img src="${escape(p.thumb)}" alt="${escape(p.name)}" draggable="false"><span class="recent-check" aria-hidden="true"></span></button>`).join('')||'<p class="hint">Fotoğraf yok veya erişim izni verilmedi.</p>';
});
function toggleRecentPhoto(id){
 const r=recentRequest;if(!recentActive(r)||r.busy||!recentPhotos.some(p=>p.id===id))return;
 if(r.selected.has(id))r.selected.delete(id);else r.selected.add(id);
 const ids=[...r.selected];for(const b of r.strip.querySelectorAll('[data-action="send-recent"]')){const i=ids.indexOf(b.dataset.id);b.setAttribute('aria-pressed',String(i>=0));b.querySelector('.recent-check').textContent=i>=0?String(i+1):'';}
 const confirm=modal.querySelector('.recent-confirm');if(confirm){confirm.hidden=!ids.length;confirm.textContent=`${ids.length} fotoğrafı ekle`;}
}
async function sendRecentPhoto(id) {
  if(isLocked())return;
  return sendRecentPhotos([id]);
}
async function sendRecentPhotos(ids){
 if(isLocked())return;
 const r=recentRequest,photos=[...new Set(ids)].map(id=>recentPhotos.find(p=>p.id===id));if(!recentActive(r)||!photos.length||photos.some(p=>!p)||r.busy)return;
 if(photos.some(p=>p.size>50*1048576))throw Error('Dosya sınırı 50 MB.');r.busy=true;
 const confirm=modal.querySelector('.recent-confirm');if(confirm)confirm.disabled=true;
 try{const files=[];for(const p of photos){const chunks=[];for(let offset=0;offset<p.size;offset+=49152){if(!recentActive(r))return;const size=Math.min(49152,p.size-offset),part=window.FSNative.photoChunk(p.id,offset,size);if(!part)throw Error('Fotoğraf okunamadı. Galeriden tekrar seç.');const bytes=unb64(part);if(bytes.length!==size)throw Error('Fotoğraf eksik okundu. Galeriden tekrar seç.');chunks.push(bytes);if(offset%(49152*4)===0)await new Promise(resolve=>setTimeout(resolve,0));}files.push(new File(chunks,p.name,{type:p.mime||'image/jpeg'}));}
 if(!recentActive(r))return;stageFiles(files,r.ctx.room,r.ctx.epoch);modal.close();
 }finally{r.busy=false;if(confirm?.isConnected)confirm.disabled=false;}
}

window.addEventListener("fs-audio-devices", (e) => { if(state.page!=="call"||!state.call||state.call.incoming)return;const info=e.detail||{};if(!!info.bluetooth!==!!document.querySelector('.call [data-action="bluetooth"]'))showCall();updateAudioRouteControls(info); });
window.addEventListener("fs-audio-error",e=>{if(state.call&&!isLocked())notice(String(e.detail||"Ses cihazı kullanılamıyor."),3500,"error");});
window.addEventListener("fs-audio-route", (e) => {if(state.page==="call"&&state.call&&!state.call.incoming)updateAudioRouteControls({route:e.detail});});

window.addEventListener("fs-ringtone-file",e=>{if(!isLocked()&&!state.call&&modal.open&&modal.querySelector("#ringtone-form")){showRingtoneSettings();notice(e.detail===true?"Zil sesi dosyası eklendi. Seçip kaydedin.":"Ses dosyası açılamadı.",3500,e.detail===true?"success":"error");}});
