// Account validation mirrors server limits; it never replaces server validation.
export function accountIssues(values, register) {
  const issues = [];
  const add = (field, message) => issues.push({field, message});
  if (register) {
    const name = String(values.name || '').trim();
    if (!name) add('name', 'Adınızı yazın.');
    else if (name.length > 120) add('name', 'Adınız en fazla 120 karakter olabilir.');
    const nick = String(values.nick || '').trim();
    if (!/^[A-Za-z0-9_]{3,32}$/.test(nick)) add('nick', 'Kullanıcı adı 3–32 karakter olmalı; harf, rakam ve alt çizgi kullanın.');
    const phone = String(values.phone || '').replace(/[^0-9+]/g, '');
    if (!/^\+?[0-9]{10,15}$/.test(phone)) add('phone', 'Geçerli telefon numaranızı 10–15 rakamla yazın.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(values.email || "").trim()) || String(values.email || "").length > 254) add("email", "Geçerli e-posta adresinizi yazın.");
    if (values.passwordConfirm !== values.password) add("passwordConfirm", "Şifreler eşleşmiyor.");
    if (String(values.invite || '').trim() !== '0032') add('invite', 'Davet kodunu 0032 olarak yazın.');
    if (values.privacy !== 'on') add('privacy', 'Devam etmek için gizlilik politikasını okuyup kabul edin.');
  } else if (!String(values.login || '').trim()) add('login', 'Telefon numaranızı yazın.');
  const password = String(values.password || '');
  if (password.length < 6 || password.length > 256) add('password', 'Hesap şifresi 6–256 karakter olmalı.');
  return issues;
}
export function showNotice(element, text, {kind='info', compact=false, duration=3000, schedule=setTimeout, cancel=clearTimeout}={}) {
  cancel(element.noticeTimer);
  element.textContent = text;
  element.className = `notice-${kind}${compact ? ' notice-compact' : ''}`;
  element.setAttribute('role', kind === 'error' && !compact ? 'alert' : 'status');
  element.setAttribute('aria-live', kind === 'error' && !compact ? 'assertive' : 'polite');
  element.style.display = 'block';
  element.noticeTimer = schedule(() => {element.style.display='none';}, duration);
}
