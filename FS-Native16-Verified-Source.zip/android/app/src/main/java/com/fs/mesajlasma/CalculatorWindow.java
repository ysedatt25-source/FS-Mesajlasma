package com.fs.mesajlasma;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.util.*;
/** Calculator-only overlay: no session, message, microphone or camera bridge. */
final class CalculatorWindow {
 private final MainActivity owner; private final WindowManager wm;
 private FrameLayout panel; private WebView calculator; private WindowManager.LayoutParams params;
 private boolean minimized=false; private String initial;
 private static final String ORIGIN="https://appassets.androidplatform.net";
 CalculatorWindow(MainActivity owner){this.owner=owner;wm=(WindowManager)owner.getSystemService(Activity.WINDOW_SERVICE);}
 private int dp(float n){return (int)(n*owner.getResources().getDisplayMetrics().density+.5f);}
 private int screenW(){return owner.getResources().getDisplayMetrics().widthPixels;}
 private int screenH(){return owner.getResources().getDisplayMetrics().heightPixels;}
 void open(String state){close();initial=state;panel=new FrameLayout(owner);GradientDrawable bg=new GradientDrawable();bg.setColor(0xffe7e8e9);bg.setCornerRadius(dp(24));panel.setBackground(bg);panel.setClipToOutline(true);
  params=new WindowManager.LayoutParams(Math.min(screenW()-dp(24),dp(330)),Math.min(screenH()-dp(80),dp(570)),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT);params.gravity=Gravity.TOP|Gravity.LEFT;params.x=Math.max(0,(screenW()-params.width)/2);params.y=dp(60);
  calculator=new WebView(owner);calculator.setOverScrollMode(android.view.View.OVER_SCROLL_NEVER);calculator.setBackgroundColor(0xffe7e8e9);WebSettings s=calculator.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  calculator.addJavascriptInterface(new Bridge(),"FSCalculator");calculator.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return true;}
   @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){String path=r.getUrl().getPath();String origin=r.getUrl().getScheme()+"://"+r.getUrl().getHost();if(ORIGIN.equals(origin)&&Arrays.asList("/calculator-window.html","/calculator-window.js","/calculator-ui.js","/calculator.js","/style.css").contains(path)){try{return new WebResourceResponse(path.endsWith(".js")?"application/javascript":path.endsWith(".css")?"text/css":"text/html","UTF-8",owner.getAssets().open("web"+path));}catch(IOException ignored){}}return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));}
   @Override public void onPageFinished(WebView view,String url){calculator.evaluateJavascript("window.FSCalculatorView&&window.FSCalculatorView.restore("+org.json.JSONObject.quote(initial==null?"{}":initial)+")",null);}
  });
  FrameLayout.LayoutParams webLayout=new FrameLayout.LayoutParams(-1,-1);webLayout.topMargin=dp(26);webLayout.bottomMargin=dp(10);panel.addView(calculator,webLayout);
  TextView handle=new TextView(owner);handle.setText("•••");handle.setTextColor(0xff686b69);handle.setGravity(Gravity.CENTER);FrameLayout.LayoutParams h=new FrameLayout.LayoutParams(-1,dp(26),Gravity.TOP);panel.addView(handle,h);handle.setOnTouchListener(new View.OnTouchListener(){float x,y;int px,py;public boolean onTouch(View v,MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){x=e.getRawX();y=e.getRawY();px=params.x;py=params.y;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){params.x=Math.max(0,Math.min(screenW()-params.width,px+(int)(e.getRawX()-x)));params.y=Math.max(0,Math.min(screenH()-params.height,py+(int)(e.getRawY()-y)));wm.updateViewLayout(panel,params);return true;}return true;}});
  TextView resize=new TextView(owner);resize.setText("⌟");resize.setTextColor(0xff777a78);resize.setGravity(Gravity.CENTER);panel.addView(resize,new FrameLayout.LayoutParams(dp(30),dp(25),Gravity.BOTTOM|Gravity.RIGHT));resize.setOnTouchListener(new View.OnTouchListener(){float x,y;int w,h;public boolean onTouch(View v,MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){x=e.getRawX();y=e.getRawY();w=params.width;h=params.height;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){params.width=Math.min(screenW()-params.x,Math.max(dp(230),w+(int)(e.getRawX()-x)));params.height=Math.min(screenH()-params.y,Math.max(dp(330),h+(int)(e.getRawY()-y)));wm.updateViewLayout(panel,params);return true;}return true;}});
  try{wm.addView(panel,params);calculator.loadUrl(ORIGIN+"/calculator-window.html");owner.moveTaskToBack(true);}catch(Exception e){close();Toast.makeText(owner,"Küçük pencere açılamadı. İzni kontrol edin.",Toast.LENGTH_LONG).show();}
 }
 void close(){if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}if(calculator!=null){calculator.removeJavascriptInterface("FSCalculator");calculator.destroy();}panel=null;calculator=null;minimized=false;}}
 private void minimize(){if(panel==null||minimized)return;minimized=true;int w=params.width,h=params.height;calculator.onPause();for(int i=0;i<panel.getChildCount();i++)panel.getChildAt(i).setVisibility(View.GONE);TextView bubble=new TextView(owner);bubble.setText("▦");bubble.setTextColor(Color.BLACK);bubble.setGravity(Gravity.CENTER);bubble.setTextSize(30);panel.addView(bubble,new FrameLayout.LayoutParams(-1,-1));params.width=dp(58);params.height=dp(58);wm.updateViewLayout(panel,params);bubble.setOnClickListener(v->{panel.removeView(bubble);for(int i=0;i<panel.getChildCount();i++)panel.getChildAt(i).setVisibility(View.VISIBLE);params.width=w;params.height=h;params.x=Math.max(0,Math.min(screenW()-w,params.x));params.y=Math.max(0,Math.min(screenH()-h,params.y));wm.updateViewLayout(panel,params);calculator.onResume();minimized=false;});}
 private class Bridge {
  @JavascriptInterface public void windowAction(String action,String state){if(state==null||state.length()>3000)return;owner.runOnUiThread(()->{if(action.equals("close"))close();else if(action.equals("minimize"))minimize();else if(action.equals("fullscreen")||action.equals("float")){close();owner.startActivity(new Intent(owner,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT|Intent.FLAG_ACTIVITY_SINGLE_TOP));owner.restoreCalculator(state);}});}
 }
}
