# Native16 görsel ve görüşme düzenlemeleri

Kullanıcının 27052024 ekranlı görseli Android ana ekran ikonuna uygulanır. Adaptif ikon güvenli alanı için çerçeve payı eklenir; görseldeki rakamlar değiştirilmez. Paket com.fs.mesajlasma, mevcut kalıcı APK sertifikası korunur. versionCode 16, önceki Native15 imzalı APK ile karşılaştırılır.

Hesap makinesinde Android WebView kenar yayları ve dokunma vurguları kapatılır. Tuşlar yalnız basılıyken 1.05 ölçek ve 1.20 parlaklık kullanır. Hesaplama, PIN ve erişim kapısı modülleri değiştirilmemiştir. Bilimsel mod ve küçük pencere aynı stil dosyasını kullanır.

Sohbet içindeki arama kaydına dokunmak/Enter ile etkinleştirmek, kayıttaki sesli veya görüntülü türle yeniden arama başlatır. Kilit, seçim ve eski odaya ait kayıt denetimleri korunur. Basılı tutup seçim akışı korunur. Arama simgeleri daha büyük, belirgin ve durum renkleriyle gösterilir.

Okyanus, Zümrüt, Kumtaşı, Gül Kurusu temaları eklenir. Tema aynı mevcut hesap ayarında saklanır. 16 hazır avatar özgün yapay üretim kurgusal yetişkin portreleriyle değiştirilir. Avatar kimlikleri, kullanıcı fotoğraf yükleme akışı ve önceden kaydedilmiş kullanıcı verileri korunur.

Kamera Full HD / 30 FPS tercih eder; zorunlu alt/üst sınır koyulmaz. Kamera motion ipucunu, ekran paylaşımı mevcut detail akışını kullanır. Mevcut uyarlamalı WebRTC sıkışma kontrolü, ses önceliği, yeniden bağlantı ve şifreleme korunur. Yüksek kalite, sıfır kesinti, gerçek kamera/Bluetooth performansı cihaz/ağ testleri yapılmadan doğrulanmış sayılmaz. İlgili teknik dayanak: https://www.w3.org/TR/mst-content-hint/ .

Yerel JavaScript testleri: 814/814. Gerçek Android kabulü ve CircleCI'nin tam tarayıcı/Android derleme sonuçları ayrıca kontrol edilmelidir. Canlı sunucu ve yönetici giriş bilgileri bu görsel güncellemede değiştirilmez.
