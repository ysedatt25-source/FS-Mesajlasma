"""Calculator feedback/layout under real Chromium; synthetic PIN only."""
import os,pathlib,unittest
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
class PolishBrowser(unittest.TestCase):
 def test_pressed_key_only_and_real_arithmetic(self):
  with sync_playwright() as p:
   options={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage']}
   if os.environ.get('FS_CHROMIUM'):options['executable_path']=os.environ['FS_CHROMIUM']
   browser=p.chromium.launch(**options)
   try:
    page=browser.new_page(viewport={'width':360,'height':780})
    page.set_content('<div id="app"></div>')
    for name in ('style.css','polish.css'):page.add_style_tag(content=(ROOT/'web'/name).read_text())
    code=(ROOT/'web/calculator.js').read_text().replace('export ','')+'\n'+(ROOT/'web/calculator-ui.js').read_text().split('\n',1)[1].replace('export ','')
    page.add_script_tag(content=code+'\nmountCalculator(document.querySelector("#app"));')
    key=page.locator('[data-calc="8"]');key.hover();page.mouse.down()
    pressed=key.evaluate('(e)=>({transform:getComputedStyle(e).transform,filter:getComputedStyle(e).filter})')
    page.wait_for_timeout(120)
    pressed=key.evaluate('(e)=>({transform:getComputedStyle(e).transform,filter:getComputedStyle(e).filter})')
    self.assertIn('1.05',pressed['transform']);self.assertEqual(pressed['filter'],'brightness(1.2)')
    other=page.locator('[data-calc="7"]').evaluate('(e)=>getComputedStyle(e).transform');self.assertEqual(other,'none')
    page.mouse.up();page.locator('[data-calc="AC"]').click()
    for value in ['1','2','÷','4','=']:page.locator('[data-calc="'+value+'"]').click()
    self.assertEqual(page.locator('.display').inner_text(),'3')
    self.assertEqual(page.evaluate('document.documentElement.scrollWidth<=innerWidth'),True)
   finally:browser.close()
if __name__=='__main__':unittest.main()
