import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
import {THEMES,selectedTheme,themeChoices} from '../web/themes.js';
import {videoCaptureConstraints,preferVideoMotion,preferVideoDetail} from '../web/call-quality.js';
test('six persisted theme values and escaped fixed preview controls',()=>{
 assert.equal(new Set(THEMES.map(t=>t.id)).size,6);assert.equal(selectedTheme('sand').light,true);assert.equal(selectedTheme('forest').light,false);assert.equal(selectedTheme('<script>').id,'dark');assert.equal((themeChoices('ocean').match(/aria-pressed="true"/g)||[]).length,1);
});
test('camera prioritizes motion while screen detail remains available, without mandatory capture caps',()=>{
 const camera={kind:'video',contentHint:''};preferVideoMotion(camera);assert.equal(camera.contentHint,'motion');preferVideoDetail(camera);assert.equal(camera.contentHint,'detail');
 const c=videoCaptureConstraints();assert.equal(c.width.ideal,1920);assert.equal(c.height.ideal,1080);assert.equal(c.frameRate.ideal,30);assert.equal(c.width.max,undefined);
});
test('history redial uses recorded call kind and rejects stale, locked or selected history',async()=>{
 const s=fs.readFileSync(new URL('../web/app.js',import.meta.url),'utf8');const block=s.slice(s.indexOf('    case "redial-history":'),s.indexOf('    case "audio-call":',s.indexOf('    case "redial-history":')));
 for(const video of [true,false])for(const mode of ['allowed','locked','selected','wrong-room','not-call']){
  const calls=[],state={page:'chat',room:{id:'room'},selected:new Set(mode==='selected'?['message']:[])};
  const record={room:mode==='wrong-room'?'other':'room',callRecord:mode!=='not-call',payload:{history:{video}}};
  const ctx={state,isLocked:()=>mode==='locked',eligibleMessage:()=>record,startCall:async v=>calls.push(v)};vm.createContext(ctx);
  await vm.runInContext('(async()=>{const el={dataset:{id:"record"}};switch("redial-history"){'+block+'}})()',ctx);
  assert.deepEqual(calls,mode==='allowed'?[video]:[]);
 }
});
