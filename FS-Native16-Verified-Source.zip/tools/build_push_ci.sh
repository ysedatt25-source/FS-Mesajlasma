#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${ANDROID_HOME:?Android SDK required}"
: "${FS_FCM_PROJECT:?Set Firebase project ID in CircleCI}"
: "${FS_GOOGLE_SERVICES_JSON_B64:?Set base64 Android client configuration in CircleCI}"
# Do not pass service account credentials to the Android build job.
if [[ -n "${FS_FCM_SERVICE_ACCOUNT_JSON:-}" ]]; then
  echo 'Server credentials must never be configured in the Android CI job.' >&2
  exit 1
fi
python3 tools/prepare_push_build.py
trap 'rm -f android/app/src/push/google-services.json' EXIT
unset FS_GOOGLE_SERVICES_JSON_B64
# Gradle 8.9: independently pinned official distribution checksum.
tmp="$(mktemp -d)"
trap 'rm -f android/app/src/push/google-services.json; rm -rf "$tmp"' EXIT
curl --fail --location --retry 3 -o "$tmp/gradle.zip" https://services.gradle.org/distributions/gradle-8.9-bin.zip
printf '%s  %s\n' d725d707bfabd4dfdc958c624003b3c80accc03f7037b5122c4b1d0ef15cecab "$tmp/gradle.zip" | sha256sum -c -
unzip -q "$tmp/gradle.zip" -d "$tmp"
sdkmanager 'platforms;android-35' 'build-tools;35.0.0'
"$tmp/gradle-8.9/bin/gradle" --project-dir android --no-daemon -PfsPush :app:assemblePushRelease
mkdir -p build/ci
apk=android/app/build/outputs/apk/push/release/app-push-release-unsigned.apk
python3 tools/verify_push_apk.py "$apk" "$ANDROID_HOME/build-tools/35.0.0/aapt"
"$ANDROID_HOME/build-tools/35.0.0/zipalign" -c -P 16 4 "$apk"
cp "$apk" build/ci/FS-Mesajlasma-34.32-native16-push-unsigned.apk
sha256sum build/ci/FS-Mesajlasma-34.32-native16-push-unsigned.apk > build/ci/SHA256SUMS.txt
