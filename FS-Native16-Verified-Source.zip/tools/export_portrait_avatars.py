"""Export the original 4x4 fictional portrait master to the stable avatar IDs."""
import base64,io,json
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
def main():
    target=ROOT/'web/profile-avatars.js';text=target.read_text()
    rows,_=json.JSONDecoder().raw_decode(text[text.index('[',text.index('Object.freeze')):])
    if len(rows)!=16:raise ValueError('Expected existing 16 avatar identities')
    image=Image.open(ROOT/'design/portrait-avatars.png').convert('RGB');w,h=image.size
    if w!=h or w<1024:raise ValueError('Expected square 4x4 portrait master')
    for row,index in zip(rows,[0,2,5,7,9,11,12,14,1,3,4,6,8,10,13,15]):
        x,y=index%4,index//4
        tile=image.crop((round(x*w/4),round(y*h/4),round((x+1)*w/4),round((y+1)*h/4))).resize((512,512),Image.Resampling.LANCZOS)
        output=io.BytesIO();tile.save(output,format='JPEG',quality=88,optimize=True)
        row['photo']='data:image/jpeg;base64,'+base64.b64encode(output.getvalue()).decode()
    target.write_text('// Original AI-generated fictional adult portrait avatars; no external requests.\nexport const PROFILE_AVATARS = Object.freeze('+json.dumps(rows,separators=(',',':'),ensure_ascii=False)+'.map(Object.freeze));\nexport function profileAvatar(id) { return PROFILE_AVATARS.find(a=>a.id===id) || null; }\n')
if __name__=='__main__':main()
